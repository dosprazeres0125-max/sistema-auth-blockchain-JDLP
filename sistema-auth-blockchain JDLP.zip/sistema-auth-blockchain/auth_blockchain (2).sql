-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 08-Fev-2026 às 18:48
-- Versão do servidor: 10.4.32-MariaDB
-- versão do PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `auth_blockchain`
--

DELIMITER $$
--
-- Procedimentos
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `criar_novo_bloco` ()   BEGIN
    DECLARE last_block_hash VARCHAR(128);
    DECLARE merkle_root VARCHAR(128);
    DECLARE new_block_hash VARCHAR(128);
    DECLARE nonce_val BIGINT DEFAULT 0;
    DECLARE difficulty_val INT DEFAULT 1;
    DECLARE timestamp_val BIGINT;
    DECLARE found_hash BOOLEAN DEFAULT FALSE;
    
    -- Obter hash do último bloco
    SELECT bloco_hash INTO last_block_hash
    FROM blocos_blockchain 
    ORDER BY id_bloco DESC 
    LIMIT 1;
    
    -- Calcular Merkle Root das últimas transações
    SELECT SHA2(GROUP_CONCAT(hash_transacao ORDER BY id_evento), 256) INTO merkle_root
    FROM registro_eventos 
    WHERE bloco_hash = last_block_hash;
    
    -- Se não houver transações, usar hash padrão
    IF merkle_root IS NULL THEN
        SET merkle_root = SHA2('empty', 256);
    END IF;
    
    SET timestamp_val = UNIX_TIMESTAMP();
    
    -- Simulação de mineração (Proof of Work simples)
    mining_loop: WHILE NOT found_hash DO
        SET new_block_hash = SHA2(CONCAT(last_block_hash, merkle_root, nonce_val, timestamp_val), 256);
        
        -- Verificar se o hash atende à dificuldade (começar com '00')
        IF LEFT(new_block_hash, 2) = '00' THEN
            SET found_hash = TRUE;
        ELSE
            SET nonce_val = nonce_val + 1;
        END IF;
        
        -- Limite de tentativas para evitar loop infinito
        IF nonce_val > 1000000 THEN
            INSERT INTO logs_seguranca (tipo_log, severidade, descricao) 
            VALUES ('blockchain_mineracao', 'alta', 'Não foi possível minerar novo bloco');
            LEAVE mining_loop;
        END IF;
    END WHILE mining_loop;
    
    -- Inserir novo bloco se encontrou hash válido
    IF found_hash THEN
        INSERT INTO blocos_blockchain (
            bloco_hash,
            bloco_hash_anterior,
            hash_merkle_root,
            nonce,
            dificuldade,
            timestamp_criacao,
            numero_transacoes
        ) VALUES (
            new_block_hash,
            last_block_hash,
            merkle_root,
            nonce_val,
            difficulty_val,
            timestamp_val,
            (SELECT COUNT(*) FROM registro_eventos WHERE bloco_hash = last_block_hash)
        );
        
        INSERT INTO logs_seguranca (tipo_log, severidade, descricao) 
        VALUES ('blockchain_novo_bloco', 'media', CONCAT('Novo bloco criado: ', LEFT(new_block_hash, 16), '...'));
    END IF;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `limpar_sessoes_expiradas` ()   BEGIN
    DECLARE sessions_deleted INT;
    
    DELETE FROM sessoes_ativas WHERE expiracao < NOW();
    
    SET sessions_deleted = ROW_COUNT();
    
    IF sessions_deleted > 0 THEN
        INSERT INTO logs_seguranca (tipo_log, severidade, descricao) 
        VALUES ('limpeza_sessoes', 'baixa', CONCAT('Sessões expiradas removidas: ', sessions_deleted));
    END IF;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `registrar_evento_login` (IN `p_tipo_evento` VARCHAR(60), IN `p_id_usuario` INT, IN `p_email` VARCHAR(255), IN `p_ip_origem` VARCHAR(45), IN `p_user_agent` VARCHAR(280))   BEGIN
    DECLARE v_hash_transacao VARCHAR(128);
    DECLARE v_hash_conteudo VARCHAR(128);
    DECLARE v_hash_anterior VARCHAR(128);
    DECLARE v_timestamp BIGINT;
    DECLARE v_bloco_hash VARCHAR(128);
    DECLARE v_bloco_numero BIGINT;
    DECLARE v_email_hash VARCHAR(128);
    
    -- Gerar timestamp
    SET v_timestamp = UNIX_TIMESTAMP();
    
    -- Hash do email
    SET v_email_hash = SHA2(p_email, 256);
    
    -- Hash do conteúdo (inclui o email para maior integridade)
    SET v_hash_conteudo = SHA2(CONCAT(p_tipo_evento, COALESCE(p_id_usuario, 0), p_email, v_timestamp, p_ip_origem), 256);
    
    -- Último hash anterior
    SELECT hash_transacao INTO v_hash_anterior
    FROM registro_eventos 
    ORDER BY id_evento DESC 
    LIMIT 1;
    
    -- Hash da transação
    SET v_hash_transacao = SHA2(CONCAT(v_hash_conteudo, COALESCE(v_hash_anterior, '0'), v_timestamp), 256);
    
    -- Bloco atual
    SELECT bloco_hash, id_bloco INTO v_bloco_hash, v_bloco_numero
    FROM blocos_blockchain 
    ORDER BY id_bloco DESC 
    LIMIT 1;
    
    -- Inserir o evento – AGORA INCLUI email_informado
    INSERT INTO registro_eventos (
        tipo_evento,
        id_usuario,
        email_hash,
        email_informado,           -- ← Campo novo sendo preenchido
        ip_origem,
        user_agent,
        hash_transacao,
        hash_conteudo,
        hash_anterior,
        bloco_hash,
        bloco_numero,
        timestamp,
        data_hora
    ) VALUES (
        p_tipo_evento,
        p_id_usuario,
        v_email_hash,
        p_email,                   -- ← Email original aqui
        p_ip_origem,
        p_user_agent,
        v_hash_transacao,
        v_hash_conteudo,
        v_hash_anterior,
        v_bloco_hash,
        v_bloco_numero,
        v_timestamp,
        NOW()
    );
    
    -- Atualizar contador do bloco
    UPDATE blocos_blockchain 
    SET numero_transacoes = numero_transacoes + 1 
    WHERE bloco_hash = v_bloco_hash;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `verificar_integridade_blockchain` ()   BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE current_hash VARCHAR(128);
    DECLARE previous_hash VARCHAR(128);
    DECLARE expected_hash VARCHAR(128);
    DECLARE event_id BIGINT;
    DECLARE cur CURSOR FOR 
        SELECT id_evento, hash_transacao, hash_anterior 
        FROM registro_eventos 
        ORDER BY id_evento;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
    
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        INSERT INTO logs_seguranca (tipo_log, severidade, descricao) 
        VALUES ('blockchain_integridade', 'alta', 'Erro na verificação de integridade da blockchain');
    END;
    
    OPEN cur;
    
    read_loop: LOOP
        FETCH cur INTO event_id, current_hash, previous_hash;
        IF done THEN
            LEAVE read_loop;
        END IF;
        
        -- Verificar hash anterior (exceto para o primeiro evento)
        IF previous_hash IS NOT NULL THEN
            SELECT hash_transacao INTO expected_hash
            FROM registro_eventos 
            WHERE hash_transacao = previous_hash;
            
            IF expected_hash IS NULL THEN
                INSERT INTO logs_seguranca (tipo_log, severidade, descricao) 
                VALUES ('blockchain_corrompida', 'critica', CONCAT('Bloco corrompido encontrado: ', event_id));
            END IF;
        END IF;
    END LOOP;
    
    CLOSE cur;
    
    INSERT INTO logs_seguranca (tipo_log, severidade, descricao) 
    VALUES ('blockchain_integridade', 'baixa', 'Verificação de integridade concluída com sucesso');
END$$

--
-- Funções
--
CREATE DEFINER=`root`@`localhost` FUNCTION `gerar_hash_transacao` (`tipo_evento` VARCHAR(60), `id_usuario` INT, `timestamp_val` BIGINT) RETURNS VARCHAR(128) CHARSET utf8mb4 COLLATE utf8mb4_general_ci DETERMINISTIC BEGIN
    DECLARE hash_result VARCHAR(128);
    SET hash_result = SHA2(CONCAT(tipo_evento, COALESCE(id_usuario, 0), timestamp_val, RAND()), 256);
    RETURN hash_result;
END$$

CREATE DEFINER=`root`@`localhost` FUNCTION `verificar_usuario_bloqueado` (`id_usuario_param` INT) RETURNS TINYINT(1) READS SQL DATA BEGIN
    DECLARE bloqueado_ate_val DATETIME;
    DECLARE is_bloqueado BOOLEAN DEFAULT FALSE;
    
    SELECT bloqueado_ate INTO bloqueado_ate_val
    FROM usuarios 
    WHERE id_usuario = id_usuario_param;
    
    IF bloqueado_ate_val IS NOT NULL AND bloqueado_ate_val > NOW() THEN
        SET is_bloqueado = TRUE;
    END IF;
    
    RETURN is_bloqueado;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Estrutura da tabela `auditoria_acessos`
--

CREATE TABLE `auditoria_acessos` (
  `id_auditoria` bigint(20) UNSIGNED NOT NULL,
  `id_usuario` int(10) UNSIGNED DEFAULT NULL,
  `id_auditor` int(10) UNSIGNED DEFAULT NULL,
  `tipo_acao` varchar(50) NOT NULL,
  `entidade` varchar(50) NOT NULL,
  `id_entidade` bigint(20) UNSIGNED DEFAULT NULL,
  `dados_anteriores` text DEFAULT NULL,
  `dados_novos` text DEFAULT NULL,
  `ip_origem` varchar(45) NOT NULL,
  `user_agent` varchar(280) DEFAULT NULL,
  `hash_transacao` varchar(128) NOT NULL,
  `data_hora` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `backup_codigos_mfa`
--

CREATE TABLE `backup_codigos_mfa` (
  `id_backup` bigint(20) UNSIGNED NOT NULL,
  `id_usuario` int(10) UNSIGNED NOT NULL,
  `codigo_hash` varchar(255) NOT NULL,
  `data_criacao` datetime NOT NULL DEFAULT current_timestamp(),
  `data_expiracao` datetime NOT NULL,
  `utilizado` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `blocos_blockchain`
--

CREATE TABLE `blocos_blockchain` (
  `id_bloco` bigint(20) UNSIGNED NOT NULL,
  `bloco_hash` varchar(128) NOT NULL,
  `bloco_hash_anterior` varchar(128) DEFAULT NULL,
  `hash_merkle_root` varchar(128) NOT NULL,
  `nonce` bigint(20) UNSIGNED NOT NULL,
  `dificuldade` int(11) NOT NULL DEFAULT 1,
  `timestamp_criacao` bigint(20) UNSIGNED NOT NULL,
  `numero_transacoes` int(11) NOT NULL DEFAULT 0,
  `dados_bloco` text DEFAULT NULL,
  `assinatura_digital` text DEFAULT NULL,
  `data_hora` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `blocos_blockchain`
--

INSERT INTO `blocos_blockchain` (`id_bloco`, `bloco_hash`, `bloco_hash_anterior`, `hash_merkle_root`, `nonce`, `dificuldade`, `timestamp_criacao`, `numero_transacoes`, `dados_bloco`, `assinatura_digital`, `data_hora`) VALUES
(1, '0000000000000000000000000000000000000000000000000000000000000000', NULL, '0000000000000000000000000000000000000000000000000000000000000000', 0, 1, 1769084674, 0, '{\"descricao\": \"Bloco Gênesis do Sistema\", \"criador\": \"Sistema\", \"timestamp\": UNIX_TIMESTAMP(), \"versao\": \"1.0.0\"}', NULL, '2026-01-22 13:24:34');

-- --------------------------------------------------------

--
-- Estrutura da tabela `chaves_criptografia`
--

CREATE TABLE `chaves_criptografia` (
  `id_chave` bigint(20) UNSIGNED NOT NULL,
  `id_usuario` int(10) UNSIGNED NOT NULL,
  `tipo_chave` enum('publica','privada','sessao') NOT NULL,
  `chave_criptografada` text NOT NULL,
  `chave_hash` varchar(128) NOT NULL,
  `data_criacao` datetime NOT NULL DEFAULT current_timestamp(),
  `data_expiracao` datetime DEFAULT NULL,
  `ativa` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `codigos_verificacao_mfa`
--

CREATE TABLE `codigos_verificacao_mfa` (
  `id` int(10) UNSIGNED NOT NULL,
  `id_usuario` int(10) UNSIGNED NOT NULL,
  `codigo_verificacao` varchar(6) NOT NULL,
  `metodo` enum('email','sms') NOT NULL,
  `data_criacao` datetime DEFAULT current_timestamp(),
  `expiracao` datetime NOT NULL,
  `utilizado` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `configuracoes_sistema`
--

CREATE TABLE `configuracoes_sistema` (
  `id_configuracao` int(10) UNSIGNED NOT NULL,
  `chave` varchar(100) NOT NULL,
  `valor` text DEFAULT NULL,
  `descricao` varchar(255) DEFAULT NULL,
  `categoria` varchar(50) DEFAULT NULL,
  `data_atualizacao` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `configuracoes_sistema`
--

INSERT INTO `configuracoes_sistema` (`id_configuracao`, `chave`, `valor`, `descricao`, `categoria`, `data_atualizacao`) VALUES
(1, 'tempo_expiracao_sessao', '1800', 'Tempo de expiração da sessão em segundos (30 minutos)', 'seguranca', '2026-01-22 13:24:33'),
(2, 'max_tentativas_login', '5', 'Máximo de tentativas de login falhas antes do bloqueio', 'seguranca', '2026-01-22 13:24:33'),
(3, 'tempo_bloqueio_login', '900', 'Tempo de bloqueio após tentativas falhas em segundos (15 minutos)', 'seguranca', '2026-01-22 13:24:33'),
(4, 'tamanho_minimo_senha', '8', 'Tamanho mínimo para senhas', 'seguranca', '2026-01-22 13:24:33'),
(5, 'requer_senha_forte', '1', 'Requer senha forte (letras, números, caracteres especiais)', 'seguranca', '2026-01-22 13:24:33'),
(6, 'requer_mfa_admin', '1', 'Requer MFA para administradores', 'seguranca', '2026-01-22 13:24:33'),
(7, 'manter_logs_dias', '90', 'Dias para manter logs no sistema', 'auditoria', '2026-01-22 13:24:33'),
(8, 'fuso_horario', 'America/Sao_Paulo', 'Fuso horário do sistema', 'sistema', '2026-01-22 13:24:33'),
(9, 'nome_sistema', 'Sistema Auth Blockchain', 'Nome do sistema', 'sistema', '2026-01-22 13:24:33'),
(10, 'versao_sistema', '2.0.0', 'Versão do sistema', 'sistema', '2026-01-22 13:24:33'),
(11, 'criptografia_pontaa_ponto', '1', 'Habilitar criptografia de ponta a ponta', 'seguranca', '2026-01-22 13:24:33'),
(12, 'blockchain_habilitado', '1', 'Habilitar registro em blockchain', 'sistema', '2026-01-22 13:24:33'),
(13, 'mfa_obrigatorio', '0', 'MFA obrigatório para todos os usuários', 'seguranca', '2026-01-22 13:24:33'),
(14, 'auditoria_tempo_real', '1', 'Habilitar auditoria em tempo real', 'auditoria', '2026-01-22 13:24:33');

-- --------------------------------------------------------

--
-- Estrutura da tabela `logs_seguranca`
--

CREATE TABLE `logs_seguranca` (
  `id_log` bigint(20) UNSIGNED NOT NULL,
  `tipo_log` varchar(50) NOT NULL,
  `id_usuario` int(10) UNSIGNED DEFAULT NULL,
  `severidade` enum('baixa','media','alta','critica') DEFAULT 'media',
  `descricao` text NOT NULL,
  `ip_origem` varchar(45) DEFAULT NULL,
  `user_agent` varchar(280) DEFAULT NULL,
  `dados_adicionais` text DEFAULT NULL,
  `data_hora` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `logs_seguranca`
--

INSERT INTO `logs_seguranca` (`id_log`, `tipo_log`, `id_usuario`, `severidade`, `descricao`, `ip_origem`, `user_agent`, `dados_adicionais`, `data_hora`) VALUES
(1, 'blockchain_integridade', NULL, 'alta', 'Erro na verificação de integridade da blockchain', NULL, NULL, NULL, '2026-02-08 12:40:13'),
(2, 'blockchain_integridade', NULL, 'alta', 'Erro na verificação de integridade da blockchain', NULL, NULL, NULL, '2026-02-08 12:47:32'),
(3, 'blockchain_integridade', NULL, 'alta', 'Erro na verificação de integridade da blockchain', NULL, NULL, NULL, '2026-02-08 12:47:37'),
(4, 'blockchain_integridade', NULL, 'alta', 'Erro na verificação de integridade da blockchain', NULL, NULL, NULL, '2026-02-08 12:47:40'),
(5, 'blockchain_integridade', NULL, 'alta', 'Erro na verificação de integridade da blockchain', NULL, NULL, NULL, '2026-02-08 13:32:00'),
(6, 'falha_registro_evento', NULL, 'alta', 'Falha ao registrar evento LOGIN_ATTEMPT - Email: uis@gmail.com - Erro: SQLSTATE[HY000]: General error: 1267 Illegal mix of collations (utf8mb4_unicode_ci,IMPLICIT) and (utf8mb4_general_ci,IMPLICIT) for operation \'=\'', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', NULL, '2026-02-08 14:05:40'),
(7, 'falha_registro_evento', NULL, 'alta', 'Falha ao registrar evento LOGIN_FAILED_USER_NOT_FOUND - Email: uis@gmail.com - Erro: SQLSTATE[HY000]: General error: 1267 Illegal mix of collations (utf8mb4_unicode_ci,IMPLICIT) and (utf8mb4_general_ci,IMPLICIT) for operation \'=\'', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', NULL, '2026-02-08 14:05:40'),
(8, 'falha_registro_evento', NULL, 'alta', 'Falha ao registrar evento LOGIN_ATTEMPT - Email: uis@gmail.com - Erro: SQLSTATE[HY000]: General error: 1267 Illegal mix of collations (utf8mb4_unicode_ci,IMPLICIT) and (utf8mb4_general_ci,IMPLICIT) for operation \'=\'', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', NULL, '2026-02-08 14:11:33'),
(9, 'falha_registro_evento', NULL, 'alta', 'Falha ao registrar evento LOGIN_FAILED_USER_NOT_FOUND - Email: uis@gmail.com - Erro: SQLSTATE[HY000]: General error: 1267 Illegal mix of collations (utf8mb4_unicode_ci,IMPLICIT) and (utf8mb4_general_ci,IMPLICIT) for operation \'=\'', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', NULL, '2026-02-08 14:11:33'),
(10, 'falha_registro_evento', NULL, 'alta', 'Falha ao registrar evento LOGIN_ATTEMPT - Email: lis@gmail.com - Erro: SQLSTATE[HY000]: General error: 1267 Illegal mix of collations (utf8mb4_unicode_ci,IMPLICIT) and (utf8mb4_general_ci,IMPLICIT) for operation \'=\'', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', NULL, '2026-02-08 14:11:42'),
(11, 'falha_registro_evento', NULL, 'alta', 'Falha ao registrar evento LOGIN_FAILED_USER_NOT_FOUND - Email: lis@gmail.com - Erro: SQLSTATE[HY000]: General error: 1267 Illegal mix of collations (utf8mb4_unicode_ci,IMPLICIT) and (utf8mb4_general_ci,IMPLICIT) for operation \'=\'', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', NULL, '2026-02-08 14:11:42'),
(12, 'falha_registro_evento', NULL, 'alta', 'Falha ao registrar evento LOGIN_ATTEMPT - Email: lis@gmail.com - Erro: SQLSTATE[HY000]: General error: 1267 Illegal mix of collations (utf8mb4_unicode_ci,IMPLICIT) and (utf8mb4_general_ci,IMPLICIT) for operation \'=\'', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', NULL, '2026-02-08 14:12:59'),
(13, 'falha_registro_evento', NULL, 'alta', 'Falha ao registrar evento LOGIN_FAILED_USER_NOT_FOUND - Email: lis@gmail.com - Erro: SQLSTATE[HY000]: General error: 1267 Illegal mix of collations (utf8mb4_unicode_ci,IMPLICIT) and (utf8mb4_general_ci,IMPLICIT) for operation \'=\'', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', NULL, '2026-02-08 14:13:00'),
(14, 'falha_registro_evento', NULL, 'alta', 'Falha ao registrar evento LOGIN_ATTEMPT - Email: luis@gmail.com - Erro: SQLSTATE[HY000]: General error: 1267 Illegal mix of collations (utf8mb4_unicode_ci,IMPLICIT) and (utf8mb4_general_ci,IMPLICIT) for operation \'=\'', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', NULL, '2026-02-08 14:13:35'),
(15, 'falha_registro_evento', NULL, 'alta', 'Falha ao registrar evento LOGIN_SUCCESS - Email: luis@gmail.com - Erro: SQLSTATE[HY000]: General error: 1267 Illegal mix of collations (utf8mb4_unicode_ci,IMPLICIT) and (utf8mb4_general_ci,IMPLICIT) for operation \'=\'', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', NULL, '2026-02-08 14:13:36'),
(16, 'falha_registro_evento', NULL, 'alta', 'Falha ao registrar evento LOGOUT - Email: luis@gmail.com - Erro: SQLSTATE[HY000]: General error: 1267 Illegal mix of collations (utf8mb4_unicode_ci,IMPLICIT) and (utf8mb4_general_ci,IMPLICIT) for operation \'=\'', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', NULL, '2026-02-08 14:19:05'),
(17, 'falha_registro_evento', NULL, 'alta', 'Falha ao registrar evento TENTATIVA_LOGIN - Email: luis@gmail.com - Erro: SQLSTATE[HY000]: General error: 1267 Illegal mix of collations (utf8mb4_unicode_ci,IMPLICIT) and (utf8mb4_general_ci,IMPLICIT) for operation \'=\'', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', NULL, '2026-02-08 14:19:22'),
(18, 'falha_registro_evento', NULL, 'alta', 'Falha ao registrar evento LOGIN_SUCESSO - Email: luis@gmail.com - Erro: SQLSTATE[HY000]: General error: 1267 Illegal mix of collations (utf8mb4_unicode_ci,IMPLICIT) and (utf8mb4_general_ci,IMPLICIT) for operation \'=\'', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', NULL, '2026-02-08 14:19:23'),
(19, 'falha_registro_evento', NULL, 'alta', 'Falha ao registrar evento LOGOUT - Email: luis@gmail.com - Erro: SQLSTATE[HY000]: General error: 1267 Illegal mix of collations (utf8mb4_unicode_ci,IMPLICIT) and (utf8mb4_general_ci,IMPLICIT) for operation \'=\'', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', NULL, '2026-02-08 14:21:24'),
(20, 'falha_registro_evento', NULL, 'alta', 'Falha ao registrar evento TENTATIVA_LOGIN - Email: luis@gmail.co - Erro: SQLSTATE[HY000]: General error: 1267 Illegal mix of collations (utf8mb4_unicode_ci,IMPLICIT) and (utf8mb4_general_ci,IMPLICIT) for operation \'=\'', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', NULL, '2026-02-08 14:21:37'),
(21, 'falha_registro_evento', NULL, 'alta', 'Falha ao registrar evento LOGIN_FALHO_USUARIO_NAO_ENCONTRADO - Email: luis@gmail.co - Erro: SQLSTATE[HY000]: General error: 1267 Illegal mix of collations (utf8mb4_unicode_ci,IMPLICIT) and (utf8mb4_general_ci,IMPLICIT) for operation \'=\'', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', NULL, '2026-02-08 14:21:37'),
(22, 'falha_registro_evento', NULL, 'alta', 'Falha ao registrar evento TENTATIVA_LOGIN - Email: luis@gmail.com - Erro: SQLSTATE[HY000]: General error: 1267 Illegal mix of collations (utf8mb4_unicode_ci,IMPLICIT) and (utf8mb4_general_ci,IMPLICIT) for operation \'=\'', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', NULL, '2026-02-08 14:21:44'),
(23, 'falha_registro_evento', NULL, 'alta', 'Falha ao registrar evento LOGIN_SUCESSO - Email: luis@gmail.com - Erro: SQLSTATE[HY000]: General error: 1267 Illegal mix of collations (utf8mb4_unicode_ci,IMPLICIT) and (utf8mb4_general_ci,IMPLICIT) for operation \'=\'', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', NULL, '2026-02-08 14:21:45'),
(24, 'falha_registro_evento', NULL, 'alta', 'Falha ao registrar evento LOGOUT - Email: luis@gmail.com - Erro: SQLSTATE[HY000]: General error: 1267 Illegal mix of collations (utf8mb4_unicode_ci,IMPLICIT) and (utf8mb4_general_ci,IMPLICIT) for operation \'=\'', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', NULL, '2026-02-08 14:24:11'),
(25, 'falha_registro_evento', NULL, 'alta', 'Falha ao registrar evento TENTATIVA_LOGIN - Email: luis@gmail.com - Erro: SQLSTATE[HY000]: General error: 1267 Illegal mix of collations (utf8mb4_unicode_ci,IMPLICIT) and (utf8mb4_general_ci,IMPLICIT) for operation \'=\'', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', NULL, '2026-02-08 14:26:47'),
(26, 'falha_registro_evento', NULL, 'alta', 'Falha ao registrar evento TENTATIVA_LOGIN - Email: luis@gmail.com - Erro: SQLSTATE[HY000]: General error: 1267 Illegal mix of collations (utf8mb4_unicode_ci,IMPLICIT) and (utf8mb4_general_ci,IMPLICIT) for operation \'=\'', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', NULL, '2026-02-08 14:26:51'),
(27, 'falha_registro_evento', NULL, 'alta', 'Falha ao registrar evento LOGIN_SUCESSO - Email: luis@gmail.com - Erro: SQLSTATE[HY000]: General error: 1267 Illegal mix of collations (utf8mb4_unicode_ci,IMPLICIT) and (utf8mb4_general_ci,IMPLICIT) for operation \'=\'', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', NULL, '2026-02-08 14:26:52');

-- --------------------------------------------------------

--
-- Estrutura da tabela `notificacoes_sistema`
--

CREATE TABLE `notificacoes_sistema` (
  `id_notificacao` bigint(20) UNSIGNED NOT NULL,
  `id_usuario` int(10) UNSIGNED DEFAULT NULL,
  `tipo_notificacao` varchar(50) NOT NULL,
  `titulo` varchar(255) NOT NULL,
  `mensagem` text DEFAULT NULL,
  `lida` tinyint(1) DEFAULT 0,
  `data_criacao` datetime NOT NULL DEFAULT current_timestamp(),
  `data_leitura` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura da tabela `perfis_acesso`
--

CREATE TABLE `perfis_acesso` (
  `id_perfil` int(10) UNSIGNED NOT NULL,
  `nome_perfil` varchar(100) NOT NULL,
  `descricao` varchar(255) DEFAULT NULL,
  `permissoes` text DEFAULT NULL,
  `data_criacao` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `perfis_acesso`
--

INSERT INTO `perfis_acesso` (`id_perfil`, `nome_perfil`, `descricao`, `permissoes`, `data_criacao`) VALUES
(1, 'user', 'Usuário Comum', '{\"dashboard\": [\"ver\"], \"meuperfil\": [\"ver\", \"editar\"], \"mfa\": [\"ver\", \"gerenciar\"], \"sessoes\": [\"ver\", \"gerenciar\"]}', '2026-01-22 13:24:33'),
(2, 'auditor', 'Auditor de Sistema', '{\"dashboard\": [\"ver\"], \"eventos\": [\"ver\", \"exportar\", \"analisar\"], \"auditoria\": [\"ver\", \"analisar\", \"gerar_relatorios\"], \"relatorios\": [\"ver\", \"gerar\"], \"meuperfil\": [\"ver\", \"editar\"], \"mfa\": [\"ver\", \"gerenciar\"], \"sessoes\": [\"ver\", \"gerenciar\"], \"logs\": [\"ver\"]}', '2026-01-22 13:24:33'),
(3, 'admin', 'Administrador do Sistema', '{\"dashboard\": [\"ver\"], \"usuarios\": [\"ver\", \"criar\", \"editar\", \"excluir\", \"bloquear\", \"desbloquear\"], \"eventos\": [\"ver\", \"exportar\", \"analisar\", \"auditar\"], \"auditoria\": [\"ver\", \"analisar\", \"gerar_relatorios\"], \"relatorios\": [\"ver\", \"gerar\", \"exportar\"], \"configuracoes\": [\"ver\", \"editar\", \"resetar\"], \"meuperfil\": [\"ver\", \"editar\"], \"mfa\": [\"ver\", \"gerenciar\", \"configurar\"], \"sessoes\": [\"ver\", \"gerenciar\", \"revogar\"], \"logs\": [\"ver\", \"analisar\", \"limpar\"], \"seguranca\": [\"ver\", \"configurar\", \"auditar\"], \"blockchain\": [\"ver\", \"auditar\", \"manter\"]}', '2026-01-22 13:24:33');

-- --------------------------------------------------------

--
-- Estrutura da tabela `registro_eventos`
--

CREATE TABLE `registro_eventos` (
  `id_evento` bigint(20) UNSIGNED NOT NULL,
  `tipo_evento` varchar(60) NOT NULL,
  `id_usuario` int(10) UNSIGNED DEFAULT NULL,
  `email_hash` varchar(128) DEFAULT NULL,
  `email_informado` varchar(255) DEFAULT NULL,
  `ip_origem` varchar(45) NOT NULL,
  `user_agent` varchar(280) DEFAULT NULL,
  `hash_transacao` varchar(128) NOT NULL,
  `hash_conteudo` varchar(128) NOT NULL,
  `hash_anterior` varchar(128) DEFAULT NULL,
  `hash_seguinte` varchar(128) DEFAULT NULL,
  `bloco_numero` bigint(20) UNSIGNED DEFAULT NULL,
  `bloco_hash` varchar(128) DEFAULT NULL,
  `timestamp` bigint(20) UNSIGNED NOT NULL,
  `dados_auditoria` text DEFAULT NULL,
  `data_hora` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `registro_eventos`
--

INSERT INTO `registro_eventos` (`id_evento`, `tipo_evento`, `id_usuario`, `email_hash`, `email_informado`, `ip_origem`, `user_agent`, `hash_transacao`, `hash_conteudo`, `hash_anterior`, `hash_seguinte`, `bloco_numero`, `bloco_hash`, `timestamp`, `dados_auditoria`, `data_hora`) VALUES
(64, 'LOGIN_ATTEMPT', NULL, 'eccc9f52998143eb03b41fffba200aa34bf91e41ebf145729d42c8af1d5d1d5c', 'lis@gmail.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', '635f4bb0aefde91d61dac3da808048befe801a7ce391c6bc4159f41497ac6612', '601b68a79fa3df5cc5e5aaad3e655c4b98e19d4c8a55eaa660f9c331c329d454', NULL, NULL, 1, '0000000000000000000000000000000000000000000000000000000000000000', 1770570779, NULL, '2026-02-08 14:12:59'),
(65, 'LOGIN_FAILED_USER_NOT_FOUND', NULL, 'eccc9f52998143eb03b41fffba200aa34bf91e41ebf145729d42c8af1d5d1d5c', 'lis@gmail.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', '2713066be46b38ebfd83368ed350b00f3fd62ffbc54cc6ebb2c78d60dde054c1', '4044f0b80c707b06f175234e50874b64da332c8e719b69f316cfa4eb1b07f10b', '635f4bb0aefde91d61dac3da808048befe801a7ce391c6bc4159f41497ac6612', NULL, 1, '0000000000000000000000000000000000000000000000000000000000000000', 1770570779, NULL, '2026-02-08 14:12:59'),
(66, 'LOGIN_ATTEMPT', NULL, '339e317955ab3368d6fa027e0a5515a7d255bc86dbc78f715cdd6d264355110a', 'luis@gmail.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', '067146fbac455639f2ea3c9e1fde8c990c105313117cc72adfb4d28b87f84c89', '6c0a823141781eed65bed7442941cd59f3f70ec1b1836d15b889c0055bb94bbf', '2713066be46b38ebfd83368ed350b00f3fd62ffbc54cc6ebb2c78d60dde054c1', NULL, 1, '0000000000000000000000000000000000000000000000000000000000000000', 1770570815, NULL, '2026-02-08 14:13:35'),
(67, 'LOGIN_SUCCESS', 3, '339e317955ab3368d6fa027e0a5515a7d255bc86dbc78f715cdd6d264355110a', 'luis@gmail.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', '74248942c6899a9c56c3b96586221a02e5da0f416fc52c799357ef2ec7d22680', '41d51d692f498a77c0e289f7559bc9942a20c9badb6c2913979f4b8a042ebb93', '067146fbac455639f2ea3c9e1fde8c990c105313117cc72adfb4d28b87f84c89', NULL, 1, '0000000000000000000000000000000000000000000000000000000000000000', 1770570816, NULL, '2026-02-08 14:13:36'),
(68, 'LOGOUT', 3, '339e317955ab3368d6fa027e0a5515a7d255bc86dbc78f715cdd6d264355110a', 'luis@gmail.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', 'c351077d39124b33e9e3a2b0ab1af8681ae27ffcb06e56d01aeb23f1daf1b234', 'd25970d6498930cf57b1bc17ae95479092360a7403fb70bba5ca65d8958e3d2f', '74248942c6899a9c56c3b96586221a02e5da0f416fc52c799357ef2ec7d22680', NULL, 1, '0000000000000000000000000000000000000000000000000000000000000000', 1770571145, NULL, '2026-02-08 14:19:05'),
(69, 'TENTATIVA_LOGIN', NULL, '339e317955ab3368d6fa027e0a5515a7d255bc86dbc78f715cdd6d264355110a', 'luis@gmail.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', '42f2208e4fa8c89cf59991242cb92d3aae80672ae315cba360712c3861cc1db5', 'aa23d257478064f6692000df9ee4c7579bed9b48c22d39fea59f007ceee5c97f', 'c351077d39124b33e9e3a2b0ab1af8681ae27ffcb06e56d01aeb23f1daf1b234', NULL, 1, '0000000000000000000000000000000000000000000000000000000000000000', 1770571162, NULL, '2026-02-08 14:19:22'),
(70, 'LOGIN_SUCESSO', 3, '339e317955ab3368d6fa027e0a5515a7d255bc86dbc78f715cdd6d264355110a', 'luis@gmail.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', '52d73d05ee4b57b0d164cf17e5faab13b4ae77e78197b005c9a5ad992854ccea', 'e69a929c2aee67aff6591f2200efd9b4ca13fe57cd2c80a8b7df5849e2498094', '42f2208e4fa8c89cf59991242cb92d3aae80672ae315cba360712c3861cc1db5', NULL, 1, '0000000000000000000000000000000000000000000000000000000000000000', 1770571163, NULL, '2026-02-08 14:19:23'),
(71, 'LOGOUT', 3, '339e317955ab3368d6fa027e0a5515a7d255bc86dbc78f715cdd6d264355110a', 'luis@gmail.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', '3c6d321be32552f0d54daea5bbdd78a46bb5b392a7109dd27b5f465a6b710fa3', 'da86563ee8d611c5834243d3669b47c8e910a96566e260857e8f4e98443acefa', '52d73d05ee4b57b0d164cf17e5faab13b4ae77e78197b005c9a5ad992854ccea', NULL, 1, '0000000000000000000000000000000000000000000000000000000000000000', 1770571284, NULL, '2026-02-08 14:21:24'),
(72, 'TENTATIVA_LOGIN', NULL, '7f6cb729601613b128712010aa0ee355c6fef72adecc8219b2536269d1566c1e', 'luis@gmail.co', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', 'edab92eb65441d79fe6f5b1cd82672a33cc06f9d1cc6be13871445ebd00bc4f4', 'd5f18113a3309d89f95fdc99d2a7021a10b8ac9f3609d35c60fe7d03471ba295', '3c6d321be32552f0d54daea5bbdd78a46bb5b392a7109dd27b5f465a6b710fa3', NULL, 1, '0000000000000000000000000000000000000000000000000000000000000000', 1770571296, NULL, '2026-02-08 14:21:36'),
(73, 'LOGIN_FALHO_USUARIO_NAO_ENCONTRADO', NULL, '7f6cb729601613b128712010aa0ee355c6fef72adecc8219b2536269d1566c1e', 'luis@gmail.co', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', '80e029d2923f8794d8749a10f644c5c358e8620d161165afcbee1b31167dd6e6', '0f05c37e6ce8346133705fa0f0ac863ffb0d7cbc06bb6021f1ce325b9b7f06dd', 'edab92eb65441d79fe6f5b1cd82672a33cc06f9d1cc6be13871445ebd00bc4f4', NULL, 1, '0000000000000000000000000000000000000000000000000000000000000000', 1770571297, NULL, '2026-02-08 14:21:37'),
(74, 'TENTATIVA_LOGIN', NULL, '339e317955ab3368d6fa027e0a5515a7d255bc86dbc78f715cdd6d264355110a', 'luis@gmail.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', '216276a81a205a3cbe9b697383da64de8c9f80691710178bd4c91d390cef10e5', '05806cc1d59591257182ea124e8258df16d544f5b966a7cd99a673aa2b7998ad', '80e029d2923f8794d8749a10f644c5c358e8620d161165afcbee1b31167dd6e6', NULL, 1, '0000000000000000000000000000000000000000000000000000000000000000', 1770571304, NULL, '2026-02-08 14:21:44'),
(75, 'LOGIN_SUCESSO', 3, '339e317955ab3368d6fa027e0a5515a7d255bc86dbc78f715cdd6d264355110a', 'luis@gmail.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', 'f7d4c4b2b9db2ed19eea1824e2caa470525b74e141b3dd34fe9e0f2057afd13b', '04e0dfdbab7359bebd777787851c688efbc2f5e2109afd0800ec236480245d7b', '216276a81a205a3cbe9b697383da64de8c9f80691710178bd4c91d390cef10e5', NULL, 1, '0000000000000000000000000000000000000000000000000000000000000000', 1770571305, NULL, '2026-02-08 14:21:45'),
(76, 'LOGOUT', 3, '339e317955ab3368d6fa027e0a5515a7d255bc86dbc78f715cdd6d264355110a', 'luis@gmail.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', 'f78f10985308e88c64feb94387989298b7deab0c24fbf4b71df9a535c6091487', '358320cec693654cfbdcb845192f53d6879c9d1d121ff9c54f581168f34a8892', 'f7d4c4b2b9db2ed19eea1824e2caa470525b74e141b3dd34fe9e0f2057afd13b', NULL, 1, '0000000000000000000000000000000000000000000000000000000000000000', 1770571451, NULL, '2026-02-08 14:24:11'),
(77, 'TENTATIVA_LOGIN', NULL, '339e317955ab3368d6fa027e0a5515a7d255bc86dbc78f715cdd6d264355110a', 'luis@gmail.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', '9748aa7e126748c246e6b6b172850b91a18904389cd6217dec03d2a4495140e7', '93171291ddf7d71005283f1b7e96314d5198a691e876009cc2c2b245e0d60bbf', 'f78f10985308e88c64feb94387989298b7deab0c24fbf4b71df9a535c6091487', NULL, 1, '0000000000000000000000000000000000000000000000000000000000000000', 1770571607, NULL, '2026-02-08 14:26:47'),
(78, 'TENTATIVA_LOGIN', NULL, '339e317955ab3368d6fa027e0a5515a7d255bc86dbc78f715cdd6d264355110a', 'luis@gmail.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', 'c9d0fd53410a4a33f4b3436c81bfc57dad4775477f3644f74e193a382446f903', '8d65c1979aae5d4b9c86fae08ee9bb8918073a98d1df372cd41a0827d4428b74', '9748aa7e126748c246e6b6b172850b91a18904389cd6217dec03d2a4495140e7', NULL, 1, '0000000000000000000000000000000000000000000000000000000000000000', 1770571611, NULL, '2026-02-08 14:26:51'),
(79, 'LOGIN_SUCESSO', 3, '339e317955ab3368d6fa027e0a5515a7d255bc86dbc78f715cdd6d264355110a', 'luis@gmail.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', 'c295678b2d556f8b34a4e5c2c53cbea0adc36d6592c603feadbaedb2ec3eade5', '0430915b11bd831b1396b183a19a837a667de90a99bdd51e75f2bcaca163dd47', 'c9d0fd53410a4a33f4b3436c81bfc57dad4775477f3644f74e193a382446f903', NULL, 1, '0000000000000000000000000000000000000000000000000000000000000000', 1770571612, NULL, '2026-02-08 14:26:52');

-- --------------------------------------------------------

--
-- Estrutura da tabela `sessoes_ativas`
--

CREATE TABLE `sessoes_ativas` (
  `id_sessao` varchar(128) NOT NULL,
  `id_usuario` int(10) UNSIGNED NOT NULL,
  `ip` varchar(45) NOT NULL,
  `user_agent` varchar(280) NOT NULL,
  `token_sessao` varchar(128) NOT NULL,
  `token_criptografia` text DEFAULT NULL,
  `data_inicio` datetime NOT NULL DEFAULT current_timestamp(),
  `data_ultima_atividade` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `expiracao` datetime NOT NULL,
  `detalhes_sessao` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Extraindo dados da tabela `sessoes_ativas`
--

INSERT INTO `sessoes_ativas` (`id_sessao`, `id_usuario`, `ip`, `user_agent`, `token_sessao`, `token_criptografia`, `data_inicio`, `data_ultima_atividade`, `expiracao`, `detalhes_sessao`) VALUES
('3ad9ce9cf69f339a50d523758f374c36a3dd6cd2ba2e04fc8bf39748e2c7693c', 3, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', '859714bcfd9d89a0b0e28e0bc93d208e85c4cc48adedb38f1719b46eafddd4f4', NULL, '2026-01-27 21:58:01', '2026-01-27 21:58:01', '2026-01-28 02:28:01', NULL),
('6f467a20a0609d190ecddf87faa68756797836726679ecd7892017537557a613', 3, '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/144.0.0.0 Safari/537.36 Edg/144.0.0.0', '798c70521226722ae85665f83aa486b6a3c2d43e5f2c141a459996b74482228e', NULL, '2026-02-08 14:26:52', '2026-02-08 14:26:52', '2026-02-08 18:56:52', NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuarios`
--

CREATE TABLE `usuarios` (
  `id_usuario` int(10) UNSIGNED NOT NULL,
  `nome_completo` varchar(120) NOT NULL,
  `email` varchar(180) NOT NULL,
  `email_hash` varchar(128) DEFAULT NULL,
  `tipo_usuario` enum('user','auditor','admin') NOT NULL DEFAULT 'user',
  `senha_hash` varchar(255) NOT NULL,
  `mfa_codigo_hash` varchar(255) DEFAULT NULL,
  `mfa_ultima_alteracao` datetime DEFAULT NULL,
  `chaves_criptografia` text DEFAULT NULL,
  `data_criacao` datetime NOT NULL DEFAULT current_timestamp(),
  `data_ultimo_login` datetime DEFAULT NULL,
  `data_ultima_atividade` datetime DEFAULT NULL,
  `tentativas_falhas` smallint(5) UNSIGNED DEFAULT 0,
  `bloqueado_ate` datetime DEFAULT NULL,
  `ultimo_ip` varchar(45) DEFAULT NULL,
  `configuracoes` text DEFAULT NULL,
  `ativo` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Extraindo dados da tabela `usuarios`
--

INSERT INTO `usuarios` (`id_usuario`, `nome_completo`, `email`, `email_hash`, `tipo_usuario`, `senha_hash`, `mfa_codigo_hash`, `mfa_ultima_alteracao`, `chaves_criptografia`, `data_criacao`, `data_ultimo_login`, `data_ultima_atividade`, `tentativas_falhas`, `bloqueado_ate`, `ultimo_ip`, `configuracoes`, `ativo`) VALUES
(2, 'Davide Muhepe', 'davide@gmail.com', 'e8be776e9c5a86984f66f6a0c4ebfd499afb818eb7d0d650504187343cfe4116', 'auditor', '$2y$10$R1Lo3pthzPdHD9Q8gCsoeu8HVnUhKGb..VxjmOOOopebPWc/Akwxi', '$2y$10$0cCqsY7GosDsx5sTlqms8ODc00vBEHd1KNsGse0KVXA5sW91wRjB.', '2026-01-22 15:32:13', NULL, '2026-01-22 15:32:13', NULL, NULL, 0, NULL, NULL, NULL, 1),
(3, 'Luís Francisco', 'luis@gmail.com', '339e317955ab3368d6fa027e0a5515a7d255bc86dbc78f715cdd6d264355110a', 'admin', '$2y$10$XpioGq3sBs6Peq8rs4JMzOmz1h1WpSo9x.9W1XPfv2uMrijz3BeqC', '$2y$10$GV3/YeU2IGARvmsuFnzo2uB7QRvWGnbySb0a0QPckJPi88LoUC.vO', '2026-02-08 10:00:05', NULL, '2026-01-22 15:32:13', '2026-02-08 14:26:52', '2026-02-08 14:26:52', 0, NULL, '::1', NULL, 1),
(4, 'Júlio Mutemeca', 'julio@gmail.com', '89387fb8e5a5d48aa1e6e88b6720f33efe347aa440bd7411165fb7a435b55fcc', 'user', '$2y$10$wvFYg9Q1eNfV99WiChuM3.hDzPACw7okHkjpbE6x7ueBRzJ0Xh55C', NULL, '2026-01-22 15:32:13', NULL, '2026-01-22 15:32:13', '2026-01-27 18:48:42', '2026-01-27 18:48:42', 0, NULL, '::1', NULL, 1),
(5, 'Antonio Pinocas', 'pinocas@gmail.com', '0ec890d21535c0bea70f77e224c86c8f81d40b202fe9433795a2265023f21cf6', 'auditor', '$2y$10$8AfKD105gReN11IjfJDYYOfAx04Dzx.QtywWh5XWNGkyvK0I0NAxm', NULL, '2026-01-22 15:32:14', NULL, '2026-01-22 15:32:14', NULL, NULL, 0, NULL, NULL, NULL, 1);

--
-- Acionadores `usuarios`
--
DELIMITER $$
CREATE TRIGGER `usuarios_before_insert` BEFORE INSERT ON `usuarios` FOR EACH ROW BEGIN
    IF NEW.email_hash IS NULL THEN
        SET NEW.email_hash = SHA2(NEW.email, 256);
    END IF;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `usuarios_before_update` BEFORE UPDATE ON `usuarios` FOR EACH ROW BEGIN
    IF NEW.email <> OLD.email THEN
        SET NEW.email_hash = SHA2(NEW.email, 256);
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estrutura stand-in para vista `view_auditoria_completa`
-- (Veja abaixo para a view atual)
--
CREATE TABLE `view_auditoria_completa` (
`id_auditoria` bigint(20) unsigned
,`tipo_acao` varchar(50)
,`entidade` varchar(50)
,`id_entidade` bigint(20) unsigned
,`usuario` varchar(120)
,`auditor` varchar(120)
,`ip_origem` varchar(45)
,`data_hora` datetime
,`hash_transacao` varchar(128)
,`tamanho_dados_anteriores` int(10)
,`tamanho_dados_novos` int(10)
);

-- --------------------------------------------------------

--
-- Estrutura stand-in para vista `view_blockchain_resumo`
-- (Veja abaixo para a view atual)
--
CREATE TABLE `view_blockchain_resumo` (
`id_bloco` bigint(20) unsigned
,`bloco_hash` varchar(128)
,`hash_curto` varchar(8)
,`numero_transacoes` int(11)
,`data_criacao` varchar(24)
,`dificuldade` int(11)
,`nonce` bigint(20) unsigned
,`eventos_no_bloco` bigint(21)
);

-- --------------------------------------------------------

--
-- Estrutura stand-in para vista `view_estatisticas_sistema`
-- (Veja abaixo para a view atual)
--
CREATE TABLE `view_estatisticas_sistema` (
`total_usuarios` bigint(21)
,`usuarios_comuns` bigint(21)
,`auditores` bigint(21)
,`administradores` bigint(21)
,`sessoes_ativas` bigint(21)
,`total_eventos` bigint(21)
,`total_blocos` bigint(21)
,`ultimo_bloco_timestamp` bigint(20) unsigned
);

-- --------------------------------------------------------

--
-- Estrutura stand-in para vista `view_usuarios_detalhados`
-- (Veja abaixo para a view atual)
--
CREATE TABLE `view_usuarios_detalhados` (
`id_usuario` int(10) unsigned
,`nome_completo` varchar(120)
,`email` varchar(180)
,`tipo_usuario` enum('user','auditor','admin')
,`nome_perfil` varchar(100)
,`descricao_perfil` varchar(255)
,`data_criacao` datetime
,`data_ultimo_login` datetime
,`ativo` tinyint(1)
,`sessoes_ativas` bigint(21)
,`total_eventos` bigint(21)
);

-- --------------------------------------------------------

--
-- Estrutura para vista `view_auditoria_completa`
--
DROP TABLE IF EXISTS `view_auditoria_completa`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_auditoria_completa`  AS SELECT `a`.`id_auditoria` AS `id_auditoria`, `a`.`tipo_acao` AS `tipo_acao`, `a`.`entidade` AS `entidade`, `a`.`id_entidade` AS `id_entidade`, `u`.`nome_completo` AS `usuario`, `aud`.`nome_completo` AS `auditor`, `a`.`ip_origem` AS `ip_origem`, `a`.`data_hora` AS `data_hora`, `a`.`hash_transacao` AS `hash_transacao`, octet_length(`a`.`dados_anteriores`) AS `tamanho_dados_anteriores`, octet_length(`a`.`dados_novos`) AS `tamanho_dados_novos` FROM ((`auditoria_acessos` `a` left join `usuarios` `u` on(`a`.`id_usuario` = `u`.`id_usuario`)) left join `usuarios` `aud` on(`a`.`id_auditor` = `aud`.`id_usuario`)) ORDER BY `a`.`data_hora` DESC ;

-- --------------------------------------------------------

--
-- Estrutura para vista `view_blockchain_resumo`
--
DROP TABLE IF EXISTS `view_blockchain_resumo`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_blockchain_resumo`  AS SELECT `bb`.`id_bloco` AS `id_bloco`, `bb`.`bloco_hash` AS `bloco_hash`, left(`bb`.`bloco_hash`,8) AS `hash_curto`, `bb`.`numero_transacoes` AS `numero_transacoes`, date_format(from_unixtime(`bb`.`timestamp_criacao`),'%d/%m/%Y %H:%i:%s') AS `data_criacao`, `bb`.`dificuldade` AS `dificuldade`, `bb`.`nonce` AS `nonce`, (select count(0) from `registro_eventos` `re` where `re`.`bloco_hash` = `bb`.`bloco_hash`) AS `eventos_no_bloco` FROM `blocos_blockchain` AS `bb` ORDER BY `bb`.`id_bloco` DESC ;

-- --------------------------------------------------------

--
-- Estrutura para vista `view_estatisticas_sistema`
--
DROP TABLE IF EXISTS `view_estatisticas_sistema`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_estatisticas_sistema`  AS SELECT (select count(0) from `usuarios`) AS `total_usuarios`, (select count(0) from `usuarios` where `usuarios`.`tipo_usuario` = 'user') AS `usuarios_comuns`, (select count(0) from `usuarios` where `usuarios`.`tipo_usuario` = 'auditor') AS `auditores`, (select count(0) from `usuarios` where `usuarios`.`tipo_usuario` = 'admin') AS `administradores`, (select count(0) from `sessoes_ativas` where `sessoes_ativas`.`expiracao` > current_timestamp()) AS `sessoes_ativas`, (select count(0) from `registro_eventos`) AS `total_eventos`, (select count(0) from `blocos_blockchain`) AS `total_blocos`, (select max(`blocos_blockchain`.`timestamp_criacao`) from `blocos_blockchain`) AS `ultimo_bloco_timestamp` ;

-- --------------------------------------------------------

--
-- Estrutura para vista `view_usuarios_detalhados`
--
DROP TABLE IF EXISTS `view_usuarios_detalhados`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_usuarios_detalhados`  AS SELECT `u`.`id_usuario` AS `id_usuario`, `u`.`nome_completo` AS `nome_completo`, `u`.`email` AS `email`, `u`.`tipo_usuario` AS `tipo_usuario`, `p`.`nome_perfil` AS `nome_perfil`, `p`.`descricao` AS `descricao_perfil`, `u`.`data_criacao` AS `data_criacao`, `u`.`data_ultimo_login` AS `data_ultimo_login`, `u`.`ativo` AS `ativo`, (select count(0) from `sessoes_ativas` `sa` where `sa`.`id_usuario` = `u`.`id_usuario` and `sa`.`expiracao` > current_timestamp()) AS `sessoes_ativas`, (select count(0) from `registro_eventos` `re` where `re`.`id_usuario` = `u`.`id_usuario`) AS `total_eventos` FROM (`usuarios` `u` left join `perfis_acesso` `p` on(`u`.`tipo_usuario` collate utf8mb4_unicode_ci = `p`.`nome_perfil`)) ;

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `auditoria_acessos`
--
ALTER TABLE `auditoria_acessos`
  ADD PRIMARY KEY (`id_auditoria`),
  ADD UNIQUE KEY `hash_transacao` (`hash_transacao`),
  ADD KEY `id_usuario` (`id_usuario`),
  ADD KEY `id_auditor` (`id_auditor`),
  ADD KEY `idx_tipo_acao` (`tipo_acao`),
  ADD KEY `idx_entidade` (`entidade`),
  ADD KEY `idx_data_hora` (`data_hora`);

--
-- Índices para tabela `backup_codigos_mfa`
--
ALTER TABLE `backup_codigos_mfa`
  ADD PRIMARY KEY (`id_backup`),
  ADD KEY `id_usuario` (`id_usuario`),
  ADD KEY `idx_data_expiracao` (`data_expiracao`),
  ADD KEY `idx_utilizado` (`utilizado`);

--
-- Índices para tabela `blocos_blockchain`
--
ALTER TABLE `blocos_blockchain`
  ADD PRIMARY KEY (`id_bloco`),
  ADD UNIQUE KEY `bloco_hash` (`bloco_hash`),
  ADD KEY `idx_bloco_hash_anterior` (`bloco_hash_anterior`),
  ADD KEY `idx_timestamp_criacao` (`timestamp_criacao`),
  ADD KEY `idx_hash_merkle_root` (`hash_merkle_root`);

--
-- Índices para tabela `chaves_criptografia`
--
ALTER TABLE `chaves_criptografia`
  ADD PRIMARY KEY (`id_chave`),
  ADD UNIQUE KEY `chave_hash` (`chave_hash`),
  ADD KEY `id_usuario` (`id_usuario`),
  ADD KEY `idx_tipo_chave` (`tipo_chave`),
  ADD KEY `idx_data_expiracao` (`data_expiracao`),
  ADD KEY `idx_ativa` (`ativa`);

--
-- Índices para tabela `codigos_verificacao_mfa`
--
ALTER TABLE `codigos_verificacao_mfa`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_usuario` (`id_usuario`),
  ADD KEY `idx_expiracao` (`expiracao`),
  ADD KEY `idx_utilizado` (`utilizado`);

--
-- Índices para tabela `configuracoes_sistema`
--
ALTER TABLE `configuracoes_sistema`
  ADD PRIMARY KEY (`id_configuracao`),
  ADD UNIQUE KEY `chave` (`chave`),
  ADD KEY `idx_categoria` (`categoria`);

--
-- Índices para tabela `logs_seguranca`
--
ALTER TABLE `logs_seguranca`
  ADD PRIMARY KEY (`id_log`),
  ADD KEY `id_usuario` (`id_usuario`),
  ADD KEY `idx_tipo_log` (`tipo_log`),
  ADD KEY `idx_severidade` (`severidade`),
  ADD KEY `idx_data_hora` (`data_hora`);

--
-- Índices para tabela `notificacoes_sistema`
--
ALTER TABLE `notificacoes_sistema`
  ADD PRIMARY KEY (`id_notificacao`),
  ADD KEY `id_usuario` (`id_usuario`),
  ADD KEY `idx_lida` (`lida`),
  ADD KEY `idx_data_criacao` (`data_criacao`);

--
-- Índices para tabela `perfis_acesso`
--
ALTER TABLE `perfis_acesso`
  ADD PRIMARY KEY (`id_perfil`),
  ADD UNIQUE KEY `nome_perfil` (`nome_perfil`);

--
-- Índices para tabela `registro_eventos`
--
ALTER TABLE `registro_eventos`
  ADD PRIMARY KEY (`id_evento`),
  ADD UNIQUE KEY `hash_transacao` (`hash_transacao`),
  ADD KEY `idx_usuario_tipo` (`id_usuario`,`tipo_evento`),
  ADD KEY `idx_data_hora` (`data_hora`),
  ADD KEY `idx_bloco_numero` (`bloco_numero`),
  ADD KEY `idx_hash_anterior` (`hash_anterior`),
  ADD KEY `idx_hash_seguinte` (`hash_seguinte`),
  ADD KEY `idx_bloco_hash` (`bloco_hash`),
  ADD KEY `idx_timestamp` (`timestamp`),
  ADD KEY `idx_email_hash` (`email_hash`);

--
-- Índices para tabela `sessoes_ativas`
--
ALTER TABLE `sessoes_ativas`
  ADD PRIMARY KEY (`id_sessao`),
  ADD UNIQUE KEY `token_sessao` (`token_sessao`),
  ADD KEY `id_usuario` (`id_usuario`),
  ADD KEY `idx_expiracao` (`expiracao`),
  ADD KEY `idx_data_ultima_atividade` (`data_ultima_atividade`);

--
-- Índices para tabela `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id_usuario`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `email_hash` (`email_hash`),
  ADD KEY `idx_tipo_usuario` (`tipo_usuario`),
  ADD KEY `idx_data_ultimo_login` (`data_ultimo_login`),
  ADD KEY `idx_ativo` (`ativo`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `auditoria_acessos`
--
ALTER TABLE `auditoria_acessos`
  MODIFY `id_auditoria` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `backup_codigos_mfa`
--
ALTER TABLE `backup_codigos_mfa`
  MODIFY `id_backup` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `blocos_blockchain`
--
ALTER TABLE `blocos_blockchain`
  MODIFY `id_bloco` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `chaves_criptografia`
--
ALTER TABLE `chaves_criptografia`
  MODIFY `id_chave` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `codigos_verificacao_mfa`
--
ALTER TABLE `codigos_verificacao_mfa`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `configuracoes_sistema`
--
ALTER TABLE `configuracoes_sistema`
  MODIFY `id_configuracao` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT de tabela `logs_seguranca`
--
ALTER TABLE `logs_seguranca`
  MODIFY `id_log` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT de tabela `notificacoes_sistema`
--
ALTER TABLE `notificacoes_sistema`
  MODIFY `id_notificacao` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `perfis_acesso`
--
ALTER TABLE `perfis_acesso`
  MODIFY `id_perfil` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `registro_eventos`
--
ALTER TABLE `registro_eventos`
  MODIFY `id_evento` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=80;

--
-- AUTO_INCREMENT de tabela `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id_usuario` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `auditoria_acessos`
--
ALTER TABLE `auditoria_acessos`
  ADD CONSTRAINT `auditoria_acessos_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`) ON DELETE SET NULL,
  ADD CONSTRAINT `auditoria_acessos_ibfk_2` FOREIGN KEY (`id_auditor`) REFERENCES `usuarios` (`id_usuario`) ON DELETE SET NULL;

--
-- Limitadores para a tabela `backup_codigos_mfa`
--
ALTER TABLE `backup_codigos_mfa`
  ADD CONSTRAINT `backup_codigos_mfa_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`) ON DELETE CASCADE;

--
-- Limitadores para a tabela `chaves_criptografia`
--
ALTER TABLE `chaves_criptografia`
  ADD CONSTRAINT `chaves_criptografia_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`) ON DELETE CASCADE;

--
-- Limitadores para a tabela `codigos_verificacao_mfa`
--
ALTER TABLE `codigos_verificacao_mfa`
  ADD CONSTRAINT `codigos_verificacao_mfa_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`) ON DELETE CASCADE;

--
-- Limitadores para a tabela `logs_seguranca`
--
ALTER TABLE `logs_seguranca`
  ADD CONSTRAINT `logs_seguranca_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`) ON DELETE SET NULL;

--
-- Limitadores para a tabela `notificacoes_sistema`
--
ALTER TABLE `notificacoes_sistema`
  ADD CONSTRAINT `notificacoes_sistema_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`) ON DELETE CASCADE;

--
-- Limitadores para a tabela `registro_eventos`
--
ALTER TABLE `registro_eventos`
  ADD CONSTRAINT `registro_eventos_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`) ON DELETE SET NULL;

--
-- Limitadores para a tabela `sessoes_ativas`
--
ALTER TABLE `sessoes_ativas`
  ADD CONSTRAINT `sessoes_ativas_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`) ON DELETE CASCADE;

DELIMITER $$
--
-- Eventos
--
CREATE DEFINER=`root`@`localhost` EVENT `criar_bloco_periodico` ON SCHEDULE EVERY 10 MINUTE STARTS '2026-01-22 13:25:15' ON COMPLETION NOT PRESERVE ENABLE DO BEGIN
    CALL criar_novo_bloco();
END$$

CREATE DEFINER=`root`@`localhost` EVENT `verificar_integridade_diaria` ON SCHEDULE EVERY 1 DAY STARTS '2026-01-23 13:25:15' ON COMPLETION NOT PRESERVE ENABLE DO BEGIN
    CALL verificar_integridade_blockchain();
END$$

CREATE DEFINER=`root`@`localhost` EVENT `limpar_sessoes_event` ON SCHEDULE EVERY 1 HOUR STARTS '2026-01-22 13:25:15' ON COMPLETION NOT PRESERVE ENABLE DO BEGIN
    CALL limpar_sessoes_expiradas();
END$$

DELIMITER ;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
