<?php
// Iniciar sessão e carregar configurações
session_start();
require_once 'includes/config.php';
require_once 'includes/funcoes-seguranca.php';

error_log("[LOGIN] ========== INICIANDO PROCESSO DE LOGIN ==========");
error_log("[LOGIN] Sessão ID: " . session_id());

// Redirecionar se já estiver logado
if (isset($_SESSION['id_usuario']) && !empty($_SESSION['id_usuario'])) {
    error_log("[LOGIN] Usuário já autenticado, redirecionando para dashboard");
    header("Location: dashboard.php");
    exit;
}

// Só aceita POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    error_log("[LOGIN] Método não POST, redirecionando para index");
    header("Location: index.php");
    exit;
}

// Resposta padrão
$resposta = ['success' => false, 'error' => 'Erro desconhecido'];

// Email exatamente como o usuário digitou
$email_informado = '';

try {
    // 1. Verificar token CSRF
    if (!isset($_POST['token_form']) || !verificarTokenCSRF($_POST['token_form'])) {
        $_SESSION['token_form'] = bin2hex(random_bytes(32));
        $resposta['error'] = 'Token de segurança inválido ou expirado. Recarregue a página.';
        $resposta['novo_token'] = $_SESSION['token_form'];
        throw new Exception('Token CSRF inválido');
    }

    // 2. Verificar e descriptografar dados
    if (!isset($_POST['dados_criptografados'])) {
        throw new Exception('Dados criptografados não recebidos');
    }

    $dadosCriptografados = json_decode($_POST['dados_criptografados'], true);
    if (!$dadosCriptografados || !is_array($dadosCriptografados)) {
        throw new Exception('Formato inválido dos dados criptografados');
    }

    $dados = descriptografarDados($dadosCriptografados);
    if (!$dados) {
        throw new Exception('Falha ao descriptografar dados');
    }

    $email_informado = trim($dados['email'] ?? '');
    $senha           = $dados['senha'] ?? '';
    $codigoMFA       = $dados['codigo_mfa'] ?? '';
    $userAgent       = $dados['user_agent'] ?? $_SERVER['HTTP_USER_AGENT'] ?? '';

    if (empty($email_informado)) {
        throw new Exception('Email não informado');
    }

    // 3. Registrar TENTATIVA de login (sempre)
    $ip = obterIPCliente();
    registrarEventoBlockchain('TENTATIVA_LOGIN', null, $email_informado, $ip, $userAgent);

    // 4. Validar formato do email
    if (!filter_var($email_informado, FILTER_VALIDATE_EMAIL)) {
        registrarEventoBlockchain('LOGIN_FALHO_EMAIL_INVALIDO', null, $email_informado, $ip, $userAgent);
        $resposta['error'] = 'Formato de email inválido';
        throw new Exception('Email inválido');
    }

    // 5. Conectar ao banco
    $conn = conectarBancoDados();

    // 6. Buscar usuário pelo email_hash
    $emailHash = hash('sha256', $email_informado);
    $stmt = $conn->prepare("SELECT * FROM usuarios WHERE email_hash = ? AND ativo = 1");
    $stmt->execute([$emailHash]);
    $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$usuario) {
        registrarEventoBlockchain('LOGIN_FALHO_USUARIO_NAO_ENCONTRADO', null, $email_informado, $ip, $userAgent);
        $resposta['error'] = 'Credenciais inválidas';
        throw new Exception('Usuário não encontrado');
    }

    // 7. Verificar se está bloqueado
    if (verificarUsuarioBloqueado($usuario['id_usuario'])) {
        registrarEventoBlockchain('USUARIO_BLOQUEADO', $usuario['id_usuario'], $email_informado, $ip, $userAgent);
        $resposta['error'] = 'Usuário bloqueado temporariamente. Tente novamente mais tarde.';
        throw new Exception('Usuário bloqueado');
    }

    // 8. Verificar senha
    if (!verificarSenha($senha, $usuario['senha_hash'])) {
        incrementarTentativaFalha($usuario['id_usuario']);

        $tentativas = ($usuario['tentativas_falhas'] ?? 0) + 1;
        if ($tentativas >= MAX_TENTATIVAS_LOGIN) {
            bloquearUsuario($usuario['id_usuario']);
            registrarEventoBlockchain('CONTA_BLOQUEADA_TENTATIVAS', $usuario['id_usuario'], $email_informado, $ip, $userAgent);
            $resposta['error'] = 'Conta bloqueada devido a múltiplas tentativas falhas. Tente novamente em 15 minutos.';
        } else {
            registrarEventoBlockchain('LOGIN_FALHO_SENHA_INCORRETA', $usuario['id_usuario'], $email_informado, $ip, $userAgent);
            $resposta['error'] = 'Credenciais inválidas';
        }
        throw new Exception('Falha na autenticação da senha');
    }

    // 9. Verificar MFA (se habilitado)
    if (!empty($usuario['mfa_codigo_hash'])) {
        if (empty($codigoMFA)) {
            $_SESSION['email_verificacao'] = $email_informado;
            $resposta['requiresMFA'] = true;
            $resposta['error'] = 'Código MFA necessário';
            throw new Exception('MFA requerido');
        }

        if (!verificarMFACodigo($codigoMFA, $usuario['mfa_codigo_hash'])) {
            registrarEventoBlockchain('MFA_FALHO', $usuario['id_usuario'], $email_informado, $ip, $userAgent);
            $resposta['error'] = 'Código MFA inválido';
            throw new Exception('MFA inválido');
        }
    }

    // ────────────────────────────────────────────────
    // LOGIN BEM-SUCEDIDO
    // ────────────────────────────────────────────────

    // Resetar contadores de falha e bloqueio
    resetarTentativasFalhas($usuario['id_usuario']);

    // Gerar tokens de sessão
    $idSessao    = bin2hex(random_bytes(32));
    $tokenSessao = bin2hex(random_bytes(32));
    $expiracao   = date('Y-m-d H:i:s', time() + TEMPO_EXPIRACAO_SESSAO);

    // Inserir sessão ativa
    $stmt = $conn->prepare("
        INSERT INTO sessoes_ativas 
        (id_sessao, id_usuario, ip, user_agent, token_sessao, expiracao) 
        VALUES (?, ?, ?, ?, ?, ?)
    ");
    $stmt->execute([$idSessao, $usuario['id_usuario'], $ip, $userAgent, $tokenSessao, $expiracao]);

    // Atualizar dados do usuário
    $stmt = $conn->prepare("
        UPDATE usuarios 
        SET data_ultimo_login    = NOW(),
            data_ultima_atividade = NOW(),
            ultimo_ip             = ?,
            tentativas_falhas     = 0,
            bloqueado_ate         = NULL
        WHERE id_usuario = ?
    ");
    $stmt->execute([$ip, $usuario['id_usuario']]);

    // Registrar sucesso no blockchain
    registrarEventoBlockchain(
        'LOGIN_SUCCESS',  // padronizando nome do evento
        $usuario['id_usuario'],
        $email_informado,
        $ip,
        $userAgent
    );

    // Configurar sessão PHP
    $_SESSION['id_usuario']     = $usuario['id_usuario'];
    $_SESSION['email']          = $usuario['email'];
    $_SESSION['tipo_usuario']   = $usuario['tipo_usuario'];
    $_SESSION['nome_completo']  = $usuario['nome_completo'];
    $_SESSION['id_sessao']      = $idSessao;
    $_SESSION['token_sessao']   = $tokenSessao;
    $_SESSION['ultima_atividade'] = time();

    // Limpar dados temporários de MFA
    unset($_SESSION['email_verificacao']);

    $resposta = [
        'success'  => true,
        'redirect' => 'dashboard.php',
        'message'  => 'Login realizado com sucesso'
    ];

} catch (Exception $e) {
    error_log("[LOGIN] Erro: " . $e->getMessage());

    // Registrar falha genérica apenas se ainda não foi registrado
    if (!str_contains($resposta['error'] ?? '', 'já registrado')) {
        if (isset($usuario['id_usuario'])) {
            registrarEventoBlockchain('LOGIN_FAILED', $usuario['id_usuario'] ?? null, $email_informado, $ip ?? obterIPCliente(), $userAgent ?? '');
        }
    }

    $resposta['error'] = $resposta['error'] ?? 'Erro interno ao processar login';
}

// Sempre responder JSON
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-cache, no-store, must-revalidate');
echo json_encode($resposta, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);

error_log("[LOGIN] Resposta: " . json_encode($resposta, JSON_UNESCAPED_UNICODE));
error_log("[LOGIN] ========== FIM DO PROCESSO DE LOGIN ==========");
exit;