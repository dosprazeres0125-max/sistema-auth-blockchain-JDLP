<?php
require_once 'includes/config.php';
require_once 'includes/funcoes-seguranca.php';

// Redirecionar se já estiver logado
if (isset($_SESSION['id_usuario']) && !empty($_SESSION['id_usuario'])) {
    header("Location: dashboard.php");
    exit;
}

$mensagensFlash = obterMensagensFlash();

// Verificar se há email em verificação MFA
$emailVerificacao = $_SESSION['email_verificacao'] ?? '';
$temMFAVerificacao = false;

if ($emailVerificacao) {
    try {
        $conn = conectarBancoDados();
        $emailHash = hash('sha256', $emailVerificacao);
        
        $stmt = $conn->prepare("SELECT mfa_codigo_hash FROM usuarios WHERE email_hash = ? AND ativo = 1");
        $stmt->execute([$emailHash]);
        $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($usuario && !empty($usuario['mfa_codigo_hash'])) {
            $temMFAVerificacao = true;
        } else {
            unset($_SESSION['email_verificacao']);
        }
    } catch (Exception $e) {
        error_log("Erro verificação MFA: " . $e->getMessage());
        unset($_SESSION['email_verificacao']);
    }
}
?>
<!DOCTYPE html>
<html lang="pt" class="scroll-smooth">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= NOME_SISTEMA ?> • Acesso Seguro</title>
    <link rel="icon" type="image/x-icon" href="<?= CAMINHO_FAVICON ?>">
    <meta name="description" content="Sistema de autenticação imutável baseado em blockchain com auditoria completa">

    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    
    <!-- CryptoJS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/crypto-js/4.1.1/crypto-js.min.js"></script>
    
    <!-- Particles.js -->
    <script src="https://cdn.jsdelivr.net/particles.js/2.0.0/particles.min.js"></script>

    <script>
        tailwind.config = {
            theme: {
                fontFamily: {
                    'sans': ['Inter', 'system-ui', 'sans-serif'],
                },
                extend: {
                    colors: {
                        'marinho': {
                            50: '#e6f2ff',
                            100: '#cce5ff',
                            200: '#99ccff',
                            300: '#66b2ff',
                            400: '#3399ff',
                            500: '#007fff',
                            600: '#0066cc',
                            700: '#004c99',
                            800: '#003366',
                            900: '#001933',
                        },
                        'security': {
                            'blue': '#0066ff',
                            'dark-blue': '#001f3f',
                            'light-blue': '#4a90e2',
                            'success': '#10b981',
                            'warning': '#f59e0b',
                            'danger': '#ef4444'
                        }
                    },
                    animation: {
                        'float': 'float 6s ease-in-out infinite',
                        'slide-in': 'slideIn 0.5s ease-out',
                        'fade-in': 'fadeIn 0.6s ease-out',
                        'pulse-gentle': 'pulseGentle 2s ease-in-out infinite',
                        'slide-up': 'slideUp 0.4s ease-out',
                        'shake': 'shake 0.5s ease-in-out',
                        'bounce-in': 'bounceIn 0.6s ease-out',
                        'glow': 'glow 1.5s ease-in-out infinite alternate',
                        'click-effect': 'clickEffect 0.3s ease-out',
                    },
                    keyframes: {
                        float: {
                            '0%, 100%': { transform: 'translateY(0) rotate(0deg)' },
                            '33%': { transform: 'translateY(-10px) rotate(2deg)' },
                            '66%': { transform: 'translateY(5px) rotate(-1deg)' },
                        },
                        slideIn: {
                            '0%': { 
                                transform: 'translateX(-100px)',
                                opacity: '0'
                            },
                            '100%': { 
                                transform: 'translateX(0)',
                                opacity: '1'
                            },
                        },
                        fadeIn: {
                            '0%': { opacity: '0' },
                            '100%': { opacity: '1' },
                        },
                        pulseGentle: {
                            '0%, 100%': { opacity: '1' },
                            '50%': { opacity: '0.7' },
                        },
                        slideUp: {
                            '0%': { 
                                transform: 'translateY(20px)',
                                opacity: '0'
                            },
                            '100%': { 
                                transform: 'translateY(0)',
                                opacity: '1'
                            },
                        },
                        shake: {
                            '0%, 100%': { transform: 'translateX(0)' },
                            '10%, 30%, 50%, 70%, 90%': { transform: 'translateX(-5px)' },
                            '20%, 40%, 60%, 80%': { transform: 'translateX(5px)' },
                        },
                        bounceIn: {
                            '0%': { 
                                transform: 'scale(0.3)',
                                opacity: '0'
                            },
                            '50%': { 
                                transform: 'scale(1.05)',
                                opacity: '1'
                            },
                            '70%': { transform: 'scale(0.9)' },
                            '100%': { transform: 'scale(1)' },
                        },
                        glow: {
                            '0%': { 
                                boxShadow: '0 0 5px rgba(0, 102, 255, 0.5)',
                            },
                            '100%': { 
                                boxShadow: '0 0 20px rgba(0, 102, 255, 0.8)',
                            },
                        },
                        clickEffect: {
                            '0%': { 
                                transform: 'scale(1)',
                                boxShadow: '0 0 0 0 rgba(0, 127, 255, 0.7)'
                            },
                            '50%': { 
                                transform: 'scale(0.95)',
                                boxShadow: '0 0 0 10px rgba(0, 127, 255, 0)'
                            },
                            '100%': { 
                                transform: 'scale(1)',
                                boxShadow: '0 0 0 0 rgba(0, 127, 255, 0)'
                            },
                        }
                    },
                    backgroundImage: {
                        'gradient-security': 'linear-gradient(135deg, #001f3f 0%, #003366 50%, #0066ff 100%)',
                    }
                }
            }
        }
    </script>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            -webkit-tap-highlight-color: transparent;
        }
        
        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #0a192f 0%, #0f2b46 100%);
            min-height: 100vh;
            overflow-x: hidden;
            color: #e2e8f0;
            cursor: default;
        }
        
        #particles-js {
            position: fixed;
            width: 100%;
            height: 100%;
            top: 0;
            left: 0;
            z-index: 0;
        }
        
        .glass-panel {
            background: rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.15);
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.2);
            backdrop-filter: blur(4px);
        }
        
        .glass-panel-light {
            background: rgba(255, 255, 255, 0.98);
            border: 1px solid rgba(0, 127, 255, 0.1);
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.15);
        }
        
        .card-hover {
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            cursor: pointer;
            position: relative;
            overflow: hidden;
        }
        
        .card-hover::before {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.1), transparent);
            transition: left 0.6s;
        }
        
        .card-hover:hover::before {
            left: 100%;
        }
        
        .card-hover:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.3);
        }
        
        .card-hover:active {
            transform: translateY(-2px) scale(0.98);
            transition: all 0.1s ease;
        }
        
        .input-modern-light {
            background: rgba(255, 255, 255, 0.95);
            border: 2px solid #e2e8f0;
            transition: all 0.2s ease;
        }
        
        .input-modern-light:focus {
            background: white;
            border-color: #007fff;
            box-shadow: 0 0 0 3px rgba(0, 127, 255, 0.15);
            outline: none;
        }
        
        .btn-gradient {
            background: linear-gradient(135deg, #007fff 0%, #004c99 100%);
            position: relative;
            overflow: hidden;
            transition: all 0.3s ease;
            cursor: pointer;
        }
        
        .btn-gradient:hover {
            background: linear-gradient(135deg, #0066cc 0%, #003366 100%);
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(0, 127, 255, 0.25);
        }
        
        .btn-gradient:active {
            transform: translateY(0) scale(0.98);
            box-shadow: 0 4px 10px rgba(0, 127, 255, 0.2);
        }
        
        .status-dot {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            display: inline-block;
            margin-right: 8px;
        }
        
        .status-dot.verifying {
            background: #f59e0b;
            animation: pulseGentle 1s infinite;
        }
        
        .status-dot.active {
            background: #10b981;
        }
        
        .typewriter {
            overflow: hidden;
            border-right: 2px solid #007fff;
            white-space: nowrap;
            margin: 0 auto;
            letter-spacing: 0.15em;
            animation: typing 3.5s steps(40, end), blink-caret 0.75s step-end infinite;
        }
        
        @keyframes typing {
            from { width: 0 }
            to { width: 100% }
        }
        
        @keyframes blink-caret {
            from, to { border-color: transparent }
            50% { border-color: #007fff }
        }
        
        .security-badge {
            background: linear-gradient(135deg, rgba(0, 127, 255, 0.15), rgba(0, 127, 255, 0.25));
            border: 1px solid rgba(0, 127, 255, 0.3);
            backdrop-filter: blur(4px);
        }
        
        .floating-element {
            animation: float 8s ease-in-out infinite;
        }
        
        .floating-element:nth-child(2) {
            animation-delay: 1s;
        }
        
        .floating-element:nth-child(3) {
            animation-delay: 2s;
        }
        
        .floating-element:nth-child(4) {
            animation-delay: 3s;
        }
        
        .modal-overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.75);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 1000;
            opacity: 0;
            visibility: hidden;
            transition: all 0.3s ease;
        }
        
        .modal-overlay.active {
            opacity: 1;
            visibility: visible;
        }
        
        .modal-content {
            background: white;
            border-radius: 16px;
            width: 90%;
            max-width: 500px;
            max-height: 80vh;
            overflow-y: auto;
            transform: translateY(-20px) scale(0.95);
            transition: all 0.3s ease;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.35);
        }
        
        .modal-overlay.active .modal-content {
            transform: translateY(0) scale(1);
        }
        
        .click-ripple {
            position: absolute;
            border-radius: 50%;
            background: rgba(0, 127, 255, 0.3);
            transform: scale(0);
            animation: ripple 0.6s linear;
            pointer-events: none;
        }
        
        @keyframes ripple {
            to {
                transform: scale(4);
                opacity: 0;
            }
        }
        
        .btn-click:active {
            animation: clickEffect 0.3s ease-out;
        }
        
        .card-blue {
            background: linear-gradient(135deg, rgba(0, 127, 255, 0.15), rgba(0, 127, 255, 0.25));
            border: 1px solid rgba(0, 127, 255, 0.3);
        }
        
        .card-green {
            background: linear-gradient(135deg, rgba(16, 185, 129, 0.15), rgba(16, 185, 129, 0.25));
            border: 1px solid rgba(16, 185, 129, 0.3);
        }
        
        .card-purple {
            background: linear-gradient(135deg, rgba(139, 92, 246, 0.15), rgba(139, 92, 246, 0.25));
            border: 1px solid rgba(139, 92, 246, 0.3);
        }
        
        .card-amber {
            background: linear-gradient(135deg, rgba(245, 158, 11, 0.15), rgba(245, 158, 11, 0.25));
            border: 1px solid rgba(245, 158, 11, 0.3);
        }
        
        @media (max-width: 768px) {
            .typewriter {
                animation: none;
                border-right: none;
                white-space: normal;
            }
            
            .floating-element {
                animation: float 6s ease-in-out infinite;
            }
        }
        
        .animate-delay-1 { animation-delay: 0.1s; }
        .animate-delay-2 { animation-delay: 0.2s; }
        .animate-delay-3 { animation-delay: 0.3s; }
        .animate-delay-4 { animation-delay: 0.4s; }
        .animate-delay-5 { animation-delay: 0.5s; }
        
        .clickable {
            cursor: pointer;
            user-select: none;
        }
        
        .clickable:active {
            transform: scale(0.98);
        }
        
        .icon-glow {
            filter: drop-shadow(0 0 8px currentColor);
            transition: filter 0.3s ease;
        }
        
        .icon-glow:hover {
            filter: drop-shadow(0 0 12px currentColor);
        }
        
        .input-valid {
            border-color: #10b981 !important;
            background: rgba(16, 185, 129, 0.05) !important;
        }
        
        .input-invalid {
            border-color: #ef4444 !important;
            background: rgba(239, 68, 68, 0.05) !important;
        }
        
        .input-warning {
            border-color: #f59e0b !important;
            background: rgba(245, 158, 11, 0.05) !important;
        }
        
        /* Toast notifications */
        .toast-container {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 9999;
            max-width: 400px;
        }
        
        .toast {
            animation: slideInRight 0.3s ease-out;
            margin-bottom: 10px;
        }
        
        @keyframes slideInRight {
            from {
                transform: translateX(100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }
        
        .toast.hiding {
            animation: slideOutRight 0.3s ease-in forwards;
        }
        
        @keyframes slideOutRight {
            from {
                transform: translateX(0);
                opacity: 1;
            }
            to {
                transform: translateX(100%);
                opacity: 0;
            }
        }
    </style>
</head>
<body class="min-h-screen flex flex-col relative overflow-hidden">
    <div id="particles-js"></div>
    
    <div class="fixed inset-0 overflow-hidden pointer-events-none z-0">
        <div class="floating-element absolute top-1/4 left-1/4 w-64 h-64 rounded-full bg-gradient-to-br from-blue-500/5 to-purple-500/5 blur-3xl"></div>
        <div class="floating-element absolute bottom-1/4 right-1/4 w-96 h-96 rounded-full bg-gradient-to-tr from-cyan-500/5 to-blue-500/5 blur-3xl"></div>
        <div class="floating-element absolute top-1/3 right-1/3 w-48 h-48 rounded-full bg-gradient-to-r from-indigo-500/5 to-pink-500/5 blur-3xl"></div>
    </div>

    <!-- Toast Container -->
    <div id="toast-container" class="toast-container"></div>

    <?php if (!empty($mensagensFlash)): ?>
    <div class="fixed top-6 left-1/2 transform -translate-x-1/2 z-50 w-full max-w-md px-4 space-y-3">
        <?php foreach ($mensagensFlash as $flash): ?>
        <div class="animate-slide-up rounded-2xl p-4 shadow-2xl border-l-4 flex items-start glass-panel-light animate-delay-1 <?php
            echo match($flash['tipo']) {
                'success' => 'border-green-500 bg-green-50',
                'error'   => 'border-red-500 bg-red-50',
                'warning' => 'border-yellow-500 bg-yellow-50',
                'info'    => 'border-blue-500 bg-blue-50',
                default   => 'border-gray-500 bg-gray-50',
            };
        ?>">
            <div class="flex-shrink-0 pt-0.5">
                <?php if ($flash['tipo'] === 'success'): ?>
                    <div class="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center">
                        <i class="fas fa-check-circle text-green-600 text-sm"></i>
                    </div>
                <?php elseif ($flash['tipo'] === 'error'): ?>
                    <div class="w-8 h-8 rounded-full bg-red-100 flex items-center justify-center">
                        <i class="fas fa-exclamation-circle text-red-600 text-sm"></i>
                    </div>
                <?php elseif ($flash['tipo'] === 'warning'): ?>
                    <div class="w-8 h-8 rounded-full bg-yellow-100 flex items-center justify-center">
                        <i class="fas fa-exclamation-triangle text-yellow-600 text-sm"></i>
                    </div>
                <?php else: ?>
                    <div class="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center">
                        <i class="fas fa-info-circle text-blue-600 text-sm"></i>
                    </div>
                <?php endif; ?>
            </div>
            <div class="ml-3 flex-1">
                <h3 class="text-sm font-semibold text-gray-900">
                    <?= htmlspecialchars($flash['titulo']) ?>
                </h3>
                <div class="mt-1 text-xs text-gray-700">
                    <?= htmlspecialchars($flash['mensagem']) ?>
                </div>
            </div>
            <button onclick="this.parentElement.remove()" class="ml-2 text-gray-400 hover:text-gray-600 transition-colors clickable">
                <i class="fas fa-times"></i>
            </button>
        </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <main class="flex-1 flex items-center justify-center p-4 md:p-6 relative z-10">
        <div class="w-full max-w-6xl">
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 md:gap-12 items-center">
                <div class="space-y-6 md:space-y-8">
                    <div class="flex items-center space-x-3 mb-4">
                        <div class="w-10 h-10 rounded-xl bg-gradient-to-br from-marinho-500 to-marinho-700 flex items-center justify-center shadow-lg">
                            <i class="fas fa-link text-white text-lg"></i>
                        </div>
                        <div>
                            <h1 class="text-xl md:text-2xl font-bold text-white"><?= NOME_SISTEMA ?></h1>
                            <p class="text-xs text-blue-300">Blockchain Security System</p>
                        </div>
                    </div>

                    <div class="inline-flex items-center space-x-2 security-badge px-3 py-1.5 rounded-full animate-slide-in">
                        <i class="fas fa-shield-alt text-blue-400"></i>
                        <span class="text-xs font-medium text-blue-300">Sistema Imutável</span>
                    </div>
                    
                    <div class="space-y-3">
                        <h2 class="text-3xl md:text-4xl lg:text-5xl font-bold text-white leading-tight">
                            Autenticação
                            <span class="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-cyan-300">
                                Segura
                            </span>
                            com
                            <span class="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-cyan-300">
                                Blockchain
                            </span>
                        </h2>
                        
                        <p class="text-sm md:text-base text-blue-100 leading-relaxed">
                            Sistema de login que registra todos os eventos em blockchain para auditoria completa e transparente.
                        </p>
                    </div>

                    <div class="grid grid-cols-2 gap-3">
                        <div class="card-hover p-4 rounded-xl card-blue animate-delay-1 clickable" onclick="abrirModal('mfa')">
                            <div class="flex flex-col items-center text-center">
                                <div class="w-10 h-10 rounded-lg bg-blue-500/20 flex items-center justify-center mb-2">
                                    <i class="fas fa-fingerprint text-blue-400 text-lg icon-glow"></i>
                                </div>
                                <h3 class="text-sm font-semibold text-white mb-1">MFA em Tempo Real</h3>
                                <p class="text-xs text-blue-200">Detecção automática</p>
                            </div>
                        </div>
                        
                        <div class="card-hover p-4 rounded-xl card-green animate-delay-2 clickable" onclick="abrirModal('blockchain')">
                            <div class="flex flex-col items-center text-center">
                                <div class="w-10 h-10 rounded-lg bg-green-500/20 flex items-center justify-center mb-2">
                                    <i class="fas fa-link text-green-400 text-lg icon-glow"></i>
                                </div>
                                <h3 class="text-sm font-semibold text-white mb-1">Blockchain</h3>
                                <p class="text-xs text-green-200">Registros imutáveis</p>
                            </div>
                        </div>
                        
                        <div class="card-hover p-4 rounded-xl card-purple animate-delay-3 clickable" onclick="abrirModal('auditoria')">
                            <div class="flex flex-col items-center text-center">
                                <div class="w-10 h-10 rounded-lg bg-purple-500/20 flex items-center justify-center mb-2">
                                    <i class="fas fa-search text-purple-400 text-lg icon-glow"></i>
                                </div>
                                <h3 class="text-sm font-semibold text-white mb-1">Auditoria</h3>
                                <p class="text-xs text-purple-200">Transparência total</p>
                            </div>
                        </div>
                        
                        <div class="card-hover p-4 rounded-xl card-amber animate-delay-4 clickable" onclick="abrirModal('monitoramento')">
                            <div class="flex flex-col items-center text-center">
                                <div class="w-10 h-10 rounded-lg bg-amber-500/20 flex items-center justify-center mb-2">
                                    <i class="fas fa-bell text-amber-400 text-lg icon-glow"></i>
                                </div>
                                <h3 class="text-sm font-semibold text-white mb-1">Monitoramento</h3>
                                <p class="text-xs text-amber-200">Alertas em tempo real</p>
                            </div>
                        </div>
                    </div>

                    <div class="glass-panel p-4 rounded-xl animate-delay-5">
                        <div class="grid grid-cols-3 gap-3 text-center">
                            <div>
                                <div class="text-lg md:text-xl font-bold text-white">2.4K+</div>
                                <div class="text-xs text-blue-300">Eventos</div>
                            </div>
                            <div>
                                <div class="text-lg md:text-xl font-bold text-white">99.9%</div>
                                <div class="text-xs text-blue-300">Uptime</div>
                            </div>
                            <div>
                                <div class="text-lg md:text-xl font-bold text-white">0</div>
                                <div class="text-xs text-blue-300">Violações</div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="glass-panel-light rounded-2xl shadow-xl p-5 md:p-6">
                    <div class="text-center mb-6">
                        <div class="relative inline-block mb-3">
                            <div class="w-12 h-12 rounded-xl bg-gradient-to-br from-marinho-500 to-marinho-700 flex items-center justify-center mx-auto shadow-md">
                                <i class="fas fa-user-lock text-white text-xl"></i>
                            </div>
                        </div>
                        <h3 class="text-xl font-bold text-gray-900 mb-1">Acesso ao Sistema</h3>
                        <p class="text-sm text-gray-600">Entre com suas credenciais</p>
                    </div>

                    <form id="form-login" method="POST" class="space-y-4">
                        <input type="hidden" name="token_form" value="<?= $_SESSION['token_form'] ?? '' ?>">
                        <input type="hidden" name="dados_criptografados" id="dados-criptografados">
                        
                        <div class="space-y-1.5">
                            <label class="block text-xs font-medium text-gray-700">Email</label>
                            <div class="relative">
                                <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                    <i class="fas fa-envelope text-gray-400 text-sm"></i>
                                </div>
                                <input 
                                    type="email" 
                                    name="email" 
                                    id="email-input"
                                    required 
                                    autocomplete="email"
                                    autofocus
                                    class="w-full pl-9 pr-9 py-2.5 input-modern-light rounded-lg text-gray-900 placeholder-gray-500 text-sm"
                                    placeholder="seu.email@exemplo.com"
                                    value="<?= htmlspecialchars($emailVerificacao) ?>">
                                <div id="email-status" class="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none"></div>
                            </div>
                            <div id="mfa-check-status" class="text-xs text-gray-500 h-4 transition-all duration-200"></div>
                        </div>

                        <div class="space-y-1.5">
                            <label class="block text-xs font-medium text-gray-700">Senha</label>
                            <div class="relative">
                                <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                    <i class="fas fa-lock text-gray-400 text-sm"></i>
                                </div>
                                <input 
                                    type="password" 
                                    name="senha" 
                                    id="senha-input"
                                    required 
                                    autocomplete="current-password"
                                    class="w-full pl-9 pr-9 py-2.5 input-modern-light rounded-lg text-gray-900 placeholder-gray-500 text-sm"
                                    placeholder="••••••••••••">
                                <button type="button" onclick="alternarSenha(this)" class="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 hover:text-gray-600 transition-colors clickable">
                                    <i class="fas fa-eye text-sm"></i>
                                </button>
                            </div>
                        </div>

                        <div id="campo-mfa" style="display: <?= $temMFAVerificacao ? 'block' : 'none' ?>; opacity: <?= $temMFAVerificacao ? '1' : '0' ?>; max-height: <?= $temMFAVerificacao ? '100px' : '0' ?>; overflow: hidden; transition: all 0.2s ease;">
                            <div class="space-y-1.5">
                                <label class="block text-xs font-medium text-gray-700 flex items-center">
                                    <i class="fas fa-shield-alt text-amber-500 mr-1.5 text-sm"></i>
                                    Código de Verificação (MFA)
                                </label>
                                <div class="relative">
                                    <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                        <i class="fas fa-key text-amber-500 text-sm"></i>
                                    </div>
                                    <input 
                                        type="text" 
                                        name="codigo_mfa" 
                                        id="mfa-input"
                                        autocomplete="off"
                                        inputmode="numeric"
                                        pattern="[0-9]*"
                                        maxlength="6"
                                        class="w-full pl-9 pr-4 py-2.5 input-modern-light rounded-lg border-amber-300 text-gray-900 placeholder-gray-500 text-sm"
                                        placeholder="000000">
                                </div>
                                <p class="text-xs text-amber-600">
                                    Autenticação multifator necessária
                                </p>
                            </div>
                        </div>

                        <button 
                            type="button"
                            id="btn-login"
                            class="w-full btn-gradient text-white font-medium py-2.5 rounded-lg text-sm btn-click clickable">
                            <i class="fas fa-sign-in-alt mr-2"></i>
                            Entrar no Sistema
                        </button>

                        <div class="text-center pt-3 border-t border-gray-100">
                            <p class="text-xs text-gray-600">
                                Não tem uma conta?
                                <a class="text-marinho-600 hover:text-marinho-800 font-medium ml-1 clickable">
                                    Contacte o Administrador
                                </a>
                            </p>
                        </div>
                    </form>
                </div>
            </div>

            <div class="mt-6 text-center">
                <div class="flex flex-wrap items-center justify-center gap-3 mb-2">
                    <span class="flex items-center text-xs text-blue-300">
                        <i class="fas fa-shield-check text-green-400 mr-1.5"></i>
                        Criptografia ponta a ponta
                    </span>
                    <span class="flex items-center text-xs text-blue-300">
                        <i class="fas fa-database text-blue-400 mr-1.5"></i>
                        Registros imutáveis
                    </span>
                    <span class="flex items-center text-xs text-blue-300">
                        <i class="fas fa-clock text-purple-400 mr-1.5"></i>
                        Auditoria em tempo real
                    </span>
                </div>
                <p class="text-xs text-blue-400/70">
                    © <?= date('Y') ?> <?= NOME_SISTEMA ?> • v<?= VERSAO ?>
                </p>
            </div>
        </div>
    </main>

    
    <div id="modal-mfa" class="modal-overlay" onclick="fecharModal(event, 'mfa')">
        <div class="modal-content" onclick="event.stopPropagation()">
            <div class="p-5">
                <div class="flex items-center justify-between mb-3">
                    <div class="flex items-center space-x-3">
                        <div class="w-8 h-8 rounded-lg bg-blue-50 flex items-center justify-center">
                            <i class="fas fa-fingerprint text-blue-600 text-sm"></i>
                        </div>
                        <h3 class="text-base font-semibold text-gray-900">Autenticação MFA</h3>
                    </div>
                    <button onclick="fecharModal(event, 'mfa')" class="text-gray-400 hover:text-gray-600 clickable">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div class="space-y-3">
                    <p class="text-sm text-gray-600">
                        A autenticação multifator (MFA) adiciona uma camada extra de segurança ao seu login.
                        O sistema detecta automaticamente se MFA está habilitado e exige o código quando necessário.
                    </p>
                    <div class="bg-blue-50 rounded-lg p-3">
                        <h4 class="font-medium text-blue-900 mb-1 text-sm">Como funciona:</h4>
                        <ul class="text-xs text-blue-800 space-y-1">
                            <li class="flex items-start">
                                <i class="fas fa-check-circle text-blue-500 mt-0.5 mr-2 text-xs"></i>
                                <span>Detecção automática durante a digitação do email</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check-circle text-blue-500 mt-0.5 mr-2 text-xs"></i>
                                <span>Campo aparece instantaneamente quando necessário</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check-circle text-blue-500 mt-0.5 mr-2 text-xs"></i>
                                <span>Códigos gerados por aplicativos autenticadores</span>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div id="modal-blockchain" class="modal-overlay" onclick="fecharModal(event, 'blockchain')">
        <div class="modal-content" onclick="event.stopPropagation()">
            <div class="p-5">
                <div class="flex items-center justify-between mb-3">
                    <div class="flex items-center space-x-3">
                        <div class="w-8 h-8 rounded-lg bg-green-50 flex items-center justify-center">
                            <i class="fas fa-link text-green-600 text-sm"></i>
                        </div>
                        <h3 class="text-base font-semibold text-gray-900">Tecnologia Blockchain</h3>
                    </div>
                    <button onclick="fecharModal(event, 'blockchain')" class="text-gray-400 hover:text-gray-600 clickable">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div class="space-y-3">
                    <p class="text-sm text-gray-600">
                        Todos os eventos de autenticação são registrados em blockchain, garantindo
                        imutabilidade e transparência total dos registros.
                    </p>
                    <div class="bg-green-50 rounded-lg p-3">
                        <h4 class="font-medium text-green-900 mb-1 text-sm">Vantagens:</h4>
                        <ul class="text-xs text-green-800 space-y-1">
                            <li class="flex items-start">
                                <i class="fas fa-check-circle text-green-500 mt-0.5 mr-2 text-xs"></i>
                                <span>Registros imutáveis e à prova de violação</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check-circle text-green-500 mt-0.5 mr-2 text-xs"></i>
                                <span>Transparência completa em todas as operações</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check-circle text-green-500 mt-0.5 mr-2 text-xs"></i>
                                <span>Auditoria simplificada e confiável</span>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div id="modal-auditoria" class="modal-overlay" onclick="fecharModal(event, 'auditoria')">
        <div class="modal-content" onclick="event.stopPropagation()">
            <div class="p-5">
                <div class="flex items-center justify-between mb-3">
                    <div class="flex items-center space-x-3">
                        <div class="w-8 h-8 rounded-lg bg-purple-50 flex items-center justify-center">
                            <i class="fas fa-search text-purple-600 text-sm"></i>
                        </div>
                        <h3 class="text-base font-semibold text-gray-900">Auditoria Completa</h3>
                    </div>
                    <button onclick="fecharModal(event, 'auditoria')" class="text-gray-400 hover:text-gray-600 clickable">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div class="space-y-3">
                    <p class="text-sm text-gray-600">
                        Sistema de auditoria que registra e monitora todas as atividades
                        de autenticação em tempo real.
                    </p>
                    <div class="bg-purple-50 rounded-lg p-3">
                        <h4 class="font-medium text-purple-900 mb-1 text-sm">Recursos:</h4>
                        <ul class="text-xs text-purple-800 space-y-1">
                            <li class="flex items-start">
                                <i class="fas fa-check-circle text-purple-500 mt-0.5 mr-2 text-xs"></i>
                                <span>Monitoramento em tempo real</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check-circle text-purple-500 mt-0.5 mr-2 text-xs"></i>
                                <span>Relatórios detalhados e exportáveis</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check-circle text-purple-500 mt-0.5 mr-2 text-xs"></i>
                                <span>Alertas automáticos</span>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div id="modal-monitoramento" class="modal-overlay" onclick="fecharModal(event, 'monitoramento')">
        <div class="modal-content" onclick="event.stopPropagation()">
            <div class="p-5">
                <div class="flex items-center justify-between mb-3">
                    <div class="flex items-center space-x-3">
                        <div class="w-8 h-8 rounded-lg bg-amber-50 flex items-center justify-center">
                            <i class="fas fa-bell text-amber-600 text-sm"></i>
                        </div>
                        <h3 class="text-base font-semibold text-gray-900">Monitoramento Ativo</h3>
                    </div>
                    <button onclick="fecharModal(event, 'monitoramento')" class="text-gray-400 hover:text-gray-600 clickable">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div class="space-y-3">
                    <p class="text-sm text-gray-600">
                        Sistema de monitoramento 24/7 que detecta e alerta sobre atividades
                        suspeitas em tempo real.
                    </p>
                    <div class="bg-amber-50 rounded-lg p-3">
                        <h4 class="font-medium text-amber-900 mb-1 text-sm">Funcionalidades:</h4>
                        <ul class="text-xs text-amber-800 space-y-1">
                            <li class="flex items-start">
                                <i class="fas fa-check-circle text-amber-500 mt-0.5 mr-2 text-xs"></i>
                                <span>Detecção de tentativas suspeitas</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check-circle text-amber-500 mt-0.5 mr-2 text-xs"></i>
                                <span>Alertas em tempo real</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check-circle text-amber-500 mt-0.5 mr-2 text-xs"></i>
                                <span>Análise comportamental</span>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Configurar particles.js
        particlesJS('particles-js', {
            particles: {
                number: {
                    value: 50,
                    density: {
                        enable: true,
                        value_area: 800
                    }
                },
                color: {
                    value: ["#007fff", "#4a90e2", "#10b981"]
                },
                shape: {
                    type: "circle",
                    stroke: {
                        width: 0,
                        color: "#000000"
                    }
                },
                opacity: {
                    value: 0.2,
                    random: true,
                    anim: {
                        enable: true,
                        speed: 1,
                        opacity_min: 0.1,
                        sync: false
                    }
                },
                size: {
                    value: 2,
                    random: true,
                    anim: {
                        enable: true,
                        speed: 2,
                        size_min: 0.1,
                        sync: false
                    }
                },
                line_linked: {
                    enable: true,
                    distance: 120,
                    color: "#4a90e2",
                    opacity: 0.1,
                    width: 1
                },
                move: {
                    enable: true,
                    speed: 0.8,
                    direction: "none",
                    random: true,
                    straight: false,
                    out_mode: "out",
                    bounce: false
                }
            },
            interactivity: {
                detect_on: "canvas",
                events: {
                    onhover: {
                        enable: true,
                        mode: "grab"
                    },
                    onclick: {
                        enable: true,
                        mode: "push"
                    },
                    resize: true
                },
                modes: {
                    grab: {
                        distance: 120,
                        line_linked: {
                            opacity: 0.2
                        }
                    },
                    push: {
                        particles_nb: 3
                    }
                }
            },
            retina_detect: true
        });

        // Constantes
        const CHAVE_CRIPTOGRAFIA = '<?= CHAVE_CRIPTOGRAFIA_CLIENTE ?>';
        
        // Elementos DOM
        const emailInput = document.getElementById('email-input');
        const campoMFA = document.getElementById('campo-mfa');
        const mfaInput = document.getElementById('mfa-input');
        const statusDiv = document.getElementById('mfa-check-status');
        const emailStatusDiv = document.getElementById('email-status');
        
        // Variáveis de estado
        let temporizadorDebounce;
        let ultimoEmail = '';
        let emailValido = false;
        let emailExistente = false;
        let temMFA = false;

        /**
         * Função para mostrar toast notifications
         */
        function mostrarToast(tipo, titulo, mensagem) {
            const toastContainer = document.getElementById('toast-container');
            if (!toastContainer) return;
            
            const toastId = 'toast-' + Date.now();
            const toast = document.createElement('div');
            toast.id = toastId;
            toast.className = `toast rounded-lg shadow-lg p-4 mb-2 ${
                tipo === 'success' ? 'bg-green-50 border-l-4 border-green-500' :
                tipo === 'error' ? 'bg-red-50 border-l-4 border-red-500' :
                tipo === 'warning' ? 'bg-yellow-50 border-l-4 border-yellow-500' :
                'bg-blue-50 border-l-4 border-blue-500'
            }`;
            
            // Ícone baseado no tipo
            let iconClass = 'fa-info-circle';
            let iconColor = 'text-blue-600';
            
            if (tipo === 'success') {
                iconClass = 'fa-check-circle';
                iconColor = 'text-green-600';
            } else if (tipo === 'error') {
                iconClass = 'fa-exclamation-circle';
                iconColor = 'text-red-600';
            } else if (tipo === 'warning') {
                iconClass = 'fa-exclamation-triangle';
                iconColor = 'text-yellow-600';
            }
            
            toast.innerHTML = `
                <div class="flex items-start">
                    <div class="flex-shrink-0">
                        <i class="fas ${iconClass} ${iconColor} text-lg"></i>
                    </div>
                    <div class="ml-3 flex-1">
                        <p class="text-sm font-medium text-gray-900">${titulo}</p>
                        <p class="text-sm text-gray-600 mt-1">${mensagem}</p>
                    </div>
                    <button onclick="document.getElementById('${toastId}').classList.add('hiding'); setTimeout(() => document.getElementById('${toastId}')?.remove(), 300)" 
                            class="ml-4 text-gray-400 hover:text-gray-600">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
            `;
            
            toastContainer.appendChild(toast);
            
            // Auto-remover após 5 segundos
            setTimeout(() => {
                if (document.getElementById(toastId)) {
                    toast.classList.add('hiding');
                    setTimeout(() => {
                        if (document.getElementById(toastId)) {
                            toast.remove();
                        }
                    }, 300);
                }
            }, 5000);
        }

        /**
         * Função de criptografia
         */
        function criptografarDados(dados) {
            try {
                console.log('[LOGIN] Iniciando criptografia...');
                
                if (!dados || typeof dados !== 'object') {
                    throw new Error('Dados inválidos para criptografia');
                }
                
                const dadosParaCriptografar = {
                    email: String(dados.email || ''),
                    senha: String(dados.senha || ''),
                    codigo_mfa: String(dados.codigo_mfa || ''),
                    timestamp: Date.now(),
                    user_agent: navigator.userAgent,
                    ip: '0.0.0.0'
                };
                
                console.log('[LOGIN] Dados preparados para criptografia');
                
                const dadosString = JSON.stringify(dadosParaCriptografar);
                
                // Usar chave de 32 caracteres para AES-256
                let chaveBytes;
                if (CHAVE_CRIPTOGRAFIA.length >= 32) {
                    chaveBytes = CryptoJS.enc.Utf8.parse(CHAVE_CRIPTOGRAFIA.substring(0, 32));
                } else {
                    chaveBytes = CryptoJS.enc.Utf8.parse(CHAVE_CRIPTOGRAFIA.padEnd(32, '0'));
                }
                
                const iv = CryptoJS.lib.WordArray.random(16);
                
                const criptografado = CryptoJS.AES.encrypt(dadosString, chaveBytes, {
                    iv: iv,
                    mode: CryptoJS.mode.CBC,
                    padding: CryptoJS.pad.Pkcs7
                });
                
                console.log('[LOGIN] Criptografia bem sucedida!');
                
                return {
                    iv: CryptoJS.enc.Base64.stringify(iv),
                    dados: criptografado.toString(),
                    modo: 'CBC'
                };
                
            } catch (error) {
                console.error('[LOGIN] Falha na criptografia:', error);
                
                // Método alternativo simples
                try {
                    const dadosAlternativos = {
                        email: String(dados.email || ''),
                        senha: String(dados.senha || ''),
                        codigo_mfa: String(dados.codigo_mfa || ''),
                        timestamp: Date.now()
                    };
                    
                    const dadosString = JSON.stringify(dadosAlternativos);
                    const chaveSimples = CryptoJS.enc.Utf8.parse(CHAVE_CRIPTOGRAFIA.substring(0, 16).padEnd(16, 'X'));
                    
                    const criptografadoSimples = CryptoJS.AES.encrypt(dadosString, chaveSimples, {
                        mode: CryptoJS.mode.ECB,
                        padding: CryptoJS.pad.Pkcs7
                    });
                    
                    console.log('[LOGIN] Método alternativo funcionou!');
                    
                    return {
                        dados: criptografadoSimples.toString(),
                        modo: 'ECB'
                    };
                    
                } catch (error2) {
                    console.error('[LOGIN] Método alternativo também falhou:', error2);
                    mostrarToast('error', 'Erro', 'Falha na criptografia dos dados');
                    return null;
                }
            }
        }

        /**
         * Função para realizar login
         */
        async function realizarLogin() {
            console.log('[LOGIN] Iniciando processo de login...');
            
            const email = emailInput.value.trim();
            const senha = document.getElementById('senha-input').value;
            const codigoMFA = mfaInput.value.trim();
            
            // Validações básicas
            if (!email) {
                console.error('[LOGIN] Email vazio');
                emailInput.focus();
                emailInput.classList.add('animate-shake');
                setTimeout(() => emailInput.classList.remove('animate-shake'), 500);
                mostrarToast('error', 'Erro', 'Digite seu email');
                return false;
            }
            
            if (!senha) {
                console.error('[LOGIN] Senha vazia');
                document.getElementById('senha-input').focus();
                document.getElementById('senha-input').classList.add('animate-shake');
                setTimeout(() => document.getElementById('senha-input').classList.remove('animate-shake'), 500);
                mostrarToast('error', 'Erro', 'Digite sua senha');
                return false;
            }
            
            // Validação MFA se necessário
            const isMFAVisible = campoMFA.style.display === 'block' && campoMFA.style.opacity === '1';
            if (isMFAVisible && (!codigoMFA || codigoMFA.length !== 6 || !/^\d+$/.test(codigoMFA))) {
                console.error('[LOGIN] Código MFA inválido');
                mfaInput.focus();
                mfaInput.classList.add('animate-shake');
                setTimeout(() => mfaInput.classList.remove('animate-shake'), 500);
                mostrarToast('error', 'Erro', 'Código MFA inválido (6 dígitos necessários)');
                return false;
            }
            
            // Preparar dados
            const dadosSensiveis = {
                email: email,
                senha: senha,
                codigo_mfa: codigoMFA,
                timestamp: Date.now(),
                user_agent: navigator.userAgent,
                ip: '0.0.0.0'
            };
            
            console.log('[LOGIN] Dados sensíveis preparados');
            
            // Criptografar
            const dadosCriptografados = criptografarDados(dadosSensiveis);
            
            if (!dadosCriptografados) {
                console.error('[LOGIN] Falha na criptografia');
                return false;
            }
            
            // Obter token
            const tokenFormElement = document.querySelector('input[name="token_form"]');
            if (!tokenFormElement) {
                console.error('[LOGIN] Token form não encontrado');
                mostrarToast('error', 'Erro', 'Erro interno. Recarregue a página.');
                return false;
            }
            
            const tokenForm = tokenFormElement.value;
            
            // Preparar dados para envio
            const formData = new FormData();
            formData.append('token_form', tokenForm);
            formData.append('dados_criptografados', JSON.stringify(dadosCriptografados));
            
            // Configurar botão
            const btn = document.getElementById('btn-login');
            const originalHTML = btn.innerHTML;
            btn.innerHTML = '<i class="fas fa-circle-notch fa-spin mr-2"></i>Autenticando...';
            btn.disabled = true;
            
            try {
                console.log('[LOGIN] Enviando para login.php...');
                
                const resposta = await fetch('login.php', {
                    method: 'POST',
                    body: formData
                });
                
                console.log('[LOGIN] Status da resposta:', resposta.status);
                
                // Verificar se a resposta é JSON
                const contentType = resposta.headers.get('content-type');
                if (!contentType || !contentType.includes('application/json')) {
                    console.error('[LOGIN] Resposta não é JSON:', contentType);
                    
                    // Tentar obter o texto para debug
                    const respostaTexto = await resposta.text();
                    console.error('[LOGIN] Resposta texto:', respostaTexto.substring(0, 200));
                    
                    // Se contém redirecionamento
                    if (respostaTexto.includes('dashboard.php') || resposta.status === 302 || resposta.status === 301) {
                        console.log('[LOGIN] Redirecionamento detectado via header ou conteúdo');
                        window.location.href = 'dashboard.php';
                        return;
                    }
                    
                    throw new Error('Resposta do servidor inválida');
                }
                
                const dadosResposta = await resposta.json();
                console.log('[LOGIN] Resposta JSON:', dadosResposta);
                
                if (dadosResposta.success) {
                    console.log('[LOGIN] Login bem sucedido!');
                    
                    // Mostrar mensagem de sucesso
                    mostrarToast('success', 'Sucesso', 'Login realizado com sucesso!');
                    
                    // Redirecionar com delay
                    setTimeout(() => {
                        if (dadosResposta.redirect) {
                            console.log('[LOGIN] Redirecionando para:', dadosResposta.redirect);
                            window.location.href = dadosResposta.redirect;
                        } else {
                            console.log('[LOGIN] Redirecionando para dashboard (padrão)');
                            window.location.href = 'dashboard.php';
                        }
                    }, 1000); // 1 segundo para mostrar o toast
                    
                } else if (dadosResposta.requiresMFA) {
                    console.log('[LOGIN] MFA necessário');
                    
                    // Atualizar token se fornecido
                    if (dadosResposta.novo_token) {
                        tokenFormElement.value = dadosResposta.novo_token;
                        console.log('[LOGIN] Token atualizado');
                    }
                    
                    // Mostrar campo MFA
                    alternarCampoMFA(true);
                    
                    // Mostrar mensagem
                    mostrarToast('warning', 'MFA Necessário', dadosResposta.error || 'Código de verificação necessário');
                    
                } else {
                    console.error('[LOGIN] Erro do servidor:', dadosResposta.error);
                    
                    // Atualizar token se fornecido
                    if (dadosResposta.novo_token) {
                        tokenFormElement.value = dadosResposta.novo_token;
                        console.log('[LOGIN] Token atualizado devido a erro');
                    }
                    
                    // Mostrar erro
                    mostrarToast('error', 'Erro', dadosResposta.error || 'Erro ao fazer login');
                }
                
            } catch (error) {
                console.error('[LOGIN] Erro na requisição:', error);
                mostrarToast('error', 'Erro de Conexão', 'Não foi possível conectar ao servidor. Verifique sua internet.');
            } finally {
                // Restaurar botão
                btn.innerHTML = originalHTML;
                btn.disabled = false;
            }
        }

        /**
         * Funções auxiliares
         */
        function criarRipple(evento) {
            const botao = evento.currentTarget;
            const circulo = document.createElement("span");
            const diametro = Math.max(botao.clientWidth, botao.clientHeight);
            const raio = diametro / 2;

            circulo.style.width = circulo.style.height = `${diametro}px`;
            circulo.style.left = `${evento.clientX - botao.getBoundingClientRect().left - raio}px`;
            circulo.style.top = `${evento.clientY - botao.getBoundingClientRect().top - raio}px`;
            circulo.classList.add("click-ripple");

            const rippleExistente = botao.getElementsByClassName("click-ripple")[0];
            if (rippleExistente) {
                rippleExistente.remove();
            }

            botao.appendChild(circulo);
        }

        function alternarSenha(botao) {
            const senhaInput = document.getElementById('senha-input');
            const icone = botao.querySelector('i');
            
            criarRipple({currentTarget: botao});
            botao.style.transform = 'scale(0.95)';
            setTimeout(() => botao.style.transform = '', 150);
            
            if (senhaInput.type === 'password') {
                senhaInput.type = 'text';
                icone.classList.remove('fa-eye');
                icone.classList.add('fa-eye-slash');
                botao.classList.add('text-blue-500');
            } else {
                senhaInput.type = 'password';
                icone.classList.remove('fa-eye-slash');
                icone.classList.add('fa-eye');
                botao.classList.remove('text-blue-500');
            }
        }

        function abrirModal(modalId) {
            const modal = document.getElementById(`modal-${modalId}`);
            modal.classList.add('active');
            document.body.style.overflow = 'hidden';
            
            if (event && event.currentTarget) {
                criarRipple({currentTarget: event.currentTarget});
                event.currentTarget.style.transform = 'scale(0.95)';
                setTimeout(() => event.currentTarget.style.transform = '', 200);
            }
        }

        function fecharModal(evento, modalId) {
            evento.preventDefault();
            const modal = document.getElementById(`modal-${modalId}`);
            modal.classList.remove('active');
            document.body.style.overflow = 'auto';
            
            criarRipple({currentTarget: evento.currentTarget});
        }

        function definirStatusEmail(icone, cor, tooltip) {
            emailStatusDiv.innerHTML = `<i class="fas ${icone} ${cor} text-xs" title="${tooltip}"></i>`;
        }

        function definirMensagemStatus(mensagem, tipo = 'info') {
            const cores = {
                'info': 'text-gray-500',
                'success': 'text-green-600',
                'warning': 'text-amber-600',
                'error': 'text-red-600',
                'loading': 'text-blue-600'
            };
            
            const icones = {
                'info': 'fa-info-circle',
                'success': 'fa-check-circle',
                'warning': 'fa-exclamation-triangle',
                'error': 'fa-times-circle',
                'loading': 'fa-circle-notch fa-spin'
            };
            
            statusDiv.innerHTML = `<span class="${cores[tipo]} flex items-center text-xs"><i class="fas ${icones[tipo]} mr-1 text-xs"></i>${mensagem}</span>`;
        }

        function alternarCampoMFA(mostrar) {
            if (mostrar) {
                campoMFA.style.display = 'block';
                setTimeout(() => {
                    campoMFA.style.opacity = '1';
                    campoMFA.style.maxHeight = '100px';
                }, 10);
                mfaInput.setAttribute('required', 'required');
                setTimeout(() => mfaInput.focus(), 50);
            } else {
                campoMFA.style.opacity = '0';
                campoMFA.style.maxHeight = '0';
                mfaInput.removeAttribute('required');
                setTimeout(() => {
                    campoMFA.style.display = 'none';
                }, 200);
            }
        }

        async function verificarMFA(email) {
            if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
                return false;
            }

            try {
                definirStatusEmail('fa-circle-notch fa-spin', 'text-blue-500', 'Verificando...');
                definirMensagemStatus('Verificando configurações...', 'loading');
                
                const resposta = await fetch('verifica_mfa.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: 'email=' + encodeURIComponent(email)
                });
                
                const dados = await resposta.json();
                
                if (dados.error) {
                    definirStatusEmail('fa-exclamation-circle', 'text-red-500', 'Erro na verificação');
                    definirMensagemStatus(dados.error, 'error');
                    alternarCampoMFA(false);
                    return false;
                }
                
                if (dados.hasMFA) {
                    definirStatusEmail('fa-shield-alt', 'text-amber-500', 'MFA Habilitado');
                    definirMensagemStatus('Autenticação multifator habilitada', 'warning');
                    alternarCampoMFA(true);
                    temMFA = true;
                } else {
                    definirStatusEmail('fa-check-circle', 'text-green-500', 'MFA Não Habilitado');
                    definirMensagemStatus('Autenticação padrão', 'success');
                    alternarCampoMFA(false);
                    temMFA = false;
                }
                
                return dados.hasMFA;
            } catch (erro) {
                console.error('Erro ao verificar MFA:', erro);
                definirStatusEmail('fa-exclamation-circle', 'text-red-500', 'Erro na verificação');
                definirMensagemStatus('Erro na verificação', 'error');
                alternarCampoMFA(false);
                return false;
            }
        }

        async function verificarEmail(email) {
            if (!email) {
                emailInput.classList.remove('input-valid', 'input-invalid', 'input-warning');
                definirStatusEmail('', '', '');
                definirMensagemStatus('', 'info');
                emailValido = false;
                emailExistente = false;
                return;
            }
            
            const formatoValido = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
            
            if (!formatoValido) {
                emailInput.classList.add('input-invalid');
                emailInput.classList.remove('input-valid', 'input-warning');
                definirStatusEmail('fa-times-circle', 'text-red-400', 'Email inválido');
                definirMensagemStatus('Formato de email inválido – tentativa será registrada', 'error');
                emailValido = false;
                alternarCampoMFA(false);
                return;
            }
            
            emailValido = true;
            
            try {
                definirStatusEmail('fa-circle-notch fa-spin', 'text-blue-500', 'Verificando...');
                definirMensagemStatus('Verificando email...', 'loading');
                
                const resposta = await fetch('ajax/verificar_email.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: 'email=' + encodeURIComponent(email)
                });
                
                const dados = await resposta.json();
                
                if (dados.existe) {
                    emailInput.classList.add('input-valid');
                    emailInput.classList.remove('input-invalid', 'input-warning');
                    definirStatusEmail('fa-check-circle', 'text-green-500', 'Email válido');
                    definirMensagemStatus('Email válido e existente', 'success');
                    emailExistente = true;
                    
                    await verificarMFA(email);
                } else {
                    emailInput.classList.add('input-warning');
                    emailInput.classList.remove('input-valid', 'input-invalid');
                    definirStatusEmail('fa-exclamation-triangle', 'text-amber-500', 'Email não encontrado');
                    definirMensagemStatus('Email válido mas não cadastrado – tentativa será registrada', 'warning');
                    emailExistente = false;
                    alternarCampoMFA(false);
                }
            } catch (erro) {
                console.error('Erro ao verificar email:', erro);
                emailInput.classList.add('input-warning');
                definirStatusEmail('fa-exclamation-circle', 'text-red-500', 'Erro na verificação');
                definirMensagemStatus('Erro ao verificar email', 'error');
            }
        }

        /**
         * Event Listeners
         */
        document.addEventListener('DOMContentLoaded', function() {
            // Focar no campo de email
            emailInput.focus();
            
            // Se houver email em verificação MFA, verificar
            <?php if ($temMFAVerificacao): ?>
            setTimeout(() => {
                verificarEmail('<?= $emailVerificacao ?>');
            }, 100);
            <?php endif; ?>
            
            // Adicionar evento de clique no botão de login
            document.getElementById('btn-login').addEventListener('click', realizarLogin);
            
            // Permitir login com Enter
            document.addEventListener('keydown', function(e) {
                if (e.key === 'Enter' && document.activeElement.tagName !== 'TEXTAREA') {
                    e.preventDefault();
                    realizarLogin();
                }
            });
            
            // Fechar modal com ESC
            document.addEventListener('keydown', (e) => {
                if (e.key === 'Escape') {
                    document.querySelectorAll('.modal-overlay.active').forEach(modal => {
                        modal.classList.remove('active');
                    });
                    document.body.style.overflow = 'auto';
                }
            });
        });

        // Event listeners para o campo de email
        emailInput.addEventListener('input', function() {
            const email = this.value.trim();
            
            if (email === ultimoEmail) return;
            ultimoEmail = email;
            
            clearTimeout(temporizadorDebounce);
            
            if (!email) {
                emailInput.classList.remove('input-valid', 'input-invalid', 'input-warning');
                definirStatusEmail('', '', '');
                definirMensagemStatus('', 'info');
                alternarCampoMFA(false);
                emailValido = false;
                emailExistente = false;
                return;
            }
            
            temporizadorDebounce = setTimeout(async () => {
                await verificarEmail(email);
            }, 500);
        });

        emailInput.addEventListener('blur', async function() {
            const email = this.value.trim();
            if (email) {
                await verificarEmail(email);
            }
        });

        // Event listener para espaço no email (transforma em @)
        emailInput.addEventListener('keydown', function(e) {
            if (e.key === ' ') {
                e.preventDefault();
                const cursorPos = this.selectionStart;
                const currentValue = this.value;
                this.value = currentValue.substring(0, cursorPos) + '@' + currentValue.substring(cursorPos);
                this.setSelectionRange(cursorPos + 1, cursorPos + 1);
            }
        });

        // Adicionar efeito de clique nos botões
        document.querySelectorAll('.clickable').forEach(elemento => {
            elemento.addEventListener('mousedown', function(e) {
                if (this.tagName === 'A') return;
                criarRipple({currentTarget: this});
                this.style.transform = 'scale(0.97)';
            });
            
            elemento.addEventListener('mouseup', function() {
                this.style.transform = '';
            });
            
            elemento.addEventListener('mouseleave', function() {
                this.style.transform = '';
            });
        });

        // Adicionar evento especial no botão de login
        const loginBtn = document.getElementById('btn-login');
        loginBtn.addEventListener('mousedown', function() {
            criarRipple({currentTarget: this});
            this.style.transform = 'scale(0.98)';
        });
        
        loginBtn.addEventListener('mouseup', function() {
            this.style.transform = '';
        });
        
        loginBtn.addEventListener('mouseleave', function() {
            this.style.transform = '';
        });

        /**
         * Função de debug (opcional – pode remover em produção)
         */
        function testarCriptografiaManual() {
            console.log('=== TESTE MANUAL DE CRIPTOGRAFIA ===');
            
            const dadosTeste = {
                email: 'teste@exemplo.com',
                senha: 'Senha@123',
                codigo_mfa: '123456',
                timestamp: Date.now(),
                user_agent: navigator.userAgent,
                ip: '127.0.0.1'
            };
            
            console.log('Dados de teste:', dadosTeste);
            console.log('Chave de criptografia:', CHAVE_CRIPTOGRAFIA);
            
            const resultado = criptografarDados(dadosTeste);
            
            if (resultado) {
                console.log('✓ Criptografia bem sucedida!');
                console.log('Resultado:', resultado);
            } else {
                console.error('✗ Falha na criptografia');
            }
        }
    </script>
</body>
</html>