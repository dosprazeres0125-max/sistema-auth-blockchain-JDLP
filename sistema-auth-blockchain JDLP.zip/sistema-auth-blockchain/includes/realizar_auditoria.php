<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/funcoes-seguranca.php';

if (!isset($_SESSION['id_usuario']) || !in_array($_SESSION['tipo_usuario'] ?? '', ['admin', 'auditor'])) {
    echo json_encode(['success' => false, 'message' => 'Acesso não autorizado']);
    exit;
}

try {
    $pdo = conectarBancoDados();
    
    // Exemplo simplificado: verifica se existe alguma inconsistência
    $stmt = $pdo->query("
        SELECT COUNT(*) 
        FROM registro_eventos re1
        LEFT JOIN registro_eventos re2 ON re1.hash_anterior = re2.hash_transacao
        WHERE re1.hash_anterior IS NOT NULL AND re2.id_evento IS NULL
    ");
    
    $inconsistencias = $stmt->fetchColumn();
    
    $success = $inconsistencias == 0;
    $message = $success 
        ? "Auditoria completa realizada. Nenhum problema detectado."
        : "Auditoria completa realizada. $inconsistencias inconsistências encontradas na cadeia.";
    
    echo json_encode([
        'success' => $success,
        'message' => $message,
        'total_verificado' => $pdo->query("SELECT COUNT(*) FROM registro_eventos")->fetchColumn(),
        'inconsistencias' => $inconsistencias
    ]);
    
} catch (Exception $e) {
    error_log("Erro na auditoria completa: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'Erro durante a auditoria completa'
    ]);
}