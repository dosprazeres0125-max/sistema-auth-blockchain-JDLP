<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/funcoes-seguranca.php';

if (!isset($_SESSION['id_usuario']) || !in_array($_SESSION['tipo_usuario'] ?? '', ['admin', 'auditor'])) {
    echo json_encode(['success' => false, 'message' => 'Acesso não autorizado']);
    exit;
}

$id = $_GET['id'] ?? 0;
if (!is_numeric($id) || $id <= 0) {
    echo json_encode(['success' => false, 'message' => 'ID inválido']);
    exit;
}

try {
    $pdo = conectarBancoDados();
    
    $stmt = $pdo->prepare("
        SELECT 
            re.*,
            u.nome_completo,
            u.email AS usuario_email,
            u.tipo_usuario
        FROM registro_eventos re
        LEFT JOIN usuarios u ON re.id_usuario = u.id_usuario
        WHERE re.id_evento = :id
        LIMIT 1
    ");
    
    $stmt->execute([':id' => $id]);
    $evento = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($evento) {
        echo json_encode([
            'success' => true,
            'evento' => $evento
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Evento não encontrado'
        ]);
    }
} catch (Exception $e) {
    error_log("Erro ao obter detalhes do evento: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'Erro interno no servidor'
    ]);
}