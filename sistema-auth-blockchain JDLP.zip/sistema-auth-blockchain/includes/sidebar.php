<?php
function verificarSessaoAtiva($idSessao, $tokenSessao) {
    try {
        $conn = conectarBancoDados();
        $stmt = $conn->prepare("SELECT id_sessao FROM sessoes_ativas WHERE id_sessao = ? AND token_sessao = ? AND expiracao > NOW()");
        $stmt->execute([$idSessao, $tokenSessao]);
        return $stmt->rowCount() > 0;
    } catch (Exception $e) {
        error_log("Erro ao verificar sessão: " . $e->getMessage());
        return false;
    }
}
?>
<aside class="w-64 bg-gray-900 min-h-screen text-white">
    <div class="p-6">
        <div class="flex items-center space-x-3 mb-8">
            <div class="w-8 h-8 rounded-lg bg-blue-500 flex items-center justify-center">
                <i class="fas fa-link text-white"></i>
            </div>
            <h2 class="text-lg font-bold"><?= NOME_SISTEMA ?></h2>
        </div>
        
        <nav class="space-y-2">
            <a href="dashboard.php" class="flex items-center space-x-3 px-4 py-3 rounded-lg hover:bg-gray-800 transition-colors">
                <i class="fas fa-tachometer-alt"></i>
                <span>Dashboard</span>
            </a>
            
            <?php if ($_SESSION['tipo_usuario'] === 'admin' || $_SESSION['tipo_usuario'] === 'auditor'): ?>
            <a href="conteudo/eventos.php" class="flex items-center space-x-3 px-4 py-3 rounded-lg hover:bg-gray-800 transition-colors">
                <i class="fas fa-history"></i>
                <span>Eventos</span>
            </a>
            <?php endif; ?>
            
            <a href="conteudo/meuperfil.php" class="flex items-center space-x-3 px-4 py-3 rounded-lg hover:bg-gray-800 transition-colors">
                <i class="fas fa-user"></i>
                <span>Meu Perfil</span>
            </a>
            
            <a href="conteudo/mfa.php" class="flex items-center space-x-3 px-4 py-3 rounded-lg hover:bg-gray-800 transition-colors">
                <i class="fas fa-shield-alt"></i>
                <span>MFA</span>
            </a>
            
            <?php if ($_SESSION['tipo_usuario'] === 'admin'): ?>
            <a href="conteudo/usuarios.php" class="flex items-center space-x-3 px-4 py-3 rounded-lg hover:bg-gray-800 transition-colors">
                <i class="fas fa-users"></i>
                <span>Usuários</span>
            </a>
            <?php endif; ?>
            
            <a href="logout.php" class="flex items-center space-x-3 px-4 py-3 rounded-lg hover:bg-red-800 transition-colors mt-8">
                <i class="fas fa-sign-out-alt"></i>
                <span>Sair</span>
            </a>
        </nav>
    </div>
    
    <div class="absolute bottom-0 left-0 right-0 p-6 border-t border-gray-800">
        <div class="flex items-center space-x-3">
            <div class="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center">
                <span class="text-sm font-bold"><?= strtoupper(substr($_SESSION['nome_completo'], 0, 1)) ?></span>
            </div>
            <div>
                <p class="text-sm font-medium"><?= htmlspecialchars($_SESSION['nome_completo']) ?></p>
                <p class="text-xs text-gray-400"><?= ucfirst($_SESSION['tipo_usuario']) ?></p>
            </div>
        </div>
    </div>
</aside>