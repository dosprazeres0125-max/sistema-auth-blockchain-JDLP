<?php
// Funções de Segurança e Utilidades

/**
 * Obtém mensagens flash da sessão
 */
function obterMensagensFlash() {
    $mensagens = [];
    if (isset($_SESSION['flash_mensagens'])) {
        $mensagens = $_SESSION['flash_mensagens'];
        unset($_SESSION['flash_mensagens']);
    }
    return $mensagens;
}

/**
 * Adiciona uma mensagem flash à sessão
 */
function adicionarMensagemFlash($tipo, $titulo, $mensagem) {
    if (!isset($_SESSION['flash_mensagens'])) {
        $_SESSION['flash_mensagens'] = [];
    }
    $_SESSION['flash_mensagens'][] = [
        'tipo' => $tipo,
        'titulo' => $titulo,
        'mensagem' => $mensagem
    ];
}

/**
 * Verifica token CSRF
 */
function verificarTokenCSRF($token) {
    if (!isset($_SESSION['token_form'])) {
        error_log("[CSRF] Token de sessão não encontrado");
        return false;
    }
    
    if (empty($token)) {
        error_log("[CSRF] Token enviado vazio");
        return false;
    }
    
    return hash_equals($_SESSION['token_form'], $token);
}

/**
 * Obtém IP do cliente de forma segura
 */
function obterIPCliente() {
    $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    
    $headers = [
        'HTTP_CLIENT_IP',
        'HTTP_X_FORWARDED_FOR',
        'HTTP_X_FORWARDED',
        'HTTP_FORWARDED_FOR',
        'HTTP_FORWARDED'
    ];
    
    foreach ($headers as $header) {
        if (isset($_SERVER[$header]) && !empty($_SERVER[$header])) {
            $ipList = explode(',', $_SERVER[$header]);
            $ip = trim($ipList[0]);
            break;
        }
    }
    
    return filter_var($ip, FILTER_VALIDATE_IP) ? $ip : '0.0.0.0';
}

/**
 * Verifica senha usando password_verify
 */
function verificarSenha($senha, $hash) {
    return password_verify($senha, $hash);
}

/**
 * Verifica código MFA
 */
function verificarMFACodigo($codigo, $hash) {
    return password_verify($codigo, $hash);
}

/**
 * Incrementa tentativas falhas
 */
function incrementarTentativaFalha($idUsuario) {
    try {
        $conn = conectarBancoDados();
        $stmt = $conn->prepare("UPDATE usuarios SET tentativas_falhas = tentativas_falhas + 1 WHERE id_usuario = ?");
        $stmt->execute([$idUsuario]);
    } catch (Exception $e) {
        error_log("Erro ao incrementar tentativa: " . $e->getMessage());
    }
}

/**
 * Reseta tentativas falhas e desbloqueia usuário
 */
function resetarTentativasFalhas($idUsuario) {
    try {
        $conn = conectarBancoDados();
        $stmt = $conn->prepare("UPDATE usuarios SET tentativas_falhas = 0, bloqueado_ate = NULL WHERE id_usuario = ?");
        $stmt->execute([$idUsuario]);
    } catch (Exception $e) {
        error_log("Erro ao resetar tentativas: " . $e->getMessage());
    }
}

/**
 * Bloqueia usuário por tempo definido
 */
function bloquearUsuario($idUsuario) {
    try {
        $conn = conectarBancoDados();
        $bloqueioAte = date('Y-m-d H:i:s', time() + TEMPO_BLOQUEIO_LOGIN);
        $stmt = $conn->prepare("UPDATE usuarios SET bloqueado_ate = ? WHERE id_usuario = ?");
        $stmt->execute([$bloqueioAte, $idUsuario]);
    } catch (Exception $e) {
        error_log("Erro ao bloquear usuário: " . $e->getMessage());
    }
}

/**
 * Verifica se usuário está bloqueado no momento
 */
function verificarUsuarioBloqueado($idUsuario) {
    try {
        $conn = conectarBancoDados();
        $stmt = $conn->prepare("SELECT bloqueado_ate FROM usuarios WHERE id_usuario = ?");
        $stmt->execute([$idUsuario]);
        $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($usuario && $usuario['bloqueado_ate']) {
            return strtotime($usuario['bloqueado_ate']) > time();
        }
        
        return false;
    } catch (Exception $e) {
        error_log("Erro ao verificar bloqueio: " . $e->getMessage());
        return false;
    }
}

/**
 * Descriptografa dados recebidos do cliente (suporta CBC e ECB fallback)
 */
function descriptografarDados($dadosCriptografados) {
    try {
        error_log("[CRIPTO] Iniciando descriptografia...");
        
        if (!is_array($dadosCriptografados)) {
            error_log("[CRIPTO] Dados não são array");
            return null;
        }
        
        $modo = $dadosCriptografados['modo'] ?? 'CBC';
        error_log("[CRIPTO] Modo detectado: " . $modo);
        
        $chaveTexto = CHAVE_CRIPTOGRAFIA_CLIENTE;
        
        if ($modo === 'CBC') {
            if (!isset($dadosCriptografados['iv']) || !isset($dadosCriptografados['dados'])) {
                error_log("[CRIPTO] Campos IV ou dados faltando para CBC");
                return null;
            }
            
            $iv = base64_decode($dadosCriptografados['iv']);
            $dadosCifrados = base64_decode($dadosCriptografados['dados']);
            
            // Usar chave de 32 caracteres para AES-256
            if (strlen($chaveTexto) >= 32) {
                $chave = substr($chaveTexto, 0, 32);
            } else {
                $chave = str_pad($chaveTexto, 32, '0');
            }
            
            error_log("[CRIPTO] Tentando AES-256-CBC...");
            
            $dadosDescriptografados = openssl_decrypt(
                $dadosCifrados,
                'aes-256-cbc',
                $chave,
                OPENSSL_RAW_DATA,
                $iv
            );
            
        } else {
            // Modo ECB (fallback)
            if (!isset($dadosCriptografados['dados'])) {
                error_log("[CRIPTO] Campo dados faltando para ECB");
                return null;
            }
            
            $dadosCifrados = base64_decode($dadosCriptografados['dados']);
            
            // Usar chave de 16 caracteres para AES-128
            if (strlen($chaveTexto) >= 16) {
                $chave = substr($chaveTexto, 0, 16);
            } else {
                $chave = str_pad($chaveTexto, 16, 'X');
            }
            
            error_log("[CRIPTO] Tentando AES-128-ECB...");
            
            $dadosDescriptografados = openssl_decrypt(
                $dadosCifrados,
                'aes-128-ecb',
                $chave,
                OPENSSL_RAW_DATA
            );
        }
        
        if ($dadosDescriptografados === false) {
            $erro = openssl_error_string();
            error_log("[CRIPTO] Falha na descriptografia: " . $erro);
            return null;
        }
        
        $dadosDescriptografados = trim($dadosDescriptografados);
        $resultado = json_decode($dadosDescriptografados, true);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            error_log("[CRIPTO] JSON inválido: " . json_last_error_msg());
            error_log("[CRIPTO] Conteúdo: " . substr($dadosDescriptografados, 0, 200));
            return null;
        }
        
        error_log("[CRIPTO] Descriptografia bem sucedida!");
        return $resultado;
        
    } catch (Exception $e) {
        error_log("[CRIPTO] Exceção: " . $e->getMessage());
        return null;
    }
}

/**
 * Registra evento de login no banco via procedure (compatível com blockchain)
 * 
 * @param string      $tipoEvento       Tipo do evento (LOGIN_ATTEMPT, LOGIN_SUCCESS, LOGIN_FAILED_*, etc.)
 * @param int|null    $idUsuario        ID do usuário (pode ser null se não autenticado)
 * @param string|null $emailInformado   Email EXATO informado pelo usuário (obrigatório para salvar em email_informado)
 * @param string      $ip               IP do cliente
 * @param string      $userAgent        User-Agent do navegador
 */
function registrarEventoBlockchain($tipoEvento, $idUsuario = null, $emailInformado = null, $ip, $userAgent) {
    try {
        $conn = conectarBancoDados();
        
        // Garante que sempre tenha um valor (evita NULL na procedure)
        $emailParaSalvar = trim($emailInformado ?? '') ?: '(não informado)';
        
        error_log("[BLOCKCHAIN] Registrando evento: $tipoEvento | Email: $emailParaSalvar | ID usuário: " . ($idUsuario ?? 'null') . " | IP: $ip");
        
        // Chama a procedure existente no banco
        $stmt = $conn->prepare("CALL registrar_evento_login(?, ?, ?, ?, ?)");
        $stmt->execute([
            $tipoEvento,
            $idUsuario,
            $emailParaSalvar,      // ← Email em texto puro → será salvo em email_informado
            $ip,
            $userAgent
        ]);
        
        error_log("[BLOCKCHAIN] Evento registrado com sucesso: $tipoEvento | Email: $emailParaSalvar");
        
        // Opcional: força criação de novo bloco se desejar (caso o event não esteja ativo)
        // $conn->exec("CALL criar_novo_bloco();");
        
    } catch (Exception $e) {
        error_log("[BLOCKCHAIN] ERRO CRÍTICO ao registrar evento '$tipoEvento': " . $e->getMessage());
        
        // Fallback: registra falha em logs_seguranca
        try {
            $conn->prepare("
                INSERT INTO logs_seguranca 
                (tipo_log, severidade, descricao, ip_origem, user_agent, data_hora)
                VALUES ('falha_registro_evento', 'alta', ?, ?, ?, NOW())
            ")->execute([
                "Falha ao registrar evento $tipoEvento - Email: " . ($emailParaSalvar ?? 'n/a') . " - Erro: " . $e->getMessage(),
                $ip,
                $userAgent
            ]);
        } catch (Exception $fallbackError) {
            error_log("[FALLBACK] Falha ao logar erro de registro: " . $fallbackError->getMessage());
        }
    }
}

/**
 * Verifica se MFA está ativo para um determinado email
 */
function verificarMFAAtivo($email) {
    try {
        $conn = conectarBancoDados();
        $emailHash = hash('sha256', $email);
        
        $stmt = $conn->prepare("SELECT mfa_codigo_hash FROM usuarios WHERE email_hash = ? AND ativo = 1");
        $stmt->execute([$emailHash]);
        $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
        
        return $usuario && !empty($usuario['mfa_codigo_hash']);
        
    } catch (Exception $e) {
        error_log("Erro ao verificar MFA ativo: " . $e->getMessage());
        return false;
    }
}

/**
 * Inicializa sessão segura com boas práticas
 */
function iniciarSessaoSegura() {
    if (session_status() === PHP_SESSION_NONE) {
        // Configurações seguras de sessão
        ini_set('session.cookie_httponly', 1);
        ini_set('session.cookie_secure', isset($_SERVER['HTTPS']) ? 1 : 0);
        ini_set('session.cookie_samesite', 'Strict');
        ini_set('session.use_strict_mode', 1);
        ini_set('session.use_only_cookies', 1);
        
        session_name('AUTH_BLOCKCHAIN_SESSION');
        session_start();
        
        // Regenerar ID de sessão periodicamente (a cada 5 minutos)
        if (!isset($_SESSION['ultima_regeneracao']) || 
            (time() - $_SESSION['ultima_regeneracao'] > 300)) {
            session_regenerate_id(true);
            $_SESSION['ultima_regeneracao'] = time();
        }
        
        // Gerar token CSRF se não existir
        if (!isset($_SESSION['token_form'])) {
            $_SESSION['token_form'] = bin2hex(random_bytes(32));
        }
        
        // Verificar expiração de sessão
        if (isset($_SESSION['ultima_atividade']) && 
            (time() - $_SESSION['ultima_atividade'] > TEMPO_EXPIRACAO_SESSAO)) {
            session_unset();
            session_destroy();
            session_start();
            $_SESSION['token_form'] = bin2hex(random_bytes(32));
        }
        
        $_SESSION['ultima_atividade'] = time();
    }
}

// Inicializar sessão segura automaticamente ao incluir este arquivo
iniciarSessaoSegura();
?>