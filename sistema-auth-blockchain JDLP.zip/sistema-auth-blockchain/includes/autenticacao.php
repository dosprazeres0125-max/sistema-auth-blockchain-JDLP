<?php
require_once 'config.php';
require_once 'funcoes-seguranca.php';

// Verificar autenticação em todas as páginas protegidas
function requererAutenticacao($permissao_minima = 'user') {
    verificarAutenticacao();
    
    if (!verificarPermissao($permissao_minima)) {
        redirecionarComMensagem('dashboard.php', 'error', 'Permissão Negada', 'Você não tem permissão para acessar esta página.');
    }
}

// Verificar se precisa criar MFA (para primeiro login)
function verificarNecessidadeMFA() {
    if (!isset($_SESSION['id_usuario'])) {
        return false;
    }
    
    $usuario = obterUsuarioAtual();
    if (!$usuario) {
        return false;
    }
    
    // Se não tem MFA cadastrado e é primeiro login
    if (empty($usuario['mfa_codigo_hash']) && (!isset($_SESSION['mfa_criado']) || !$_SESSION['mfa_criado'])) {
        return true;
    }
    
    return false;
}

// Função para criar MFA
function criarMFAParaUsuario($id_usuario, $codigo_mfa) {
    $conn = conectarBanco();
    if (!$conn) return false;
    
    $hash_mfa = criarHashMFA($codigo_mfa);
    
    $stmt = $conn->prepare("UPDATE usuarios SET mfa_codigo_hash = ?, mfa_ultima_alteracao = NOW() WHERE id_usuario = ?");
    $stmt->bind_param("si", $hash_mfa, $id_usuario);
    $result = $stmt->execute();
    
    if ($result) {
        registrarEventoBlockchain('mfa_criado', $id_usuario);
    }
    
    $stmt->close();
    $conn->close();
    
    return $result;
}

// Função para atualizar MFA
function atualizarMFAParaUsuario($id_usuario, $codigo_mfa) {
    $conn = conectarBanco();
    if (!$conn) return false;
    
    $hash_mfa = criarHashMFA($codigo_mfa);
    
    $stmt = $conn->prepare("UPDATE usuarios SET mfa_codigo_hash = ?, mfa_ultima_alteracao = NOW() WHERE id_usuario = ?");
    $stmt->bind_param("si", $hash_mfa, $id_usuario);
    $result = $stmt->execute();
    
    if ($result) {
        registrarEventoBlockchain('mfa_atualizado', $id_usuario);
    }
    
    $stmt->close();
    $conn->close();
    
    return $result;
}

// Função para desativar MFA
function desativarMFAParaUsuario($id_usuario) {
    $conn = conectarBanco();
    if (!$conn) return false;
    
    $stmt = $conn->prepare("UPDATE usuarios SET mfa_codigo_hash = NULL, mfa_ultima_alteracao = NOW() WHERE id_usuario = ?");
    $stmt->bind_param("i", $id_usuario);
    $result = $stmt->execute();
    
    if ($result) {
        registrarEventoBlockchain('mfa_desativado', $id_usuario);
    }
    
    $stmt->close();
    $conn->close();
    
    return $result;
}

// Função para verificar código MFA
function verificarMFACodigo($id_usuario, $codigo_mfa) {
    $conn = conectarBanco();
    if (!$conn) return false;
    
    $stmt = $conn->prepare("SELECT mfa_codigo_hash FROM usuarios WHERE id_usuario = ?");
    $stmt->bind_param("i", $id_usuario);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        $stmt->close();
        $conn->close();
        return false;
    }
    
    $usuario = $result->fetch_assoc();
    $stmt->close();
    $conn->close();
    
    return verificarCodigoMFA($codigo_mfa, $usuario['mfa_codigo_hash']);
}
?>