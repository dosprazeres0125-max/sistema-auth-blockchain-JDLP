<?php
// Configurações do Sistema
define('NOME_SISTEMA', 'Sistema Auth Blockchain');
define('VERSAO', '2.0.0');

// Chave de criptografia (NUNCA compartilhe esta chave)
define('CHAVE_CRIPTOGRAFIA_CLIENTE', 'SistemaAuthBlockchain2026!@#SegurancaMaxima$$$');

// Caminhos
define('CAMINHO_FAVICON', 'assets/img/favicon.png');

// Configurações do Banco de Dados
define('HOST', 'localhost');
define('USUARIO', 'root');
define('SENHA', '');
define('BANCO', 'auth_blockchain');
define('PORTA', '3306');
define('CHARSET', 'utf8mb4');

// Configurações de Segurança
define('TEMPO_EXPIRACAO_SESSAO', 1800); // 30 minutos em segundos
define('MAX_TENTATIVAS_LOGIN', 5);
define('TEMPO_BLOQUEIO_LOGIN', 900); // 15 minutos em segundos

// Função para conexão com o banco de dados
function conectarBancoDados() {
    $dsn = "mysql:host=" . HOST . ";port=" . PORTA . ";dbname=" . BANCO . ";charset=" . CHARSET;
    $opcoes = [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
        PDO::ATTR_PERSISTENT => false,
        PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES " . CHARSET
    ];
    
    try {
        $pdo = new PDO($dsn, USUARIO, SENHA, $opcoes);
        $pdo->exec("SET time_zone = '-03:00'"); // Timezone Brasil
        return $pdo;
    } catch (PDOException $e) {
        error_log("Erro na conexão com o banco de dados: " . $e->getMessage());
        header('HTTP/1.1 500 Internal Server Error');
        die(json_encode(['success' => false, 'error' => 'Erro interno do servidor']));
    }
}

// Inicializar sessão se não estiver iniciada
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>