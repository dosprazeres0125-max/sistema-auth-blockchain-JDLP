<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/funcoes-seguranca.php';

if (!isset($_SESSION['id_usuario']) || !in_array($_SESSION['tipo_usuario'] ?? '', ['admin', 'auditor'])) {
    echo json_encode(['success' => false, 'message' => 'Acesso não autorizado']);
    exit;
}

try {
    $pdo = conectarBancoDados();
    
    // Verificação simples: conta blocos quebrados (hash_anterior não encontrado)
    $stmt = $pdo->query("
        SELECT COUNT(*) 
        FROM registro_eventos re
        LEFT JOIN registro_eventos prev ON re.hash_anterior = prev.hash_transacao
        WHERE re.hash_anterior IS NOT NULL AND prev.id_evento IS NULL
    ");
    
    $problemas = $stmt->fetchColumn();
    
    $success = $problemas === 0;
    $message = $success 
        ? "Blockchain íntegra - todos os hashes anteriores encontrados."
        : "Detectados $problemas problemas de integridade na cadeia.";
    
    echo json_encode([
        'success' => $success,
        'message' => $message,
        'total_blocos' => $pdo->query("SELECT COUNT(*) FROM registro_eventos")->fetchColumn(),
        'problemas' => $problemas
    ]);
    
} catch (Exception $e) {
    error_log("Erro ao verificar integridade completa: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'Erro ao verificar a blockchain completa'
    ]);
} 