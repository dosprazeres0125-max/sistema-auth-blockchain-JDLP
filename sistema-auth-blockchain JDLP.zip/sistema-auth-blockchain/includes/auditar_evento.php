<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/funcoes-seguranca.php';

if (!isset($_SESSION['id_usuario']) || $_SESSION['tipo_usuario'] !== 'auditor') {
    echo json_encode(['success' => false, 'message' => 'Apenas auditores podem realizar auditoria individual']);
    exit;
}

$id_evento = (int)($_POST['id_evento'] ?? 0);

if ($id_evento <= 0) {
    echo json_encode(['success' => false, 'message' => 'ID inválido']);
    exit;
}

try {
    $pdo = conectarBancoDados();
    
    // Aqui você pode implementar a lógica real de auditoria
    // Por exemplo: registrar que o auditor visualizou/verficou o evento
    $stmt = $pdo->prepare("
        INSERT INTO auditorias_realizadas (id_evento, id_auditor, data_auditoria, observacao)
        VALUES (:evento, :auditor, NOW(), 'Auditoria manual realizada')
    ");
    
    $stmt->execute([
        ':evento' => $id_evento,
        ':auditor' => $_SESSION['id_usuario']
    ]);
    
    echo json_encode([
        'success' => true,
        'message' => 'Evento auditado com sucesso'
    ]);
    
} catch (Exception $e) {
    error_log("Erro ao auditar evento: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'Erro ao registrar auditoria'
    ]);
}