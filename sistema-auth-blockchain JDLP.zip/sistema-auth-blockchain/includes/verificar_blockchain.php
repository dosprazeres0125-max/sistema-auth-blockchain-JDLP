<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/funcoes-seguranca.php';

if (!isset($_SESSION['id_usuario']) || !in_array($_SESSION['tipo_usuario'] ?? '', ['admin', 'auditor'])) {
    echo json_encode(['success' => false, 'message' => 'Acesso não autorizado']);
    exit;
}

$hash_transacao = $_POST['hash_transacao'] ?? '';
$id_evento = (int)($_POST['id_evento'] ?? 0);

if (empty($hash_transacao) || $id_evento <= 0) {
    echo json_encode(['success' => false, 'message' => 'Parâmetros inválidos']);
    exit;
}

try {
    $pdo = conectarBancoDados();
    
    // Busca o registro do evento
    $stmt = $pdo->prepare("SELECT * FROM registro_eventos WHERE id_evento = :id AND hash_transacao = :hash LIMIT 1");
    $stmt->execute([':id' => $id_evento, ':hash' => $hash_transacao]);
    $evento = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$evento) {
        echo json_encode(['success' => false, 'message' => 'Evento ou hash não encontrado']);
        exit;
    }
    
    // Aqui você implementa a lógica real de verificação na blockchain
    // Exemplo simplificado: compara hash anterior e hash do conteúdo
    $integridade_ok = true;
    $mensagem = "Transação verificada com sucesso";
    
    // Exemplo de verificação (adapte conforme sua implementação real)
    if (!empty($evento['hash_anterior'])) {
        $stmt_prev = $pdo->prepare("SELECT hash_conteudo FROM registro_eventos WHERE hash_transacao = :prev_hash LIMIT 1");
        $stmt_prev->execute([':prev_hash' => $evento['hash_anterior']]);
        $prev = $stmt_prev->fetchColumn();
        
        if ($prev === false || $prev !== $evento['hash_conteudo']) {  // exemplo de verificação
            $integridade_ok = false;
            $mensagem = "Hash anterior não corresponde - possível adulteração";
        }
    }
    
    echo json_encode([
        'success' => true,
        'verificacao' => [
            'integridade_verificada' => $integridade_ok,
            'mensagem' => $mensagem,
            'hash_transacao' => $hash_transacao,
            'bloco_hash' => $evento['bloco_hash'],
            'hash_anterior' => $evento['hash_anterior']
            // adicione mais campos se desejar
        ]
    ]);
    
} catch (Exception $e) {
    error_log("Erro ao verificar blockchain: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'Erro ao verificar integridade'
    ]);
}