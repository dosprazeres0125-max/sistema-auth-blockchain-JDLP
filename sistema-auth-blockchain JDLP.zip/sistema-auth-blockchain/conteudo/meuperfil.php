<?php
// conteudo/meuperfil.php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/funcoes-seguranca.php';

// Verificar se o usuário está logado
if (!isset($_SESSION['id_usuario']) || empty($_SESSION['id_usuario'])) {
    echo '<div class="p-6 text-center text-white">Faça login para acessar esta página</div>';
    return;
}

// Usar tema da sessão
$temaAtual = $_SESSION['tema'] ?? 'dark';

// Conectar ao banco de dados
try {
    $pdo = conectarBancoDados();
    
    // Buscar dados do usuário
    $idUsuario = $_SESSION['id_usuario'];
    $queryUsuario = "
        SELECT 
            u.*,
            p.nome_perfil,
            p.descricao as descricao_perfil,
            p.permissoes
        FROM usuarios u
        LEFT JOIN perfis_acesso p ON u.tipo_usuario COLLATE utf8mb4_unicode_ci = p.nome_perfil
        WHERE u.id_usuario = ?
    ";
    
    $stmtUsuario = $pdo->prepare($queryUsuario);
    $stmtUsuario->execute([$idUsuario]);
    $usuario = $stmtUsuario->fetch(PDO::FETCH_ASSOC);
    
    if (!$usuario) {
        echo '<div class="p-6 text-center text-red-500">Usuário não encontrado</div>';
        return;
    }
    
    // Buscar estatísticas do usuário
    $queryEstatisticas = "
        SELECT 
            (SELECT COUNT(*) FROM registro_eventos WHERE id_usuario = ?) as total_eventos,
            (SELECT COUNT(*) FROM sessoes_ativas WHERE id_usuario = ? AND expiracao > NOW()) as sessoes_ativas,
            (SELECT COUNT(*) FROM logs_seguranca WHERE id_usuario = ? AND severidade IN ('alta', 'critica')) as logs_importantes,
            (SELECT COUNT(*) FROM notificacoes_sistema WHERE id_usuario = ? AND lida = 0) as notificacoes_pendentes
    ";
    
    $stmtEstatisticas = $pdo->prepare($queryEstatisticas);
    $stmtEstatisticas->execute([$idUsuario, $idUsuario, $idUsuario, $idUsuario]);
    $estatisticas = $stmtEstatisticas->fetch(PDO::FETCH_ASSOC);
    
    // Buscar atividades recentes (apenas 5)
    $queryAtividades = "
        SELECT 
            tipo_evento,
            ip_origem,
            user_agent,
            data_hora
        FROM registro_eventos 
        WHERE id_usuario = ?
        ORDER BY data_hora DESC 
        LIMIT 5
    ";
    
    $stmtAtividades = $pdo->prepare($queryAtividades);
    $stmtAtividades->execute([$idUsuario]);
    $atividades = $stmtAtividades->fetchAll(PDO::FETCH_ASSOC);
    
    // Verificar se tem MFA ativo
    $mfaAtivo = !empty($usuario['mfa_codigo_hash']);
    
    // Decodificar permissões
    $permissoes = json_decode($usuario['permissoes'] ?? '{}', true);
    
} catch (Exception $e) {
    error_log("Erro ao carregar perfil: " . $e->getMessage());
    $usuario = [];
    $estatisticas = [];
    $atividades = [];
    $mfaAtivo = false;
    $permissoes = [];
}
?>

<div class="max-w-7xl mx-auto p-4 sm:p-6">
    <!-- Cabeçalho -->
    <div class="mb-6 md:mb-8">
        <div class="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
            <div class="mb-4 md:mb-0">
                <h1 class="text-2xl md:text-3xl font-bold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?> mb-2">
                    Meu Perfil
                </h1>
                <div class="flex items-center space-x-2 text-sm <?= $temaAtual === 'dark' ? 'text-gray-400' : 'text-gray-600' ?>">
                    <span>Dashboard</span>
                    <i class="fas fa-chevron-right text-xs"></i>
                    <span class="text-blue-400">Meu Perfil</span>
                </div>
            </div>
        </div>
        
        <div class="flex items-center space-x-6">
            <div class="relative">
                <div class="w-20 h-20 rounded-full bg-gradient-to-br from-blue-400 to-blue-600 flex items-center justify-center shadow-lg">
                    <span class="text-white font-bold text-2xl">
                        <?= strtoupper(substr($usuario['nome_completo'] ?? 'U', 0, 1)) ?>
                    </span>
                </div>
                <div class="absolute -bottom-1 -right-1 w-5 h-5 bg-green-500 rounded-full border-2 <?= $temaAtual === 'dark' ? 'border-gray-800' : 'border-white' ?>"></div>
            </div>
            
            <div class="flex-1">
                <div class="flex items-center space-x-3 mb-2">
                    <h2 class="text-xl font-bold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?>">
                        <?= htmlspecialchars($usuario['nome_completo'] ?? 'Usuário') ?>
                    </h2>
                    <span class="px-3 py-1 text-xs <?= $usuario['tipo_usuario'] === 'admin' ? 'bg-purple-500/20 text-purple-300' : ($usuario['tipo_usuario'] === 'auditor' ? 'bg-green-500/20 text-green-300' : 'bg-blue-500/20 text-blue-300') ?> rounded-full font-medium">
                        <i class="fas <?= $usuario['tipo_usuario'] === 'admin' ? 'fa-crown' : ($usuario['tipo_usuario'] === 'auditor' ? 'fa-search' : 'fa-user') ?> mr-1"></i>
                        <?= ucfirst($usuario['tipo_usuario'] ?? 'user') ?>
                    </span>
                </div>
                
                <p class="<?= $temaAtual === 'dark' ? 'text-gray-300' : 'text-gray-700' ?> mb-1">
                    <?= htmlspecialchars($usuario['email'] ?? '') ?>
                </p>
                
                <div class="flex items-center space-x-4 text-sm <?= $temaAtual === 'dark' ? 'text-gray-400' : 'text-gray-600' ?>">
                    <div class="flex items-center">
                        <i class="fas fa-calendar-alt mr-2"></i>
                        <span>Membro desde <?= date('d/m/Y', strtotime($usuario['data_criacao'] ?? 'now')) ?></span>
                    </div>
                    <div class="flex items-center">
                        <i class="fas fa-sign-in-alt mr-2"></i>
                        <span>Último login: <?= $usuario['data_ultimo_login'] ? date('d/m/Y H:i', strtotime($usuario['data_ultimo_login'])) : 'Nunca' ?></span>
                    </div>
                </div>
            </div>
            
            <div class="text-right hidden md:block">
                <div class="text-xs <?= $temaAtual === 'dark' ? 'text-gray-400' : 'text-gray-600' ?>">Status</div>
                <div class="flex items-center justify-end space-x-2 mt-1">
                    <div class="w-2 h-2 rounded-full <?= ($usuario['ativo'] ?? 0) ? 'bg-green-500' : 'bg-red-500' ?>"></div>
                    <span class="text-sm font-medium <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?>">
                        <?= ($usuario['ativo'] ?? 0) ? 'Ativo' : 'Inativo' ?>
                    </span>
                </div>
            </div>
        </div>
    </div>

    <!-- Grid Principal -->
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <!-- Coluna Esquerda - Perfil e Estatísticas -->
        <div class="lg:col-span-2 space-y-6">
            <!-- Informações do Perfil -->
            <div class="card-light">
                <div class="p-6">
                    <div class="flex items-center justify-between mb-6">
                        <h3 class="text-lg font-bold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?> flex items-center">
                            <i class="fas fa-id-card text-blue-400 mr-3"></i>
                            Informações do Perfil
                        </h3>
                        <button onclick="editarPerfil()" 
                                class="px-4 py-2 text-sm <?= $temaAtual === 'dark' ? 'bg-white/10 hover:bg-white/20 text-white' : 'bg-gray-100 hover:bg-gray-200 text-gray-800' ?> rounded-lg clickable transition-colors duration-200 flex items-center">
                            <i class="fas fa-edit mr-2"></i> Editar
                        </button>
                    </div>
                    
                    <div class="space-y-6">
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label class="block text-sm <?= $temaAtual === 'dark' ? 'text-gray-400' : 'text-gray-600' ?> mb-2">Nome Completo</label>
                                <div class="p-3 <?= $temaAtual === 'dark' ? 'bg-white/5 border-white/10' : 'bg-gray-50 border-gray-200' ?> rounded-lg border">
                                    <span class="<?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?>"><?= htmlspecialchars($usuario['nome_completo'] ?? '') ?></span>
                                </div>
                            </div>
                            
                            <div>
                                <label class="block text-sm <?= $temaAtual === 'dark' ? 'text-gray-400' : 'text-gray-600' ?> mb-2">Email</label>
                                <div class="p-3 <?= $temaAtual === 'dark' ? 'bg-white/5 border-white/10' : 'bg-gray-50 border-gray-200' ?> rounded-lg border">
                                    <span class="<?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?>"><?= htmlspecialchars($usuario['email'] ?? '') ?></span>
                                </div>
                            </div>
                        </div>
                        
                        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                            <div>
                                <label class="block text-sm <?= $temaAtual === 'dark' ? 'text-gray-400' : 'text-gray-600' ?> mb-2">Tipo de Usuário</label>
                                <div class="p-3 <?= $temaAtual === 'dark' ? 'bg-white/5 border-white/10' : 'bg-gray-50 border-gray-200' ?> rounded-lg border">
                                    <div class="flex items-center">
                                        <span class="px-2 py-1 text-xs <?= $usuario['tipo_usuario'] === 'admin' ? 'bg-purple-500/20 text-purple-300' : ($usuario['tipo_usuario'] === 'auditor' ? 'bg-green-500/20 text-green-300' : 'bg-blue-500/20 text-blue-300') ?> rounded-full mr-2">
                                            <?= ucfirst($usuario['tipo_usuario'] ?? 'user') ?>
                                        </span>
                                        <span class="text-xs <?= $temaAtual === 'dark' ? 'text-gray-400' : 'text-gray-500' ?> truncate">
                                            <?= htmlspecialchars($usuario['descricao_perfil'] ?? '') ?>
                                        </span>
                                    </div>
                                </div>
                            </div>
                            
                            <div>
                                <label class="block text-sm <?= $temaAtual === 'dark' ? 'text-gray-400' : 'text-gray-600' ?> mb-2">Status</label>
                                <div class="p-3 <?= $temaAtual === 'dark' ? 'bg-white/5 border-white/10' : 'bg-gray-50 border-gray-200' ?> rounded-lg border">
                                    <div class="flex items-center">
                                        <div class="w-2 h-2 rounded-full mr-2 <?= ($usuario['ativo'] ?? 0) ? 'bg-green-500' : 'bg-red-500' ?>"></div>
                                        <span class="<?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?>"><?= ($usuario['ativo'] ?? 0) ? 'Ativo' : 'Inativo' ?></span>
                                    </div>
                                </div>
                            </div>
                            
                            <div>
                                <label class="block text-sm <?= $temaAtual === 'dark' ? 'text-gray-400' : 'text-gray-600' ?> mb-2">Último IP</label>
                                <div class="p-3 <?= $temaAtual === 'dark' ? 'bg-white/5 border-white/10' : 'bg-gray-50 border-gray-200' ?> rounded-lg border">
                                    <span class="<?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?> font-mono text-sm"><?= htmlspecialchars($usuario['ultimo_ip'] ?? 'N/A') ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Estatísticas -->
            <div class="card-light">
                <div class="p-6">
                    <h3 class="text-lg font-bold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?> flex items-center mb-6">
                        <i class="fas fa-chart-bar text-blue-400 mr-3"></i>
                        Estatísticas
                    </h3>
                    
                    <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                        <div class="text-center p-4 <?= $temaAtual === 'dark' ? 'bg-white/5' : 'bg-gray-50' ?> rounded-xl border <?= $temaAtual === 'dark' ? 'border-white/10' : 'border-gray-200' ?>">
                            <div class="text-2xl font-bold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?> mb-1"><?= number_format($estatisticas['total_eventos'] ?? 0) ?></div>
                            <div class="text-xs <?= $temaAtual === 'dark' ? 'text-gray-400' : 'text-gray-600' ?>">Eventos</div>
                            <div class="mt-2">
                                <i class="fas fa-history text-blue-400"></i>
                            </div>
                        </div>
                        
                        <div class="text-center p-4 <?= $temaAtual === 'dark' ? 'bg-white/5' : 'bg-gray-50' ?> rounded-xl border <?= $temaAtual === 'dark' ? 'border-white/10' : 'border-gray-200' ?>">
                            <div class="text-2xl font-bold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?> mb-1"><?= number_format($estatisticas['sessoes_ativas'] ?? 0) ?></div>
                            <div class="text-xs <?= $temaAtual === 'dark' ? 'text-gray-400' : 'text-gray-600' ?>">Sessões Ativas</div>
                            <div class="mt-2">
                                <i class="fas fa-user-clock text-green-400"></i>
                            </div>
                        </div>
                        
                        <div class="text-center p-4 <?= $temaAtual === 'dark' ? 'bg-white/5' : 'bg-gray-50' ?> rounded-xl border <?= $temaAtual === 'dark' ? 'border-white/10' : 'border-gray-200' ?>">
                            <div class="text-2xl font-bold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?> mb-1"><?= number_format($estatisticas['logs_importantes'] ?? 0) ?></div>
                            <div class="text-xs <?= $temaAtual === 'dark' ? 'text-gray-400' : 'text-gray-600' ?>">Logs Importantes</div>
                            <div class="mt-2">
                                <i class="fas fa-exclamation-triangle text-orange-400"></i>
                            </div>
                        </div>
                        
                        <div class="text-center p-4 <?= $temaAtual === 'dark' ? 'bg-white/5' : 'bg-gray-50' ?> rounded-xl border <?= $temaAtual === 'dark' ? 'border-white/10' : 'border-gray-200' ?>">
                            <div class="text-2xl font-bold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?> mb-1"><?= number_format($estatisticas['notificacoes_pendentes'] ?? 0) ?></div>
                            <div class="text-xs <?= $temaAtual === 'dark' ? 'text-gray-400' : 'text-gray-600' ?>">Notificações</div>
                            <div class="mt-2">
                                <i class="fas fa-bell text-purple-400"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Atividades Recentes -->
            <div class="card-light">
                <div class="p-6">
                    <h3 class="text-lg font-bold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?> flex items-center mb-6">
                        <i class="fas fa-history text-blue-400 mr-3"></i>
                        Atividades Recentes
                    </h3>
                    
                    <div class="space-y-3">
                        <?php if (count($atividades) > 0): ?>
                            <?php foreach ($atividades as $atividade): ?>
                                <div class="p-3 <?= $temaAtual === 'dark' ? 'bg-white/5 border-white/10' : 'bg-gray-50 border-gray-200' ?> rounded-lg border">
                                    <div class="flex justify-between items-start">
                                        <div>
                                            <div class="font-medium <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?> text-sm mb-1">
                                                <?= htmlspecialchars($atividade['tipo_evento']) ?>
                                            </div>
                                            <div class="text-xs <?= $temaAtual === 'dark' ? 'text-gray-400' : 'text-gray-600' ?> flex items-center">
                                                <i class="fas fa-globe mr-1"></i>
                                                <span class="truncate max-w-xs"><?= htmlspecialchars($atividade['ip_origem']) ?></span>
                                            </div>
                                        </div>
                                        <div class="text-right">
                                            <div class="text-xs <?= $temaAtual === 'dark' ? 'text-gray-400' : 'text-gray-600' ?>">
                                                <?= date('H:i', strtotime($atividade['data_hora'])) ?>
                                            </div>
                                            <div class="text-xs <?= $temaAtual === 'dark' ? 'text-gray-400' : 'text-gray-600' ?>">
                                                <?= date('d/m/Y', strtotime($atividade['data_hora'])) ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="text-center py-8 <?= $temaAtual === 'dark' ? 'text-gray-400' : 'text-gray-500' ?>">
                                <i class="fas fa-info-circle text-2xl mb-2"></i>
                                <p class="text-sm">Nenhuma atividade recente</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Coluna Direita - Segurança -->
        <div class="space-y-6">
            <!-- Segurança -->
            <div class="card-light">
                <div class="p-6">
                    <h3 class="text-lg font-bold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?> flex items-center mb-6">
                        <i class="fas fa-shield-alt text-green-400 mr-3"></i>
                        Segurança
                    </h3>
                    
                    <div class="space-y-4">
                        <!-- MFA -->
                        <div class="p-4 <?= $mfaAtivo ? 'bg-green-500/10 border-green-500/20' : 'bg-red-500/10 border-red-500/20' ?> rounded-xl border">
                            <div class="flex items-center justify-between">
                                <div>
                                    <div class="font-medium <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?>">Autenticação em Duas Etapas</div>
                                    <div class="text-xs <?= $temaAtual === 'dark' ? 'text-gray-400' : 'text-gray-600' ?> mt-1">
                                        <?= $mfaAtivo ? 'Ativada' : 'Desativada' ?>
                                        <?php if ($mfaAtivo && $usuario['mfa_ultima_alteracao']): ?>
                                            em <?= date('d/m/Y', strtotime($usuario['mfa_ultima_alteracao'])) ?>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="text-right">
                                    <div class="text-sm font-bold <?= $mfaAtivo ? 'text-green-500' : 'text-red-500' ?>">
                                        <?= $mfaAtivo ? 'ATIVA' : 'INATIVA' ?>
                                    </div>
                                </div>
                            </div>
                            <div class="mt-3">
                                <button onclick="carregarPagina('seguranca')" 
                                        class="w-full py-2.5 text-sm btn-gradient text-white rounded-lg clickable transition-colors duration-200 flex items-center justify-center">
                                    <i class="fas <?= $mfaAtivo ? 'fa-cog' : 'fa-shield-alt' ?> mr-2"></i>
                                    <?= $mfaAtivo ? 'Gerenciar MFA' : 'Configurar Segurança' ?>
                                </button>
                            </div>
                        </div>
                        
                        <!-- Alterar Senha -->
                        <div class="p-4 <?= $temaAtual === 'dark' ? 'bg-white/5 border-white/10' : 'bg-gray-50 border-gray-200' ?> rounded-xl border">
                            <div class="font-medium <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?> mb-2">Senha</div>
                            <div class="text-xs <?= $temaAtual === 'dark' ? 'text-gray-400' : 'text-gray-600' ?> mb-3">
                                Última alteração: <?= $usuario['data_criacao'] ? date('d/m/Y', strtotime($usuario['data_criacao'])) : 'Nunca' ?>
                            </div>
                            <button onclick="alterarSenha()" 
                                    class="w-full py-2.5 text-sm <?= $temaAtual === 'dark' ? 'bg-white/10 hover:bg-white/20 text-white' : 'bg-gray-100 hover:bg-gray-200 text-gray-800' ?> rounded-lg clickable transition-colors duration-200 flex items-center justify-center">
                                <i class="fas fa-key mr-2"></i> Alterar Senha
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Notificações -->
            <div class="card-light">
                <div class="p-6">
                    <div class="flex items-center justify-between mb-6">
                        <h3 class="text-lg font-bold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?> flex items-center">
                            <i class="fas fa-bell text-purple-400 mr-3"></i>
                            Notificações
                        </h3>
                        <span class="text-xs px-2 py-1 <?= $temaAtual === 'dark' ? 'bg-purple-500/20 text-purple-300' : 'bg-purple-100 text-purple-800' ?> rounded-full">
                            <?= $estatisticas['notificacoes_pendentes'] ?? 0 ?>
                        </span>
                    </div>
                    
                    <div class="space-y-3">
                        <?php if (($estatisticas['notificacoes_pendentes'] ?? 0) > 0): ?>
                            <div class="text-center p-4 <?= $temaAtual === 'dark' ? 'bg-white/5' : 'bg-gray-50' ?> rounded-xl">
                                <i class="fas fa-bell text-purple-400 text-xl mb-2"></i>
                                <p class="text-sm <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?>">
                                    Você tem <?= $estatisticas['notificacoes_pendentes'] ?> notificação(ões) pendente(s)
                                </p>
                                <button onclick="carregarPagina('notificacoes')" 
                                        class="mt-2 text-sm text-blue-500 hover:text-blue-400 clickable">
                                    Ver notificações
                                </button>
                            </div>
                        <?php else: ?>
                            <div class="text-center py-8 <?= $temaAtual === 'dark' ? 'text-gray-400' : 'text-gray-500' ?>">
                                <i class="fas fa-bell-slash text-2xl mb-2"></i>
                                <p class="text-sm">Nenhuma notificação pendente</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal Editar Perfil -->
<div id="modalEditarPerfil" class="modal-overlay" onclick="fecharModal()">
    <div class="modal-content" onclick="event.stopPropagation()">
        <div class="p-6 border-b <?= $temaAtual === 'dark' ? 'border-white/10' : 'border-gray-200' ?>">
            <div class="flex justify-between items-center">
                <h3 class="text-lg font-bold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?>">Editar Perfil</h3>
                <button onclick="fecharModal()" class="w-8 h-8 <?= $temaAtual === 'dark' ? 'hover:bg-white/10' : 'hover:bg-gray-100' ?> rounded-full flex items-center justify-center clickable">
                    <i class="fas fa-times <?= $temaAtual === 'dark' ? 'text-white/50' : 'text-gray-500' ?>"></i>
                </button>
            </div>
        </div>
        <div class="p-6">
            <form id="formEditarPerfil" onsubmit="salvarPerfil(event)">
                <div class="space-y-4">
                    <div>
                        <label class="block text-sm <?= $temaAtual === 'dark' ? 'text-gray-400' : 'text-gray-600' ?> mb-2">Nome Completo</label>
                        <input type="text" name="nome_completo" value="<?= htmlspecialchars($usuario['nome_completo'] ?? '') ?>" 
                               class="w-full p-3 border <?= $temaAtual === 'dark' ? 'border-white/10 bg-white/5 text-white' : 'border-gray-300 bg-white text-gray-900' ?> rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent" 
                               required>
                    </div>
                    
                    <div>
                        <label class="block text-sm <?= $temaAtual === 'dark' ? 'text-gray-400' : 'text-gray-600' ?> mb-2">Email</label>
                        <input type="email" name="email" value="<?= htmlspecialchars($usuario['email'] ?? '') ?>" 
                               class="w-full p-3 border <?= $temaAtual === 'dark' ? 'border-white/10 bg-white/5 text-white' : 'border-gray-300 bg-white text-gray-900' ?> rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent" 
                               required>
                    </div>
                    
                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm <?= $temaAtual === 'dark' ? 'text-gray-400' : 'text-gray-600' ?> mb-2">Tipo de Usuário</label>
                            <div class="p-3 <?= $temaAtual === 'dark' ? 'bg-white/5 border-white/10' : 'bg-gray-50 border-gray-200' ?> rounded-lg border">
                                <span class="<?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?>"><?= ucfirst($usuario['tipo_usuario'] ?? 'user') ?></span>
                            </div>
                        </div>
                        
                        <div>
                            <label class="block text-sm <?= $temaAtual === 'dark' ? 'text-gray-400' : 'text-gray-600' ?> mb-2">Status</label>
                            <div class="p-3 <?= $temaAtual === 'dark' ? 'bg-white/5 border-white/10' : 'bg-gray-50 border-gray-200' ?> rounded-lg border">
                                <div class="flex items-center">
                                    <div class="w-2 h-2 rounded-full mr-2 <?= ($usuario['ativo'] ?? 0) ? 'bg-green-500' : 'bg-red-500' ?>"></div>
                                    <span class="<?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?>"><?= ($usuario['ativo'] ?? 0) ? 'Ativo' : 'Inativo' ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="mt-6 flex justify-end space-x-3">
                    <button type="button" onclick="fecharModal()" 
                            class="px-4 py-2 <?= $temaAtual === 'dark' ? 'bg-white/10 hover:bg-white/20 text-white' : 'bg-gray-100 hover:bg-gray-200 text-gray-800' ?> rounded-lg clickable transition-colors">
                        Cancelar
                    </button>
                    <button type="submit" 
                            class="px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-lg clickable transition-colors">
                        <i class="fas fa-save mr-2"></i> Salvar Alterações
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal Alterar Senha -->
<div id="modalAlterarSenha" class="modal-overlay" onclick="fecharModalSenha()">
    <div class="modal-content" onclick="event.stopPropagation()">
        <div class="p-6 border-b <?= $temaAtual === 'dark' ? 'border-white/10' : 'border-gray-200' ?>">
            <div class="flex justify-between items-center">
                <h3 class="text-lg font-bold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?>">Alterar Senha</h3>
                <button onclick="fecharModalSenha()" class="w-8 h-8 <?= $temaAtual === 'dark' ? 'hover:bg-white/10' : 'hover:bg-gray-100' ?> rounded-full flex items-center justify-center clickable">
                    <i class="fas fa-times <?= $temaAtual === 'dark' ? 'text-white/50' : 'text-gray-500' ?>"></i>
                </button>
            </div>
        </div>
        <div class="p-6">
            <form id="formAlterarSenha" onsubmit="salvarSenha(event)">
                <div class="space-y-4">
                    <div>
                        <label class="block text-sm <?= $temaAtual === 'dark' ? 'text-gray-400' : 'text-gray-600' ?> mb-2">Senha Atual</label>
                        <input type="password" name="senha_atual" 
                               class="w-full p-3 border <?= $temaAtual === 'dark' ? 'border-white/10 bg-white/5 text-white' : 'border-gray-300 bg-white text-gray-900' ?> rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent" 
                               required>
                    </div>
                    
                    <div>
                        <label class="block text-sm <?= $temaAtual === 'dark' ? 'text-gray-400' : 'text-gray-600' ?> mb-2">Nova Senha</label>
                        <input type="password" name="nova_senha" 
                               class="w-full p-3 border <?= $temaAtual === 'dark' ? 'border-white/10 bg-white/5 text-white' : 'border-gray-300 bg-white text-gray-900' ?> rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent" 
                               required>
                        <div class="text-xs <?= $temaAtual === 'dark' ? 'text-gray-500' : 'text-gray-600' ?> mt-1">
                            Mínimo 8 caracteres, com letras, números e caracteres especiais
                        </div>
                    </div>
                    
                    <div>
                        <label class="block text-sm <?= $temaAtual === 'dark' ? 'text-gray-400' : 'text-gray-600' ?> mb-2">Confirmar Nova Senha</label>
                        <input type="password" name="confirmar_senha" 
                               class="w-full p-3 border <?= $temaAtual === 'dark' ? 'border-white/10 bg-white/5 text-white' : 'border-gray-300 bg-white text-gray-900' ?> rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent" 
                               required>
                    </div>
                </div>
                
                <div class="mt-6 flex justify-end space-x-3">
                    <button type="button" onclick="fecharModalSenha()" 
                            class="px-4 py-2 <?= $temaAtual === 'dark' ? 'bg-white/10 hover:bg-white/20 text-white' : 'bg-gray-100 hover:bg-gray-200 text-gray-800' ?> rounded-lg clickable transition-colors">
                        Cancelar
                    </button>
                    <button type="submit" 
                            class="px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-lg clickable transition-colors">
                        <i class="fas fa-key mr-2"></i> Alterar Senha
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    // Funções do perfil
    function editarPerfil() {
        document.getElementById('modalEditarPerfil').classList.add('active');
        document.body.style.overflow = 'hidden';
    }
    
    function salvarPerfil(event) {
        event.preventDefault();
        
        const form = event.target;
        const formData = new FormData(form);
        
        fetch('ajax/meuperfil.php?acao=editar', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                mostrarToast('success', 'Sucesso', 'Perfil atualizado com sucesso!');
                fecharModal();
                // Recarregar dados da página
                setTimeout(() => window.location.reload(), 1000);
            } else {
                mostrarToast('error', 'Erro', data.message || 'Erro ao atualizar perfil');
            }
        })
        .catch(error => {
            console.error('Erro:', error);
            mostrarToast('error', 'Erro', 'Erro ao atualizar perfil');
        });
    }
    
    function alterarSenha() {
        document.getElementById('modalAlterarSenha').classList.add('active');
        document.body.style.overflow = 'hidden';
    }
    
    function salvarSenha(event) {
        event.preventDefault();
        
        const form = event.target;
        const formData = new FormData(form);
        
        // Validar senhas
        const novaSenha = formData.get('nova_senha');
        const confirmarSenha = formData.get('confirmar_senha');
        
        if (novaSenha !== confirmarSenha) {
            mostrarToast('error', 'Erro', 'As senhas não coincidem');
            return;
        }
        
        if (novaSenha.length < 8) {
            mostrarToast('error', 'Erro', 'A senha deve ter no mínimo 8 caracteres');
            return;
        }
        
        fetch('ajax/meuperfil.php?acao=alterar_senha', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                mostrarToast('success', 'Sucesso', 'Senha alterada com sucesso!');
                fecharModalSenha();
                // Redirecionar para login após 2 segundos
                setTimeout(() => {
                    window.location.href = 'logout.php';
                }, 2000);
            } else {
                mostrarToast('error', 'Erro', data.message || 'Erro ao alterar senha');
            }
        })
        .catch(error => {
            console.error('Erro:', error);
            mostrarToast('error', 'Erro', 'Erro ao alterar senha');
        });
    }
    
    // Funções auxiliares
    function fecharModal() {
        document.getElementById('modalEditarPerfil').classList.remove('active');
        document.body.style.overflow = 'auto';
    }
    
    function fecharModalSenha() {
        document.getElementById('modalAlterarSenha').classList.remove('active');
        document.body.style.overflow = 'auto';
    }
</script>