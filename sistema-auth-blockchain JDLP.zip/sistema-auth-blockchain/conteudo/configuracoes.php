<?php
// conteudo/configuracoes.php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/funcoes-seguranca.php';

// Verificar se o usuário está logado e é admin
if (!isset($_SESSION['id_usuario']) || empty($_SESSION['id_usuario'])) {
    echo '<div class="p-6 text-center text-red-500">Sessão expirada. Faça login novamente.</div>';
    return;
}

if ($_SESSION['tipo_usuario'] !== 'admin') {
    echo '<div class="p-6 text-center text-red-500">Acesso negado. Apenas administradores podem acessar esta página.</div>';
    return;
}

// Usar tema da sessão
$temaAtual = $_SESSION['tema'] ?? 'dark';

// Garantir conexão com o banco
$pdo = conectarBancoDados();

// Carregar configurações atuais
try {
    // Verificar se a tabela configuracoes_sistema existe
    $stmt = $pdo->query("SHOW TABLES LIKE 'configuracoes_sistema'");
    $tabelaExiste = $stmt->fetch();
    
    if ($tabelaExiste) {
        $stmt = $pdo->query("SELECT chave, valor FROM configuracoes_sistema");
        $configs = [];
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $configs[$row['chave']] = $row['valor'];
        }
    } else {
        // Criar tabela se não existir
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS configuracoes_sistema (
                id_configuracao INT AUTO_INCREMENT PRIMARY KEY,
                chave VARCHAR(100) UNIQUE NOT NULL,
                valor TEXT,
                descricao TEXT,
                categoria VARCHAR(50) DEFAULT 'geral',
                tipo VARCHAR(20) DEFAULT 'texto',
                data_atualizacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            )
        ");
        
        // Inserir configurações padrão
        $configsPadrao = [
            ['nome_sistema', NOME_SISTEMA, 'Nome do sistema exibido na interface'],
            ['versao_sistema', VERSAO, 'Versão atual do sistema'],
            ['tempo_expiracao_sessao', '1800', 'Tempo de expiração da sessão em segundos'],
            ['mfa_obrigatorio', '0', 'MFA obrigatório para todos os usuários'],
            ['tentativas_login_max', '5', 'Número máximo de tentativas de login'],
            ['bloqueio_tempo', '900', 'Tempo de bloqueio após tentativas excedidas'],
            ['log_manutencao', '1', 'Manter logs de auditoria'],
            ['manutencao_modo', '0', 'Modo de manutenção ativado']
        ];
        
        $stmt = $pdo->prepare("
            INSERT INTO configuracoes_sistema (chave, valor, descricao) 
            VALUES (?, ?, ?)
            ON DUPLICATE KEY UPDATE valor = VALUES(valor)
        ");
        
        foreach ($configsPadrao as $config) {
            $stmt->execute($config);
        }
        
        $configs = [
            'nome_sistema' => NOME_SISTEMA,
            'versao_sistema' => VERSAO,
            'tempo_expiracao_sessao' => '1800',
            'mfa_obrigatorio' => '0',
            'tentativas_login_max' => '5',
            'bloqueio_tempo' => '900',
            'log_manutencao' => '1',
            'manutencao_modo' => '0'
        ];
    }
    
    // Valores para exibição
    $nomeSistema = $configs['nome_sistema'] ?? NOME_SISTEMA;
    $versao = $configs['versao_sistema'] ?? VERSAO;
    $tempoSessaoMin = (int)($configs['tempo_expiracao_sessao'] ?? 1800) / 60;
    $mfaObrigatorio = !empty($configs['mfa_obrigatorio']) && $configs['mfa_obrigatorio'] == '1';
    $tentativasLogin = (int)($configs['tentativas_login_max'] ?? 5);
    $bloqueioTempo = (int)($configs['bloqueio_tempo'] ?? 900) / 60; // segundos para minutos
    $logManutencao = !empty($configs['log_manutencao']) && $configs['log_manutencao'] == '1';
    $modoManutencao = !empty($configs['manutencao_modo']) && $configs['manutencao_modo'] == '1';
    
    // Estatísticas em tempo real
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM sessoes_ativas WHERE expiracao > NOW()");
    $usuariosOnline = $stmt->fetch()['total'] ?? 0;
    
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM registro_eventos WHERE DATE(data_hora) = CURDATE()");
    $eventosHoje = $stmt->fetch()['total'] ?? 0;
    
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM usuarios WHERE ativo = 1");
    $usuariosAtivos = $stmt->fetch()['total'] ?? 0;
    
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM logs_seguranca WHERE severidade IN ('alta', 'critica') AND DATE(data_hora) = CURDATE()");
    $alertasHoje = $stmt->fetch()['total'] ?? 0;

} catch (Exception $e) {
    error_log("Erro ao carregar configurações: " . $e->getMessage());
    $nomeSistema = NOME_SISTEMA;
    $versao = VERSAO;
    $tempoSessaoMin = 30;
    $mfaObrigatorio = false;
    $tentativasLogin = 5;
    $bloqueioTempo = 15;
    $logManutencao = true;
    $modoManutencao = false;
    $usuariosOnline = 0;
    $eventosHoje = 0;
    $usuariosAtivos = 0;
    $alertasHoje = 0;
}
?>

<div class="max-w-7xl mx-auto p-4 sm:p-6">
    <!-- Cabeçalho -->
    <div class="mb-6 md:mb-8">
        <div class="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
            <div class="mb-4 md:mb-0">
                <h1 class="text-2xl md:text-3xl font-bold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?> mb-2">
                    Configurações do Sistema
                </h1>
                <div class="flex items-center space-x-2 text-sm <?= $temaAtual === 'dark' ? 'text-gray-400' : 'text-gray-600' ?>">
                    <span>Dashboard</span>
                    <i class="fas fa-chevron-right text-xs"></i>
                    <span class="text-blue-400">Configurações</span>
                </div>
            </div>
            
            <div class="flex items-center space-x-3">
                <div class="text-right hidden md:block">
                    <div class="text-xs <?= $temaAtual === 'dark' ? 'text-gray-400' : 'text-gray-600' ?>">Status</div>
                    <div class="flex items-center justify-end space-x-2 mt-1">
                        <div class="w-2 h-2 rounded-full <?= $modoManutencao ? 'bg-red-500 animate-pulse' : 'bg-green-500' ?>"></div>
                        <span class="text-sm font-medium <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?>">
                            <?= $modoManutencao ? 'Manutenção' : 'Operacional' ?>
                        </span>
                    </div>
                </div>
                
                <button type="submit" form="form-configuracoes"
                        class="px-5 py-2.5 btn-gradient text-white font-medium rounded-lg shadow-sm transition-all duration-200 flex items-center gap-2 clickable">
                    <i class="fas fa-save"></i>
                    Salvar Alterações
                </button>
            </div>
        </div>
    </div>

    <form id="form-configuracoes" method="POST" action="ajax/salvar_configuracoes.php">
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <!-- Coluna principal - Configurações -->
            <div class="lg:col-span-2 space-y-6">
                <!-- Configurações Gerais -->
                <div class="card-light">
                    <div class="p-6">
                        <h3 class="text-lg font-bold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?> flex items-center mb-6 pb-4 border-b <?= $temaAtual === 'dark' ? 'border-white/10' : 'border-gray-200' ?>">
                            <i class="fas fa-cog text-blue-400 mr-3"></i>
                            Configurações Gerais
                        </h3>

                        <div class="space-y-6">
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div>
                                    <label class="block text-sm <?= $temaAtual === 'dark' ? 'text-gray-400' : 'text-gray-600' ?> mb-2">
                                        Nome do Sistema
                                    </label>
                                    <input type="text" readonly
                                           value="<?= htmlspecialchars($nomeSistema) ?>"
                                           class="w-full p-3 <?= $temaAtual === 'dark' ? 'bg-white/5 border-white/10 text-white' : 'bg-gray-50 border-gray-200 text-gray-900' ?> rounded-lg border">
                                </div>

                                <div>
                                    <label class="block text-sm <?= $temaAtual === 'dark' ? 'text-gray-400' : 'text-gray-600' ?> mb-2">
                                        Versão Atual
                                    </label>
                                    <input type="text" readonly
                                           value="v<?= htmlspecialchars($versao) ?>"
                                           class="w-full p-3 <?= $temaAtual === 'dark' ? 'bg-white/5 border-white/10 text-white' : 'bg-gray-50 border-gray-200 text-gray-900' ?> rounded-lg border">
                                </div>
                            </div>

                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div>
                                    <label for="session-timeout" class="block text-sm <?= $temaAtual === 'dark' ? 'text-gray-400' : 'text-gray-600' ?> mb-2">
                                        Tempo de Sessão (minutos)
                                    </label>
                                    <input type="number" id="session-timeout" name="tempo_expiracao_sessao"
                                           min="5" max="1440" step="5" value="<?= $tempoSessaoMin ?>"
                                           class="w-full p-3 <?= $temaAtual === 'dark' ? 'border-white/10 bg-white/5 text-white' : 'border-gray-300 bg-white text-gray-900' ?> rounded-lg border focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                    <p class="mt-1.5 text-xs <?= $temaAtual === 'dark' ? 'text-gray-500' : 'text-gray-600' ?>">
                                        Valor atual: <?= $tempoSessaoMin ?> minutos
                                    </p>
                                </div>

                                <div>
                                    <label for="login-attempts" class="block text-sm <?= $temaAtual === 'dark' ? 'text-gray-400' : 'text-gray-600' ?> mb-2">
                                        Tentativas de Login Máximas
                                    </label>
                                    <input type="number" id="login-attempts" name="tentativas_login_max"
                                           min="1" max="10" step="1" value="<?= $tentativasLogin ?>"
                                           class="w-full p-3 <?= $temaAtual === 'dark' ? 'border-white/10 bg-white/5 text-white' : 'border-gray-300 bg-white text-gray-900' ?> rounded-lg border focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                    <p class="mt-1.5 text-xs <?= $temaAtual === 'dark' ? 'text-gray-500' : 'text-gray-600' ?>">
                                        Máximo de tentativas antes do bloqueio
                                    </p>
                                </div>
                            </div>

                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div>
                                    <label for="block-time" class="block text-sm <?= $temaAtual === 'dark' ? 'text-gray-400' : 'text-gray-600' ?> mb-2">
                                        Tempo de Bloqueio (minutos)
                                    </label>
                                    <input type="number" id="block-time" name="bloqueio_tempo"
                                           min="1" max="1440" step="1" value="<?= $bloqueioTempo ?>"
                                           class="w-full p-3 <?= $temaAtual === 'dark' ? 'border-white/10 bg-white/5 text-white' : 'border-gray-300 bg-white text-gray-900' ?> rounded-lg border focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                                    <p class="mt-1.5 text-xs <?= $temaAtual === 'dark' ? 'text-gray-500' : 'text-gray-600' ?>">
                                        Tempo de bloqueio após tentativas excedidas
                                    </p>
                                </div>

                                <div class="flex items-center justify-between">
                                    <div>
                                        <div class="text-sm font-medium <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?> mb-1">
                                            Modo Manutenção
                                        </div>
                                        <p class="text-xs <?= $temaAtual === 'dark' ? 'text-gray-500' : 'text-gray-600' ?>">
                                            Desativa acesso geral ao sistema
                                        </p>
                                    </div>
                                    <label class="relative inline-flex items-center cursor-pointer">
                                        <input type="checkbox" name="manutencao_modo" value="1" 
                                               class="sr-only peer" <?= $modoManutencao ? 'checked' : '' ?>>
                                        <div class="w-12 h-6 <?= $temaAtual === 'dark' ? 'bg-white/20' : 'bg-gray-300' ?> 
                                                    peer-focus:outline-none peer-focus:ring-2 
                                                    peer-focus:ring-blue-500/50 rounded-full peer 
                                                    peer-checked:after:translate-x-6 peer-checked:bg-red-500
                                                    after:content-[''] after:absolute after:top-1 after:left-1 
                                                    after:bg-white after:border-gray-300 after:border after:rounded-full 
                                                    after:h-4 after:w-4 after:transition-all duration-200"></div>
                                    </label>
                                </div>
                            </div>

                            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div class="flex items-center justify-between">
                                    <div>
                                        <div class="text-sm font-medium <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?> mb-1">
                                            MFA Obrigatório
                                        </div>
                                        <p class="text-xs <?= $temaAtual === 'dark' ? 'text-gray-500' : 'text-gray-600' ?>">
                                            Exigir MFA para todos os usuários
                                        </p>
                                    </div>
                                    <label class="relative inline-flex items-center cursor-pointer">
                                        <input type="checkbox" name="mfa_obrigatorio" value="1" 
                                               class="sr-only peer" <?= $mfaObrigatorio ? 'checked' : '' ?>>
                                        <div class="w-12 h-6 <?= $temaAtual === 'dark' ? 'bg-white/20' : 'bg-gray-300' ?> 
                                                    peer-focus:outline-none peer-focus:ring-2 
                                                    peer-focus:ring-blue-500/50 rounded-full peer 
                                                    peer-checked:after:translate-x-6 peer-checked:bg-blue-500
                                                    after:content-[''] after:absolute after:top-1 after:left-1 
                                                    after:bg-white after:border-gray-300 after:border after:rounded-full 
                                                    after:h-4 after:w-4 after:transition-all duration-200"></div>
                                    </label>
                                </div>

                                <div class="flex items-center justify-between">
                                    <div>
                                        <div class="text-sm font-medium <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?> mb-1">
                                            Manter Logs
                                        </div>
                                        <p class="text-xs <?= $temaAtual === 'dark' ? 'text-gray-500' : 'text-gray-600' ?>">
                                            Manter histórico de auditoria
                                        </p>
                                    </div>
                                    <label class="relative inline-flex items-center cursor-pointer">
                                        <input type="checkbox" name="log_manutencao" value="1" 
                                               class="sr-only peer" <?= $logManutencao ? 'checked' : '' ?>>
                                        <div class="w-12 h-6 <?= $temaAtual === 'dark' ? 'bg-white/20' : 'bg-gray-300' ?> 
                                                    peer-focus:outline-none peer-focus:ring-2 
                                                    peer-focus:ring-blue-500/50 rounded-full peer 
                                                    peer-checked:after:translate-x-6 peer-checked:bg-green-500
                                                    after:content-[''] after:absolute after:top-1 after:left-1 
                                                    after:bg-white after:border-gray-300 after:border after:rounded-full 
                                                    after:h-4 after:w-4 after:transition-all duration-200"></div>
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Sidebar - Informações do Sistema -->
            <div class="space-y-6">
                <!-- Status do Sistema -->
                <div class="card-light">
                    <div class="p-6">
                        <h3 class="text-lg font-bold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?> flex items-center mb-6">
                            <i class="fas fa-heartbeat text-red-400 mr-3"></i>
                            Status do Sistema
                        </h3>

                        <div class="space-y-4">
                            <div class="flex justify-between items-center py-2">
                                <span class="text-sm <?= $temaAtual === 'dark' ? 'text-gray-400' : 'text-gray-600' ?>">Usuários Online</span>
                                <span class="font-medium <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?>"><?= number_format($usuariosOnline) ?></span>
                            </div>

                            <div class="flex justify-between items-center py-2">
                                <span class="text-sm <?= $temaAtual === 'dark' ? 'text-gray-400' : 'text-gray-600' ?>">Eventos Hoje</span>
                                <span class="font-medium <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?>"><?= number_format($eventosHoje) ?></span>
                            </div>

                            <div class="flex justify-between items-center py-2">
                                <span class="text-sm <?= $temaAtual === 'dark' ? 'text-gray-400' : 'text-gray-600' ?>">Usuários Ativos</span>
                                <span class="font-medium <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?>"><?= number_format($usuariosAtivos) ?></span>
                            </div>

                            <div class="flex justify-between items-center py-2">
                                <span class="text-sm <?= $temaAtual === 'dark' ? 'text-gray-400' : 'text-gray-600' ?>">Alertas Críticos Hoje</span>
                                <span class="font-medium <?= $alertasHoje > 0 ? 'text-red-500' : ($temaAtual === 'dark' ? 'text-white' : 'text-gray-900') ?>">
                                    <?= number_format($alertasHoje) ?>
                                </span>
                            </div>
                        </div>

                        <div class="mt-6 pt-6 border-t <?= $temaAtual === 'dark' ? 'border-white/10' : 'border-gray-200' ?>">
                            <div class="flex items-center justify-center space-x-2">
                                <div class="w-2 h-2 rounded-full <?= $modoManutencao ? 'bg-red-500 animate-pulse' : 'bg-green-500' ?>"></div>
                                <span class="text-sm font-medium <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?>">
                                    Sistema <?= $modoManutencao ? 'em Manutenção' : 'Operacional' ?>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>

<script>
// Submissão do formulário via AJAX
document.getElementById('form-configuracoes').addEventListener('submit', async function(e) {
    e.preventDefault();
    
    const form = this;
    const formData = new FormData(form);
    
    // Converter minutos para segundos para tempo de sessão
    const tempoSessaoMin = formData.get('tempo_expiracao_sessao');
    formData.set('tempo_expiracao_sessao', tempoSessaoMin * 60);
    
    // Converter minutos para segundos para tempo de bloqueio
    const bloqueioTempoMin = formData.get('bloqueio_tempo');
    formData.set('bloqueio_tempo', bloqueioTempoMin * 60);
    
    try {
        const response = await fetch('ajax/salvar_configuracoes.php', {
            method: 'POST',
            body: formData
        });
        
        const result = await response.json();
        
        if (result.success) {
            mostrarToast('success', 'Sucesso', 'Configurações salvas com sucesso!');
            setTimeout(() => window.location.reload(), 1500);
        } else {
            mostrarToast('error', 'Erro', result.message || 'Erro ao salvar configurações.');
        }
    } catch (error) {
        console.error('Erro:', error);
        mostrarToast('error', 'Erro', 'Falha na comunicação com o servidor.');
    }
});
</script>