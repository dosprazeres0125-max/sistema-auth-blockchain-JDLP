<?php
// conteudo/notificacoes.php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/funcoes-seguranca.php';

// Verificar se o usuário está logado
if (!isset($_SESSION['id_usuario']) || empty($_SESSION['id_usuario'])) {
    echo '<div class="p-6 text-center text-red-500">Sessão expirada. Faça login novamente.</div>';
    return;
}

// Usar tema da sessão
$temaAtual = $_SESSION['tema'] ?? 'dark';

// Garantir conexão com o banco
$pdo = conectarBancoDados();

// Processar marcação como lida
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['marcar_lida'])) {
    $idNotificacao = $_POST['id_notificacao'] ?? 0;
    
    if ($idNotificacao > 0) {
        try {
            $stmt = $pdo->prepare("UPDATE notificacoes_sistema SET lida = 1 WHERE id_notificacao = ? AND id_usuario = ?");
            $stmt->execute([$idNotificacao, $_SESSION['id_usuario']]);
            
            // Registrar evento
            registrarEvento('NOTIFICACAO_LIDA', $_SESSION['id_usuario'], "Notificação #{$idNotificacao} marcada como lida");
            
            echo json_encode(['success' => true]);
            exit;
        } catch (Exception $e) {
            error_log("Erro ao marcar notificação como lida: " . $e->getMessage());
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
            exit;
        }
    }
}

// Processar marcação todas como lidas
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['marcar_todas_lidas'])) {
    try {
        $stmt = $pdo->prepare("UPDATE notificacoes_sistema SET lida = 1 WHERE id_usuario = ? AND lida = 0");
        $stmt->execute([$_SESSION['id_usuario']]);
        
        registrarEvento('NOTIFICACOES_LIDAS', $_SESSION['id_usuario'], 'Todas as notificações marcadas como lidas');
        
        echo json_encode(['success' => true, 'message' => 'Todas as notificações foram marcadas como lidas']);
        exit;
    } catch (Exception $e) {
        error_log("Erro ao marcar todas notificações como lidas: " . $e->getMessage());
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        exit;
    }
}

// Processar exclusão de notificação
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['excluir_notificacao'])) {
    $idNotificacao = $_POST['id_notificacao'] ?? 0;
    
    if ($idNotificacao > 0) {
        try {
            $stmt = $pdo->prepare("DELETE FROM notificacoes_sistema WHERE id_notificacao = ? AND id_usuario = ?");
            $stmt->execute([$idNotificacao, $_SESSION['id_usuario']]);
            
            registrarEvento('NOTIFICACAO_EXCLUIDA', $_SESSION['id_usuario'], "Notificação #{$idNotificacao} excluída");
            
            echo json_encode(['success' => true]);
            exit;
        } catch (Exception $e) {
            error_log("Erro ao excluir notificação: " . $e->getMessage());
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
            exit;
        }
    }
}

// Carregar notificações
try {
    // Contar notificações por tipo
    $stmt = $pdo->prepare("
        SELECT 
            SUM(CASE WHEN lida = 0 THEN 1 ELSE 0 END) as nao_lidas,
            SUM(CASE WHEN lida = 1 THEN 1 ELSE 0 END) as lidas,
            COUNT(*) as total
        FROM notificacoes_sistema 
        WHERE id_usuario = ? OR id_usuario IS NULL
    ");
    $stmt->execute([$_SESSION['id_usuario']]);
    $contagem = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Carregar notificações
    $pagina = isset($_GET['pagina']) ? max(1, intval($_GET['pagina'])) : 1;
    $limite = 20;
    $offset = ($pagina - 1) * $limite;
    
    $stmt = $pdo->prepare("
        SELECT 
            ns.*,
            COALESCE(u.nome_completo, 'Sistema') as nome_origem,
            u.email as email_origem
        FROM notificacoes_sistema ns
        LEFT JOIN usuarios u ON ns.id_usuario_origem = u.id_usuario
        WHERE ns.id_usuario = ? OR ns.id_usuario IS NULL
        ORDER BY ns.data_criacao DESC
        LIMIT ? OFFSET ?
    ");
    $stmt->bindValue(1, $_SESSION['id_usuario'], PDO::PARAM_INT);
    $stmt->bindValue(2, $limite, PDO::PARAM_INT);
    $stmt->bindValue(3, $offset, PDO::PARAM_INT);
    $stmt->execute();
    $notificacoes = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Formatar dados das notificações
    foreach ($notificacoes as &$notificacao) {
        $notificacao['data_formatada'] = formatarDataRelativa($notificacao['data_criacao']);
        $notificacao['tipo_formatado'] = formatarTipoNotificacao($notificacao['tipo_notificacao']);
        $notificacao['icone'] = obterIconeNotificacao($notificacao['tipo_notificacao']);
        $notificacao['cor'] = obterCorNotificacao($notificacao['tipo_notificacao']);
    }
    
    // Contar total de páginas
    $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM notificacoes_sistema WHERE id_usuario = ? OR id_usuario IS NULL");
    $stmt->execute([$_SESSION['id_usuario']]);
    $totalNotificacoes = $stmt->fetch()['total'];
    $totalPaginas = ceil($totalNotificacoes / $limite);

} catch (Exception $e) {
    error_log("Erro ao carregar notificações: " . $e->getMessage());
    $contagem = ['nao_lidas' => 0, 'lidas' => 0, 'total' => 0];
    $notificacoes = [];
    $totalPaginas = 1;
    $pagina = 1;
}

// Funções auxiliares
function formatarDataRelativa($data) {
    $agora = new DateTime();
    $dataNotificacao = new DateTime($data);
    $diferenca = $agora->diff($dataNotificacao);
    
    if ($diferenca->days == 0) {
        if ($diferenca->h == 0) {
            if ($diferenca->i == 0) {
                return 'agora mesmo';
            }
            return $diferenca->i . ' min atrás';
        }
        return $diferenca->h . ' h atrás';
    } elseif ($diferenca->days == 1) {
        return 'ontem';
    } elseif ($diferenca->days < 7) {
        return $diferenca->days . ' dias atrás';
    } else {
        return $dataNotificacao->format('d/m/Y');
    }
}

function formatarTipoNotificacao($tipo) {
    $tipos = [
        'LOGIN_SUCCESS' => 'Login bem-sucedido',
        'LOGIN_FAILED' => 'Tentativa de login falha',
        'MFA_CREATED' => 'MFA configurado',
        'MFA_REMOVED' => 'MFA removido',
        'PASSWORD_CHANGED' => 'Senha alterada',
        'USER_CREATED' => 'Usuário criado',
        'USER_UPDATED' => 'Usuário atualizado',
        'USER_DELETED' => 'Usuário excluído',
        'SYSTEM_ALERT' => 'Alerta do sistema',
        'SECURITY_ALERT' => 'Alerta de segurança',
        'INFO' => 'Informação',
        'WARNING' => 'Aviso',
        'ERROR' => 'Erro'
    ];
    
    return $tipos[$tipo] ?? $tipo;
}

function obterIconeNotificacao($tipo) {
    $icones = [
        'LOGIN_SUCCESS' => 'fa-check-circle',
        'LOGIN_FAILED' => 'fa-times-circle',
        'MFA_CREATED' => 'fa-shield-alt',
        'MFA_REMOVED' => 'fa-shield-alt',
        'PASSWORD_CHANGED' => 'fa-key',
        'USER_CREATED' => 'fa-user-plus',
        'USER_UPDATED' => 'fa-user-edit',
        'USER_DELETED' => 'fa-user-minus',
        'SYSTEM_ALERT' => 'fa-exclamation-triangle',
        'SECURITY_ALERT' => 'fa-shield-alt',
        'INFO' => 'fa-info-circle',
        'WARNING' => 'fa-exclamation-circle',
        'ERROR' => 'fa-exclamation-triangle'
    ];
    
    return $icones[$tipo] ?? 'fa-bell';
}

function obterCorNotificacao($tipo) {
    $cores = [
        'LOGIN_SUCCESS' => 'green',
        'LOGIN_FAILED' => 'red',
        'MFA_CREATED' => 'blue',
        'MFA_REMOVED' => 'gray',
        'PASSWORD_CHANGED' => 'purple',
        'USER_CREATED' => 'green',
        'USER_UPDATED' => 'blue',
        'USER_DELETED' => 'red',
        'SYSTEM_ALERT' => 'amber',
        'SECURITY_ALERT' => 'red',
        'INFO' => 'blue',
        'WARNING' => 'amber',
        'ERROR' => 'red'
    ];
    
    return $cores[$tipo] ?? 'gray';
}
?>

<div class="max-w-7xl mx-auto p-4 sm:p-6">
    <!-- Cabeçalho -->
    <div class="mb-6 md:mb-8">
        <div class="flex flex-col md:flex-row justify-between items-start md:items-center mb-6">
            <div class="mb-4 md:mb-0">
                <h1 class="text-2xl md:text-3xl font-bold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?> mb-2">
                    Notificações
                </h1>
                <div class="flex items-center space-x-2 text-sm <?= $temaAtual === 'dark' ? 'text-gray-400' : 'text-gray-600' ?>">
                    <span>Dashboard</span>
                    <i class="fas fa-chevron-right text-xs"></i>
                    <span class="text-blue-400">Notificações</span>
                </div>
            </div>
            
            <div class="flex items-center space-x-3">
                <div class="text-right hidden md:block">
                    <div class="text-xs <?= $temaAtual === 'dark' ? 'text-gray-400' : 'text-gray-600' ?>">Total</div>
                    <div class="text-sm font-medium <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?>">
                        <?= number_format($contagem['total'] ?? 0) ?> notificações
                    </div>
                </div>
                
                <div class="flex items-center space-x-2">
                    <?php if ($contagem['nao_lidas'] > 0): ?>
                    <button onclick="marcarTodasComoLidas()" 
                            class="px-4 py-2 text-sm <?= $temaAtual === 'dark' ? 'bg-blue-500/20 hover:bg-blue-500/30 text-blue-300' : 'bg-blue-100 hover:bg-blue-200 text-blue-800' ?> rounded-lg clickable transition-colors">
                        <i class="fas fa-check-double mr-2"></i> Marcar todas como lidas
                    </button>
                    <?php endif; ?>
                    
                    <button onclick="atualizarNotificacoes()" 
                            class="px-4 py-2 text-sm <?= $temaAtual === 'dark' ? 'bg-white/10 hover:bg-white/20 text-white' : 'bg-gray-100 hover:bg-gray-200 text-gray-800' ?> rounded-lg clickable transition-colors">
                        <i class="fas fa-sync-alt mr-2"></i> Atualizar
                    </button>
                </div>
            </div>
        </div>
        
        <!-- Resumo -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <div class="p-4 <?= $temaAtual === 'dark' ? 'bg-white/5' : 'bg-gray-50' ?> rounded-xl border <?= $temaAtual === 'dark' ? 'border-white/10' : 'border-gray-200' ?>">
                <div class="flex items-center justify-between">
                    <div>
                        <div class="text-2xl font-bold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?>"><?= number_format($contagem['total'] ?? 0) ?></div>
                        <div class="text-sm <?= $temaAtual === 'dark' ? 'text-gray-400' : 'text-gray-600' ?>">Total</div>
                    </div>
                    <div class="w-10 h-10 rounded-lg bg-blue-500/20 flex items-center justify-center">
                        <i class="fas fa-bell text-blue-400"></i>
                    </div>
                </div>
            </div>
            
            <div class="p-4 <?= $temaAtual === 'dark' ? 'bg-white/5' : 'bg-gray-50' ?> rounded-xl border <?= $temaAtual === 'dark' ? 'border-white/10' : 'border-gray-200' ?>">
                <div class="flex items-center justify-between">
                    <div>
                        <div class="text-2xl font-bold <?= $contagem['nao_lidas'] > 0 ? 'text-red-500' : ($temaAtual === 'dark' ? 'text-white' : 'text-gray-900') ?>">
                            <?= number_format($contagem['nao_lidas'] ?? 0) ?>
                        </div>
                        <div class="text-sm <?= $temaAtual === 'dark' ? 'text-gray-400' : 'text-gray-600' ?>">Não lidas</div>
                    </div>
                    <div class="w-10 h-10 rounded-lg bg-red-500/20 flex items-center justify-center">
                        <i class="fas fa-envelope text-red-400"></i>
                    </div>
                </div>
            </div>
            
            <div class="p-4 <?= $temaAtual === 'dark' ? 'bg-white/5' : 'bg-gray-50' ?> rounded-xl border <?= $temaAtual === 'dark' ? 'border-white/10' : 'border-gray-200' ?>">
                <div class="flex items-center justify-between">
                    <div>
                        <div class="text-2xl font-bold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?>"><?= number_format($contagem['lidas'] ?? 0) ?></div>
                        <div class="text-sm <?= $temaAtual === 'dark' ? 'text-gray-400' : 'text-gray-600' ?>">Lidas</div>
                    </div>
                    <div class="w-10 h-10 rounded-lg bg-green-500/20 flex items-center justify-center">
                        <i class="fas fa-envelope-open text-green-400"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Filtros -->
    <div class="mb-6">
        <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div class="flex items-center space-x-4">
                <div class="relative">
                    <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <i class="<?= $temaAtual === 'dark' ? 'text-white/50' : 'text-gray-400' ?> fas fa-search"></i>
                    </div>
                    <input type="text" id="buscar-notificacoes" 
                           placeholder="Buscar notificações..." 
                           class="pl-10 pr-4 py-2 w-full md:w-64 <?= $temaAtual === 'dark' ? 'border-white/10 bg-white/5 text-white placeholder-white/50' : 'border-gray-300 bg-white text-gray-900 placeholder-gray-500' ?> rounded-lg border focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                </div>
                
                <select id="filtro-tipo" 
                        class="px-4 py-2 <?= $temaAtual === 'dark' ? 'border-white/10 bg-white/5 text-white' : 'border-gray-300 bg-white text-gray-900' ?> rounded-lg border focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                    <option value="">Todos os tipos</option>
                    <option value="LOGIN_SUCCESS">Logins</option>
                    <option value="SECURITY_ALERT">Alertas de segurança</option>
                    <option value="SYSTEM_ALERT">Alertas do sistema</option>
                    <option value="USER_CREATED">Novos usuários</option>
                    <option value="INFO">Informações</option>
                </select>
                
                <select id="filtro-status" 
                        class="px-4 py-2 <?= $temaAtual === 'dark' ? 'border-white/10 bg-white/5 text-white' : 'border-gray-300 bg-white text-gray-900' ?> rounded-lg border focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                    <option value="">Todos os status</option>
                    <option value="nao_lidas">Não lidas</option>
                    <option value="lidas">Lidas</option>
                </select>
            </div>
            
            <div class="flex items-center space-x-2">
                <button onclick="exportarNotificacoes()" 
                        class="px-4 py-2 text-sm <?= $temaAtual === 'dark' ? 'bg-green-500/20 hover:bg-green-500/30 text-green-300' : 'bg-green-100 hover:bg-green-200 text-green-800' ?> rounded-lg clickable transition-colors">
                    <i class="fas fa-download mr-2"></i> Exportar
                </button>
            </div>
        </div>
    </div>

    <!-- Lista de Notificações -->
    <div class="card-light">
        <div class="p-6">
            <?php if (count($notificacoes) > 0): ?>
                <div class="space-y-3" id="lista-notificacoes">
                    <?php foreach ($notificacoes as $notificacao): ?>
                        <div class="notificacao-item p-4 <?= $temaAtual === 'dark' ? 'bg-white/5 hover:bg-white/10' : 'bg-gray-50 hover:bg-gray-100' ?> rounded-lg border <?= $temaAtual === 'dark' ? 'border-white/10' : 'border-gray-200' ?> transition-colors <?= $notificacao['lida'] ? '' : 'border-l-4 border-l-' . $notificacao['cor'] . '-500' ?>"
                             data-id="<?= $notificacao['id_notificacao'] ?>"
                             data-tipo="<?= $notificacao['tipo_notificacao'] ?>"
                             data-status="<?= $notificacao['lida'] ? 'lida' : 'nao_lida' ?>"
                             data-texto="<?= htmlspecialchars(strtolower($notificacao['titulo'] . ' ' . $notificacao['mensagem'])) ?>">
                            
                            <div class="flex items-start justify-between">
                                <div class="flex items-start space-x-3 flex-1">
                                    <div class="w-10 h-10 rounded-lg <?= $temaAtual === 'dark' ? 'bg-' . $notificacao['cor'] . '-500/20' : 'bg-' . $notificacao['cor'] . '-100' ?> flex items-center justify-center flex-shrink-0">
                                        <i class="fas <?= $notificacao['icone'] ?> text-<?= $notificacao['cor'] ?>-500"></i>
                                    </div>
                                    
                                    <div class="flex-1 min-w-0">
                                        <div class="flex items-center justify-between mb-1">
                                            <h4 class="text-sm font-semibold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?>">
                                                <?= htmlspecialchars($notificacao['titulo']) ?>
                                            </h4>
                                            <div class="flex items-center space-x-2">
                                                <?php if (!$notificacao['lida']): ?>
                                                    <span class="text-xs px-2 py-1 <?= $temaAtual === 'dark' ? 'bg-red-500/20 text-red-300' : 'bg-red-100 text-red-800' ?> rounded-full">
                                                        Nova
                                                    </span>
                                                <?php endif; ?>
                                                <span class="text-xs <?= $temaAtual === 'dark' ? 'text-gray-400' : 'text-gray-500' ?>">
                                                    <?= $notificacao['data_formatada'] ?>
                                                </span>
                                            </div>
                                        </div>
                                        
                                        <p class="text-sm <?= $temaAtual === 'dark' ? 'text-gray-300' : 'text-gray-700' ?> mb-2">
                                            <?= htmlspecialchars($notificacao['mensagem']) ?>
                                        </p>
                                        
                                        <div class="flex items-center space-x-4 text-xs <?= $temaAtual === 'dark' ? 'text-gray-400' : 'text-gray-500' ?>">
                                            <div class="flex items-center">
                                                <i class="fas fa-tag mr-1"></i>
                                                <span><?= $notificacao['tipo_formatado'] ?></span>
                                            </div>
                                            
                                            <?php if ($notificacao['nome_origem']): ?>
                                                <div class="flex items-center">
                                                    <i class="fas fa-user mr-1"></i>
                                                    <span><?= htmlspecialchars($notificacao['nome_origem']) ?></span>
                                                    <?php if ($notificacao['email_origem']): ?>
                                                        <span class="ml-1">(<?= htmlspecialchars($notificacao['email_origem']) ?>)</span>
                                                    <?php endif; ?>
                                                </div>
                                            <?php endif; ?>
                                            
                                            <?php if ($notificacao['link_acao']): ?>
                                                <div class="flex items-center">
                                                    <i class="fas fa-link mr-1"></i>
                                                    <a href="<?= htmlspecialchars($notificacao['link_acao']) ?>" 
                                                       class="text-blue-500 hover:text-blue-400 clickable">
                                                        Ver detalhes
                                                    </a>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="flex items-center space-x-2 ml-4">
                                    <?php if (!$notificacao['lida']): ?>
                                        <button onclick="marcarComoLida(<?= $notificacao['id_notificacao'] ?>)" 
                                                class="w-8 h-8 <?= $temaAtual === 'dark' ? 'hover:bg-white/10 text-white/50 hover:text-white' : 'hover:bg-gray-100 text-gray-500 hover:text-gray-700' ?> rounded-full flex items-center justify-center clickable transition-colors"
                                                title="Marcar como lida">
                                            <i class="fas fa-check"></i>
                                        </button>
                                    <?php endif; ?>
                                    
                                    <button onclick="excluirNotificacao(<?= $notificacao['id_notificacao'] ?>)" 
                                            class="w-8 h-8 <?= $temaAtual === 'dark' ? 'hover:bg-red-500/20 text-white/50 hover:text-red-300' : 'hover:bg-red-100 text-gray-500 hover:text-red-600' ?> rounded-full flex items-center justify-center clickable transition-colors"
                                            title="Excluir notificação">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
                
                <!-- Paginação -->
                <?php if ($totalPaginas > 1): ?>
                    <div class="mt-6 pt-6 border-t <?= $temaAtual === 'dark' ? 'border-white/10' : 'border-gray-200' ?>">
                        <div class="flex items-center justify-between">
                            <div class="text-sm <?= $temaAtual === 'dark' ? 'text-gray-400' : 'text-gray-600' ?>">
                                Mostrando <?= $offset + 1 ?> - <?= min($offset + $limite, $totalNotificacoes) ?> de <?= $totalNotificacoes ?> notificações
                            </div>
                            
                            <div class="flex items-center space-x-2">
                                <?php if ($pagina > 1): ?>
                                    <a href="?pagina=<?= $pagina - 1 ?>" 
                                       class="px-3 py-1 <?= $temaAtual === 'dark' ? 'bg-white/10 hover:bg-white/20 text-white' : 'bg-gray-100 hover:bg-gray-200 text-gray-800' ?> rounded-lg clickable transition-colors">
                                        <i class="fas fa-chevron-left"></i>
                                    </a>
                                <?php endif; ?>
                                
                                <div class="flex items-center space-x-1">
                                    <?php for ($i = 1; $i <= min(5, $totalPaginas); $i++): ?>
                                        <a href="?pagina=<?= $i ?>" 
                                           class="w-8 h-8 flex items-center justify-center <?= $pagina == $i ? 'bg-blue-500 text-white' : ($temaAtual === 'dark' ? 'bg-white/10 hover:bg-white/20 text-white' : 'bg-gray-100 hover:bg-gray-200 text-gray-800') ?> rounded-lg clickable transition-colors">
                                            <?= $i ?>
                                        </a>
                                    <?php endfor; ?>
                                    
                                    <?php if ($totalPaginas > 5): ?>
                                        <span class="px-2 <?= $temaAtual === 'dark' ? 'text-white/50' : 'text-gray-500' ?>">...</span>
                                        <a href="?pagina=<?= $totalPaginas ?>" 
                                           class="w-8 h-8 flex items-center justify-center <?= $temaAtual === 'dark' ? 'bg-white/10 hover:bg-white/20 text-white' : 'bg-gray-100 hover:bg-gray-200 text-gray-800' ?> rounded-lg clickable transition-colors">
                                            <?= $totalPaginas ?>
                                        </a>
                                    <?php endif; ?>
                                </div>
                                
                                <?php if ($pagina < $totalPaginas): ?>
                                    <a href="?pagina=<?= $pagina + 1 ?>" 
                                       class="px-3 py-1 <?= $temaAtual === 'dark' ? 'bg-white/10 hover:bg-white/20 text-white' : 'bg-gray-100 hover:bg-gray-200 text-gray-800' ?> rounded-lg clickable transition-colors">
                                        <i class="fas fa-chevron-right"></i>
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
                
            <?php else: ?>
                <div class="text-center py-12">
                    <div class="w-16 h-16 mx-auto <?= $temaAtual === 'dark' ? 'bg-white/10' : 'bg-gray-100' ?> rounded-full flex items-center justify-center mb-4">
                        <i class="fas fa-bell-slash text-2xl <?= $temaAtual === 'dark' ? 'text-white/50' : 'text-gray-400' ?>"></i>
                    </div>
                    <h3 class="text-lg font-semibold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?> mb-2">
                        Nenhuma notificação
                    </h3>
                    <p class="<?= $temaAtual === 'dark' ? 'text-gray-400' : 'text-gray-600' ?> mb-4">
                        Você não tem notificações no momento.
                    </p>
                    <button onclick="atualizarNotificacoes()" 
                            class="px-4 py-2 text-sm <?= $temaAtual === 'dark' ? 'bg-white/10 hover:bg-white/20 text-white' : 'bg-gray-100 hover:bg-gray-200 text-gray-800' ?> rounded-lg clickable transition-colors">
                        <i class="fas fa-sync-alt mr-2"></i> Atualizar
                    </button>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Modal de Confirmação -->
    <div id="modalConfirmacao" class="modal-overlay" onclick="fecharModalConfirmacao()">
        <div class="modal-content" onclick="event.stopPropagation()">
            <div class="p-6">
                <div class="flex items-center space-x-3 mb-4">
                    <div class="w-10 h-10 rounded-lg bg-red-500/20 flex items-center justify-center">
                        <i class="fas fa-exclamation-triangle text-red-400 text-lg"></i>
                    </div>
                    <h3 class="text-lg font-semibold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?>" id="modalTitulo">
                        Confirmar Exclusão
                    </h3>
                </div>
                
                <p class="<?= $temaAtual === 'dark' ? 'text-gray-300' : 'text-gray-700' ?> mb-6" id="modalMensagem">
                    Tem certeza que deseja excluir esta notificação?
                </p>
                
                <div class="flex justify-end space-x-3">
                    <button onclick="fecharModalConfirmacao()" 
                            class="px-4 py-2 <?= $temaAtual === 'dark' ? 'bg-white/10 hover:bg-white/20 text-white' : 'bg-gray-100 hover:bg-gray-200 text-gray-800' ?> rounded-lg clickable transition-colors">
                        Cancelar
                    </button>
                    <button onclick="confirmarExclusao()" 
                            class="px-4 py-2 bg-red-500 hover:bg-red-600 text-white rounded-lg clickable transition-colors">
                        <i class="fas fa-trash mr-2"></i> Excluir
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// Variáveis globais
let notificacaoParaExcluir = null;
let timeoutBusca = null;

// Filtragem de notificações
document.addEventListener('DOMContentLoaded', function() {
    // Busca em tempo real
    const inputBusca = document.getElementById('buscar-notificacoes');
    const filtroTipo = document.getElementById('filtro-tipo');
    const filtroStatus = document.getElementById('filtro-status');
    
    function filtrarNotificacoes() {
        const termoBusca = inputBusca.value.toLowerCase();
        const tipoSelecionado = filtroTipo.value;
        const statusSelecionado = filtroStatus.value;
        
        document.querySelectorAll('.notificacao-item').forEach(notificacao => {
            const texto = notificacao.dataset.texto.toLowerCase();
            const tipo = notificacao.dataset.tipo;
            const status = notificacao.dataset.status;
            
            let mostrar = true;
            
            if (termoBusca && !texto.includes(termoBusca)) {
                mostrar = false;
            }
            
            if (tipoSelecionado && tipo !== tipoSelecionado) {
                mostrar = false;
            }
            
            if (statusSelecionado && status !== statusSelecionado) {
                mostrar = false;
            }
            
            if (mostrar) {
                notificacao.classList.remove('hidden');
            } else {
                notificacao.classList.add('hidden');
            }
        });
    }
    
    inputBusca.addEventListener('input', function() {
        clearTimeout(timeoutBusca);
        timeoutBusca = setTimeout(filtrarNotificacoes, 300);
    });
    
    filtroTipo.addEventListener('change', filtrarNotificacoes);
    filtroStatus.addEventListener('change', filtrarNotificacoes);
});

// Funções de notificações
function atualizarNotificacoes() {
    window.location.reload();
}

function marcarComoLida(idNotificacao) {
    fetch('', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `marcar_lida=1&id_notificacao=${idNotificacao}`
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            mostrarToast('success', 'Notificação', 'Notificação marcada como lida!');
            
            // Atualizar visualmente
            const notificacao = document.querySelector(`.notificacao-item[data-id="${idNotificacao}"]`);
            if (notificacao) {
                notificacao.classList.remove('border-l-4');
                notificacao.dataset.status = 'lida';
                
                // Remover badge "Nova"
                const badge = notificacao.querySelector('.bg-red-500\\/20, .bg-red-100');
                if (badge) {
                    badge.remove();
                }
                
                // Atualizar contador na página principal (se existir)
                setTimeout(() => {
                    if (typeof carregarNotificacoes === 'function') {
                        carregarNotificacoes();
                    }
                }, 500);
            }
        } else {
            mostrarToast('error', 'Erro', data.message || 'Erro ao marcar notificação como lida.');
        }
    })
    .catch(error => {
        console.error('Erro:', error);
        mostrarToast('error', 'Erro', 'Erro ao marcar notificação como lida.');
    });
}

function marcarTodasComoLidas() {
    if (confirm('Tem certeza que deseja marcar todas as notificações como lidas?')) {
        fetch('', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'marcar_todas_lidas=1'
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                mostrarToast('success', 'Notificações', 'Todas as notificações foram marcadas como lidas!');
                setTimeout(() => {
                    window.location.reload();
                }, 1000);
            } else {
                mostrarToast('error', 'Erro', data.message || 'Erro ao marcar notificações como lidas.');
            }
        })
        .catch(error => {
            console.error('Erro:', error);
            mostrarToast('error', 'Erro', 'Erro ao marcar notificações como lidas.');
        });
    }
}

function excluirNotificacao(idNotificacao) {
    notificacaoParaExcluir = idNotificacao;
    document.getElementById('modalMensagem').textContent = 'Tem certeza que deseja excluir esta notificação?';
    document.getElementById('modalConfirmacao').classList.add('active');
    document.body.style.overflow = 'hidden';
}

function confirmarExclusao() {
    if (!notificacaoParaExcluir) return;
    
    fetch('', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `excluir_notificacao=1&id_notificacao=${notificacaoParaExcluir}`
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            mostrarToast('success', 'Notificação', 'Notificação excluída com sucesso!');
            fecharModalConfirmacao();
            
            // Remover elemento da lista
            const notificacao = document.querySelector(`.notificacao-item[data-id="${notificacaoParaExcluir}"]`);
            if (notificacao) {
                notificacao.remove();
                
                // Verificar se ainda há notificações
                if (document.querySelectorAll('.notificacao-item').length === 0) {
                    window.location.reload();
                }
            }
        } else {
            mostrarToast('error', 'Erro', data.message || 'Erro ao excluir notificação.');
        }
    })
    .catch(error => {
        console.error('Erro:', error);
        mostrarToast('error', 'Erro', 'Erro ao excluir notificação.');
    });
}

function exportarNotificacoes() {
    const filtroTipo = document.getElementById('filtro-tipo').value;
    const filtroStatus = document.getElementById('filtro-status').value;
    const busca = document.getElementById('buscar-notificacoes').value;
    
    let url = 'ajax/exportar_notificacoes.php?exportar=1';
    
    if (filtroTipo) {
        url += `&tipo=${encodeURIComponent(filtroTipo)}`;
    }
    
    if (filtroStatus) {
        url += `&status=${encodeURIComponent(filtroStatus)}`;
    }
    
    if (busca) {
        url += `&busca=${encodeURIComponent(busca)}`;
    }
    
    mostrarToast('info', 'Exportação', 'Preparando exportação...');
    window.open(url, '_blank');
}

function fecharModalConfirmacao() {
    document.getElementById('modalConfirmacao').classList.remove('active');
    document.body.style.overflow = 'auto';
    notificacaoParaExcluir = null;
}

// Atualizar notificações periodicamente (opcional)
let intervaloAtualizacao = null;

function iniciarAtualizacaoPeriodica() {
    if (intervaloAtualizacao) {
        clearInterval(intervaloAtualizacao);
    }
    
    // Atualizar a cada 30 segundos se estiver na aba ativa
    intervaloAtualizacao = setInterval(() => {
        if (!document.hidden) {
            fetch('ajax/carregar_notificacoes.php?contagem=true')
                .then(response => response.json())
                .then(data => {
                    if (data.success && data.contagem) {
                        // Atualizar contador se houver mudanças
                        const contadorAtual = document.querySelector('.text-red-500\\/20, .bg-red-100')?.textContent || '0';
                        if (data.contagem.nao_lidas > 0 && data.contagem.nao_lidas != parseInt(contadorAtual)) {
                            mostrarToast('info', 'Nova notificação', 'Você tem novas notificações!');
                        }
                    }
                });
        }
    }, 30000);
}

// Iniciar atualização periódica quando a página carregar
document.addEventListener('visibilitychange', function() {
    if (!document.hidden) {
        iniciarAtualizacaoPeriodica();
    } else {
        if (intervaloAtualizacao) {
            clearInterval(intervaloAtualizacao);
        }
    }
});

// Iniciar quando a página carrega
if (!document.hidden) {
    iniciarAtualizacaoPeriodica();
}
</script>