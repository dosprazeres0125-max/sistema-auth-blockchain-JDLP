<?php
// dashboard.php - Visão Geral do Sistema Auth Blockchain

require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/funcoes-seguranca.php';

// Verificar se o usuário está logado
if (!isset($_SESSION['id_usuario']) || empty($_SESSION['id_usuario'])) {
    echo '<div class="p-6 text-center text-red-500">Sessão expirada. Faça login novamente.</div>';
    return;
}

$idUsuarioAtual = $_SESSION['id_usuario'];

// Verificar tema atual (vindo da sessão ou default)
$temaAtual = $_SESSION['tema'] ?? 'light';

// Conexão
$pdo = conectarBancoDados();

try {
    // 1. Estatísticas básicas usando views existentes
    $stmt = $pdo->query("SELECT total_usuarios, sessoes_ativas, total_eventos FROM view_estatisticas_sistema");
    $estatisticas = $stmt->fetch(PDO::FETCH_ASSOC);
    
    $totalUsuarios = $estatisticas['total_usuarios'] ?? 0;
    $sessoesAtivas = $estatisticas['sessoes_ativas'] ?? 0;
    $totalEventos = $estatisticas['total_eventos'] ?? 0;

    // Contagens específicas
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM registro_eventos WHERE tipo_evento = 'LOGIN_SUCCESS'");
    $loginsSucesso = $stmt->fetch()['total'];

    $stmt = $pdo->query("SELECT COUNT(*) as total FROM registro_eventos WHERE tipo_evento LIKE 'LOGIN_FAILED%'");
    $loginsFalhas = $stmt->fetch()['total'];

    $stmt = $pdo->query("SELECT COUNT(*) as total FROM usuarios WHERE mfa_codigo_hash IS NOT NULL AND mfa_codigo_hash != ''");
    $mfaCriados = $stmt->fetch()['total'];

    // 2. Verificar se o usuário atual tem MFA configurado
    $stmt = $pdo->prepare("SELECT mfa_codigo_hash FROM usuarios WHERE id_usuario = ?");
    $stmt->execute([$idUsuarioAtual]);
    $usuarioAtual = $stmt->fetch();
    $mfaConfigurado = !empty($usuarioAtual['mfa_codigo_hash']);

    // 3. Estatísticas por hora (últimas 6 horas) - corrigido para funcionar com timestamp UNIX
    $stmt = $pdo->query("
        SELECT 
            DATE_FORMAT(FROM_UNIXTIME(timestamp), '%H:00') as hora,
            COUNT(CASE WHEN tipo_evento = 'LOGIN_SUCCESS' THEN 1 END) as logins_sucesso,
            COUNT(CASE WHEN tipo_evento LIKE 'LOGIN_FAILED%' THEN 1 END) as logins_falha,
            COUNT(*) as total_eventos
        FROM registro_eventos
        WHERE timestamp >= UNIX_TIMESTAMP(NOW() - INTERVAL 6 HOUR)
        GROUP BY HOUR(FROM_UNIXTIME(timestamp))
        ORDER BY hora
    ");
    $estatisticasHora = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Garantir que temos dados para todas as últimas 6 horas
    $horasCompletas = [];
    $horaAtual = (int)date('H');
    
    for ($i = 5; $i >= 0; $i--) {
        $horaFormatada = sprintf('%02d:00', ($horaAtual - $i + 24) % 24);
        $encontrado = false;
        
        foreach ($estatisticasHora as $dado) {
            if ($dado['hora'] == $horaFormatada) {
                $horasCompletas[] = [
                    'hora' => substr($dado['hora'], 0, 5), // Remove os segundos
                    'logins_sucesso' => (int)$dado['logins_sucesso'],
                    'logins_falha' => (int)$dado['logins_falha'],
                    'total_eventos' => (int)$dado['total_eventos']
                ];
                $encontrado = true;
                break;
            }
        }
        
        if (!$encontrado) {
            $horasCompletas[] = [
                'hora' => substr($horaFormatada, 0, 5),
                'logins_sucesso' => 0,
                'logins_falha' => 0,
                'total_eventos' => 0
            ];
        }
    }

    // 4. Distribuição de eventos (últimos 7 dias) - corrigido para funcionar com sua estrutura
    $stmt = $pdo->query("
        SELECT 
            CASE 
                WHEN tipo_evento = 'LOGIN_SUCCESS' THEN 'Logins Bem-sucedidos'
                WHEN tipo_evento LIKE 'LOGIN_FAILED%' THEN 'Tentativas Falhas'
                WHEN tipo_evento = 'LOGOUT' THEN 'Logouts'
                ELSE 'Outros Eventos'
            END as categoria,
            COUNT(*) as quantidade
        FROM registro_eventos
        WHERE data_hora >= NOW() - INTERVAL 7 DAY
        GROUP BY 
            CASE 
                WHEN tipo_evento = 'LOGIN_SUCCESS' THEN 'Logins Bem-sucedidos'
                WHEN tipo_evento LIKE 'LOGIN_FAILED%' THEN 'Tentativas Falhas'
                WHEN tipo_evento = 'LOGOUT' THEN 'Logouts'
                ELSE 'Outros Eventos'
            END
        ORDER BY quantidade DESC
    ");
    $distribuicaoEventos = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Adicionar MFA_CREATED separadamente (se existir na tabela)
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM usuarios WHERE mfa_codigo_hash IS NOT NULL AND mfa_codigo_hash != '' AND data_criacao >= NOW() - INTERVAL 7 DAY");
    $mfaCriadosUltimos7Dias = $stmt->fetch()['total'];
    
    if ($mfaCriadosUltimos7Dias > 0) {
        $distribuicaoEventos[] = [
            'categoria' => 'MFA Configurados',
            'quantidade' => $mfaCriadosUltimos7Dias
        ];
    }

    // 5. Últimos 5 eventos de segurança - corrigido para usar a estrutura real
    $stmt = $pdo->prepare("
        SELECT 
            re.id_evento,
            re.tipo_evento,
            re.data_hora,
            re.ip_origem,
            u.nome_completo,
            u.email,
            u.tipo_usuario,
            CASE 
                WHEN u.tipo_usuario = 'admin' THEN 'Administrador'
                WHEN u.tipo_usuario = 'auditor' THEN 'Auditor'
                ELSE 'Usuário'
            END as tipo_usuario_formatado
        FROM registro_eventos re
        LEFT JOIN usuarios u ON re.id_usuario = u.id_usuario
        ORDER BY re.data_hora DESC
        LIMIT 5
    ");
    $stmt->execute();
    $ultimosEventos = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // 6. Informações do bloco blockchain atual
    $stmt = $pdo->query("SELECT COUNT(*) as total_blocos, MAX(timestamp_criacao) as ultimo_bloco FROM blocos_blockchain");
    $blockchainInfo = $stmt->fetch(PDO::FETCH_ASSOC);
    
    $totalBlocos = $blockchainInfo['total_blocos'] ?? 1;
    $ultimoBlocoTimestamp = $blockchainInfo['ultimo_bloco'] ?? time();

    // 7. Informações sobre usuários por tipo
    $stmt = $pdo->query("
        SELECT 
            tipo_usuario,
            COUNT(*) as quantidade,
            GROUP_CONCAT(nome_completo SEPARATOR ', ') as nomes
        FROM usuarios 
        WHERE ativo = 1 
        GROUP BY tipo_usuario
    ");
    $usuariosPorTipo = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (Exception $e) {
    error_log("Erro ao carregar dados do dashboard: " . $e->getMessage() . " - " . $e->getTraceAsString());
    
    // Valores padrão em caso de erro
    $totalUsuarios = $loginsSucesso = $loginsFalhas = $mfaCriados = $sessoesAtivas = $totalEventos = 0;
    $horasCompletas = [];
    $distribuicaoEventos = [
        ['categoria' => 'Logins Bem-sucedidos', 'quantidade' => 0],
        ['categoria' => 'Tentativas Falhas', 'quantidade' => 0],
        ['categoria' => 'Logouts', 'quantidade' => 0],
        ['categoria' => 'Outros Eventos', 'quantidade' => 0]
    ];
    $ultimosEventos = [];
    $mfaConfigurado = false;
    $usuariosPorTipo = [];
    $totalBlocos = 1;
}
?>

<!-- Container principal com tema dinâmico -->
<div class="min-h-screen transition-colors duration-300 <?= $temaAtual === 'dark' ? 'bg-gray-900 text-white' : 'bg-gray-50 text-gray-900' ?>">
    <!-- Partículas Background -->
    <div id="particles-js" class="absolute inset-0 z-0"></div>
    
    <main class="p-6 relative z-10">
        <!-- Breadcrumb -->
        <div class="mb-6 flex items-center text-sm <?= $temaAtual === 'dark' ? 'text-gray-300' : 'text-gray-600' ?>">
            <a href="#" onclick="carregarPagina('dashboard')" class="hover:text-marinho-400 clickable transition-colors flex items-center">
                <i class="fas fa-home mr-2 text-xs"></i> Dashboard
            </a>
            <i class="fas fa-chevron-right mx-2 text-xs <?= $temaAtual === 'dark' ? 'text-gray-500' : 'text-gray-400' ?>"></i>
            <span class="text-marinho-400 font-medium">Visão Geral do Sistema</span>
        </div>

        <!-- Cards de Estatísticas -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 mb-8">
            <!-- Total de Eventos -->
            <div class="rounded-xl border shadow-sm hover:shadow-md transition-all p-5 clickable <?= $temaAtual === 'dark' ? 'bg-gray-800 border-gray-700 hover:border-blue-500' : 'bg-white border-blue-100' ?>" onclick="carregarPagina('eventos')">
                <div class="flex items-center justify-between mb-4">
                    <div>
                        <p class="text-xs <?= $temaAtual === 'dark' ? 'text-gray-300' : 'text-gray-500' ?> mb-1">Total de Eventos</p>
                        <p class="text-2xl font-bold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-800' ?>"><?= number_format($totalEventos) ?></p>
                    </div>
                    <div class="w-12 h-12 rounded-full <?= $temaAtual === 'dark' ? 'bg-blue-900/30' : 'bg-blue-50' ?> flex items-center justify-center">
                        <i class="fas fa-stream <?= $temaAtual === 'dark' ? 'text-blue-400' : 'text-blue-500' ?> text-lg"></i>
                    </div>
                </div>
                <div class="flex items-center text-xs <?= $temaAtual === 'dark' ? 'text-blue-300' : 'text-blue-600' ?> font-medium">
                    <i class="fas fa-link mr-2"></i>
                    <span>Registros blockchain</span>
                </div>
            </div>

            <!-- Logins Bem-sucedidos -->
            <div class="rounded-xl border shadow-sm hover:shadow-md transition-all p-5 clickable <?= $temaAtual === 'dark' ? 'bg-gray-800 border-gray-700 hover:border-green-500' : 'bg-white border-green-100' ?>" onclick="carregarPagina('eventos')">
                <div class="flex items-center justify-between mb-4">
                    <div>
                        <p class="text-xs <?= $temaAtual === 'dark' ? 'text-gray-300' : 'text-gray-500' ?> mb-1">Logins Bem-sucedidos</p>
                        <p class="text-2xl font-bold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-800' ?>"><?= number_format($loginsSucesso) ?></p>
                    </div>
                    <div class="w-12 h-12 rounded-full <?= $temaAtual === 'dark' ? 'bg-green-900/30' : 'bg-green-50' ?> flex items-center justify-center">
                        <i class="fas fa-user-check <?= $temaAtual === 'dark' ? 'text-green-400' : 'text-green-500' ?> text-lg"></i>
                    </div>
                </div>
                <div class="flex items-center text-xs <?= $temaAtual === 'dark' ? 'text-green-300' : 'text-green-600' ?> font-medium">
                    <i class="fas fa-shield-alt mr-2"></i>
                    <span>Autenticações válidas</span>
                </div>
            </div>

            <!-- Tentativas Falhas -->
            <div class="rounded-xl border shadow-sm hover:shadow-md transition-all p-5 clickable <?= $temaAtual === 'dark' ? 'bg-gray-800 border-gray-700 hover:border-red-500' : 'bg-white border-red-100' ?>" onclick="carregarPagina('eventos')">
                <div class="flex items-center justify-between mb-4">
                    <div>
                        <p class="text-xs <?= $temaAtual === 'dark' ? 'text-gray-300' : 'text-gray-500' ?> mb-1">Tentativas Falhas</p>
                        <p class="text-2xl font-bold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-800' ?>"><?= number_format($loginsFalhas) ?></p>
                    </div>
                    <div class="w-12 h-12 rounded-full <?= $temaAtual === 'dark' ? 'bg-red-900/30' : 'bg-red-50' ?> flex items-center justify-center">
                        <i class="fas fa-user-lock <?= $temaAtual === 'dark' ? 'text-red-400' : 'text-red-500' ?> text-lg"></i>
                    </div>
                </div>
                <div class="flex items-center text-xs <?= $temaAtual === 'dark' ? 'text-red-300' : 'text-red-600' ?> font-medium">
                    <i class="fas fa-exclamation-triangle mr-2"></i>
                    <span>Bloqueios automáticos</span>
                </div>
            </div>

            <!-- MFA Configurados -->
            <div class="rounded-xl border shadow-sm hover:shadow-md transition-all p-5 clickable <?= $temaAtual === 'dark' ? 'bg-gray-800 border-gray-700 hover:border-amber-500' : 'bg-white border-amber-100' ?>" onclick="carregarPagina('seguranca')">
                <div class="flex items-center justify-between mb-4">
                    <div>
                        <p class="text-xs <?= $temaAtual === 'dark' ? 'text-gray-300' : 'text-gray-500' ?> mb-1">MFA Configurados</p>
                        <p class="text-2xl font-bold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-800' ?>"><?= number_format($mfaCriados) ?></p>
                    </div>
                    <div class="w-12 h-12 rounded-full <?= $temaAtual === 'dark' ? 'bg-amber-900/30' : 'bg-amber-50' ?> flex items-center justify-center">
                        <i class="fas fa-lock <?= $temaAtual === 'dark' ? 'text-amber-400' : 'text-amber-500' ?> text-lg"></i>
                    </div>
                </div>
                <div class="flex items-center text-xs <?= $temaAtual === 'dark' ? 'text-amber-300' : 'text-amber-600' ?> font-medium">
                    <i class="fas fa-key mr-2"></i>
                    <span>Segurança reforçada</span>
                </div>
            </div>

            <!-- Usuários Registrados -->
            <div class="rounded-xl border shadow-sm hover:shadow-md transition-all p-5 clickable <?= $temaAtual === 'dark' ? 'bg-gray-800 border-gray-700 hover:border-purple-500' : 'bg-white border-purple-100' ?>" onclick="carregarPagina('usuarios')">
                <div class="flex items-center justify-between mb-4">
                    <div>
                        <p class="text-xs <?= $temaAtual === 'dark' ? 'text-gray-300' : 'text-gray-500' ?> mb-1">Usuários Registrados</p>
                        <p class="text-2xl font-bold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-800' ?>"><?= number_format($totalUsuarios) ?></p>
                    </div>
                    <div class="w-12 h-12 rounded-full <?= $temaAtual === 'dark' ? 'bg-purple-900/30' : 'bg-purple-50' ?> flex items-center justify-center">
                        <i class="fas fa-users <?= $temaAtual === 'dark' ? 'text-purple-400' : 'text-purple-500' ?> text-lg"></i>
                    </div>
                </div>
                <div class="flex items-center justify-between text-xs">
                    <div class="flex items-center <?= $temaAtual === 'dark' ? 'text-purple-300' : 'text-purple-600' ?> font-medium">
                        <i class="fas fa-circle text-green-400 mr-1 text-xs"></i>
                        <span><?= $sessoesAtivas ?> ativos</span>
                    </div>
                    <span class="<?= $temaAtual === 'dark' ? 'text-gray-400' : 'text-gray-400' ?>"><?= $totalUsuarios - $sessoesAtivas ?> inativos</span>
                </div>
            </div>
        </div>

        <!-- Blockchain Info Card -->
        <div class="rounded-xl shadow-sm mb-8 p-1 <?= $temaAtual === 'dark' ? 'bg-gradient-to-r from-indigo-900/20 to-blue-900/20 border border-indigo-800' : 'bg-gradient-to-r from-indigo-50 to-blue-50 border border-indigo-200' ?>">
            <div class="p-4 flex items-center justify-between">
                <div class="flex items-center">
                    <div class="w-14 h-14 rounded-full <?= $temaAtual === 'dark' ? 'bg-indigo-800/40' : 'bg-indigo-100' ?> flex items-center justify-center mr-4">
                        <i class="<?= $temaAtual === 'dark' ? 'fas fa-link text-indigo-400' : 'fas fa-link text-indigo-600' ?> text-2xl"></i>
                    </div>
                    <div>
                        <h3 class="text-lg font-bold <?= $temaAtual === 'dark' ? 'text-indigo-300' : 'text-indigo-700' ?>">
                            Blockchain Ativa
                        </h3>
                        <p class="text-sm <?= $temaAtual === 'dark' ? 'text-gray-300' : 'text-gray-600' ?> mt-1">
                            Sistema com <?= $totalBlocos ?> blocos • Último bloco: <?= date('d/m/Y H:i', $ultimoBlocoTimestamp) ?>
                        </p>
                    </div>
                </div>
                <a href="#" onclick="carregarPagina('auditoria')" class="bg-gradient-to-r from-indigo-500 to-blue-500 hover:from-indigo-600 hover:to-blue-600 text-white px-5 py-2.5 rounded-lg font-medium text-sm flex items-center shadow-sm hover:shadow transition-all">
                    <i class="fas fa-search mr-2"></i> Verificar Blockchain
                </a>
            </div>
        </div>

        <!-- Seu Status MFA -->
        <div class="rounded-xl shadow-sm mb-8 p-1 <?= $mfaConfigurado 
            ? ($temaAtual === 'dark' ? 'bg-gradient-to-r from-green-900/20 to-emerald-900/20 border border-green-800' : 'bg-gradient-to-r from-green-50 to-emerald-50 border border-green-200')
            : ($temaAtual === 'dark' ? 'bg-gradient-to-r from-red-900/20 to-orange-900/20 border border-red-800' : 'bg-gradient-to-r from-red-50 to-orange-50 border border-red-200') ?>">
            <div class="p-4 flex items-center justify-between">
                <div class="flex items-center">
                    <div class="w-14 h-14 rounded-full <?= $mfaConfigurado 
                        ? ($temaAtual === 'dark' ? 'bg-green-800/40' : 'bg-green-100')
                        : ($temaAtual === 'dark' ? 'bg-red-800/40' : 'bg-red-100') ?> flex items-center justify-center mr-4">
                        <i class="<?= $mfaConfigurado 
                            ? ($temaAtual === 'dark' ? 'fas fa-shield-check text-green-400' : 'fas fa-shield-check text-green-600')
                            : ($temaAtual === 'dark' ? 'fas fa-shield-exclamation text-red-400' : 'fas fa-shield-exclamation text-red-600') ?> text-2xl"></i>
                    </div>
                    <div>
                        <h3 class="text-lg font-bold <?= $mfaConfigurado 
                            ? ($temaAtual === 'dark' ? 'text-green-300' : 'text-green-700')
                            : ($temaAtual === 'dark' ? 'text-red-300' : 'text-red-700') ?>">
                            <?= $mfaConfigurado ? 'Autenticação Multifator Ativada' : 'MFA Não Configurado' ?>
                        </h3>
                        <p class="text-sm <?= $temaAtual === 'dark' ? 'text-gray-300' : 'text-gray-600' ?> mt-1">
                            <?= $mfaConfigurado 
                                ? 'Sua conta está protegida com código MFA de 6 dígitos.' 
                                : 'Configure o MFA para aumentar a segurança da sua conta.' ?>
                        </p>
                    </div>
                </div>
                <?php if (!$mfaConfigurado): ?>
                    <button onclick="carregarPagina('seguranca')" class="bg-gradient-to-r from-red-500 to-orange-500 hover:from-red-600 hover:to-orange-600 text-white px-5 py-2.5 rounded-lg font-medium text-sm flex items-center shadow-sm hover:shadow transition-all">
                        <i class="fas fa-cog mr-2"></i> Configurar MFA
                    </button>
                <?php else: ?>
                    <button onclick="carregarPagina('seguranca')" class="bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600 text-white px-5 py-2.5 rounded-lg font-medium text-sm flex items-center shadow-sm hover:shadow transition-all">
                        <i class="fas fa-sync-alt mr-2"></i> Gerenciar MFA
                    </button>
                <?php endif; ?>
            </div>
        </div>

        <!-- Gráficos -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
            <!-- Atividade por Hora -->
            <div class="rounded-xl border shadow-sm p-5 <?= $temaAtual === 'dark' ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200' ?>">
                <div class="flex items-center justify-between mb-5">
                    <div>
                        <h3 class="text-lg font-bold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-800' ?> flex items-center">
                            <i class="fas fa-chart-line <?= $temaAtual === 'dark' ? 'text-blue-400' : 'text-blue-500' ?> mr-3"></i>
                            Atividade por Hora
                        </h3>
                        <p class="text-sm <?= $temaAtual === 'dark' ? 'text-gray-400' : 'text-gray-500' ?> mt-1">Últimas 6 horas</p>
                    </div>
                    <div class="flex items-center space-x-2">
                        <div class="flex items-center text-xs">
                            <div class="w-3 h-3 rounded-full bg-green-500 mr-1"></div>
                            <span class="<?= $temaAtual === 'dark' ? 'text-gray-300' : 'text-gray-600' ?>">Sucesso</span>
                        </div>
                        <div class="flex items-center text-xs">
                            <div class="w-3 h-3 rounded-full bg-red-500 mr-1"></div>
                            <span class="<?= $temaAtual === 'dark' ? 'text-gray-300' : 'text-gray-600' ?>">Falha</span>
                        </div>
                    </div>
                </div>
                <div class="chart-container" style="height: 280px;">
                    <canvas id="loginsChart"></canvas>
                </div>
            </div>

            <!-- Distribuição de Eventos -->
            <div class="rounded-xl border shadow-sm p-5 <?= $temaAtual === 'dark' ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200' ?>">
                <div class="flex items-center justify-between mb-5">
                    <div>
                        <h3 class="text-lg font-bold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-800' ?> flex items-center">
                            <i class="fas fa-chart-pie <?= $temaAtual === 'dark' ? 'text-purple-400' : 'text-purple-500' ?> mr-3"></i>
                            Distribuição de Eventos
                        </h3>
                        <p class="text-sm <?= $temaAtual === 'dark' ? 'text-gray-400' : 'text-gray-500' ?> mt-1">Últimos 7 dias</p>
                    </div>
                    <span class="text-xs font-medium px-3 py-1 <?= $temaAtual === 'dark' ? 'bg-gray-700 text-gray-300' : 'bg-gray-100 text-gray-700' ?> rounded-full">
                        <?= array_sum(array_column($distribuicaoEventos, 'quantidade')) ?> eventos
                    </span>
                </div>
                <div class="chart-container" style="height: 280px;">
                    <canvas id="eventosChart"></canvas>
                </div>
            </div>
        </div>

        <!-- Últimos Eventos -->
        <div class="rounded-xl border shadow-sm p-5 mb-8 <?= $temaAtual === 'dark' ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200' ?>">
            <div class="flex items-center justify-between mb-6">
                <div>
                    <h3 class="text-lg font-bold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-800' ?> flex items-center">
                        <i class="fas fa-history <?= $temaAtual === 'dark' ? 'text-amber-400' : 'text-amber-500' ?> mr-3"></i>
                        Últimos Eventos de Segurança
                    </h3>
                    <p class="text-sm <?= $temaAtual === 'dark' ? 'text-gray-400' : 'text-gray-500' ?> mt-1">Registros em tempo real</p>
                </div>
                <a href="#" onclick="carregarPagina('eventos')" class="text-sm text-marinho-400 hover:text-marinho-300 font-medium clickable transition-colors flex items-center">
                    Ver todos
                    <i class="fas fa-arrow-right ml-2 text-xs"></i>
                </a>
            </div>

            <div class="overflow-x-auto rounded-lg border <?= $temaAtual === 'dark' ? 'border-gray-700' : 'border-gray-200' ?>">
                <table class="w-full">
                    <thead>
                        <tr class="text-left text-sm <?= $temaAtual === 'dark' ? 'text-gray-300 bg-gray-900/50' : 'text-gray-700 bg-gray-50/80' ?> border-b <?= $temaAtual === 'dark' ? 'border-gray-700' : 'border-gray-200' ?>">
                            <th class="px-5 py-3 font-semibold">Data/Hora</th>
                            <th class="px-5 py-3 font-semibold">Usuário</th>
                            <th class="px-5 py-3 font-semibold">Evento</th>
                            <th class="px-5 py-3 font-semibold">IP Origem</th>
                            <th class="px-5 py-3 font-semibold">Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (count($ultimosEventos) > 0): ?>
                            <?php foreach ($ultimosEventos as $evento): ?>
                                <tr class="text-sm hover:<?= $temaAtual === 'dark' ? 'bg-gray-700/50' : 'bg-gray-50/80' ?> transition-colors border-b <?= $temaAtual === 'dark' ? 'border-gray-800' : 'border-gray-100' ?> last:border-b-0">
                                    <td class="px-5 py-4">
                                        <div class="flex flex-col">
                                            <span class="font-medium <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?>"><?= date('d/m/Y', strtotime($evento['data_hora'])) ?></span>
                                            <span class="text-xs <?= $temaAtual === 'dark' ? 'text-gray-400' : 'text-gray-500' ?>"><?= date('H:i:s', strtotime($evento['data_hora'])) ?></span>
                                        </div>
                                    </td>
                                    <td class="px-5 py-4">
                                        <div class="flex items-center">
                                            <div class="w-9 h-9 rounded-full <?= $temaAtual === 'dark' ? 'bg-blue-900/40' : 'bg-gradient-to-r from-blue-100 to-blue-50' ?> flex items-center justify-center mr-3">
                                                <span class="<?= $temaAtual === 'dark' ? 'text-blue-300' : 'text-blue-600' ?> font-bold text-sm">
                                                    <?= strtoupper(substr($evento['nome_completo'] ?? 'S', 0, 1)) ?>
                                                </span>
                                            </div>
                                            <div>
                                                <p class="font-semibold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?>">
                                                    <?= htmlspecialchars($evento['nome_completo'] ?? 'Sistema') ?>
                                                </p>
                                                <p class="text-xs <?= $temaAtual === 'dark' ? 'text-gray-400' : 'text-gray-500' ?>">
                                                    <?= htmlspecialchars($evento['tipo_usuario_formatado'] ?? $evento['tipo_usuario'] ?? 'Sistema') ?>
                                                </p>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="px-5 py-4">
                                        <div class="flex items-center">
                                            <?php
                                            $icon = match(true) {
                                                $evento['tipo_evento'] === 'LOGIN_SUCCESS' => 'fa-sign-in-alt',
                                                str_contains($evento['tipo_evento'], 'FAILED') => 'fa-exclamation-triangle',
                                                $evento['tipo_evento'] === 'LOGOUT' => 'fa-sign-out-alt',
                                                default => 'fa-history'
                                            };
                                            ?>
                                            <i class="fas <?= $icon ?> <?= $temaAtual === 'dark' ? 'text-gray-500' : 'text-gray-400' ?> mr-2 text-sm"></i>
                                            <span class="font-medium <?= $temaAtual === 'dark' ? 'text-gray-200' : 'text-gray-700' ?>">
                                                <?= ucfirst(str_replace('_', ' ', strtolower($evento['tipo_evento']))) ?>
                                            </span>
                                        </div>
                                    </td>
                                    <td class="px-5 py-4">
                                        <span class="font-mono text-sm <?= $temaAtual === 'dark' ? 'bg-gray-700 text-gray-300' : 'bg-gray-100 text-gray-700' ?> px-3 py-1 rounded">
                                            <?= htmlspecialchars($evento['ip_origem']) ?>
                                        </span>
                                    </td>
                                    <td class="px-5 py-4">
                                        <?php
                                        $badgeClass = match(true) {
                                            $evento['tipo_evento'] === 'LOGIN_SUCCESS' => $temaAtual === 'dark' ? 'bg-green-900/40 text-green-300' : 'bg-green-100 text-green-800',
                                            str_contains($evento['tipo_evento'], 'FAILED') => $temaAtual === 'dark' ? 'bg-red-900/40 text-red-300' : 'bg-red-100 text-red-800',
                                            $evento['tipo_evento'] === 'LOGOUT' => $temaAtual === 'dark' ? 'bg-amber-900/40 text-amber-300' : 'bg-amber-100 text-amber-800',
                                            default => $temaAtual === 'dark' ? 'bg-gray-700 text-gray-300' : 'bg-gray-100 text-gray-800'
                                        };

                                        $badgeText = match(true) {
                                            $evento['tipo_evento'] === 'LOGIN_SUCCESS' => 'Sucesso',
                                            str_contains($evento['tipo_evento'], 'FAILED') => 'Falha',
                                            $evento['tipo_evento'] === 'LOGOUT' => 'Logout',
                                            default => 'Evento'
                                        };
                                        ?>
                                        <span class="px-3 py-1.5 rounded-full text-xs font-medium <?= $badgeClass ?> inline-flex items-center">
                                            <i class="fas <?= 
                                                $badgeText === 'Sucesso' ? 'fa-check-circle' : 
                                                ($badgeText === 'Falha' ? 'fa-times-circle' : 
                                                ($badgeText === 'Logout' ? 'fa-sign-out-alt' : 'fa-history')) 
                                            ?> mr-1.5"></i>
                                            <?= $badgeText ?>
                                        </span>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="5" class="px-5 py-8 text-center <?= $temaAtual === 'dark' ? 'text-gray-400' : 'text-gray-500' ?>">
                                    <i class="fas fa-inbox text-3xl mb-2 opacity-50"></i>
                                    <p class="text-sm">Nenhum evento registrado ainda.</p>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Informações de Usuários -->
        <?php if (count($usuariosPorTipo) > 0): ?>
        <div class="rounded-xl border shadow-sm p-5 mb-8 <?= $temaAtual === 'dark' ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200' ?>">
            <div class="flex items-center justify-between mb-6">
                <div>
                    <h3 class="text-lg font-bold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-800' ?> flex items-center">
                        <i class="fas fa-users <?= $temaAtual === 'dark' ? 'text-blue-400' : 'text-blue-500' ?> mr-3"></i>
                        Distribuição de Usuários
                    </h3>
                    <p class="text-sm <?= $temaAtual === 'dark' ? 'text-gray-400' : 'text-gray-500' ?> mt-1">Total: <?= $totalUsuarios ?> usuários ativos</p>
                </div>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                <?php foreach ($usuariosPorTipo as $tipo): ?>
                    <?php
                    $tipoInfo = match($tipo['tipo_usuario']) {
                        'admin' => [
                            'color' => $temaAtual === 'dark' ? 'from-red-900/20 to-orange-900/20' : 'from-red-50 to-orange-50',
                            'border' => $temaAtual === 'dark' ? 'border-red-800' : 'border-red-200',
                            'icon' => 'fa-user-shield',
                            'text' => 'Administradores'
                        ],
                        'auditor' => [
                            'color' => $temaAtual === 'dark' ? 'from-blue-900/20 to-indigo-900/20' : 'from-blue-50 to-indigo-50',
                            'border' => $temaAtual === 'dark' ? 'border-blue-800' : 'border-blue-200',
                            'icon' => 'fa-user-secret',
                            'text' => 'Auditores'
                        ],
                        default => [
                            'color' => $temaAtual === 'dark' ? 'from-green-900/20 to-emerald-900/20' : 'from-green-50 to-emerald-50',
                            'border' => $temaAtual === 'dark' ? 'border-green-800' : 'border-green-200',
                            'icon' => 'fa-user',
                            'text' => 'Usuários Comuns'
                        ]
                    };
                    ?>
                    <div class="rounded-lg border p-4 <?= $temaAtual === 'dark' ? $tipoInfo['color'] . ' ' . $tipoInfo['border'] : $tipoInfo['color'] . ' ' . $tipoInfo['border'] ?>">
                        <div class="flex items-center justify-between mb-2">
                            <div class="flex items-center">
                                <div class="w-10 h-10 rounded-full <?= $temaAtual === 'dark' ? 'bg-gray-700' : 'bg-gray-100' ?> flex items-center justify-center mr-3">
                                    <i class="fas <?= $tipoInfo['icon'] ?> <?= $temaAtual === 'dark' ? 'text-gray-300' : 'text-gray-600' ?>"></i>
                                </div>
                                <div>
                                    <p class="font-bold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-800' ?>"><?= $tipoInfo['text'] ?></p>
                                    <p class="text-2xl font-bold <?= $temaAtual === 'dark' ? 'text-gray-300' : 'text-gray-700' ?>"><?= $tipo['quantidade'] ?></p>
                                </div>
                            </div>
                        </div>
                        <?php if (!empty($tipo['nomes'])): ?>
                            <p class="text-xs <?= $temaAtual === 'dark' ? 'text-gray-400' : 'text-gray-600' ?> mt-2 truncate">
                                <i class="fas fa-users mr-1"></i>
                                <?= htmlspecialchars($tipo['nomes']) ?>
                            </p>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

        <!-- Ações Rápidas -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-5">
            <div class="rounded-xl border p-5 hover:shadow-md transition-all clickable <?= $temaAtual === 'dark' ? 'bg-gray-800 border-gray-700 hover:border-amber-500' : 'border-amber-200 hover:shadow-amber-50' ?> bg-gradient-to-r <?= $temaAtual === 'dark' ? 'from-amber-900/10 to-orange-900/10' : 'from-amber-50 to-orange-50' ?>" onclick="carregarPagina('mfa')">
                <div class="w-12 h-12 rounded-full <?= $temaAtual === 'dark' ? 'bg-gradient-to-r from-amber-900/30 to-orange-900/30' : 'bg-gradient-to-r from-amber-100 to-orange-100' ?> flex items-center justify-center mb-4">
                    <i class="fas fa-lock <?= $temaAtual === 'dark' ? 'text-amber-400' : 'text-amber-600' ?> text-xl"></i>
                </div>
                <h3 class="text-base font-bold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-800' ?> mb-2">Gerenciar MFA</h3>
                <p class="text-sm <?= $temaAtual === 'dark' ? 'text-gray-300' : 'text-gray-600' ?> mb-4">Configure ou altere seu código de autenticação multifator.</p>
                <div class="flex items-center <?= $temaAtual === 'dark' ? 'text-amber-300' : 'text-amber-700' ?> text-sm font-semibold">
                    <span>Configurar Segurança</span>
                    <i class="fas fa-arrow-right ml-2 transform group-hover:translate-x-1 transition-transform"></i>
                </div>
            </div>

            <div class="rounded-xl border p-5 hover:shadow-md transition-all clickable <?= $temaAtual === 'dark' ? 'bg-gray-800 border-gray-700 hover:border-emerald-500' : 'border-emerald-200 hover:shadow-emerald-50' ?> bg-gradient-to-r <?= $temaAtual === 'dark' ? 'from-emerald-900/10 to-green-900/10' : 'from-emerald-50 to-green-50' ?>" onclick="carregarPagina('auditoria')">
                <div class="w-12 h-12 rounded-full <?= $temaAtual === 'dark' ? 'bg-gradient-to-r from-emerald-900/30 to-green-900/30' : 'bg-gradient-to-r from-emerald-100 to-green-100' ?> flex items-center justify-center mb-4">
                    <i class="fas fa-link <?= $temaAtual === 'dark' ? 'text-emerald-400' : 'text-emerald-600' ?> text-xl"></i>
                </div>
                <h3 class="text-base font-bold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-800' ?> mb-2">Verificar Blockchain</h3>
                <p class="text-sm <?= $temaAtual === 'dark' ? 'text-gray-300' : 'text-gray-600' ?> mb-4">Acesse registros imutáveis e auditáveis da blockchain.</p>
                <div class="flex items-center <?= $temaAtual === 'dark' ? 'text-emerald-300' : 'text-emerald-700' ?> text-sm font-semibold">
                    <span>Acessar Auditoria</span>
                    <i class="fas fa-arrow-right ml-2 transform group-hover:translate-x-1 transition-transform"></i>
                </div>
            </div>

            <div class="rounded-xl border p-5 hover:shadow-md transition-all clickable <?= $temaAtual === 'dark' ? 'bg-gray-800 border-gray-700 hover:border-violet-500' : 'border-violet-200 hover:shadow-violet-50' ?> bg-gradient-to-r <?= $temaAtual === 'dark' ? 'from-violet-900/10 to-purple-900/10' : 'from-violet-50 to-purple-50' ?>" onclick="carregarPagina('relatorios')">
                <div class="w-12 h-12 rounded-full <?= $temaAtual === 'dark' ? 'bg-gradient-to-r from-violet-900/30 to-purple-900/30' : 'bg-gradient-to-r from-violet-100 to-purple-100' ?> flex items-center justify-center mb-4">
                    <i class="fas fa-chart-bar <?= $temaAtual === 'dark' ? 'text-violet-400' : 'text-violet-600' ?> text-xl"></i>
                </div>
                <h3 class="text-base font-bold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-800' ?> mb-2">Gerar Relatório</h3>
                <p class="text-sm <?= $temaAtual === 'dark' ? 'text-gray-300' : 'text-gray-600' ?> mb-4">Crie relatórios detalhados de segurança e auditoria.</p>
                <div class="flex items-center <?= $temaAtual === 'dark' ? 'text-violet-300' : 'text-violet-700' ?> text-sm font-semibold">
                    <span>Criar Relatório</span>
                    <i class="fas fa-arrow-right ml-2 transform group-hover:translate-x-1 transition-transform"></i>
                </div>
            </div>
        </div>
    </main>
</div>

<!-- Scripts para gráficos e partículas -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script src="https://cdn.jsdelivr.net/particles.js/2.0.0/particles.min.js"></script>

<script>
// Configuração das partículas
function inicializarParticulas() {
    const temaAtual = "<?= $temaAtual ?>";
    
    particlesJS('particles-js', {
        particles: {
            number: {
                value: temaAtual === 'dark' ? 80 : 50,
                density: {
                    enable: true,
                    value_area: 800
                }
            },
            color: {
                value: temaAtual === 'dark' ? '#3b82f6' : '#8b5cf6'
            },
            shape: {
                type: 'circle',
                stroke: {
                    width: 0,
                    color: temaAtual === 'dark' ? '#1e40af' : '#7c3aed'
                }
            },
            opacity: {
                value: temaAtual === 'dark' ? 0.3 : 0.2,
                random: true,
                anim: {
                    enable: true,
                    speed: 1,
                    opacity_min: 0.1,
                    sync: false
                }
            },
            size: {
                value: 3,
                random: true,
                anim: {
                    enable: true,
                    speed: 2,
                    size_min: 0.1,
                    sync: false
                }
            },
            line_linked: {
                enable: true,
                distance: temaAtual === 'dark' ? 150 : 100,
                color: temaAtual === 'dark' ? '#4f46e5' : '#8b5cf6',
                opacity: temaAtual === 'dark' ? 0.1 : 0.05,
                width: 1
            },
            move: {
                enable: true,
                speed: 1,
                direction: 'none',
                random: true,
                straight: false,
                out_mode: 'out',
                bounce: false,
                attract: {
                    enable: false,
                    rotateX: 600,
                    rotateY: 1200
                }
            }
        },
        interactivity: {
            detect_on: 'canvas',
            events: {
                onhover: {
                    enable: true,
                    mode: 'repulse'
                },
                onclick: {
                    enable: true,
                    mode: 'push'
                },
                resize: true
            },
            modes: {
                grab: {
                    distance: 400,
                    line_linked: {
                        opacity: 1
                    }
                },
                bubble: {
                    distance: 400,
                    size: 40,
                    duration: 2,
                    opacity: 8,
                    speed: 3
                },
                repulse: {
                    distance: 100,
                    duration: 0.4
                },
                push: {
                    particles_nb: 4
                },
                remove: {
                    particles_nb: 2
                }
            }
        },
        retina_detect: true
    });
}

// Inicializar gráficos do dashboard
function inicializarGraficosDashboard() {
    const estatisticasHora = <?= json_encode($horasCompletas) ?>;
    const distribuicaoEventos = <?= json_encode($distribuicaoEventos) ?>;
    const temaAtual = "<?= $temaAtual ?>";

    // Configuração global do Chart.js baseado no tema
    Chart.defaults.color = temaAtual === 'dark' ? '#d1d5db' : '#4b5563';
    Chart.defaults.borderColor = temaAtual === 'dark' ? 'rgba(255, 255, 255, 0.1)' : 'rgba(0, 0, 0, 0.1)';

    // Gráfico de Logins por Hora
    if (estatisticasHora.length > 0) {
        const horas = estatisticasHora.map(item => item.hora);
        const loginsSucesso = estatisticasHora.map(item => parseInt(item.logins_sucesso) || 0);
        const loginsFalha = estatisticasHora.map(item => parseInt(item.logins_falha) || 0);

        const ctx1 = document.getElementById('loginsChart');
        if (ctx1) {
            if (ctx1.chart) ctx1.chart.destroy();
            ctx1.chart = new Chart(ctx1.getContext('2d'), {
                type: 'line',
                data: {
                    labels: horas,
                    datasets: [
                        {
                            label: 'Logins Bem-sucedidos',
                            data: loginsSucesso,
                            borderColor: '#10b981',
                            backgroundColor: temaAtual === 'dark' ? 'rgba(16, 185, 129, 0.15)' : 'rgba(16, 185, 129, 0.08)',
                            borderWidth: 3,
                            tension: 0.3,
                            fill: true,
                            pointBackgroundColor: '#10b981',
                            pointBorderColor: temaAtual === 'dark' ? '#1f2937' : '#ffffff',
                            pointBorderWidth: 2,
                            pointRadius: 4,
                            pointHoverRadius: 6
                        },
                        {
                            label: 'Tentativas Falhas',
                            data: loginsFalha,
                            borderColor: '#ef4444',
                            backgroundColor: temaAtual === 'dark' ? 'rgba(239, 68, 68, 0.15)' : 'rgba(239, 68, 68, 0.08)',
                            borderWidth: 3,
                            tension: 0.3,
                            fill: true,
                            pointBackgroundColor: '#ef4444',
                            pointBorderColor: temaAtual === 'dark' ? '#1f2937' : '#ffffff',
                            pointBorderWidth: 2,
                            pointRadius: 4,
                            pointHoverRadius: 6
                        }
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { 
                            position: 'top', 
                            labels: { 
                                padding: 15, 
                                usePointStyle: true, 
                                pointStyle: 'circle',
                                font: { size: 12 },
                                color: temaAtual === 'dark' ? '#e5e7eb' : '#374151'
                            } 
                        },
                        tooltip: { 
                            mode: 'index', 
                            intersect: false,
                            backgroundColor: temaAtual === 'dark' ? 'rgba(17, 24, 39, 0.9)' : 'rgba(0, 0, 0, 0.8)',
                            titleColor: temaAtual === 'dark' ? '#e5e7eb' : '#ffffff',
                            bodyColor: temaAtual === 'dark' ? '#e5e7eb' : '#ffffff',
                            titleFont: { size: 12 },
                            bodyFont: { size: 13 }
                        }
                    },
                    scales: {
                        y: { 
                            beginAtZero: true, 
                            grid: { 
                                color: temaAtual === 'dark' ? 'rgba(255, 255, 255, 0.05)' : 'rgba(0,0,0,0.04)',
                                drawBorder: false
                            }, 
                            ticks: { 
                                precision: 0,
                                font: { size: 11 }
                            } 
                        },
                        x: { 
                            grid: { 
                                color: temaAtual === 'dark' ? 'rgba(255, 255, 255, 0.05)' : 'rgba(0,0,0,0.04)',
                                drawBorder: false
                            },
                            ticks: {
                                font: { size: 11 }
                            }
                        }
                    },
                    interaction: { intersect: false, mode: 'nearest' },
                    elements: {
                        line: {
                            tension: 0.3
                        }
                    }
                }
            });
        }
    } else {
        // Caso não haja dados, mostrar mensagem no gráfico
        const ctx1 = document.getElementById('loginsChart');
        if (ctx1) {
            ctx1.innerHTML = '<div class="flex flex-col items-center justify-center h-full text-gray-500">' +
                '<i class="fas fa-chart-line text-3xl mb-2 opacity-50"></i>' +
                '<p class="text-sm">Sem dados de atividade nas últimas 6 horas</p>' +
                '</div>';
        }
    }

    // Gráfico de Distribuição
    if (distribuicaoEventos.length > 0) {
        const categorias = distribuicaoEventos.map(item => item.categoria);
        const quantidades = distribuicaoEventos.map(item => parseInt(item.quantidade) || 0);
        
        const cores = temaAtual === 'dark' ? [
            'rgba(16, 185, 129, 0.9)',   // verde
            'rgba(239, 68, 68, 0.9)',    // vermelho
            'rgba(245, 158, 11, 0.9)',   // amber
            'rgba(139, 92, 246, 0.9)',   // roxo
            'rgba(59, 130, 246, 0.9)',   // azul
            'rgba(156, 163, 175, 0.9)'   // cinza
        ] : [
            'rgba(16, 185, 129, 0.8)',
            'rgba(239, 68, 68, 0.8)',
            'rgba(245, 158, 11, 0.8)',
            'rgba(139, 92, 246, 0.8)',
            'rgba(59, 130, 246, 0.8)',
            'rgba(107, 114, 128, 0.8)'
        ];

        const ctx2 = document.getElementById('eventosChart');
        if (ctx2) {
            if (ctx2.chart) ctx2.chart.destroy();
            ctx2.chart = new Chart(ctx2.getContext('2d'), {
                type: 'doughnut',
                data: {
                    labels: categorias,
                    datasets: [{
                        data: quantidades,
                        backgroundColor: cores.slice(0, categorias.length),
                        borderColor: temaAtual === 'dark' ? '#1f2937' : '#ffffff',
                        borderWidth: 3,
                        hoverOffset: 20,
                        hoverBorderWidth: 4
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { 
                            position: 'right', 
                            labels: { 
                                padding: 15, 
                                usePointStyle: true, 
                                pointStyle: 'circle',
                                font: { size: 11 },
                                color: temaAtual === 'dark' ? '#e5e7eb' : '#374151'
                            } 
                        },
                        tooltip: {
                            backgroundColor: temaAtual === 'dark' ? 'rgba(17, 24, 39, 0.9)' : 'rgba(0, 0, 0, 0.8)',
                            titleColor: temaAtual === 'dark' ? '#e5e7eb' : '#ffffff',
                            bodyColor: temaAtual === 'dark' ? '#e5e7eb' : '#ffffff',
                            titleFont: { size: 12 },
                            bodyFont: { size: 13 },
                            callbacks: {
                                label: function(context) {
                                    const label = context.label || '';
                                    const value = context.raw || 0;
                                    const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                    const percentage = Math.round((value / total) * 100);
                                    return `${label}: ${value} (${percentage}%)`;
                                }
                            }
                        }
                    },
                    cutout: '70%',
                    animation: {
                        animateScale: true,
                        animateRotate: true
                    }
                }
            });
        }
    } else {
        // Caso não haja dados, mostrar mensagem no gráfico
        const ctx2 = document.getElementById('eventosChart');
        if (ctx2) {
            ctx2.innerHTML = '<div class="flex flex-col items-center justify-center h-full text-gray-500">' +
                '<i class="fas fa-chart-pie text-3xl mb-2 opacity-50"></i>' +
                '<p class="text-sm">Sem dados de eventos nos últimos 7 dias</p>' +
                '</div>';
        }
    }
}

// Função para atualizar tema dinamicamente
function atualizarTemaDashboard(novoTema) {
    // Atualizar sessão via AJAX
    fetch('ajax/atualizar-tema.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ tema: novoTema })
    }).then(() => {
        // Recarregar dashboard com novo tema
        carregarPagina('dashboard');
    });
}

// Inicializar tudo quando o DOM estiver pronto
document.addEventListener('DOMContentLoaded', function() {
    inicializarParticulas();
    inicializarGraficosDashboard();
    
    // Verificar mudanças de tema
    if (typeof window.onTemaAlterado === 'function') {
        window.onTemaAlterado = function(novoTema) {
            atualizarTemaDashboard(novoTema);
        };
    }
});

// Função de inicialização do dashboard
function inicializarDashboard() {
    inicializarGraficosDashboard();
    inicializarParticulas();
}
</script>

<!-- Estilo adicional para partículas -->
<style>
#particles-js {
    position: absolute;
    width: 100%;
    height: 100%;
    pointer-events: none;
    z-index: 0;
}

.z-10 {
    position: relative;
    z-index: 10;
}

.chart-container {
    position: relative;
    width: 100%;
}

/* Ajustes para modo escuro */
.dark .chart-container canvas {
    filter: brightness(0.9);
}

/* Transições suaves */
.transition-colors {
    transition: background-color 0.3s ease, border-color 0.3s ease, color 0.3s ease;
}

/* Ajuste de contraste para modo escuro */
.dark .text-gray-300 {
    color: #d1d5db;
}

.dark .text-gray-400 {
    color: #9ca3af;
}

.dark .text-gray-500 {
    color: #6b7280;
}
</style>