<?php
// Verificar se as constantes estão definidas
if (!defined('NOME_SISTEMA')) {
    require_once __DIR__ . '/../includes/config.php';
}

// Verificar se o usuário está logado
if (!isset($_SESSION['id_usuario']) || empty($_SESSION['id_usuario'])) {
    echo '<div class="p-6 text-center text-white">Faça login para acessar esta página</div>';
    return;
}

// Incluir funções de segurança
require_once __DIR__ . '/../includes/funcoes-seguranca.php';

// Verificar tema atual
$temaAtual = $_SESSION['tema'] ?? 'dark';

$pdo = conectarBancoDados();
$idUsuario = $_SESSION['id_usuario'];

// Buscar informações do usuário
$stmt = $pdo->prepare("SELECT nome_completo, email, tipo_usuario, data_ultimo_login, data_ultima_atividade, ultimo_ip FROM usuarios WHERE id_usuario = ?");
$stmt->execute([$idUsuario]);
$usuario = $stmt->fetch(PDO::FETCH_ASSOC);

// Buscar informações de MFA
$stmt = $pdo->prepare("SELECT mfa_codigo_hash, mfa_ultima_alteracao FROM usuarios WHERE id_usuario = ?");
$stmt->execute([$idUsuario]);
$mfaInfo = $stmt->fetch(PDO::FETCH_ASSOC);

$mfaAtivado = !empty($mfaInfo['mfa_codigo_hash']);
$dataMFA = $mfaInfo['mfa_ultima_alteracao'] ? date('d/m/Y H:i', strtotime($mfaInfo['mfa_ultima_alteracao'])) : 'Nunca';

// Buscar última alteração de senha
$stmt = $pdo->prepare("SELECT data_hora FROM registro_eventos WHERE id_usuario = ? AND tipo_evento = 'SENHA_ALTERADA' ORDER BY data_hora DESC LIMIT 1");
$stmt->execute([$idUsuario]);
$ultimaAlteracaoSenha = $stmt->fetch(PDO::FETCH_COLUMN);

if ($ultimaAlteracaoSenha) {
    $dataAlteracao = new DateTime($ultimaAlteracaoSenha);
    $agora = new DateTime();
    $diferenca = $agora->diff($dataAlteracao);
    $diasDesdeAlteracao = $diferenca->days;
    $statusSenha = $diasDesdeAlteracao > 90 ? 'critico' : ($diasDesdeAlteracao > 60 ? 'alerta' : 'seguro');
} else {
    $diasDesdeAlteracao = 'N/A';
    $statusSenha = 'desconhecido';
}

// Buscar sessões ativas
$stmt = $pdo->prepare("SELECT id_sessao, ip, user_agent, data_inicio, data_ultima_atividade, expiracao FROM sessoes_ativas WHERE id_usuario = ? AND expiracao > NOW() ORDER BY data_ultima_atividade DESC");
$stmt->execute([$idUsuario]);
$sessoesAtivas = $stmt->fetchAll(PDO::FETCH_ASSOC);

$numeroSessoes = count($sessoesAtivas);
$sessaoAtual = session_id();

// Buscar histórico de login (apenas 4 últimos eventos)
$stmt = $pdo->prepare("
    SELECT 
        tipo_evento,
        ip_origem,
        user_agent,
        data_hora,
        dados_auditoria
    FROM registro_eventos 
    WHERE id_usuario = ? 
    AND tipo_evento IN ('LOGIN_SUCCESS', 'LOGIN_FAILED', 'LOGOUT', 'MFA_CREATED', 'MFA_REMOVED', 'SENHA_ALTERADA')
    ORDER BY data_hora DESC 
    LIMIT 4
");
$stmt->execute([$idUsuario]);
$historicoLogin = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Buscar estatísticas de segurança (últimos 30 dias)
$stmt = $pdo->prepare("
    SELECT 
        tipo_evento,
        COUNT(*) as quantidade
    FROM registro_eventos 
    WHERE id_usuario = ? 
    AND data_hora > DATE_SUB(NOW(), INTERVAL 30 DAY)
    AND tipo_evento = 'LOGIN_FAILED'
    GROUP BY tipo_evento
");
$stmt->execute([$idUsuario]);
$tentativasFalhas30Dias = $stmt->fetch(PDO::FETCH_ASSOC)['quantidade'] ?? 0;
?>

<div class="p-6">
    <!-- Breadcrumb -->
    <div class="mb-6 flex items-center text-sm <?= $temaAtual === 'dark' ? 'text-white/70' : 'text-gray-600' ?>">
        <a href="#" onclick="carregarPagina('dashboard')" class="hover:text-blue-400 clickable transition-colors flex items-center">
            <i class="fas fa-home mr-2 text-xs"></i> Dashboard
        </a>
        <i class="fas fa-chevron-right mx-2 text-xs <?= $temaAtual === 'dark' ? 'text-white/50' : 'text-gray-400' ?>"></i>
        <span class="text-blue-400 font-medium">Minha Segurança</span>
    </div>

    <!-- Cabeçalho com ícone e status -->
    <div class="mb-8">
        <div class="flex items-center justify-between mb-4">
            <div class="flex items-center space-x-3">
                <div class="w-14 h-14 rounded-full bg-gradient-to-br from-red-400 to-red-600 flex items-center justify-center shadow-md">
                    <i class="fas fa-shield-alt text-white text-xl"></i>
                </div>
                <div>
                    <h1 class="text-2xl font-bold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?>">Segurança da Conta</h1>
                    <p class="<?= $temaAtual === 'dark' ? 'text-white/70' : 'text-gray-600' ?>">Gerencie as configurações de segurança da sua conta</p>
                </div>
            </div>
            
            <div class="flex items-center space-x-3">
                <div class="px-4 py-2 <?= 
                    $statusSenha === 'critico' ? 'bg-red-500/20 text-red-300 border-red-500/30' : 
                    ($statusSenha === 'alerta' ? 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30' : 
                    'bg-green-500/20 text-green-300 border-green-500/30')
                ?> text-sm rounded-lg border flex items-center">
                    <i class="fas fa-<?= $statusSenha === 'critico' ? 'exclamation-triangle' : ($statusSenha === 'alerta' ? 'exclamation-circle' : 'check-circle') ?> mr-2"></i>
                    <span><?= ucfirst($statusSenha) ?></span>
                </div>
                <div class="text-xs <?= $temaAtual === 'dark' ? 'text-white/50' : 'text-gray-500' ?>">
                    <i class="fas fa-sync-alt mr-1"></i> <?= date('H:i') ?>
                </div>
            </div>
        </div>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div class="space-y-6">
            <!-- Card Senha -->
            <div class="card p-6">
                <div class="flex items-center justify-between mb-6">
                    <div>
                        <h3 class="text-lg font-bold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?> flex items-center">
                            <i class="fas fa-lock text-blue-400 mr-3"></i>
                            Senha
                        </h3>
                        <p class="text-sm <?= $temaAtual === 'dark' ? 'text-white/70' : 'text-gray-600' ?> mt-1">Atualize sua senha regularmente</p>
                    </div>
                    <div class="w-12 h-12 rounded-full <?= 
                        $diasDesdeAlteracao !== 'N/A' && $diasDesdeAlteracao <= 90 ? 
                        ($temaAtual === 'dark' ? 'bg-green-500/20' : 'bg-green-100') : 
                        ($temaAtual === 'dark' ? 'bg-red-500/20' : 'bg-red-100') 
                    ?> flex items-center justify-center">
                        <i class="fas fa-<?= $diasDesdeAlteracao !== 'N/A' && $diasDesdeAlteracao <= 90 ? 'check' : 'times' ?> <?= 
                            $diasDesdeAlteracao !== 'N/A' && $diasDesdeAlteracao <= 90 ? 
                            ($temaAtual === 'dark' ? 'text-green-400' : 'text-green-600') : 
                            ($temaAtual === 'dark' ? 'text-red-400' : 'text-red-600') 
                        ?>"></i>
                    </div>
                </div>
                
                <div class="space-y-4">
                    <div class="flex items-center justify-between p-4 <?= $temaAtual === 'dark' ? 'bg-white/5' : 'bg-blue-50' ?> rounded-lg">
                        <div>
                            <p class="text-sm font-medium <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?>">Última alteração</p>
                            <p class="text-xs <?= $temaAtual === 'dark' ? 'text-white/70' : 'text-gray-600' ?>">
                                <?php if ($ultimaAlteracaoSenha): ?>
                                    <?= date('d/m/Y H:i', strtotime($ultimaAlteracaoSenha)) ?> 
                                    (<?= $diasDesdeAlteracao !== 'N/A' ? $diasDesdeAlteracao . ' dias' : 'Desconhecido' ?>)
                                <?php else: ?>
                                    Nunca alterada
                                <?php endif; ?>
                            </p>
                        </div>
                        <button onclick="abrirModalAlterarSenha()" class="px-4 py-2 btn-gradient rounded-lg clickable text-sm transition-all flex items-center">
                            <i class="fas fa-edit mr-2"></i> Alterar
                        </button>
                    </div>
                    
                    <div class="p-4 rounded-lg <?= 
                        $diasDesdeAlteracao !== 'N/A' && $diasDesdeAlteracao > 90 ? 
                        'bg-red-500/10 border-red-500/30' : 
                        ($diasDesdeAlteracao !== 'N/A' && $diasDesdeAlteracao > 60 ? 
                         'bg-yellow-500/10 border-yellow-500/30' : 
                         'bg-green-500/10 border-green-500/30')
                    ?> border">
                        <div class="flex items-start">
                            <i class="fas fa-<?= 
                                $diasDesdeAlteracao !== 'N/A' && $diasDesdeAlteracao > 90 ? 'exclamation-circle' : 
                                ($diasDesdeAlteracao !== 'N/A' && $diasDesdeAlteracao > 60 ? 'exclamation-triangle' : 'info-circle')
                            ?> <?= 
                                $diasDesdeAlteracao !== 'N/A' && $diasDesdeAlteracao > 90 ? 'text-red-400' : 
                                ($diasDesdeAlteracao !== 'N/A' && $diasDesdeAlteracao > 60 ? 'text-yellow-400' : 'text-green-400')
                            ?> mt-0.5 mr-3"></i>
                            <div>
                                <p class="text-sm font-medium <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?>">
                                    Recomendação de segurança
                                </p>
                                <p class="text-sm <?= $temaAtual === 'dark' ? 'text-white/70' : 'text-gray-700' ?> mt-1">
                                    <?php if ($diasDesdeAlteracao === 'N/A'): ?>
                                        Configure uma senha segura para proteger sua conta.
                                    <?php elseif ($diasDesdeAlteracao > 90): ?>
                                        Sua senha está desatualizada! Altere-a imediatamente para maior segurança.
                                    <?php elseif ($diasDesdeAlteracao > 60): ?>
                                        Sua senha está ficando antiga. Recomendamos alterá-la em breve.
                                    <?php else: ?>
                                        É recomendado alterar sua senha a cada 90 dias para maior segurança.
                                    <?php endif; ?>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Card MFA -->
            <div class="card p-6">
                <div class="flex items-center justify-between mb-6">
                    <div>
                        <h3 class="text-lg font-bold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?> flex items-center">
                            <i class="fas fa-shield-alt text-yellow-400 mr-3"></i>
                            Autenticação Multifator (MFA)
                        </h3>
                        <p class="text-sm <?= $temaAtual === 'dark' ? 'text-white/70' : 'text-gray-600' ?> mt-1">Código fixo de 6 dígitos para maior segurança</p>
                    </div>
                    <div class="w-12 h-12 rounded-full <?= 
                        $mfaAtivado ? 
                        ($temaAtual === 'dark' ? 'bg-green-500/20' : 'bg-green-100') : 
                        ($temaAtual === 'dark' ? 'bg-red-500/20' : 'bg-red-100') 
                    ?> flex items-center justify-center">
                        <i class="fas fa-<?= $mfaAtivado ? 'check' : 'times' ?> <?= 
                            $mfaAtivado ? 
                            ($temaAtual === 'dark' ? 'text-green-400' : 'text-green-600') : 
                            ($temaAtual === 'dark' ? 'text-red-400' : 'text-red-600') 
                        ?>"></i>
                    </div>
                </div>
                
                <div class="space-y-4">
                    <div class="p-4 <?= 
                        $mfaAtivado ? 
                        ($temaAtual === 'dark' ? 'bg-green-500/10' : 'bg-green-50') : 
                        ($temaAtual === 'dark' ? 'bg-white/5' : 'bg-gray-50') 
                    ?> rounded-lg">
                        <p class="text-sm <?= 
                            $mfaAtivado ? 
                            ($temaAtual === 'dark' ? 'text-green-300' : 'text-green-700') : 
                            ($temaAtual === 'dark' ? 'text-white/70' : 'text-gray-600') 
                        ?>">
                            <?php if ($mfaAtivado): ?>
                                <i class="fas fa-check-circle mr-2"></i> MFA ativo desde <?= $dataMFA ?>
                            <?php else: ?>
                                <i class="fas fa-info-circle mr-2"></i> Ative o MFA definindo um código fixo de 6 dígitos. Ele será solicitado em todos os logins.
                            <?php endif; ?>
                        </p>
                    </div>
                    
                    <?php if ($mfaAtivado): ?>
                        <button onclick="abrirModalAlterarMFA()" class="w-full px-4 py-3 btn-gradient rounded-lg clickable transition-all flex items-center justify-center">
                            <i class="fas fa-edit mr-3"></i> Alterar Código MFA
                        </button>
                        <button onclick="abrirModalDesativarMFA()" class="w-full mt-2 px-4 py-3 <?= $temaAtual === 'dark' ? 'bg-red-500 hover:bg-red-600' : 'bg-red-500 hover:bg-red-600' ?> text-white rounded-lg clickable transition-all flex items-center justify-center">
                            <i class="fas fa-shield-alt mr-3"></i> Desativar MFA
                        </button>
                    <?php else: ?>
                        <button onclick="abrirModalConfigurarMFA()" class="w-full px-4 py-3 btn-gradient rounded-lg clickable transition-all flex items-center justify-center">
                            <i class="fas fa-shield-alt mr-3"></i> Ativar MFA
                        </button>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="space-y-6">
            <!-- Sessões Ativas -->
            <div class="card p-6">
                <div class="flex items-center justify-between mb-6">
                    <h3 class="text-lg font-bold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?> flex items-center">
                        <i class="fas fa-desktop text-purple-400 mr-3"></i>
                        Sessões Ativas
                    </h3>
                    <span class="px-3 py-1 <?= $temaAtual === 'dark' ? 'bg-blue-500/20 text-blue-300' : 'bg-blue-100 text-blue-800' ?> text-sm rounded-full">
                        <?= $numeroSessoes ?> sessão<?= $numeroSessoes != 1 ? 'es' : '' ?>
                    </span>
                </div>
                
                <div class="space-y-3">
                    <?php if (empty($sessoesAtivas)): ?>
                        <div class="text-center py-8 <?= $temaAtual === 'dark' ? 'text-white/50' : 'text-gray-500' ?>">
                            <i class="fas fa-user-slash text-4xl <?= $temaAtual === 'dark' ? 'text-white/20' : 'text-gray-300' ?> mb-3"></i>
                            <p>Nenhuma sessão ativa além da atual</p>
                        </div>
                    <?php else: ?>
                        <?php foreach ($sessoesAtivas as $sessao): 
                            $ehSessaoAtual = hash('sha256', $sessaoAtual) === $sessao['id_sessao'];
                            $tempoAtividade = tempoDecorrido($sessao['data_ultima_atividade']);
                            $dispositivo = detectarDispositivo($sessao['user_agent']);
                            $navegador = detectarNavegador($sessao['user_agent']);
                        ?>
                            <div class="flex items-center justify-between p-4 border rounded-lg <?= 
                                $temaAtual === 'dark' ? 
                                ($ehSessaoAtual ? 'bg-green-500/10 border-green-500/30' : 'bg-white/5 border-white/10') : 
                                ($ehSessaoAtual ? 'bg-green-50 border-green-200' : 'bg-gray-50 border-gray-200') 
                            ?>">
                                <div class="flex items-center space-x-4">
                                    <div class="w-12 h-12 rounded-lg <?= $temaAtual === 'dark' ? 'bg-' . $dispositivo['cor'] . '-500/20' : 'bg-' . $dispositivo['cor'] . '-100' ?> flex items-center justify-center">
                                        <i class="fas fa-<?= $dispositivo['icone'] ?> <?= $temaAtual === 'dark' ? 'text-' . $dispositivo['cor'] . '-400' : 'text-' . $dispositivo['cor'] . '-600' ?> text-lg"></i>
                                    </div>
                                    <div>
                                        <p class="font-medium <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?>">
                                            <?= $navegador ?> em <?= $dispositivo['tipo'] ?>
                                            <?php if ($ehSessaoAtual): ?>
                                                <span class="ml-2 px-2 py-0.5 <?= $temaAtual === 'dark' ? 'bg-green-500/20 text-green-300' : 'bg-green-100 text-green-800' ?> text-xs rounded-full">Esta sessão</span>
                                            <?php endif; ?>
                                        </p>
                                        <p class="text-xs <?= $temaAtual === 'dark' ? 'text-white/70' : 'text-gray-600' ?>">
                                            IP: <?= $sessao['ip'] ?> • 
                                            Iniciada: <?= date('d/m H:i', strtotime($sessao['data_inicio'])) ?> • 
                                            Última atividade: <?= $tempoAtividade ?>
                                        </p>
                                    </div>
                                </div>
                                <?php if (!$ehSessaoAtual): ?>
                                    <button onclick="abrirModalEncerrarSessao('<?= $sessao['id_sessao'] ?>')" 
                                            class="px-3 py-1.5 text-sm <?= $temaAtual === 'dark' ? 'bg-red-500/20 text-red-300 hover:bg-red-500/30' : 'bg-red-100 text-red-700 hover:bg-red-200' ?> rounded-lg clickable transition-colors flex items-center">
                                        <i class="fas fa-sign-out-alt mr-1.5 text-xs"></i> Encerrar
                                    </button>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
                
                <?php if ($numeroSessoes > 1): ?>
                    <button onclick="abrirModalEncerrarOutrasSessoes()" class="w-full mt-4 px-4 py-3 <?= $temaAtual === 'dark' ? 'bg-red-500 hover:bg-red-600' : 'bg-red-500 hover:bg-red-600' ?> text-white rounded-lg clickable transition-all flex items-center justify-center">
                        <i class="fas fa-sign-out-alt mr-3"></i> Encerrar Todas as Outras Sessões
                    </button>
                <?php endif; ?>
            </div>

            <!-- Histórico de Atividade (4 últimos) -->
            <div class="card p-6">
                <div class="flex items-center justify-between mb-6">
                    <h3 class="text-lg font-bold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?> flex items-center">
                        <i class="fas fa-history text-blue-400 mr-3"></i>
                        Histórico de Atividade
                    </h3>
                    <span class="text-xs <?= $temaAtual === 'dark' ? 'text-white/50' : 'text-gray-500' ?>">Últimos 4 eventos</span>
                </div>
                
                <div class="space-y-3">
                    <?php if (empty($historicoLogin)): ?>
                        <div class="text-center py-8 <?= $temaAtual === 'dark' ? 'text-white/50' : 'text-gray-500' ?>">
                            <i class="fas fa-history text-4xl <?= $temaAtual === 'dark' ? 'text-white/20' : 'text-gray-300' ?> mb-3"></i>
                            <p>Nenhum evento registrado recentemente</p>
                        </div>
                    <?php else: ?>
                        <?php foreach ($historicoLogin as $evento): 
                            $tempo = tempoDecorrido($evento['data_hora']);
                            $dispositivo = detectarDispositivo($evento['user_agent'] ?? '');
                            $navegador = detectarNavegador($evento['user_agent'] ?? '');
                            $corEvento = match($evento['tipo_evento']) {
                                'LOGIN_SUCCESS' => 'green',
                                'LOGIN_FAILED' => 'red',
                                'LOGOUT' => 'blue',
                                'MFA_CREATED' => 'green',
                                'MFA_REMOVED' => 'red',
                                'SENHA_ALTERADA' => 'purple',
                                default => 'gray'
                            };
                        ?>
                            <div class="p-4 <?= $temaAtual === 'dark' ? 'bg-white/5' : 'bg-gray-50' ?> rounded-lg hover:<?= $temaAtual === 'dark' ? 'bg-white/10' : 'bg-gray-100' ?> transition-colors clickable">
                                <div class="flex items-center justify-between mb-2">
                                    <div class="flex items-center space-x-3">
                                        <div class="w-10 h-10 rounded-lg <?= $temaAtual === 'dark' ? 'bg-' . $corEvento . '-500/20' : 'bg-' . $corEvento . '-100' ?> flex items-center justify-center">
                                            <i class="fas fa-<?= match($evento['tipo_evento']) {
                                                'LOGIN_SUCCESS' => 'check',
                                                'LOGIN_FAILED' => 'times',
                                                'LOGOUT' => 'sign-out-alt',
                                                'MFA_CREATED' => 'shield-alt',
                                                'MFA_REMOVED' => 'shield',
                                                'SENHA_ALTERADA' => 'lock',
                                                default => 'info'
                                            } ?> <?= $temaAtual === 'dark' ? 'text-' . $corEvento . '-400' : 'text-' . $corEvento . '-600' ?>"></i>
                                        </div>
                                        <div>
                                            <p class="font-medium <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?>">
                                                <?php 
                                                    switch($evento['tipo_evento']) {
                                                        case 'LOGIN_SUCCESS': echo 'Login bem-sucedido'; break;
                                                        case 'LOGIN_FAILED': echo 'Tentativa de login falha'; break;
                                                        case 'LOGOUT': echo 'Logout'; break;
                                                        case 'MFA_CREATED': echo 'MFA ativado'; break;
                                                        case 'MFA_REMOVED': echo 'MFA desativado'; break;
                                                        case 'SENHA_ALTERADA': echo 'Senha alterada'; break;
                                                        default: echo $evento['tipo_evento'];
                                                    }
                                                ?>
                                            </p>
                                            <p class="text-xs <?= $temaAtual === 'dark' ? 'text-white/70' : 'text-gray-600' ?>">
                                                <?= $navegador ?> em <?= $dispositivo['tipo'] ?> • IP: <?= $evento['ip_origem'] ?>
                                            </p>
                                        </div>
                                    </div>
                                    <span class="text-xs <?= $temaAtual === 'dark' ? 'text-white/50' : 'text-gray-500' ?>"><?= $tempo ?></span>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Alertas de Segurança -->
    <div class="mt-8">
        <div class="card p-6">
            <h3 class="text-lg font-bold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?> mb-6 flex items-center">
                <i class="fas fa-bell text-yellow-400 mr-3"></i>
                Alertas de Segurança
            </h3>
            <div class="space-y-4">
                <?php if (!$mfaAtivado): ?>
                    <div class="flex items-start p-4 <?= $temaAtual === 'dark' ? 'bg-yellow-500/10 border-yellow-500/30' : 'bg-yellow-50 border-yellow-200' ?> border rounded-lg">
                        <i class="fas fa-exclamation-triangle text-yellow-400 mt-0.5 mr-3 text-lg"></i>
                        <div class="flex-1">
                            <p class="text-sm font-medium <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?>">MFA não ativado</p>
                            <p class="text-sm <?= $temaAtual === 'dark' ? 'text-white/70' : 'text-gray-700' ?>">Ative a autenticação multifator para proteger melhor sua conta.</p>
                        </div>
                        <button onclick="abrirModalConfigurarMFA()" class="ml-4 px-4 py-2 <?= $temaAtual === 'dark' ? 'bg-yellow-500 hover:bg-yellow-600' : 'bg-yellow-500 hover:bg-yellow-600' ?> text-white text-sm rounded-lg clickable transition-all">
                            Ativar agora
                        </button>
                    </div>
                <?php endif; ?>
                
                <?php if ($diasDesdeAlteracao !== 'N/A' && $diasDesdeAlteracao > 90): ?>
                    <div class="flex items-start p-4 <?= $temaAtual === 'dark' ? 'bg-red-500/10 border-red-500/30' : 'bg-red-50 border-red-200' ?> border rounded-lg">
                        <i class="fas fa-exclamation-circle text-red-400 mt-0.5 mr-3 text-lg"></i>
                        <div class="flex-1">
                            <p class="text-sm font-medium <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?>">Senha desatualizada</p>
                            <p class="text-sm <?= $temaAtual === 'dark' ? 'text-white/70' : 'text-gray-700' ?>">Sua senha tem mais de 90 dias. Altere imediatamente.</p>
                        </div>
                        <button onclick="abrirModalAlterarSenha()" class="ml-4 px-4 py-2 <?= $temaAtual === 'dark' ? 'bg-red-500 hover:bg-red-600' : 'bg-red-500 hover:bg-red-600' ?> text-white text-sm rounded-lg clickable transition-all">
                            Alterar agora
                        </button>
                    </div>
                <?php endif; ?>
                
                <?php if ($numeroSessoes > 3): ?>
                    <div class="flex items-start p-4 <?= $temaAtual === 'dark' ? 'bg-blue-500/10 border-blue-500/30' : 'bg-blue-50 border-blue-200' ?> border rounded-lg">
                        <i class="fas fa-info-circle text-blue-400 mt-0.5 mr-3 text-lg"></i>
                        <div class="flex-1">
                            <p class="text-sm font-medium <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?>">Múltiplas sessões ativas</p>
                            <p class="text-sm <?= $temaAtual === 'dark' ? 'text-white/70' : 'text-gray-700' ?>">Você tem <?= $numeroSessoes ?> sessões ativas em diferentes dispositivos.</p>
                        </div>
                        <button onclick="abrirModalEncerrarOutrasSessoes()" class="ml-4 px-4 py-2 <?= $temaAtual === 'dark' ? 'bg-blue-500 hover:bg-blue-600' : 'bg-blue-500 hover:bg-blue-600' ?> text-white text-sm rounded-lg clickable transition-all">
                            Gerenciar
                        </button>
                    </div>
                <?php endif; ?>
                
                <?php if ($tentativasFalhas30Dias > 3): ?>
                    <div class="flex items-start p-4 <?= $temaAtual === 'dark' ? 'bg-orange-500/10 border-orange-500/30' : 'bg-orange-50 border-orange-200' ?> border rounded-lg">
                        <i class="fas fa-shield-alt text-orange-400 mt-0.5 mr-3 text-lg"></i>
                        <div class="flex-1">
                            <p class="text-sm font-medium <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?>">Tentativas suspeitas</p>
                            <p class="text-sm <?= $temaAtual === 'dark' ? 'text-white/70' : 'text-gray-700' ?>"><?= $tentativasFalhas30Dias ?> tentativas de login falhas nos últimos 30 dias.</p>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Modal Alterar Senha -->
<div id="modal-alterar-senha" class="modal-overlay hidden" onclick="fecharModal('modal-alterar-senha')">
    <div class="modal-content" style="max-width: 500px;" onclick="event.stopPropagation()">
        <div class="p-6">
            <div class="flex items-center justify-between mb-6">
                <div class="flex items-center space-x-3">
                    <div class="w-10 h-10 rounded-lg <?= $temaAtual === 'dark' ? 'bg-blue-500/20' : 'bg-blue-100' ?> flex items-center justify-center">
                        <i class="fas fa-lock <?= $temaAtual === 'dark' ? 'text-blue-400' : 'text-blue-600' ?> text-lg"></i>
                    </div>
                    <h3 class="text-lg font-semibold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?>">Alterar Senha</h3>
                </div>
                <button type="button" onclick="fecharModal('modal-alterar-senha')" class="<?= $temaAtual === 'dark' ? 'text-white/50 hover:text-white' : 'text-gray-500 hover:text-gray-700' ?> clickable">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <form id="form-alterar-senha" onsubmit="alterarSenha(event)">
                <div class="space-y-4">
                    <div>
                        <label class="block text-sm font-medium <?= $temaAtual === 'dark' ? 'text-white/90' : 'text-gray-900' ?> mb-2">Senha Atual *</label>
                        <input type="password" name="senha_atual" required
                               class="w-full input-modern rounded-lg h-11"
                               placeholder="Digite sua senha atual">
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium <?= $temaAtual === 'dark' ? 'text-white/90' : 'text-gray-900' ?> mb-2">Nova Senha *</label>
                        <input type="password" name="nova_senha" required minlength="8"
                               class="w-full input-modern rounded-lg h-11"
                               placeholder="Mínimo 8 caracteres">
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium <?= $temaAtual === 'dark' ? 'text-white/90' : 'text-gray-900' ?> mb-2">Confirmar Nova Senha *</label>
                        <input type="password" name="confirmar_senha" required minlength="8"
                               class="w-full input-modern rounded-lg h-11"
                               placeholder="Digite novamente a nova senha">
                    </div>
                    
                    <div class="<?= $temaAtual === 'dark' ? 'bg-yellow-500/10 border-yellow-500/20' : 'bg-yellow-50 border-yellow-100' ?> border rounded-lg p-4">
                        <div class="flex items-start">
                            <i class="fas fa-info-circle <?= $temaAtual === 'dark' ? 'text-yellow-400' : 'text-yellow-500' ?> mt-0.5 mr-3"></i>
                            <div>
                                <h4 class="font-medium <?= $temaAtual === 'dark' ? 'text-white' : 'text-yellow-900' ?>">Recomendações de Segurança</h4>
                                <ul class="text-sm <?= $temaAtual === 'dark' ? 'text-white/70' : 'text-yellow-700' ?> mt-1 list-disc list-inside space-y-1">
                                    <li>Use pelo menos 8 caracteres</li>
                                    <li>Combine letras, números e símbolos</li>
                                    <li>Evite senhas óbvias ou pessoais</li>
                                    <li>Altere sua senha regularmente</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="flex justify-end space-x-3 mt-6 pt-6 border-t <?= $temaAtual === 'dark' ? 'border-white/10' : 'border-gray-200' ?>">
                    <button type="button" onclick="fecharModal('modal-alterar-senha')"
                            class="px-4 py-2 <?= $temaAtual === 'dark' ? 'text-white/70 hover:text-white' : 'text-gray-700 hover:text-gray-900' ?> clickable">
                        Cancelar
                    </button>
                    <button type="submit"
                            class="px-4 py-2 btn-gradient rounded-lg clickable transition-colors flex items-center">
                        <i class="fas fa-save mr-2"></i>Salvar Alterações
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal Configurar MFA -->
<div id="modal-configurar-mfa" class="modal-overlay hidden" onclick="fecharModal('modal-configurar-mfa')">
    <div class="modal-content" style="max-width: 500px;" onclick="event.stopPropagation()">
        <div class="p-6">
            <div class="flex items-center justify-between mb-6">
                <div class="flex items-center space-x-3">
                    <div class="w-10 h-10 rounded-lg <?= $temaAtual === 'dark' ? 'bg-green-500/20' : 'bg-green-100' ?> flex items-center justify-center">
                        <i class="fas fa-shield-alt <?= $temaAtual === 'dark' ? 'text-green-400' : 'text-green-600' ?> text-lg"></i>
                    </div>
                    <h3 class="text-lg font-semibold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?>">Ativar MFA</h3>
                </div>
                <button type="button" onclick="fecharModal('modal-configurar-mfa')" class="<?= $temaAtual === 'dark' ? 'text-white/50 hover:text-white' : 'text-gray-500 hover:text-gray-700' ?> clickable">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <form id="form-configurar-mfa" onsubmit="configurarMFA(event)">
                <div class="space-y-6">
                    <div class="<?= $temaAtual === 'dark' ? 'bg-blue-500/10 border-blue-500/20' : 'bg-blue-50 border-blue-100' ?> border rounded-lg p-4">
                        <div class="flex items-start">
                            <i class="fas fa-info-circle <?= $temaAtual === 'dark' ? 'text-blue-400' : 'text-blue-500' ?> mt-0.5 mr-3"></i>
                            <div>
                                <h4 class="font-medium <?= $temaAtual === 'dark' ? 'text-white' : 'text-blue-900' ?>">Autenticação Multifator (MFA)</h4>
                                <p class="text-sm <?= $temaAtual === 'dark' ? 'text-white/70' : 'text-blue-700' ?> mt-1">
                                    O MFA adiciona uma camada extra de segurança. Você precisará informar este código de 6 dígitos sempre que fizer login.
                                </p>
                            </div>
                        </div>
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium <?= $temaAtual === 'dark' ? 'text-white/90' : 'text-gray-900' ?> mb-2">Código MFA *</label>
                        <input type="text" name="codigo_mfa" required pattern="\d{6}" maxlength="6"
                               class="w-full input-modern rounded-lg h-11 text-center text-xl tracking-widest"
                               placeholder="000000"
                               oninput="this.value = this.value.replace(/[^0-9]/g, '')">
                        <p class="text-xs <?= $temaAtual === 'dark' ? 'text-white/50' : 'text-gray-500' ?> mt-1">Digite um código de 6 dígitos que você possa lembrar</p>
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium <?= $temaAtual === 'dark' ? 'text-white/90' : 'text-gray-900' ?> mb-2">Confirmar Código *</label>
                        <input type="text" name="confirmar_codigo" required pattern="\d{6}" maxlength="6"
                               class="w-full input-modern rounded-lg h-11 text-center text-xl tracking-widest"
                               placeholder="000000"
                               oninput="this.value = this.value.replace(/[^0-9]/g, '')">
                        <p class="text-xs <?= $temaAtual === 'dark' ? 'text-white/50' : 'text-gray-500' ?> mt-1">Digite o mesmo código novamente para confirmar</p>
                    </div>
                    
                    <div class="<?= $temaAtual === 'dark' ? 'bg-yellow-500/10 border-yellow-500/20' : 'bg-yellow-50 border-yellow-100' ?> border rounded-lg p-4">
                        <div class="flex items-start">
                            <i class="fas fa-exclamation-triangle <?= $temaAtual === 'dark' ? 'text-yellow-400' : 'text-yellow-500' ?> mt-0.5 mr-3"></i>
                            <div>
                                <h4 class="font-medium <?= $temaAtual === 'dark' ? 'text-white' : 'text-yellow-900' ?>">Importante</h4>
                                <p class="text-sm <?= $temaAtual === 'dark' ? 'text-white/70' : 'text-yellow-700' ?> mt-1">
                                    Guarde este código em um local seguro. Você precisará dele sempre que fizer login.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="flex justify-end space-x-3 mt-6 pt-6 border-t <?= $temaAtual === 'dark' ? 'border-white/10' : 'border-gray-200' ?>">
                    <button type="button" onclick="fecharModal('modal-configurar-mfa')"
                            class="px-4 py-2 <?= $temaAtual === 'dark' ? 'text-white/70 hover:text-white' : 'text-gray-700 hover:text-gray-900' ?> clickable">
                        Cancelar
                    </button>
                    <button type="submit"
                            class="px-4 py-2 btn-gradient rounded-lg clickable transition-colors flex items-center">
                        <i class="fas fa-shield-alt mr-2"></i>Ativar MFA
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal Alterar MFA -->
<div id="modal-alterar-mfa" class="modal-overlay hidden" onclick="fecharModal('modal-alterar-mfa')">
    <div class="modal-content" style="max-width: 500px;" onclick="event.stopPropagation()">
        <div class="p-6">
            <div class="flex items-center justify-between mb-6">
                <div class="flex items-center space-x-3">
                    <div class="w-10 h-10 rounded-lg <?= $temaAtual === 'dark' ? 'bg-blue-500/20' : 'bg-blue-100' ?> flex items-center justify-center">
                        <i class="fas fa-edit <?= $temaAtual === 'dark' ? 'text-blue-400' : 'text-blue-600' ?> text-lg"></i>
                    </div>
                    <h3 class="text-lg font-semibold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?>">Alterar Código MFA</h3>
                </div>
                <button type="button" onclick="fecharModal('modal-alterar-mfa')" class="<?= $temaAtual === 'dark' ? 'text-white/50 hover:text-white' : 'text-gray-500 hover:text-gray-700' ?> clickable">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <form id="form-alterar-mfa" onsubmit="alterarMFA(event)">
                <div class="space-y-4">
                    <div>
                        <label class="block text-sm font-medium <?= $temaAtual === 'dark' ? 'text-white/90' : 'text-gray-900' ?> mb-2">Código MFA Atual *</label>
                        <input type="text" name="codigo_atual" required pattern="\d{6}" maxlength="6"
                               class="w-full input-modern rounded-lg h-11 text-center text-xl tracking-widest"
                               placeholder="000000"
                               oninput="this.value = this.value.replace(/[^0-9]/g, '')">
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium <?= $temaAtual === 'dark' ? 'text-white/90' : 'text-gray-900' ?> mb-2">Novo Código MFA *</label>
                        <input type="text" name="novo_codigo_mfa" required pattern="\d{6}" maxlength="6"
                               class="w-full input-modern rounded-lg h-11 text-center text-xl tracking-widest"
                               placeholder="000000"
                               oninput="this.value = this.value.replace(/[^0-9]/g, '')">
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium <?= $temaAtual === 'dark' ? 'text-white/90' : 'text-gray-900' ?> mb-2">Confirmar Novo Código *</label>
                        <input type="text" name="confirmar_novo_codigo" required pattern="\d{6}" maxlength="6"
                               class="w-full input-modern rounded-lg h-11 text-center text-xl tracking-widest"
                               placeholder="000000"
                               oninput="this.value = this.value.replace(/[^0-9]/g, '')">
                    </div>
                    
                    <div class="<?= $temaAtual === 'dark' ? 'bg-yellow-500/10 border-yellow-500/20' : 'bg-yellow-50 border-yellow-100' ?> border rounded-lg p-4">
                        <div class="flex items-start">
                            <i class="fas fa-exclamation-triangle <?= $temaAtual === 'dark' ? 'text-yellow-400' : 'text-yellow-500' ?> mt-0.5 mr-3"></i>
                            <div>
                                <h4 class="font-medium <?= $temaAtual === 'dark' ? 'text-white' : 'text-yellow-900' ?>">Atenção</h4>
                                <p class="text-sm <?= $temaAtual === 'dark' ? 'text-white/70' : 'text-yellow-700' ?> mt-1">
                                    Após alterar o código, você precisará usar o novo código em todos os logins futuros.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="flex justify-end space-x-3 mt-6 pt-6 border-t <?= $temaAtual === 'dark' ? 'border-white/10' : 'border-gray-200' ?>">
                    <button type="button" onclick="fecharModal('modal-alterar-mfa')"
                            class="px-4 py-2 <?= $temaAtual === 'dark' ? 'text-white/70 hover:text-white' : 'text-gray-700 hover:text-gray-900' ?> clickable">
                        Cancelar
                    </button>
                    <button type="submit"
                            class="px-4 py-2 btn-gradient rounded-lg clickable transition-colors flex items-center">
                        <i class="fas fa-save mr-2"></i>Alterar Código
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal Desativar MFA -->
<div id="modal-desativar-mfa" class="modal-overlay hidden" onclick="fecharModal('modal-desativar-mfa')">
    <div class="modal-content" style="max-width: 500px;" onclick="event.stopPropagation()">
        <div class="p-6">
            <div class="flex items-center justify-between mb-6">
                <div class="flex items-center space-x-3">
                    <div class="w-10 h-10 rounded-lg <?= $temaAtual === 'dark' ? 'bg-red-500/20' : 'bg-red-100' ?> flex items-center justify-center">
                        <i class="fas fa-shield <?= $temaAtual === 'dark' ? 'text-red-400' : 'text-red-600' ?> text-lg"></i>
                    </div>
                    <h3 class="text-lg font-semibold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?>">Desativar MFA</h3>
                </div>
                <button type="button" onclick="fecharModal('modal-desativar-mfa')" class="<?= $temaAtual === 'dark' ? 'text-white/50 hover:text-white' : 'text-gray-500 hover:text-gray-700' ?> clickable">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <form id="form-desativar-mfa" onsubmit="desativarMFA(event)">
                <div class="space-y-6">
                    <div class="<?= $temaAtual === 'dark' ? 'bg-red-500/10 border-red-500/20' : 'bg-red-50 border-red-100' ?> border rounded-lg p-4">
                        <div class="flex items-start">
                            <i class="fas fa-exclamation-triangle <?= $temaAtual === 'dark' ? 'text-red-400' : 'text-red-500' ?> mt-0.5 mr-3"></i>
                            <div>
                                <h4 class="font-medium <?= $temaAtual === 'dark' ? 'text-white' : 'text-red-900' ?>">⚠️ ATENÇÃO</h4>
                                <p class="text-sm <?= $temaAtual === 'dark' ? 'text-white/70' : 'text-red-700' ?> mt-1">
                                    Desativar o MFA reduzirá a segurança da sua conta. Você poderá fazer login apenas com seu email e senha.
                                </p>
                            </div>
                        </div>
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium <?= $temaAtual === 'dark' ? 'text-white/90' : 'text-gray-900' ?> mb-2">Código MFA Atual *</label>
                        <input type="text" name="codigo_mfa" required pattern="\d{6}" maxlength="6"
                               class="w-full input-modern rounded-lg h-11 text-center text-xl tracking-widest"
                               placeholder="000000"
                               oninput="this.value = this.value.replace(/[^0-9]/g, '')">
                        <p class="text-xs <?= $temaAtual === 'dark' ? 'text-white/50' : 'text-gray-500' ?> mt-1">Digite seu código MFA atual para confirmar a desativação</p>
                    </div>
                    
                    <div class="<?= $temaAtual === 'dark' ? 'bg-yellow-500/10 border-yellow-500/20' : 'bg-yellow-50 border-yellow-100' ?> border rounded-lg p-4">
                        <div class="flex items-start">
                            <i class="fas fa-question-circle <?= $temaAtual === 'dark' ? 'text-yellow-400' : 'text-yellow-500' ?> mt-0.5 mr-3"></i>
                            <div>
                                <h4 class="font-medium <?= $temaAtual === 'dark' ? 'text-white' : 'text-yellow-900' ?>">Considerar manter ativado?</h4>
                                <p class="text-sm <?= $temaAtual === 'dark' ? 'text-white/70' : 'text-yellow-700' ?> mt-1">
                                    O MFA é uma camada importante de segurança contra acessos não autorizados.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="flex justify-end space-x-3 mt-6 pt-6 border-t <?= $temaAtual === 'dark' ? 'border-white/10' : 'border-gray-200' ?>">
                    <button type="button" onclick="fecharModal('modal-desativar-mfa')"
                            class="px-4 py-2 <?= $temaAtual === 'dark' ? 'text-white/70 hover:text-white' : 'text-gray-700 hover:text-gray-900' ?> clickable">
                        Cancelar
                    </button>
                    <button type="submit"
                            class="px-4 py-2 <?= $temaAtual === 'dark' ? 'bg-red-500 hover:bg-red-600' : 'bg-red-500 hover:bg-red-600' ?> text-white rounded-lg clickable transition-colors flex items-center">
                        <i class="fas fa-shield mr-2"></i>Desativar MFA
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal Encerrar Sessão -->
<div id="modal-encerrar-sessao" class="modal-overlay hidden" onclick="fecharModal('modal-encerrar-sessao')">
    <div class="modal-content" style="max-width: 500px;" onclick="event.stopPropagation()">
        <div class="p-6">
            <div class="flex items-center justify-between mb-6">
                <div class="flex items-center space-x-3">
                    <div class="w-10 h-10 rounded-lg <?= $temaAtual === 'dark' ? 'bg-red-500/20' : 'bg-red-100' ?> flex items-center justify-center">
                        <i class="fas fa-sign-out-alt <?= $temaAtual === 'dark' ? 'text-red-400' : 'text-red-600' ?> text-lg"></i>
                    </div>
                    <h3 class="text-lg font-semibold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?>">Encerrar Sessão</h3>
                </div>
                <button type="button" onclick="fecharModal('modal-encerrar-sessao')" class="<?= $temaAtual === 'dark' ? 'text-white/50 hover:text-white' : 'text-gray-500 hover:text-gray-700' ?> clickable">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <div class="space-y-4">
                <div class="<?= $temaAtual === 'dark' ? 'bg-orange-500/10 border-orange-500/20' : 'bg-orange-50 border-orange-100' ?> border rounded-lg p-4">
                    <div class="flex items-start">
                        <i class="fas fa-exclamation-triangle <?= $temaAtual === 'dark' ? 'text-orange-400' : 'text-orange-500' ?> mt-0.5 mr-3"></i>
                        <div>
                            <h4 class="font-medium <?= $temaAtual === 'dark' ? 'text-white' : 'text-orange-900' ?>">Atenção</h4>
                            <p class="text-sm <?= $temaAtual === 'dark' ? 'text-white/70' : 'text-orange-700' ?> mt-1">
                                Esta sessão será encerrada imediatamente em todos os dispositivos onde estiver ativa.
                            </p>
                        </div>
                    </div>
                </div>
                
                <p class="<?= $temaAtual === 'dark' ? 'text-white/90' : 'text-gray-700' ?>">
                    Tem certeza que deseja encerrar esta sessão? O usuário será desconectado imediatamente.
                </p>
                
                <div class="flex justify-end space-x-3 mt-6 pt-6 border-t <?= $temaAtual === 'dark' ? 'border-white/10' : 'border-gray-200' ?>">
                    <button type="button" onclick="fecharModal('modal-encerrar-sessao')"
                            class="px-4 py-2 <?= $temaAtual === 'dark' ? 'text-white/70 hover:text-white' : 'text-gray-700 hover:text-gray-900' ?> clickable">
                        Cancelar
                    </button>
                    <button type="button" onclick="encerrarSessaoConfirmado()"
                            class="px-4 py-2 <?= $temaAtual === 'dark' ? 'bg-red-500 hover:bg-red-600' : 'bg-red-500 hover:bg-red-600' ?> text-white rounded-lg clickable transition-colors flex items-center">
                        <i class="fas fa-sign-out-alt mr-2"></i>Encerrar Sessão
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal Encerrar Outras Sessões -->
<div id="modal-encerrar-outras-sessoes" class="modal-overlay hidden" onclick="fecharModal('modal-encerrar-outras-sessoes')">
    <div class="modal-content" style="max-width: 500px;" onclick="event.stopPropagation()">
        <div class="p-6">
            <div class="flex items-center justify-between mb-6">
                <div class="flex items-center space-x-3">
                    <div class="w-10 h-10 rounded-lg <?= $temaAtual === 'dark' ? 'bg-red-500/20' : 'bg-red-100' ?> flex items-center justify-center">
                        <i class="fas fa-sign-out-alt <?= $temaAtual === 'dark' ? 'text-red-400' : 'text-red-600' ?> text-lg"></i>
                    </div>
                    <h3 class="text-lg font-semibold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?>">Encerrar Outras Sessões</h3>
                </div>
                <button type="button" onclick="fecharModal('modal-encerrar-outras-sessoes')" class="<?= $temaAtual === 'dark' ? 'text-white/50 hover:text-white' : 'text-gray-500 hover:text-gray-700' ?> clickable">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <div class="space-y-4">
                <div class="<?= $temaAtual === 'dark' ? 'bg-orange-500/10 border-orange-500/20' : 'bg-orange-50 border-orange-100' ?> border rounded-lg p-4">
                    <div class="flex items-start">
                        <i class="fas fa-exclamation-triangle <?= $temaAtual === 'dark' ? 'text-orange-400' : 'text-orange-500' ?> mt-0.5 mr-3"></i>
                        <div>
                            <h4 class="font-medium <?= $temaAtual === 'dark' ? 'text-white' : 'text-orange-900' ?>">Atenção</h4>
                            <p class="text-sm <?= $temaAtual === 'dark' ? 'text-white/70' : 'text-orange-700' ?> mt-1">
                                Todas as suas outras sessões ativas serão encerradas imediatamente.
                            </p>
                        </div>
                    </div>
                </div>
                
                <p class="<?= $temaAtual === 'dark' ? 'text-white/90' : 'text-gray-700' ?>">
                    Você será desconectado de todos os outros dispositivos, mantendo apenas esta sessão ativa.
                </p>
                
                <div class="flex justify-end space-x-3 mt-6 pt-6 border-t <?= $temaAtual === 'dark' ? 'border-white/10' : 'border-gray-200' ?>">
                    <button type="button" onclick="fecharModal('modal-encerrar-outras-sessoes')"
                            class="px-4 py-2 <?= $temaAtual === 'dark' ? 'text-white/70 hover:text-white' : 'text-gray-700 hover:text-gray-900' ?> clickable">
                        Cancelar
                    </button>
                    <button type="button" onclick="encerrarOutrasSessoesConfirmado()"
                            class="px-4 py-2 <?= $temaAtual === 'dark' ? 'bg-red-500 hover:bg-red-600' : 'bg-red-500 hover:bg-red-600' ?> text-white rounded-lg clickable transition-colors flex items-center">
                        <i class="fas fa-sign-out-alt mr-2"></i>Encerrar Todas as Outras
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// Variáveis globais
let sessaoParaEncerrar = null;

// Funções de modal
function abrirModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.remove('hidden');
        modal.classList.add('active');
        document.body.style.overflow = 'hidden';
        
        // Focar no primeiro input
        setTimeout(() => {
            const input = modal.querySelector('input');
            if (input) input.focus();
        }, 100);
    }
}

function fecharModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.remove('active');
        modal.classList.add('hidden');
        document.body.style.overflow = 'auto';
        
        // Resetar forms
        const forms = modal.querySelectorAll('form');
        forms.forEach(form => form.reset());
    }
}

function fecharTodosModais() {
    const modais = document.querySelectorAll('.modal-overlay');
    modais.forEach(modal => {
        modal.classList.remove('active');
        modal.classList.add('hidden');
    });
    document.body.style.overflow = 'auto';
}

// Funções específicas para abrir modais
function abrirModalAlterarSenha() {
    abrirModal('modal-alterar-senha');
}

function abrirModalConfigurarMFA() {
    abrirModal('modal-configurar-mfa');
}

function abrirModalAlterarMFA() {
    abrirModal('modal-alterar-mfa');
}

function abrirModalDesativarMFA() {
    abrirModal('modal-desativar-mfa');
}

function abrirModalEncerrarSessao(idSessao) {
    sessaoParaEncerrar = idSessao;
    abrirModal('modal-encerrar-sessao');
}

function abrirModalEncerrarOutrasSessoes() {
    abrirModal('modal-encerrar-outras-sessoes');
}

// Alterar Senha
async function alterarSenha(event) {
    event.preventDefault();
    
    const form = event.target;
    const formData = new FormData(form);
    
    const dados = {
        senha_atual: formData.get('senha_atual'),
        nova_senha: formData.get('nova_senha'),
        confirmar_senha: formData.get('confirmar_senha')
    };
    
    // Validações
    if (!dados.senha_atual || !dados.nova_senha || !dados.confirmar_senha) {
        mostrarToastExtendido('error', 'Erro', 'Todos os campos são obrigatórios');
        return;
    }
    
    if (dados.nova_senha !== dados.confirmar_senha) {
        mostrarToastExtendido('error', 'Erro', 'As senhas não coincidem');
        return;
    }
    
    if (dados.nova_senha.length < 8) {
        mostrarToastExtendido('error', 'Erro', 'A senha deve ter pelo menos 8 caracteres');
        return;
    }
    
    try {
        mostrarCarregamento();
        const response = await fetch('ajax/seguranca/alterar_senha.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(dados)
        });
        
        const data = await response.json();
        
        if (data.success) {
            mostrarToastExtendido('success', 'Sucesso', data.message || 'Senha alterada com sucesso!');
            fecharModal('modal-alterar-senha');
            setTimeout(() => location.reload(), 1500);
        } else {
            mostrarToastExtendido('error', 'Erro', data.error || 'Erro ao alterar senha');
        }
    } catch (error) {
        console.error('Erro:', error);
        mostrarToastExtendido('error', 'Erro', 'Erro ao conectar com o servidor');
    } finally {
        esconderCarregamento();
    }
}

// Configurar MFA
async function configurarMFA(event) {
    event.preventDefault();
    
    const form = event.target;
    const formData = new FormData(form);
    
    const dados = {
        codigo_mfa: formData.get('codigo_mfa'),
        confirmar_codigo: formData.get('confirmar_codigo')
    };
    
    // Validações
    if (!dados.codigo_mfa || !dados.confirmar_codigo) {
        mostrarToastExtendido('error', 'Erro', 'Todos os campos são obrigatórios');
        return;
    }
    
    if (!/^\d{6}$/.test(dados.codigo_mfa)) {
        mostrarToastExtendido('error', 'Erro', 'O código MFA deve ter exatamente 6 dígitos');
        return;
    }
    
    if (dados.codigo_mfa !== dados.confirmar_codigo) {
        mostrarToastExtendido('error', 'Erro', 'Os códigos não coincidem');
        return;
    }
    
    try {
        mostrarCarregamento();
        const response = await fetch('ajax/seguranca/configurar_mfa.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(dados)
        });
        
        const data = await response.json();
        
        if (data.success) {
            mostrarToastExtendido('success', 'Sucesso', data.message || 'MFA configurado com sucesso!');
            fecharModal('modal-configurar-mfa');
            setTimeout(() => location.reload(), 1500);
        } else {
            mostrarToastExtendido('error', 'Erro', data.error || 'Erro ao configurar MFA');
        }
    } catch (error) {
        console.error('Erro:', error);
        mostrarToastExtendido('error', 'Erro', 'Erro ao conectar com o servidor');
    } finally {
        esconderCarregamento();
    }
}

// Alterar MFA
async function alterarMFA(event) {
    event.preventDefault();
    
    const form = event.target;
    const formData = new FormData(form);
    
    const dados = {
        codigo_atual: formData.get('codigo_atual'),
        novo_codigo_mfa: formData.get('novo_codigo_mfa'),
        confirmar_novo_codigo: formData.get('confirmar_novo_codigo')
    };
    
    // Validações
    if (!dados.codigo_atual || !dados.novo_codigo_mfa || !dados.confirmar_novo_codigo) {
        mostrarToastExtendido('error', 'Erro', 'Todos os campos são obrigatórios');
        return;
    }
    
    if (!/^\d{6}$/.test(dados.codigo_atual) || !/^\d{6}$/.test(dados.novo_codigo_mfa)) {
        mostrarToastExtendido('error', 'Erro', 'Os códigos devem ter exatamente 6 dígitos');
        return;
    }
    
    if (dados.novo_codigo_mfa !== dados.confirmar_novo_codigo) {
        mostrarToastExtendido('error', 'Erro', 'Os novos códigos não coincidem');
        return;
    }
    
    try {
        mostrarCarregamento();
        const response = await fetch('ajax/seguranca/alterar_mfa.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(dados)
        });
        
        const data = await response.json();
        
        if (data.success) {
            mostrarToastExtendido('success', 'Sucesso', data.message || 'Código MFA alterado com sucesso!');
            fecharModal('modal-alterar-mfa');
            setTimeout(() => location.reload(), 1500);
        } else {
            mostrarToastExtendido('error', 'Erro', data.error || 'Erro ao alterar código MFA');
        }
    } catch (error) {
        console.error('Erro:', error);
        mostrarToastExtendido('error', 'Erro', 'Erro ao conectar com o servidor');
    } finally {
        esconderCarregamento();
    }
}

// Desativar MFA
async function desativarMFA(event) {
    event.preventDefault();
    
    const form = event.target;
    const codigoMFA = form.codigo_mfa.value;
    
    if (!codigoMFA) {
        mostrarToastExtendido('error', 'Erro', 'O código MFA é obrigatório');
        return;
    }
    
    if (!/^\d{6}$/.test(codigoMFA)) {
        mostrarToastExtendido('error', 'Erro', 'O código MFA deve ter exatamente 6 dígitos');
        return;
    }
    
    try {
        mostrarCarregamento();
        const response = await fetch('ajax/seguranca/desativar_mfa.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({codigo_mfa: codigoMFA})
        });
        
        const data = await response.json();
        
        if (data.success) {
            mostrarToastExtendido('success', 'Sucesso', data.message || 'MFA desativado com sucesso!');
            fecharModal('modal-desativar-mfa');
            setTimeout(() => location.reload(), 1500);
        } else {
            mostrarToastExtendido('error', 'Erro', data.error || 'Erro ao desativar MFA');
        }
    } catch (error) {
        console.error('Erro:', error);
        mostrarToastExtendido('error', 'Erro', 'Erro ao conectar com o servidor');
    } finally {
        esconderCarregamento();
    }
}

// Encerrar sessão individual
async function encerrarSessaoConfirmado() {
    if (!sessaoParaEncerrar) {
        mostrarToastExtendido('error', 'Erro', 'Nenhuma sessão selecionada');
        return;
    }
    
    try {
        mostrarCarregamento();
        const response = await fetch('ajax/seguranca/encerrar_sessao.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({id_sessao: sessaoParaEncerrar})
        });
        
        const data = await response.json();
        
        if (data.success) {
            mostrarToastExtendido('success', 'Sucesso', data.message || 'Sessão encerrada com sucesso!');
            fecharModal('modal-encerrar-sessao');
            setTimeout(() => location.reload(), 1500);
        } else {
            mostrarToastExtendido('error', 'Erro', data.error || 'Erro ao encerrar sessão');
        }
    } catch (error) {
        console.error('Erro:', error);
        mostrarToastExtendido('error', 'Erro', 'Erro ao conectar com o servidor');
    } finally {
        esconderCarregamento();
    }
}

// Encerrar outras sessões
async function encerrarOutrasSessoesConfirmado() {
    try {
        mostrarCarregamento();
        const response = await fetch('ajax/seguranca/encerrar_outras_sessoes.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            }
        });
        
        const data = await response.json();
        
        if (data.success) {
            mostrarToastExtendido('success', 'Sucesso', data.message || 'Todas as outras sessões foram encerradas!');
            fecharModal('modal-encerrar-outras-sessoes');
            setTimeout(() => location.reload(), 1500);
        } else {
            mostrarToastExtendido('error', 'Erro', data.error || 'Erro ao encerrar sessões');
        }
    } catch (error) {
        console.error('Erro:', error);
        mostrarToastExtendido('error', 'Erro', 'Erro ao conectar com o servidor');
    } finally {
        esconderCarregamento();
    }
}

// Função auxiliar para mostrar toast com tempo estendido
function mostrarToastExtendido(tipo, titulo, mensagem, duracao = 10000) {
    const toastContainer = document.createElement('div');
    toastContainer.className = `toast-notification ${tipo}`;
    
    toastContainer.innerHTML = `
        <div class="p-4">
            <div class="flex items-start">
                <div class="flex-shrink-0 pt-0.5">
                    <i class="fas ${tipo === 'success' ? 'fa-check-circle' : tipo === 'error' ? 'fa-times-circle' : tipo === 'warning' ? 'fa-exclamation-triangle' : 'fa-info-circle'} text-xl"></i>
                </div>
                <div class="ml-3 flex-1">
                    <h4 class="font-semibold text-white">${titulo}</h4>
                    <p class="text-sm text-white/90 mt-1">${mensagem}</p>
                </div>
                <button onclick="this.parentElement.parentElement.remove()" class="ml-4 text-white/70 hover:text-white">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        </div>
        <div class="toast-progress" style="animation-duration: ${duracao}ms;"></div>
    `;
    
    document.body.appendChild(toastContainer);
    
    setTimeout(() => {
        if (toastContainer.parentElement) {
            toastContainer.classList.add('hiding');
            setTimeout(() => toastContainer.remove(), 500);
        }
    }, duracao);
}

function mostrarCarregamento() {
    // Adicionar overlay de carregamento
    const loadingOverlay = document.createElement('div');
    loadingOverlay.id = 'loading-overlay';
    loadingOverlay.className = 'fixed inset-0 bg-black/50 flex items-center justify-center z-50';
    loadingOverlay.innerHTML = `
        <div class="bg-gray-800 rounded-lg p-6 flex flex-col items-center">
            <div class="loader mb-4"></div>
            <p class="text-white">Processando...</p>
        </div>
    `;
    document.body.appendChild(loadingOverlay);
    document.body.style.cursor = 'wait';
}

function esconderCarregamento() {
    const loadingOverlay = document.getElementById('loading-overlay');
    if (loadingOverlay) {
        loadingOverlay.remove();
    }
    document.body.style.cursor = 'default';
}

// Event listener para ESC
document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') {
        fecharTodosModais();
    }
});

// Adicionar event listeners para inputs MFA (auto-foco)
document.addEventListener('DOMContentLoaded', function() {
    // Auto-foco nos inputs de código
    const mfaInputs = document.querySelectorAll('input[pattern="\\d{6}"]');
    mfaInputs.forEach(input => {
        input.addEventListener('input', function(e) {
            if (this.value.length === 6) {
                this.blur();
                const nextInput = this.parentElement.nextElementSibling?.querySelector('input');
                if (nextInput) {
                    nextInput.focus();
                }
            }
        });
    });
    
    // Adicionar classe toast-notification ao CSS global se não existir
    if (!document.querySelector('#toast-styles')) {
        const style = document.createElement('style');
        style.id = 'toast-styles';
        style.textContent = `
            .toast-notification {
                position: fixed;
                top: 1rem;
                right: 1rem;
                z-index: 9999;
                min-width: 300px;
                max-width: 400px;
                background: #1f2937;
                border-radius: 0.5rem;
                overflow: hidden;
                box-shadow: 0 10px 25px rgba(0, 0, 0, 0.3);
                animation: slideIn 0.3s ease-out;
                border-left: 4px solid;
            }
            
            .toast-notification.success {
                border-left-color: #10b981;
            }
            
            .toast-notification.error {
                border-left-color: #ef4444;
            }
            
            .toast-notification.warning {
                border-left-color: #f59e0b;
            }
            
            .toast-notification.info {
                border-left-color: #3b82f6;
            }
            
            .toast-notification.hiding {
                animation: slideOut 0.3s ease-in forwards;
            }
            
            .toast-progress {
                height: 3px;
                background: currentColor;
                width: 100%;
                animation: progress linear;
            }
            
            @keyframes slideIn {
                from {
                    transform: translateX(100%);
                    opacity: 0;
                }
                to {
                    transform: translateX(0);
                    opacity: 1;
                }
            }
            
            @keyframes slideOut {
                from {
                    transform: translateX(0);
                    opacity: 1;
                }
                to {
                    transform: translateX(100%);
                    opacity: 0;
                }
            }
            
            @keyframes progress {
                from {
                    width: 100%;
                }
                to {
                    width: 0%;
                }
            }
            
            .loader {
                border: 4px solid rgba(255, 255, 255, 0.3);
                border-radius: 50%;
                border-top: 4px solid #3b82f6;
                width: 40px;
                height: 40px;
                animation: spin 1s linear infinite;
            }
            
            @keyframes spin {
                0% { transform: rotate(0deg); }
                100% { transform: rotate(360deg); }
            }
        `;
        document.head.appendChild(style);
    }
});
</script>

<style>
/* Estilos para os modais */
.modal-overlay {
    position: fixed;
    inset: 0;
    background: rgba(0, 0, 0, 0.75);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 9998;
    opacity: 0;
    visibility: hidden;
    transition: all 0.3s ease;
}

.modal-overlay.active {
    opacity: 1;
    visibility: visible;
}

.modal-content {
    background: <?= $temaAtual === 'dark' ? '#1f2937' : '#ffffff' ?>;
    border-radius: 0.75rem;
    box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
    animation: modalSlideIn 0.3s ease-out;
    max-width: 90vw;
    max-height: 90vh;
    overflow-y: auto;
}

@keyframes modalSlideIn {
    from {
        transform: translateY(-20px);
        opacity: 0;
    }
    to {
        transform: translateY(0);
        opacity: 1;
    }
}

/* Estilos para inputs nos modais */
.input-modern {
    background: <?= $temaAtual === 'dark' ? 'rgba(255, 255, 255, 0.05)' : '#f9fafb' ?>;
    border: 1px solid <?= $temaAtual === 'dark' ? 'rgba(255, 255, 255, 0.1)' : '#e5e7eb' ?>;
    color: <?= $temaAtual === 'dark' ? '#ffffff' : '#111827' ?>;
    transition: all 0.2s ease;
}

.input-modern:focus {
    outline: none;
    border-color: #3b82f6;
    box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
}

/* Estilos para botões nos modais */
.btn-gradient {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    border: none;
}

.btn-gradient:hover {
    background: linear-gradient(135deg, #5a6fd8 0%, #6a4190 100%);
    transform: translateY(-1px);
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
}

/* Estilos para cards */
.card {
    background: <?= $temaAtual === 'dark' ? 'rgba(255, 255, 255, 0.03)' : '#ffffff' ?>;
    border: 1px solid <?= $temaAtual === 'dark' ? 'rgba(255, 255, 255, 0.1)' : '#e5e7eb' ?>;
    border-radius: 0.75rem;
    box-shadow: <?= $temaAtual === 'dark' ? '0 4px 6px rgba(0, 0, 0, 0.2)' : '0 1px 3px rgba(0, 0, 0, 0.1)' ?>;
}

/* Estilo para clickable elements */
.clickable {
    cursor: pointer;
    user-select: none;
}

.clickable:active {
    transform: scale(0.98);
}
</style>

<?php
function tempoDecorrido($dataHora) {
    $agora = new DateTime();
    $data = new DateTime($dataHora);
    $diff = $agora->diff($data);
    
    if ($diff->days == 0) {
        if ($diff->h > 0) return $diff->h . ' hora' . ($diff->h > 1 ? 's' : '') . ' atrás';
        if ($diff->i > 0) return $diff->i . ' minuto' . ($diff->i > 1 ? 's' : '') . ' atrás';
        return 'Agora mesmo';
    }
    if ($diff->days == 1) return 'Ontem';
    if ($diff->days < 7) return $diff->days . ' dias atrás';
    if ($diff->days < 30) return floor($diff->days / 7) . ' semana' . (floor($diff->days / 7) > 1 ? 's' : '') . ' atrás';
    return $diff->format('%m meses atrás');
}

function detectarDispositivo($userAgent) {
    $userAgent = strtolower($userAgent);
    if (strpos($userAgent, 'mobile') !== false || strpos($userAgent, 'android') !== false || strpos($userAgent, 'iphone') !== false) {
        return ['tipo' => 'Celular', 'icone' => 'mobile-alt', 'cor' => 'blue'];
    }
    if (strpos($userAgent, 'tablet') !== false || strpos($userAgent, 'ipad') !== false) {
        return ['tipo' => 'Tablet', 'icone' => 'tablet-alt', 'cor' => 'purple'];
    }
    if (strpos($userAgent, 'windows') !== false) {
        return ['tipo' => 'Windows', 'icone' => 'desktop', 'cor' => 'green'];
    }
    if (strpos($userAgent, 'mac') !== false || strpos($userAgent, 'os x') !== false) {
        return ['tipo' => 'macOS', 'icone' => 'laptop', 'cor' => 'gray'];
    }
    if (strpos($userAgent, 'linux') !== false) {
        return ['tipo' => 'Linux', 'icone' => 'desktop', 'cor' => 'yellow'];
    }
    return ['tipo' => 'Desktop', 'icone' => 'desktop', 'cor' => 'gray'];
}

function detectarNavegador($userAgent) {
    $userAgent = strtolower($userAgent);
    if (strpos($userAgent, 'chrome') !== false && strpos($userAgent, 'edg') === false) {
        return 'Chrome';
    }
    if (strpos($userAgent, 'firefox') !== false) {
        return 'Firefox';
    }
    if (strpos($userAgent, 'safari') !== false && strpos($userAgent, 'chrome') === false) {
        return 'Safari';
    }
    if (strpos($userAgent, 'edg') !== false) {
        return 'Edge';
    }
    if (strpos($userAgent, 'opera') !== false || strpos($userAgent, 'opr') !== false) {
        return 'Opera';
    }
    return 'Navegador';
}
?>