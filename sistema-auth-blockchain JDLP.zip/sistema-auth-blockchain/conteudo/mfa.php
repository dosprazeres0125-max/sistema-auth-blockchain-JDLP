<?php
if (!defined('NOME_SISTEMA')) {
    require_once __DIR__ . '/../includes/config.php';
}

if (!isset($_SESSION['id_usuario']) || empty($_SESSION['id_usuario'])) {
    echo '<div class="p-6 text-center">Faça login para acessar esta página</div>';
    return;
}

require_once __DIR__ . '/../includes/funcoes-seguranca.php';

$pdo = conectarBancoDados();
$idUsuario = $_SESSION['id_usuario'];

$stmt = $pdo->prepare("SELECT mfa_codigo_hash, mfa_ultima_alteracao FROM usuarios WHERE id_usuario = ?");
$stmt->execute([$idUsuario]);
$mfaInfo = $stmt->fetch(PDO::FETCH_ASSOC);

$mfaAtivado = !empty($mfaInfo['mfa_codigo_hash']);
$dataMFA = $mfaInfo['mfa_ultima_alteracao'] ?? 'Nunca';
?>

<div class="p-6">
    <div class="mb-6">
        <div class="flex items-center space-x-3 mb-4">
            <div class="w-12 h-12 rounded-lg bg-gradient-to-br from-green-400 to-green-600 flex items-center justify-center shadow-md">
                <i class="fas fa-mobile-alt text-white text-xl"></i>
            </div>
            <div>
                <h1 class="text-2xl font-bold text-white">Autenticação Multifator</h1>
                <p class="text-white/70">Configure e gerencie a autenticação em dois fatores</p>
            </div>
        </div>
        
        <div class="flex items-center space-x-2 mb-6">
            <div class="px-3 py-1 bg-<?= $mfaAtivado ? 'green' : 'red' ?>-100 text-<?= $mfaAtivado ? 'green' : 'red' ?>-800 text-sm rounded-full">
                <i class="fas fa-<?= $mfaAtivado ? 'check' : 'times' ?> mr-1"></i>
                <?= $mfaAtivado ? 'Ativo' : 'Inativo' ?>
            </div>
            <?php if ($mfaAtivado): ?>
                <div class="text-sm text-white/70">
                    Ativo desde: <?= date('d/m/Y H:i', strtotime($dataMFA)) ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div class="card-light p-6">
            <h3 class="text-lg font-semibold text-gray-900 mb-4">Configurar MFA</h3>
            
            <div class="space-y-4">
                <?php if (!$mfaAtivado): ?>
                    <div id="passo-1">
                        <div class="mb-4">
                            <h4 class="font-medium text-gray-900 mb-2">Passo 1: Escolha o método</h4>
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                                <div class="p-3 border rounded-lg hover:border-blue-500 cursor-pointer transition-colors" onclick="selecionarMetodoMFA('app')">
                                    <div class="flex items-center space-x-3">
                                        <div class="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center">
                                            <i class="fas fa-mobile-alt text-blue-600"></i>
                                        </div>
                                        <div>
                                            <p class="text-sm font-medium text-gray-900">App Autenticador</p>
                                            <p class="text-xs text-gray-600">Google Authenticator, Authy</p>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="p-3 border rounded-lg hover:border-green-500 cursor-pointer transition-colors" onclick="selecionarMetodoMFA('email')">
                                    <div class="flex items-center space-x-3">
                                        <div class="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center">
                                            <i class="fas fa-envelope text-green-600"></i>
                                        </div>
                                        <div>
                                            <p class="text-sm font-medium text-gray-900">Email</p>
                                            <p class="text-xs text-gray-600">Código por email</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div id="passo-app" class="hidden">
                            <div class="mb-4">
                                <h4 class="font-medium text-gray-900 mb-2">Passo 2: Configure no aplicativo</h4>
                                <div class="bg-gray-50 rounded-lg p-4">
                                    <div class="flex items-center justify-between mb-3">
                                        <div>
                                            <p class="text-sm font-medium text-gray-900">Use seu aplicativo autenticador</p>
                                            <p class="text-xs text-gray-600">Escaneie o QR code abaixo</p>
                                        </div>
                                        <div class="w-32 h-32 bg-white p-2 rounded" id="qr-code-container">
                                            <div class="w-full h-full bg-gray-200 flex items-center justify-center">
                                                <p class="text-sm text-gray-500">QR Code será gerado...</p>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="space-y-2">
                                        <p class="text-xs text-gray-600">Ou insira manualmente:</p>
                                        <div class="flex items-center space-x-2">
                                            <code class="flex-1 bg-white border rounded px-3 py-2 text-sm font-mono" id="codigo-secreto"></code>
                                            <button onclick="copiarCodigoSecreto()" class="px-3 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 clickable text-sm">
                                                <i class="fas fa-copy"></i>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="mb-4">
                                <h4 class="font-medium text-gray-900 mb-2">Passo 3: Verifique o código</h4>
                                <div class="space-y-3">
                                    <div>
                                        <label class="block text-sm font-medium text-gray-700 mb-1">Código de verificação</label>
                                        <input type="text" id="codigo-verificacao" maxlength="6" 
                                               class="w-full input-modern rounded-lg text-center text-lg tracking-widest" 
                                               placeholder="000000">
                                    </div>
                                    <p class="text-xs text-gray-600">Insira o código de 6 dígitos do seu aplicativo autenticador</p>
                                </div>
                            </div>
                            
                            <button onclick="verificarCodigoMFA()" class="w-full px-4 py-3 bg-green-500 text-white rounded-lg hover:bg-green-600 clickable">
                                <i class="fas fa-check-circle mr-2"></i> Verificar e Ativar MFA
                            </button>
                        </div>
                        
                        <div id="passo-email" class="hidden">
                            <div class="mb-4">
                                <h4 class="font-medium text-gray-900 mb-2">Passo 2: Enviar código por email</h4>
                                <div class="space-y-3">
                                    <div class="bg-blue-50 border border-blue-200 rounded-lg p-4">
                                        <div class="flex items-start">
                                            <i class="fas fa-info-circle text-blue-600 mt-0.5 mr-3"></i>
                                            <div>
                                                <p class="text-sm font-medium text-blue-800">Código será enviado para</p>
                                                <p class="text-sm text-blue-700"><?= $_SESSION['email'] ?></p>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <button onclick="enviarCodigoEmail()" class="w-full px-4 py-3 bg-blue-500 text-white rounded-lg hover:bg-blue-600 clickable">
                                        <i class="fas fa-paper-plane mr-2"></i> Enviar Código
                                    </button>
                                </div>
                            </div>
                            
                            <div id="verificacao-email" class="hidden">
                                <div class="mb-4">
                                    <h4 class="font-medium text-gray-900 mb-2">Passo 3: Verificar código</h4>
                                    <div class="space-y-3">
                                        <div>
                                            <label class="block text-sm font-medium text-gray-700 mb-1">Código enviado por email</label>
                                            <input type="text" id="codigo-email" maxlength="6" 
                                                   class="w-full input-modern rounded-lg text-center text-lg tracking-widest" 
                                                   placeholder="000000">
                                        </div>
                                        <div class="flex items-center justify-between">
                                            <p class="text-xs text-gray-600">Verifique sua caixa de entrada</p>
                                            <button onclick="reenviarCodigoEmail()" class="text-sm text-blue-600 hover:text-blue-800 clickable">
                                                Reenviar código
                                            </button>
                                        </div>
                                    </div>
                                </div>
                                
                                <button onclick="verificarCodigoEmail()" class="w-full px-4 py-3 bg-green-500 text-white rounded-lg hover:bg-green-600 clickable">
                                    <i class="fas fa-check-circle mr-2"></i> Verificar e Ativar MFA
                                </button>
                            </div>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="space-y-4">
                        <div class="bg-green-50 border border-green-200 rounded-lg p-4">
                            <div class="flex items-start">
                                <i class="fas fa-check-circle text-green-600 mt-0.5 mr-3"></i>
                                <div>
                                    <p class="text-sm font-medium text-green-800">MFA Ativo</p>
                                    <p class="text-sm text-green-700">Autenticação multifator está ativa na sua conta desde <?= date('d/m/Y H:i', strtotime($dataMFA)) ?></p>
                                </div>
                            </div>
                        </div>
                        
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <button onclick="gerarCodigosBackup()" class="w-full px-4 py-3 bg-blue-500 text-white rounded-lg hover:bg-blue-600 clickable">
                                <i class="fas fa-key mr-2"></i> Gerar Códigos de Backup
                            </button>
                            
                            <button onclick="desativarMFA()" class="w-full px-4 py-3 bg-red-500 text-white rounded-lg hover:bg-red-600 clickable">
                                <i class="fas fa-trash-alt mr-2"></i> Desativar MFA
                            </button>
                        </div>
                        
                        <div class="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                            <div class="flex items-start">
                                <i class="fas fa-exclamation-triangle text-yellow-600 mt-0.5 mr-3"></i>
                                <div>
                                    <p class="text-sm font-medium text-yellow-800">Códigos de Backup</p>
                                    <p class="text-sm text-yellow-700">Certifique-se de ter códigos de backup salvos em caso de perda do dispositivo.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        
        <div class="card-light p-6">
            <h3 class="text-lg font-semibold text-gray-900 mb-4">Informações de Segurança</h3>
            
            <div class="space-y-4">
                <div>
                    <h4 class="font-medium text-gray-900 mb-2">Como funciona</h4>
                    <ul class="space-y-2 text-sm text-gray-700">
                        <li class="flex items-start">
                            <i class="fas fa-check text-green-500 mt-0.5 mr-2 text-xs"></i>
                            <span>Adiciona uma camada extra de segurança à sua conta</span>
                        </li>
                        <li class="flex items-start">
                            <i class="fas fa-check text-green-500 mt-0.5 mr-2 text-xs"></i>
                            <span>Requer código além da senha para login</span>
                        </li>
                        <li class="flex items-start">
                            <i class="fas fa-check text-green-500 mt-0.5 mr-2 text-xs"></i>
                            <span>Protege contra acesso não autorizado</span>
                        </li>
                    </ul>
                </div>
                
                <div>
                    <h4 class="font-medium text-gray-900 mb-2">Métodos disponíveis</h4>
                    <div class="space-y-3">
                        <div class="p-3 border rounded-lg">
                            <div class="flex items-center space-x-3">
                                <div class="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center">
                                    <i class="fas fa-mobile-alt text-blue-600 text-sm"></i>
                                </div>
                                <div class="flex-1">
                                    <p class="text-sm font-medium text-gray-900">App Autenticador</p>
                                    <p class="text-xs text-gray-600">Códigos temporários gerados por apps como Google Authenticator</p>
                                </div>
                                <div class="text-xs text-green-600 font-medium">Recomendado</div>
                            </div>
                        </div>
                        
                        <div class="p-3 border rounded-lg">
                            <div class="flex items-center space-x-3">
                                <div class="w-8 h-8 rounded-full bg-green-100 flex items-center justify-center">
                                    <i class="fas fa-envelope text-green-600 text-sm"></i>
                                </div>
                                <div class="flex-1">
                                    <p class="text-sm font-medium text-gray-900">Email</p>
                                    <p class="text-xs text-gray-600">Códigos enviados para seu email cadastrado</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="bg-gray-50 rounded-lg p-4">
                    <h4 class="font-medium text-gray-900 mb-2">Dicas de segurança</h4>
                    <ul class="space-y-1 text-sm text-gray-600">
                        <li>• Mantenha seus códigos de backup em local seguro</li>
                        <li>• Não compartilhe códigos MFA com ninguém</li>
                        <li>• Use aplicativos autenticadores oficiais</li>
                        <li>• Atualize regularmente seus métodos de autenticação</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    
    <div class="mt-6 card-light p-6">
        <h3 class="text-lg font-semibold text-gray-900 mb-4">Histórico MFA</h3>
        
        <div class="overflow-x-auto">
            <table class="w-full">
                <thead>
                    <tr class="text-left text-sm text-gray-700 border-b">
                        <th class="pb-3 font-medium">Data/Hora</th>
                        <th class="pb-3 font-medium">Evento</th>
                        <th class="pb-3 font-medium">Método</th>
                        <th class="pb-3 font-medium">IP</th>
                        <th class="pb-3 font-medium">Status</th>
                    </tr>
                </thead>
                <tbody class="text-sm">
                    <?php
                    $stmt = $pdo->prepare("
                        SELECT tipo_evento, data_hora, ip_origem, dados_auditoria
                        FROM registro_eventos 
                        WHERE id_usuario = ? 
                        AND tipo_evento LIKE '%MFA%'
                        ORDER BY data_hora DESC 
                        LIMIT 10
                    ");
                    $stmt->execute([$idUsuario]);
                    $historicoMFA = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    
                    if (empty($historicoMFA)): ?>
                        <tr>
                            <td colspan="5" class="py-4 text-center text-gray-500">
                                Nenhum histórico de MFA encontrado
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($historicoMFA as $evento): 
                            $dados = json_decode($evento['dados_auditoria'] ?? '{}', true);
                        ?>
                            <tr class="border-b border-gray-100 hover:bg-gray-50">
                                <td class="py-3"><?= date('d/m/Y H:i', strtotime($evento['data_hora'])) ?></td>
                                <td class="py-3">
                                    <?php 
                                        switch($evento['tipo_evento']) {
                                            case 'MFA_CREATED': echo 'MFA criado'; break;
                                            case 'MFA_REMOVED': echo 'MFA removido'; break;
                                            case 'MFA_VALIDATION_SUCCESS': echo 'Validação bem-sucedida'; break;
                                            case 'MFA_VALIDATION_FAILED': echo 'Validação falhou'; break;
                                            default: echo $evento['tipo_evento'];
                                        }
                                    ?>
                                </td>
                                <td class="py-3"><?= $dados['metodo'] ?? 'App' ?></td>
                                <td class="py-3"><?= $evento['ip_origem'] ?></td>
                                <td class="py-3">
                                    <span class="px-2 py-1 rounded-full text-xs <?= strpos($evento['tipo_evento'], 'FAILED') !== false ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800' ?>">
                                        <?= strpos($evento['tipo_evento'], 'FAILED') !== false ? 'Falhou' : 'Sucesso' ?>
                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
let metodoMFASelecionado = 'app';
let codigoSecreto = '';

function selecionarMetodoMFA(metodo) {
    metodoMFASelecionado = metodo;
    
    document.querySelectorAll('[onclick^="selecionarMetodoMFA"]').forEach(el => {
        el.classList.remove('border-blue-500', 'border-green-500');
        el.classList.add('border-gray-200');
    });
    
    const elemento = event.target.closest('[onclick^="selecionarMetodoMFA"]');
    if (elemento) {
        elemento.classList.remove('border-gray-200');
        elemento.classList.add(metodo === 'app' ? 'border-blue-500' : 'border-green-500');
    }
    
    document.getElementById('passo-app').classList.add('hidden');
    document.getElementById('passo-email').classList.add('hidden');
    
    if (metodo === 'app') {
        document.getElementById('passo-app').classList.remove('hidden');
        gerarCodigoSecreto();
    } else {
        document.getElementById('passo-email').classList.remove('hidden');
    }
}

async function gerarCodigoSecreto() {
    try {
        const response = await fetch('../ajax/gerar_codigo_secreto.php');
        const data = await response.json();
        
        if (data.success) {
            codigoSecreto = data.codigo_secreto;
            document.getElementById('codigo-secreto').textContent = codigoSecreto;
            
            const email = '<?= $_SESSION['email'] ?>';
            const issuer = 'Sistema Auth Blockchain';
            const otpauthUrl = `otpauth://totp/${encodeURIComponent(issuer)}:${encodeURIComponent(email)}?secret=${codigoSecreto}&issuer=${encodeURIComponent(issuer)}&algorithm=SHA1&digits=6&period=30`;
            
            new QRCode(document.getElementById("qr-code-container"), {
                text: otpauthUrl,
                width: 128,
                height: 128
            });
        }
    } catch (error) {
        console.error('Erro:', error);
        mostrarToast('error', 'Erro', 'Erro ao gerar código secreto');
    }
}

function copiarCodigoSecreto() {
    navigator.clipboard.writeText(codigoSecreto).then(() => {
        mostrarToast('success', 'Sucesso', 'Código copiado para a área de transferência');
    }).catch(err => {
        mostrarToast('error', 'Erro', 'Erro ao copiar código');
    });
}

async function verificarCodigoMFA() {
    const codigo = document.getElementById('codigo-verificacao').value;
    
    if (codigo.length !== 6 || !/^\d+$/.test(codigo)) {
        mostrarToast('error', 'Erro', 'Código inválido. Use 6 dígitos.');
        return;
    }
    
    try {
        const response = await fetch('../ajax/ativar_mfa.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                codigo_secreto: codigoSecreto,
                codigo_verificacao: codigo,
                metodo: 'app'
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            mostrarToast('success', 'Sucesso', 'MFA ativado com sucesso!');
            setTimeout(() => {
                carregarPagina('mfa');
            }, 1500);
        } else {
            mostrarToast('error', 'Erro', data.message || 'Código incorreto');
        }
    } catch (error) {
        console.error('Erro:', error);
        mostrarToast('error', 'Erro', 'Erro ao conectar com o servidor');
    }
}

async function enviarCodigoEmail() {
    try {
        const response = await fetch('../ajax/enviar_codigo_email.php');
        const data = await response.json();
        
        if (data.success) {
            mostrarToast('success', 'Sucesso', 'Código enviado para seu email');
            document.getElementById('verificacao-email').classList.remove('hidden');
        } else {
            mostrarToast('error', 'Erro', data.message || 'Erro ao enviar código');
        }
    } catch (error) {
        console.error('Erro:', error);
        mostrarToast('error', 'Erro', 'Erro ao conectar com o servidor');
    }
}

async function reenviarCodigoEmail() {
    await enviarCodigoEmail();
}

async function verificarCodigoEmail() {
    const codigo = document.getElementById('codigo-email').value;
    
    if (codigo.length !== 6 || !/^\d+$/.test(codigo)) {
        mostrarToast('error', 'Erro', 'Código inválido. Use 6 dígitos.');
        return;
    }
    
    try {
        const response = await fetch('../ajax/ativar_mfa.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                codigo_verificacao: codigo,
                metodo: 'email'
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            mostrarToast('success', 'Sucesso', 'MFA ativado com sucesso!');
            setTimeout(() => {
                carregarPagina('mfa');
            }, 1500);
        } else {
            mostrarToast('error', 'Erro', data.message || 'Código incorreto');
        }
    } catch (error) {
        console.error('Erro:', error);
        mostrarToast('error', 'Erro', 'Erro ao conectar com o servidor');
    }
}

function desativarMFA() {
    const modalHtml = `
        <div id="modal-desativar-mfa" class="modal-overlay active" onclick="closeModal(event, 'desativar-mfa')">
            <div class="modal-content" onclick="event.stopPropagation()">
                <div class="p-6">
                    <div class="flex items-center justify-between mb-6">
                        <div class="flex items-center space-x-3">
                            <div class="w-10 h-10 rounded-lg bg-red-500/20 flex items-center justify-center">
                                <i class="fas fa-shield-alt text-red-400 text-lg"></i>
                            </div>
                            <h3 class="text-lg font-semibold text-white">Desativar MFA</h3>
                        </div>
                        <button onclick="closeModal(event, 'desativar-mfa')" class="text-white/50 hover:text-white clickable">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                    
                    <div class="space-y-4">
                        <p class="text-white/80">
                            Tem certeza que deseja desativar a Autenticação Multifator? Isso reduzirá a segurança da sua conta.
                        </p>
                        
                        <div class="bg-white/10 rounded-lg p-4">
                            <label class="block text-sm font-medium text-white/80 mb-2">Código MFA Atual</label>
                            <input type="text" id="codigo-mfa-desativacao" 
                                   class="w-full input-modern rounded-lg text-center text-lg tracking-widest" 
                                   placeholder="000000" maxlength="6" autocomplete="off">
                        </div>
                        
                        <p class="text-white/60 text-sm">
                            Insira o código do seu aplicativo autenticador para confirmar a desativação.
                        </p>
                    </div>
                    
                    <div class="flex justify-end space-x-3 mt-6">
                        <button onclick="closeModal(event, 'desativar-mfa')" 
                                class="px-4 py-2 border border-white/30 text-white rounded-lg hover:bg-white/5 clickable">
                            Cancelar
                        </button>
                        <button onclick="confirmarDesativarMFA()" 
                                class="px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 clickable">
                            <i class="fas fa-trash-alt mr-2"></i> Desativar
                        </button>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    const modalContainer = document.createElement('div');
    modalContainer.innerHTML = modalHtml;
    document.body.appendChild(modalContainer);
}

async function confirmarDesativarMFA() {
    const codigo = document.getElementById('codigo-mfa-desativacao').value;
    
    if (codigo.length !== 6 || !/^\d+$/.test(codigo)) {
        mostrarToast('error', 'Erro', 'Código MFA deve ter 6 dígitos');
        return;
    }
    
    try {
        const response = await fetch('../ajax/desativar_mfa.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                codigo_mfa: codigo
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            mostrarToast('success', 'Sucesso', 'MFA desativado com sucesso');
            closeModal(event, 'desativar-mfa');
            setTimeout(() => {
                carregarPagina('mfa');
            }, 1500);
        } else {
            mostrarToast('error', 'Erro', data.message || 'Erro ao desativar MFA');
        }
    } catch (error) {
        console.error('Erro:', error);
        mostrarToast('error', 'Erro', 'Erro ao conectar com o servidor');
    }
}

async function gerarCodigosBackup() {
    try {
        const response = await fetch('../ajax/gerar_codigos_backup.php', {
            method: 'POST'
        });
        
        const data = await response.json();
        
        if (data.success) {
            const modalHtml = `
                <div id="modal-codigos-backup" class="modal-overlay active" onclick="closeModal(event, 'codigos-backup')">
                    <div class="modal-content" onclick="event.stopPropagation()">
                        <div class="p-6">
                            <div class="flex items-center justify-between mb-4">
                                <div class="flex items-center space-x-3">
                                    <div class="w-10 h-10 rounded-lg bg-green-500/20 flex items-center justify-center">
                                        <i class="fas fa-key text-green-400 text-lg"></i>
                                    </div>
                                    <h3 class="text-lg font-semibold text-white">Códigos de Backup MFA</h3>
                                </div>
                                <button onclick="closeModal(event, 'codigos-backup')" class="text-white/50 hover:text-white clickable">
                                    <i class="fas fa-times"></i>
                                </button>
                            </div>
                            
                            <div class="space-y-4">
                                <p class="text-white/80">
                                    Guarde estes códigos em um local seguro. Eles podem ser usados para acessar sua conta se você perder acesso ao aplicativo autenticador.
                                </p>
                                
                                <div class="bg-white/10 rounded-lg p-4">
                                    <div class="grid grid-cols-2 gap-3">
                                        ${data.codigos.map((codigo, index) => `
                                            <div class="p-3 bg-white/5 rounded text-center">
                                                <div class="text-lg font-mono font-bold text-white tracking-widest">${codigo}</div>
                                                <div class="text-xs text-white/50 mt-1">Código ${index + 1}</div>
                                            </div>
                                        `).join('')}
                                    </div>
                                </div>
                                
                                <div class="bg-yellow-500/20 border border-yellow-500/30 rounded-lg p-4">
                                    <div class="flex items-start">
                                        <i class="fas fa-exclamation-triangle text-yellow-400 mt-0.5 mr-3"></i>
                                        <div>
                                            <p class="text-sm font-medium text-yellow-300">Importante</p>
                                            <p class="text-sm text-yellow-200/80 mt-1">
                                                Cada código só pode ser usado uma vez. Códigos gerados anteriormente serão invalidados.
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="flex justify-end mt-6">
                                <button onclick="closeModal(event, 'codigos-backup')" 
                                        class="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 clickable">
                                    <i class="fas fa-check mr-2"></i> Entendi
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            `;
            
            const modalContainer = document.createElement('div');
            modalContainer.innerHTML = modalHtml;
            document.body.appendChild(modalContainer);
        } else {
            mostrarToast('error', 'Erro', data.message || 'Erro ao gerar códigos de backup');
        }
    } catch (error) {
        console.error('Erro:', error);
        mostrarToast('error', 'Erro', 'Erro ao conectar com o servidor');
    }
}

function closeModal(event, modalId) {
    event.preventDefault();
    event.stopPropagation();
    const modal = document.getElementById(`modal-${modalId}`);
    if (modal) {
        modal.remove();
    }
}
</script>