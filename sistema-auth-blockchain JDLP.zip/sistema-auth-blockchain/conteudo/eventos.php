<?php
// Incluir o arquivo de configuração
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/funcoes-seguranca.php';

// Verificar se o usuário está logado
if (!isset($_SESSION['id_usuario']) || empty($_SESSION['id_usuario'])) {
    echo '<div class="p-6 text-center text-white">Faça login para acessar esta página</div>';
    return;
}

// Verificar permissões conforme tipo de usuário
$tipoUsuario = $_SESSION['tipo_usuario'] ?? '';
$permitirAuditor = ($tipoUsuario === 'admin' || $tipoUsuario === 'auditor');

if (!$permitirAuditor) {
    echo '<div class="p-6 text-center text-red-500">Acesso negado. Apenas administradores e auditores podem ver eventos.</div>';
    return;
}

// Definir tema atual
$temaAtual = isset($_COOKIE['tema']) ? $_COOKIE['tema'] : 'light';
if (!in_array($temaAtual, ['light', 'dark'])) {
    $temaAtual = 'light';
}

// Conectar ao banco de dados
try {
    $pdo = conectarBancoDados();
} catch (Exception $e) {
    error_log("Erro ao conectar ao banco de dados: " . $e->getMessage());
    echo '<div class="p-6 text-center text-red-500">Erro ao conectar ao banco de dados. Tente novamente mais tarde.</div>';
    return;
}

// Buscar TODOS os eventos (sem filtros)
try {
    $query = "
        SELECT 
            re.id_evento,
            re.tipo_evento,
            re.id_usuario,
            re.email_hash,
            re.email_informado,
            re.ip_origem,
            re.user_agent,
            re.hash_transacao,
            re.hash_conteudo,
            re.hash_anterior,
            re.hash_seguinte,
            re.bloco_numero,
            re.bloco_hash,
            re.data_hora,
            re.dados_auditoria,
            u.nome_completo,
            u.email as usuario_email,
            u.tipo_usuario,
            bb.bloco_hash_anterior,
            bb.hash_merkle_root,
            bb.timestamp_criacao as bloco_timestamp
        FROM registro_eventos re 
        LEFT JOIN usuarios u ON re.id_usuario = u.id_usuario 
        LEFT JOIN blocos_blockchain bb ON re.bloco_hash = bb.bloco_hash
        ORDER BY re.data_hora DESC 
        LIMIT 1000
    ";

    $stmt = $pdo->prepare($query);
    $stmt->execute();
    $eventos = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Estatísticas
    $estatisticas = [
        'total' => count($eventos),
        'login_sucesso' => 0,
        'login_falha' => 0,
        'tentativas_sem_usuario' => 0,
        'mfa_eventos' => 0,
        'ultimos_7_dias' => 0
    ];

    foreach ($eventos as $evento) {
        $tipo = $evento['tipo_evento'] ?? '';

        if (strpos($tipo, 'LOGIN_SUCESSO') !== false) {
            $estatisticas['login_sucesso']++;
        } elseif (strpos($tipo, 'LOGIN_FALHO') !== false || strpos($tipo, 'TENTATIVA_LOGIN') !== false) {
            $estatisticas['login_falha']++;
            if (empty($evento['id_usuario'])) {
                $estatisticas['tentativas_sem_usuario']++;
            }
        } elseif (strpos($tipo, 'MFA_') !== false) {
            $estatisticas['mfa_eventos']++;
        }

        if (!empty($evento['data_hora'])) {
            try {
                $dataEvento = new DateTime($evento['data_hora']);
                $dataLimite = new DateTime('-7 days');
                if ($dataEvento > $dataLimite) {
                    $estatisticas['ultimos_7_dias']++;
                }
            } catch (Exception $e) {
                // Ignorar erros de data
            }
        }
    }

} catch (Exception $e) {
    error_log("Erro ao buscar eventos: " . $e->getMessage());
    $eventos = [];
    $estatisticas = [
        'total' => 0,
        'login_sucesso' => 0,
        'login_falha' => 0,
        'tentativas_sem_usuario' => 0,
        'mfa_eventos' => 0,
        'ultimos_7_dias' => 0
    ];
}

// Funções auxiliares
function getTipoEventoDescricao($tipo) {
    $descricoes = [
        'LOGIN_SUCESSO' => 'Login bem-sucedido',
        'TENTATIVA_LOGIN' => 'Tentativa de login',
        'LOGIN_FALHO_EMAIL_INVALIDO' => 'Email inválido',
        'LOGIN_FALHO_USUARIO_NAO_ENCONTRADO' => 'Usuário não encontrado',
        'LOGIN_FALHO_SENHA_INCORRETA' => 'Senha incorreta',
        'USUARIO_BLOQUEADO' => 'Usuário bloqueado',
        'CONTA_BLOQUEADA_TENTATIVAS' => 'Conta bloqueada por tentativas',
        'MFA_FALHO' => 'Código MFA incorreto',
        'LOGOUT' => 'Logout realizado',
        'MFA_CRIADO' => 'MFA criado/ativado',
        'MFA_REMOVIDO' => 'MFA removido/desativado',
        'MFA_ALTERADO' => 'MFA alterado',
        'SENHA_ALTERADA' => 'Senha alterada',
        'AUDITORIA_ACESSO' => 'Acesso de auditoria',
        'BLOCKCHAIN_VERIFIED' => 'Blockchain verificada',
        'BLOCKCHAIN_TAMPER_DETECTED' => 'Tentativa de adulteração detectada'
    ];
    
    return $descricoes[$tipo] ?? $tipo;
}

function getCorEvento($tipo) {
    if (strpos($tipo ?? '', 'LOGIN_SUCESSO') !== false || strpos($tipo ?? '', 'MFA_SUCCESS') !== false) {
        return 'success';
    } elseif (strpos($tipo ?? '', 'LOGIN_FALHO') !== false || strpos($tipo ?? '', 'MFA_FALHO') !== false || $tipo === 'LOGIN_BLOCKED' || $tipo === 'ACCOUNT_LOCKED') {
        return 'error';
    } elseif ($tipo === 'LOGOUT' || strpos($tipo ?? '', 'SESSION') !== false) {
        return 'warning';
    } elseif (strpos($tipo ?? '', 'MFA_') !== false) {
        return 'info';
    } elseif (strpos($tipo ?? '', 'BLOCKCHAIN') !== false) {
        return 'purple';
    } else {
        return 'gray';
    }
}

function getIconeEvento($tipo) {
    if (strpos($tipo ?? '', 'LOGIN_SUCESSO') !== false) {
        return 'fa-sign-in-alt';
    } elseif (strpos($tipo ?? '', 'LOGIN_FALHO') !== false || strpos($tipo ?? '', 'TENTATIVA_LOGIN') !== false) {
        return 'fa-exclamation-triangle';
    } elseif ($tipo === 'LOGOUT') {
        return 'fa-sign-out-alt';
    } elseif (strpos($tipo ?? '', 'MFA_') !== false) {
        return 'fa-shield-alt';
    } elseif (strpos($tipo ?? '', 'SESSION') !== false) {
        return 'fa-history';
    } elseif (strpos($tipo ?? '', 'SENHA') !== false) {
        return 'fa-key';
    } elseif (strpos($tipo ?? '', 'BLOCKCHAIN') !== false) {
        return 'fa-link';
    } elseif ($tipo === 'AUDITORIA_ACESSO') {
        return 'fa-eye';
    } else {
        return 'fa-info-circle';
    }
}

function detectarDispositivo($userAgent) {
    if (empty($userAgent)) {
        return ['tipo' => 'Desconhecido', 'icone' => 'question-circle', 'cor' => 'gray'];
    }
    
    $userAgent = strtolower($userAgent);
    
    if (strpos($userAgent, 'mobile') !== false) {
        return ['tipo' => 'Mobile', 'icone' => 'mobile-alt', 'cor' => 'purple'];
    } elseif (strpos($userAgent, 'tablet') !== false) {
        return ['tipo' => 'Tablet', 'icone' => 'tablet-alt', 'cor' => 'indigo'];
    } elseif (strpos($userAgent, 'windows') !== false) {
        return ['tipo' => 'Windows', 'icone' => 'desktop', 'cor' => 'blue'];
    } elseif (strpos($userAgent, 'macintosh') !== false || strpos($userAgent, 'mac os x') !== false) {
        return ['tipo' => 'Mac', 'icone' => 'laptop', 'cor' => 'gray'];
    } elseif (strpos($userAgent, 'linux') !== false) {
        return ['tipo' => 'Linux', 'icone' => 'server', 'cor' => 'orange'];
    } else {
        return ['tipo' => 'Dispositivo', 'icone' => 'desktop', 'cor' => 'gray'];
    }
}

function detectarNavegador($userAgent) {
    if (empty($userAgent)) {
        return 'Desconhecido';
    }
    
    $userAgent = strtolower($userAgent);
    
    if (strpos($userAgent, 'chrome') !== false && strpos($userAgent, 'edg') === false) {
        return 'Chrome';
    } elseif (strpos($userAgent, 'firefox') !== false) {
        return 'Firefox';
    } elseif (strpos($userAgent, 'safari') !== false && strpos($userAgent, 'chrome') === false) {
        return 'Safari';
    } elseif (strpos($userAgent, 'edg') !== false) {
        return 'Edge';
    } elseif (strpos($userAgent, 'opera') !== false || strpos($userAgent, 'opr') !== false) {
        return 'Opera';
    } else {
        return 'Navegador';
    }
}

function tempoDecorrido($dataHora) {
    if (empty($dataHora)) {
        return 'Data inválida';
    }
    
    try {
        $agora = new DateTime();
        $dataEvento = new DateTime($dataHora);
        $intervalo = $agora->diff($dataEvento);
        
        if ($intervalo->y > 0) {
            return "Há {$intervalo->y} ano" . ($intervalo->y > 1 ? 's' : '');
        } elseif ($intervalo->m > 0) {
            return "Há {$intervalo->m} mês" . ($intervalo->m > 1 ? 'es' : '');
        } elseif ($intervalo->d > 0) {
            return "Há {$intervalo->d} dia" . ($intervalo->d > 1 ? 's' : '');
        } elseif ($intervalo->h > 0) {
            return "Há {$intervalo->h} hora" . ($intervalo->h > 1 ? 's' : '');
        } elseif ($intervalo->i > 0) {
            return "Há {$intervalo->i} minuto" . ($intervalo->i > 1 ? 's' : '');
        } else {
            return 'Agora mesmo';
        }
    } catch (Exception $e) {
        return 'Data inválida';
    }
}

function formatarHash($hash, $tamanho = 12) {
    if (empty($hash)) return 'N/A';
    if (strlen($hash) <= $tamanho) return $hash;
    return substr($hash, 0, $tamanho) . '...';
}

function getEmailExibido($evento) {
    if (!empty($evento['email_informado']) && $evento['email_informado'] !== '(não informado)') {
        return htmlspecialchars($evento['email_informado']);
    }
    
    if (!empty($evento['usuario_email'])) {
        return htmlspecialchars($evento['usuario_email']);
    }
    
    return 'Não informado';
}

function getNomeExibido($evento) {
    if (!empty($evento['nome_completo'])) {
        return htmlspecialchars($evento['nome_completo']);
    }
    
    if (!empty($evento['email_informado']) && $evento['email_informado'] !== '(não informado)') {
        return 'Tentativa: ' . htmlspecialchars($evento['email_informado']);
    }
    
    return 'Tentativa anônima';
}

function getInicialAvatar($evento) {
    $nome = getNomeExibido($evento);
    
    if (strpos($nome, 'Tentativa') === 0 || $nome === 'Não identificado') {
        return substr($nome, 0, 1) === 'T' ? 'T' : '?';
    }
    
    return strtoupper(substr($nome, 0, 1));
}

function getCorBadge($cor, $tema) {
    $cores = [
        'success' => $tema === 'dark' ? 'bg-green-500/20 text-green-300 border-green-500/30' : 'bg-green-100 text-green-800 border-green-200',
        'error' => $tema === 'dark' ? 'bg-red-500/20 text-red-300 border-red-500/30' : 'bg-red-100 text-red-800 border-red-200',
        'warning' => $tema === 'dark' ? 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30' : 'bg-yellow-100 text-yellow-800 border-yellow-200',
        'info' => $tema === 'dark' ? 'bg-blue-500/20 text-blue-300 border-blue-500/30' : 'bg-blue-100 text-blue-800 border-blue-200',
        'purple' => $tema === 'dark' ? 'bg-purple-500/20 text-purple-300 border-purple-500/30' : 'bg-purple-100 text-purple-800 border-purple-200',
        'gray' => $tema === 'dark' ? 'bg-gray-500/20 text-gray-300 border-gray-500/30' : 'bg-gray-100 text-gray-800 border-gray-200'
    ];
    
    return $cores[$cor] ?? $cores['gray'];
}

function getTextClass($tema) {
    return $tema === 'dark' ? 'text-white' : 'text-gray-900';
}

function getTextSecondaryClass($tema) {
    return $tema === 'dark' ? 'text-white/70' : 'text-gray-600';
}
?>

<!-- CSS para modais e toast -->
<style>
.modal-overlay {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.7);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 9999;
    opacity: 0;
    visibility: hidden;
    transition: all 0.3s ease;
}
.modal-overlay.active {
    opacity: 1;
    visibility: visible;
}
.modal-content {
    background: <?= $temaAtual === 'dark' ? '#1f2937' : 'white' ?>;
    border-radius: 0.75rem;
    width: 90%;
    max-width: 800px;
    max-height: 90vh;
    overflow: hidden;
    transform: translateY(20px);
    transition: transform 0.3s ease;
    box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
}
.modal-overlay.active .modal-content {
    transform: translateY(0);
}
.loader {
    border: 3px solid <?= $temaAtual === 'dark' ? 'rgba(255,255,255,0.1)' : 'rgba(0,0,0,0.1)' ?>;
    border-radius: 50%;
    border-top: 3px solid #3b82f6;
    width: 40px;
    height: 40px;
    animation: spin 1s linear infinite;
}
@keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
}
.toast-notification {
    position: fixed;
    top: 20px;
    right: 20px;
    min-width: 300px;
    border-radius: 0.5rem;
    overflow: hidden;
    z-index: 9999;
    transform: translateX(120%);
    transition: transform 0.3s ease;
    box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.1);
}
.toast-notification:not(.hiding) {
    transform: translateX(0);
}
.toast-notification.success {
    background: linear-gradient(135deg, #10b981 0%, #059669 100%);
    border-left: 4px solid #34d399;
}
.toast-notification.error {
    background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
    border-left: 4px solid #f87171;
}
.toast-notification.warning {
    background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);
    border-left: 4px solid #fbbf24;
}
.toast-notification.info {
    background: linear-gradient(135deg, #3b82f6 0%, #1d4ed8 100%);
    border-left: 4px solid #60a5fa;
}
.toast-progress {
    height: 3px;
    background: rgba(255, 255, 255, 0.5);
    animation: progress linear forwards;
}
@keyframes progress {
    from { width: 100%; }
    to { width: 0%; }
}
.clickable {
    cursor: pointer;
    user-select: none;
}
.clickable:active {
    transform: scale(0.98);
}
.table-scroll {
    max-height: 600px;
    overflow-y: auto;
}
.table-scroll::-webkit-scrollbar {
    width: 8px;
    height: 8px;
}
.table-scroll::-webkit-scrollbar-track {
    background: <?= $temaAtual === 'dark' ? '#374151' : '#f3f4f6' ?>;
    border-radius: 4px;
}
.table-scroll::-webkit-scrollbar-thumb {
    background: <?= $temaAtual === 'dark' ? '#6b7280' : '#9ca3af' ?>;
    border-radius: 4px;
}
.table-scroll::-webkit-scrollbar-thumb:hover {
    background: <?= $temaAtual === 'dark' ? '#4b5563' : '#6b7280' ?>;
}
.badge-login-failed {
    position: relative;
}
.badge-login-failed::after {
    content: '';
    position: absolute;
    top: -2px;
    right: -2px;
    width: 8px;
    height: 8px;
    background: #ef4444;
    border-radius: 50%;
    border: 2px solid <?= $temaAtual === 'dark' ? '#1f2937' : 'white' ?>;
}
</style>

<div class="p-6">
    <!-- Breadcrumb -->
    <div class="mb-6 flex items-center text-sm <?= $temaAtual === 'dark' ? 'text-white/70' : 'text-gray-600' ?>">
        <a href="#" onclick="carregarPagina('dashboard')" class="hover:text-blue-400 clickable transition-colors flex items-center">
            <i class="fas fa-home mr-2 text-xs"></i> Dashboard
        </a>
        <i class="fas fa-chevron-right mx-2 text-xs <?= $temaAtual === 'dark' ? 'text-white/50' : 'text-gray-400' ?>"></i>
        <span class="text-blue-400 font-medium">Blockchain Auditoria</span>
    </div>

    <!-- Cabeçalho -->
    <div class="mb-8">
        <div class="flex items-center justify-between mb-4">
            <div class="flex items-center space-x-3">
                <div class="w-14 h-14 rounded-full bg-gradient-to-br from-purple-500 to-indigo-600 flex items-center justify-center shadow-md">
                    <i class="fas fa-link text-white text-xl"></i>
                </div>
                <div>
                    <h1 class="text-2xl font-bold <?= getTextClass($temaAtual) ?>">Auditoria Blockchain</h1>
                    <p class="<?= getTextSecondaryClass($temaAtual) ?>">Registros imutáveis de eventos de segurança</p>
                </div>
            </div>
           
            <div class="flex items-center space-x-3">
                <div class="px-4 py-2 bg-green-500/20 text-green-300 border-green-500/30 text-sm rounded-lg border flex items-center">
                    <i class="fas fa-shield-alt mr-2"></i>
                    <span><?= number_format($estatisticas['total']) ?> transações</span>
                </div>
                <div class="text-xs <?= $temaAtual === 'dark' ? 'text-white/50' : 'text-gray-500' ?>">
                    <i class="fas fa-clock mr-1"></i> <?= date('d/m/Y H:i') ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Estatísticas -->
    <div class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <div class="bg-white dark:bg-gray-800 rounded-lg p-4 border border-gray-200 dark:border-gray-700 shadow-sm">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm <?= getTextSecondaryClass($temaAtual) ?>">Total de Eventos</p>
                    <p class="text-2xl font-bold <?= getTextClass($temaAtual) ?>"><?= number_format($estatisticas['total']) ?></p>
                </div>
                <div class="w-12 h-12 rounded-full bg-blue-500/20 flex items-center justify-center">
                    <i class="fas fa-database text-blue-400"></i>
                </div>
            </div>
        </div>
        
        <div class="bg-white dark:bg-gray-800 rounded-lg p-4 border border-gray-200 dark:border-gray-700 shadow-sm">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm <?= getTextSecondaryClass($temaAtual) ?>">Logins Bem-sucedidos</p>
                    <p class="text-2xl font-bold <?= getTextClass($temaAtual) ?>"><?= number_format($estatisticas['login_sucesso']) ?></p>
                </div>
                <div class="w-12 h-12 rounded-full bg-green-500/20 flex items-center justify-center">
                    <i class="fas fa-check-circle text-green-400"></i>
                </div>
            </div>
        </div>
        
        <div class="bg-white dark:bg-gray-800 rounded-lg p-4 border border-gray-200 dark:border-gray-700 shadow-sm">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm <?= getTextSecondaryClass($temaAtual) ?>">Tentativas Falhas</p>
                    <p class="text-2xl font-bold <?= getTextClass($temaAtual) ?>"><?= number_format($estatisticas['login_falha']) ?></p>
                </div>
                <div class="w-12 h-12 rounded-full bg-red-500/20 flex items-center justify-center">
                    <i class="fas fa-exclamation-triangle text-red-400"></i>
                </div>
            </div>
        </div>
        
        <div class="bg-white dark:bg-gray-800 rounded-lg p-4 border border-gray-200 dark:border-gray-700 shadow-sm">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-sm <?= getTextSecondaryClass($temaAtual) ?>">Últimos 7 Dias</p>
                    <p class="text-2xl font-bold <?= getTextClass($temaAtual) ?>"><?= number_format($estatisticas['ultimos_7_dias']) ?></p>
                </div>
                <div class="w-12 h-12 rounded-full bg-purple-500/20 flex items-center justify-center">
                    <i class="fas fa-chart-line text-purple-400"></i>
                </div>
            </div>
        </div>
    </div>

    <!-- Tabela de Auditoria -->
    <div class="bg-white dark:bg-gray-800 rounded-lg p-6 border border-gray-200 dark:border-gray-700 shadow-sm">
        <div class="flex items-center justify-between mb-6">
            <div>
                <h3 class="text-lg font-bold <?= getTextClass($temaAtual) ?> flex items-center">
                    <i class="fas fa-list text-blue-400 mr-3"></i>
                    Registros Imutáveis da Blockchain
                </h3>
                <p class="text-sm <?= getTextSecondaryClass($temaAtual) ?> mt-1">
                    <?php if ($tipoUsuario === 'auditor'): ?>
                    <i class="fas fa-eye text-blue-400 mr-1"></i> Modo Auditoria: Apenas visualização de integridade
                    <?php else: ?>
                    <i class="fas fa-shield-alt text-green-400 mr-1"></i> Sistema de Autenticação Criptografada
                    <?php endif; ?>
                </p>
            </div>
            <div class="flex items-center space-x-3">
                <?php if ($tipoUsuario === 'auditor'): ?>
                <button type="button" onclick="realizarAuditoriaCompleta()"
                        class="px-4 py-2 <?= $temaAtual === 'dark' ? 'bg-green-500/20 text-green-300 hover:bg-green-500/30' : 'bg-green-100 text-green-800 hover:bg-green-200' ?> rounded-lg clickable transition-all duration-200 flex items-center">
                    <i class="fas fa-search mr-2"></i>Realizar Auditoria
                </button>
                <?php endif; ?>
                <button type="button" onclick="verificarIntegridadeBlockchain()"
                        class="px-4 py-2 <?= $temaAtual === 'dark' ? 'bg-purple-500/20 text-purple-300 hover:bg-purple-500/30' : 'bg-purple-100 text-purple-800 hover:bg-purple-200' ?> rounded-lg clickable transition-all duration-200 flex items-center">
                    <i class="fas fa-link mr-2"></i>Verificar Blockchain
                </button>
            </div>
        </div>
       
        <div class="table-scroll rounded-lg border <?= $temaAtual === 'dark' ? 'border-gray-700' : 'border-gray-200' ?>">
            <table class="w-full min-w-full divide-y <?= $temaAtual === 'dark' ? 'divide-gray-700' : 'divide-gray-200' ?>" id="tabela-auditoria">
                <thead class="sticky top-0 <?= $temaAtual === 'dark' ? 'bg-gray-900' : 'bg-gray-50' ?> z-10">
                    <tr class="text-left text-xs <?= $temaAtual === 'dark' ? 'text-white/70' : 'text-gray-700' ?>">
                        <th class="px-4 py-3 font-medium">ID</th>
                        <th class="px-4 py-3 font-medium">Data/Hora</th>
                        <th class="px-4 py-3 font-medium">Usuário / Email informado</th>
                        <th class="px-4 py-3 font-medium">Evento</th>
                        <th class="px-4 py-3 font-medium">IP & Dispositivo</th>
                        <th class="px-4 py-3 font-medium">Hashes Blockchain</th>
                        <th class="px-4 py-3 font-medium">Ações</th>
                    </tr>
                </thead>
                <tbody class="<?= $temaAtual === 'dark' ? 'divide-y divide-gray-800' : 'divide-y divide-gray-200' ?>">
                    <?php if (count($eventos) > 0): ?>
                        <?php foreach ($eventos as $evento): ?>
                            <?php
                            $nomeExibido = getNomeExibido($evento);
                            $emailExibido = getEmailExibido($evento);
                            $inicialAvatar = getInicialAvatar($evento);
                           
                            $isLoginFalhado = strpos($evento['tipo_evento'], 'LOGIN_FALHO') !== false || $evento['tipo_evento'] === 'TENTATIVA_LOGIN';
                           
                            $avatarBg = $temaAtual === 'dark' ? 'bg-blue-500/20' : 'bg-blue-100';
                            $avatarText = $temaAtual === 'dark' ? 'text-blue-300' : 'text-blue-600';
                           
                            if ($evento['tipo_usuario'] === 'admin') {
                                $avatarBg = $temaAtual === 'dark' ? 'bg-purple-500/20' : 'bg-purple-100';
                                $avatarText = $temaAtual === 'dark' ? 'text-purple-300' : 'text-purple-600';
                            } elseif ($evento['tipo_usuario'] === 'auditor') {
                                $avatarBg = $temaAtual === 'dark' ? 'bg-green-500/20' : 'bg-green-100';
                                $avatarText = $temaAtual === 'dark' ? 'text-green-300' : 'text-green-600';
                            } elseif ($isLoginFalhado && empty($evento['id_usuario'])) {
                                $avatarBg = $temaAtual === 'dark' ? 'bg-red-500/20' : 'bg-red-100';
                                $avatarText = $temaAtual === 'dark' ? 'text-red-300' : 'text-red-600';
                            } elseif (empty($evento['id_usuario'])) {
                                $avatarBg = $temaAtual === 'dark' ? 'bg-gray-500/20' : 'bg-gray-100';
                                $avatarText = $temaAtual === 'dark' ? 'text-gray-300' : 'text-gray-600';
                            }
                           
                            $descricaoEvento = getTipoEventoDescricao($evento['tipo_evento']);
                            $corEvento = getCorEvento($evento['tipo_evento']);
                            $iconeEvento = getIconeEvento($evento['tipo_evento']);
                           
                            $userAgent = $evento['user_agent'] ?? '';
                            $dispositivo = detectarDispositivo($userAgent);
                            $navegador = detectarNavegador($userAgent);
                            $tempoDecorrido = tempoDecorrido($evento['data_hora']);
                           
                            $hashTransacao = formatarHash($evento['hash_transacao'], 12);
                            $hashConteudo = formatarHash($evento['hash_conteudo'], 8);
                            $hashAnterior = formatarHash($evento['hash_anterior'], 8);
                            $blocoHash = formatarHash($evento['bloco_hash'], 10);
                            $blocoNumero = $evento['bloco_numero'] ?? 'N/A';
                           
                            $textColorClass = $isLoginFalhado ?
                                ($temaAtual === 'dark' ? 'text-red-300' : 'text-red-600') :
                                getTextClass($temaAtual);
                           
                            $infoExtra = '';
                            if ($isLoginFalhado && !empty($evento['email_informado']) && $evento['email_informado'] !== '(não informado)') {
                                $infoExtra = 'Tentativa com email: ' . htmlspecialchars($evento['email_informado']);
                            }
                            ?>
                            <tr class="transition-colors duration-200 hover:<?= $temaAtual === 'dark' ? 'bg-gray-900/50' : 'bg-gray-50' ?>" id="evento-<?= $evento['id_evento'] ?>">
                                <td class="px-4 py-3 <?= $temaAtual === 'dark' ? 'text-white/70' : 'text-gray-700' ?> font-mono text-xs">
                                    #<?= $evento['id_evento'] ?>
                                </td>
                                <td class="px-4 py-3 <?= $temaAtual === 'dark' ? 'text-white/70' : 'text-gray-700' ?>">
                                    <div class="flex flex-col">
                                        <span class="text-sm font-medium <?= getTextClass($temaAtual) ?>">
                                            <?= date('d/m/Y H:i:s', strtotime($evento['data_hora'])) ?>
                                        </span>
                                        <span class="text-xs <?= $temaAtual === 'dark' ? 'text-white/50' : 'text-gray-500' ?>">
                                            <?= $tempoDecorrido ?>
                                        </span>
                                    </div>
                                </td>
                                <td class="px-4 py-3">
                                    <div class="flex items-center" <?= $infoExtra ? 'title="' . $infoExtra . '"' : '' ?>>
                                        <div class="w-10 h-10 rounded-full <?= $avatarBg ?> <?= $avatarText ?> flex items-center justify-center mr-3 font-bold shrink-0">
                                            <span class="text-sm"><?= $inicialAvatar ?></span>
                                        </div>
                                        <div class="min-w-0">
                                            <p class="font-medium text-sm <?= $textColorClass ?> truncate max-w-[150px]">
                                                <?= $nomeExibido ?>
                                            </p>
                                            <p class="text-xs <?= $temaAtual === 'dark' ? 'text-white/50' : 'text-gray-500' ?> truncate max-w-[150px]" title="<?= $emailExibido ?>">
                                                <?= $emailExibido ?>
                                            </p>
                                        </div>
                                    </div>
                                </td>
                                <td class="px-4 py-3 <?= $temaAtual === 'dark' ? 'text-white/70' : 'text-gray-700' ?>">
                                    <div class="flex flex-col min-w-[180px]">
                                        <span class="text-sm <?= $textColorClass ?> font-medium">
                                            <i class="fas <?= $iconeEvento ?> mr-2 text-xs"></i>
                                            <?= $descricaoEvento ?>
                                        </span>
                                        <span class="text-xs <?= $temaAtual === 'dark' ? 'text-white/50' : 'text-gray-500' ?> font-mono mt-1 truncate">
                                            <?= htmlspecialchars($evento['tipo_evento']) ?>
                                        </span>
                                    </div>
                                </td>
                                <td class="px-4 py-3">
                                    <div class="flex flex-col min-w-[150px]">
                                        <div class="flex items-center mb-1">
                                            <i class="fas fa-network-wired <?= $temaAtual === 'dark' ? 'text-blue-400' : 'text-blue-600' ?> mr-2 text-xs shrink-0"></i>
                                            <span class="text-sm <?= $temaAtual === 'dark' ? 'text-white/90' : 'text-gray-900' ?> font-mono truncate">
                                                <?= htmlspecialchars($evento['ip_origem']) ?>
                                            </span>
                                        </div>
                                        <?php if (!empty($userAgent)): ?>
                                        <div class="flex items-center">
                                            <i class="fas fa-<?= $dispositivo['icone'] ?> <?= $temaAtual === 'dark' ? 'text-' . $dispositivo['cor'] . '-400' : 'text-' . $dispositivo['cor'] . '-600' ?> mr-2 text-xs shrink-0"></i>
                                            <span class="text-xs <?= $temaAtual === 'dark' ? 'text-white/70' : 'text-gray-600' ?> truncate">
                                                <?= $navegador ?> • <?= $dispositivo['tipo'] ?>
                                            </span>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                </td>
                                <td class="px-4 py-3 <?= $temaAtual === 'dark' ? 'text-white/70' : 'text-gray-700' ?>">
                                    <div class="space-y-1 min-w-[160px]">
                                        <div class="flex items-center">
                                            <i class="fas fa-fingerprint <?= $temaAtual === 'dark' ? 'text-purple-400' : 'text-purple-600' ?> mr-2 text-xs shrink-0"></i>
                                            <code class="text-xs font-mono <?= $temaAtual === 'dark' ? 'text-purple-300' : 'text-purple-700' ?> truncate" title="Transação: <?= $evento['hash_transacao'] ?>">
                                                TX: <?= $hashTransacao ?>
                                            </code>
                                        </div>
                                        <div class="flex items-center">
                                            <i class="fas fa-hashtag <?= $temaAtual === 'dark' ? 'text-blue-400' : 'text-blue-600' ?> mr-2 text-xs shrink-0"></i>
                                            <code class="text-xs font-mono <?= $temaAtual === 'dark' ? 'text-blue-300' : 'text-blue-700' ?> truncate" title="Bloco #<?= $blocoNumero ?>: <?= $evento['bloco_hash'] ?>">
                                                Bloco: <?= $blocoHash ?>
                                            </code>
                                        </div>
                                        <div class="flex items-center">
                                            <i class="fas fa-link <?= $temaAtual === 'dark' ? 'text-green-400' : 'text-green-600' ?> mr-2 text-xs shrink-0"></i>
                                            <code class="text-xs font-mono <?= $temaAtual === 'dark' ? 'text-green-300' : 'text-green-700' ?> truncate" title="Hash anterior: <?= $evento['hash_anterior'] ?>">
                                                Prev: <?= $hashAnterior ?>
                                            </code>
                                        </div>
                                    </div>
                                </td>
                                <td class="px-4 py-3">
                                    <div class="flex space-x-1">
                                        <button onclick="verDetalhesEvento(<?= $evento['id_evento'] ?>)" 
                                                class="px-3 py-1.5 text-xs <?= $temaAtual === 'dark' ? 'bg-blue-500/20 text-blue-300 hover:bg-blue-500/30' : 'bg-blue-100 text-blue-700 hover:bg-blue-200' ?> rounded-lg clickable transition-colors duration-200"
                                                title="Detalhes do evento">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                        <button onclick="copiarHash('<?= addslashes($evento['hash_transacao']) ?>')" 
                                                class="px-3 py-1.5 text-xs <?= $temaAtual === 'dark' ? 'bg-gray-700 text-white hover:bg-gray-600' : 'bg-gray-100 text-gray-700 hover:bg-gray-200' ?> rounded-lg clickable transition-colors duration-200"
                                                title="Copiar hash da transação">
                                            <i class="fas fa-copy"></i>
                                        </button>
                                        <button onclick="verificarBlockchain('<?= addslashes($evento['hash_transacao']) ?>', <?= $evento['id_evento'] ?>)" 
                                                class="px-3 py-1.5 text-xs <?= $temaAtual === 'dark' ? 'bg-green-500/20 text-green-300 hover:bg-green-500/30' : 'bg-green-100 text-green-700 hover:bg-green-200' ?> rounded-lg clickable transition-colors duration-200"
                                                title="Verificar na blockchain">
                                            <i class="fas fa-shield-alt"></i>
                                        </button>
                                        <?php if ($tipoUsuario === 'auditor'): ?>
                                        <button onclick="auditarEvento(<?= $evento['id_evento'] ?>)" 
                                                class="px-3 py-1.5 text-xs <?= $temaAtual === 'dark' ? 'bg-purple-500/20 text-purple-300 hover:bg-purple-500/30' : 'bg-purple-100 text-purple-700 hover:bg-purple-200' ?> rounded-lg clickable transition-colors duration-200"
                                                title="Auditar evento">
                                            <i class="fas fa-search"></i>
                                        </button>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="7" class="px-4 py-12 text-center <?= $temaAtual === 'dark' ? 'text-white/50' : 'text-gray-500' ?>">
                                <div class="flex flex-col items-center justify-center">
                                    <i class="fas fa-database text-4xl <?= $temaAtual === 'dark' ? 'text-gray-700' : 'text-gray-300' ?> mb-4"></i>
                                    <p class="text-lg <?= getTextSecondaryClass($temaAtual) ?> mb-2">Nenhum registro encontrado</p>
                                    <p class="text-sm <?= $temaAtual === 'dark' ? 'text-white/50' : 'text-gray-500' ?>">
                                        Aguarde novas atividades de segurança.
                                    </p>
                                </div>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal Detalhes do Evento -->
<div id="modal-detalhes-evento" class="modal-overlay" style="display: none;">
    <div class="modal-content" onclick="event.stopPropagation()">
        <div class="p-6 bg-white dark:bg-gray-800 rounded-lg">
            <div class="flex items-center justify-between mb-6">
                <div class="flex items-center space-x-3">
                    <div class="w-10 h-10 rounded-lg <?= $temaAtual === 'dark' ? 'bg-blue-500/20' : 'bg-blue-100' ?> flex items-center justify-center">
                        <i class="fas fa-info-circle <?= $temaAtual === 'dark' ? 'text-blue-400' : 'text-blue-600' ?> text-lg"></i>
                    </div>
                    <h3 class="text-lg font-semibold <?= getTextClass($temaAtual) ?>">Detalhes do Evento</h3>
                </div>
                <button type="button" onclick="fecharModalDetalhes()" class="<?= $temaAtual === 'dark' ? 'text-white/50 hover:text-white' : 'text-gray-500 hover:text-gray-700' ?> clickable transition-colors text-lg">
                    <i class="fas fa-times"></i>
                </button>
            </div>
           
            <div id="detalhes-evento-conteudo">
                <div class="text-center py-8">
                    <div class="loader mx-auto"></div>
                    <p class="<?= getTextSecondaryClass($temaAtual) ?> mt-3">Carregando detalhes...</p>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal Verificação Blockchain -->
<div id="modal-verificar-blockchain" class="modal-overlay" style="display: none;">
    <div class="modal-content" onclick="event.stopPropagation()">
        <div class="p-6 bg-white dark:bg-gray-800 rounded-lg">
            <div class="flex items-center justify-between mb-6">
                <div class="flex items-center space-x-3">
                    <div class="w-10 h-10 rounded-lg <?= $temaAtual === 'dark' ? 'bg-green-500/20' : 'bg-green-100' ?> flex items-center justify-center">
                        <i class="fas fa-shield-alt <?= $temaAtual === 'dark' ? 'text-green-400' : 'text-green-600' ?> text-lg"></i>
                    </div>
                    <h3 class="text-lg font-semibold <?= getTextClass($temaAtual) ?>">Verificação de Integridade</h3>
                </div>
                <button type="button" onclick="fecharModalBlockchain()" class="<?= $temaAtual === 'dark' ? 'text-white/50 hover:text-white' : 'text-gray-500 hover:text-gray-700' ?> clickable transition-colors text-lg">
                    <i class="fas fa-times"></i>
                </button>
            </div>
           
            <div id="blockchain-conteudo" class="text-center py-8">
                <div class="loader mx-auto"></div>
                <p class="<?= getTextSecondaryClass($temaAtual) ?> mt-3">Verificando integridade...</p>
            </div>
        </div>
    </div>
</div>

<!-- Modal Auditoria Completa -->
<div id="modal-auditoria-completa" class="modal-overlay" style="display: none;">
    <div class="modal-content" onclick="event.stopPropagation()">
        <div class="p-6 bg-white dark:bg-gray-800 rounded-lg">
            <div class="flex items-center justify-between mb-6">
                <div class="flex items-center space-x-3">
                    <div class="w-10 h-10 rounded-lg <?= $temaAtual === 'dark' ? 'bg-purple-500/20' : 'bg-purple-100' ?> flex items-center justify-center">
                        <i class="fas fa-search <?= $temaAtual === 'dark' ? 'text-purple-400' : 'text-purple-600' ?> text-lg"></i>
                    </div>
                    <h3 class="text-lg font-semibold <?= getTextClass($temaAtual) ?>">Auditoria Completa</h3>
                </div>
                <button type="button" onclick="fecharModalAuditoria()" class="<?= $temaAtual === 'dark' ? 'text-white/50 hover:text-white' : 'text-gray-500 hover:text-gray-700' ?> clickable transition-colors text-lg">
                    <i class="fas fa-times"></i>
                </button>
            </div>
           
            <div id="auditoria-conteudo" class="text-center py-8">
                <div class="loader mx-auto"></div>
                <p class="<?= getTextSecondaryClass($temaAtual) ?> mt-3">Realizando auditoria completa...</p>
            </div>
        </div>
    </div>
</div>

<script>
// Variáveis globais
let debounceTimer = null;

// Função para abrir modal
function abrirModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.style.display = 'flex';
        setTimeout(() => modal.classList.add('active'), 10);
        document.body.style.overflow = 'hidden';
    }
}

// Função para fechar modal
function fecharModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.remove('active');
        setTimeout(() => {
            modal.style.display = 'none';
            document.body.style.overflow = 'auto';
        }, 300);
    }
}

function fecharModalDetalhes() { fecharModal('modal-detalhes-evento'); }
function fecharModalBlockchain() { fecharModal('modal-verificar-blockchain'); }
function fecharModalAuditoria() { fecharModal('modal-auditoria-completa'); }

// Copiar hash
function copiarHash(hash) {
    if (!hash || hash === 'N/A') {
        mostrarToast('Nenhum hash para copiar', 'warning');
        return;
    }
    
    navigator.clipboard.writeText(hash).then(() => {
        mostrarToast('Hash copiado!', 'success');
    }).catch(() => {
        mostrarToast('Erro ao copiar hash', 'error');
    });
}

// Ver detalhes do evento
async function verDetalhesEvento(idEvento) {
    const modal = document.getElementById('modal-detalhes-evento');
    const conteudo = document.getElementById('detalhes-evento-conteudo');
    
    conteudo.innerHTML = `
        <div class="text-center py-8">
            <div class="loader mx-auto"></div>
            <p class="<?= getTextSecondaryClass($temaAtual) ?> mt-3">Carregando detalhes...</p>
        </div>
    `;
    
    abrirModal('modal-detalhes-evento');
    
    try {
        const response = await fetch(`includes/obter_detalhes_evento.php?id=${idEvento}`);
        if (!response.ok) throw new Error('Erro na requisição');
        
        const data = await response.json();
        
        if (data.success) {
            const ev = data.evento;
            conteudo.innerHTML = `
                <div class="space-y-4">
                    <p><strong>ID:</strong> ${ev.id_evento}</p>
                    <p><strong>Data:</strong> ${new Date(ev.data_hora).toLocaleString('pt-BR')}</p>
                    <p><strong>Tipo:</strong> ${ev.tipo_evento}</p>
                    <p><strong>IP:</strong> ${ev.ip_origem || '—'}</p>
                    <p><strong>Hash Transação:</strong> <code>${ev.hash_transacao || '—'}</code></p>
                    <!-- Adicione mais campos conforme necessário -->
                </div>
            `;
        } else {
            conteudo.innerHTML = `<p class="text-red-500">Erro: ${data.message || 'Não encontrado'}</p>`;
        }
    } catch (err) {
        conteudo.innerHTML = `<p class="text-red-500">Falha ao carregar: ${err.message}</p>`;
    }
}

// Verificar blockchain individual
async function verificarBlockchain(hashTransacao, idEvento) {
    const modal = document.getElementById('modal-verificar-blockchain');
    const conteudo = document.getElementById('blockchain-conteudo');
    
    conteudo.innerHTML = `
        <div class="text-center py-8">
            <div class="loader mx-auto"></div>
            <p class="<?= getTextSecondaryClass($temaAtual) ?> mt-3">Verificando...</p>
        </div>
    `;
    
    abrirModal('modal-verificar-blockchain');
    
    try {
        const response = await fetch(`includes/verificar_blockchain.php`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: `hash_transacao=${encodeURIComponent(hashTransacao)}&id_evento=${idEvento}`
        });
        
        if (!response.ok) throw new Error('Erro na requisição');
        
        const data = await response.json();
        
        if (data.success) {
            conteudo.innerHTML = `
                <div class="text-center py-8">
                    <i class="fas fa-check-circle text-6xl text-green-500 mb-4"></i>
                    <h3 class="text-xl font-bold <?= getTextClass($temaAtual) ?>">Integridade Verificada</h3>
                    <p class="<?= getTextSecondaryClass($temaAtual) ?>">${data.message || 'Transação íntegra'}</p>
                    <button onclick="fecharModalBlockchain()" class="mt-6 px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700">
                        Fechar
                    </button>
                </div>
            `;
        } else {
            conteudo.innerHTML = `
                <div class="text-center py-8">
                    <i class="fas fa-times-circle text-6xl text-red-500 mb-4"></i>
                    <h3 class="text-xl font-bold <?= getTextClass($temaAtual) ?>">Falha na Verificação</h3>
                    <p class="<?= getTextSecondaryClass($temaAtual) ?>">${data.message || 'Integridade comprometida'}</p>
                    <button onclick="fecharModalBlockchain()" class="mt-6 px-6 py-3 bg-red-600 text-white rounded-lg hover:bg-red-700">
                        Fechar
                    </button>
                </div>
            `;
        }
    } catch (err) {
        conteudo.innerHTML = `
            <div class="text-center py-8">
                <i class="fas fa-exclamation-triangle text-6xl text-yellow-500 mb-4"></i>
                <h3 class="text-xl font-bold <?= getTextClass($temaAtual) ?>">Erro</h3>
                <p class="<?= getTextSecondaryClass($temaAtual) ?>">Falha na conexão: ${err.message}</p>
                <button onclick="fecharModalBlockchain()" class="mt-6 px-6 py-3 bg-gray-600 text-white rounded-lg hover:bg-gray-700">
                    Fechar
                </button>
            </div>
        `;
    }
}

// Auditoria completa
async function realizarAuditoriaCompleta() {
    const modal = document.getElementById('modal-auditoria-completa');
    const conteudo = document.getElementById('auditoria-conteudo');
    
    conteudo.innerHTML = `
        <div class="text-center py-8">
            <div class="loader mx-auto"></div>
            <p class="<?= getTextSecondaryClass($temaAtual) ?> mt-3">Processando auditoria...</p>
        </div>
    `;
    
    abrirModal('modal-auditoria-completa');
    
    try {
        const response = await fetch('includes/realizar_auditoria.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
        });
        
        if (!response.ok) throw new Error('Erro na requisição');
        
        const data = await response.json();
        
        if (data.success) {
            conteudo.innerHTML = `
                <div class="text-center py-8">
                    <i class="fas fa-check-circle text-6xl text-green-500 mb-4"></i>
                    <h3 class="text-xl font-bold <?= getTextClass($temaAtual) ?>">Auditoria Concluída</h3>
                    <p class="<?= getTextSecondaryClass($temaAtual) ?>">${data.message || 'Blockchain íntegra'}</p>
                    <button onclick="fecharModalAuditoria()" class="mt-6 px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700">
                        Fechar
                    </button>
                </div>
            `;
        } else {
            conteudo.innerHTML = `
                <div class="text-center py-8">
                    <i class="fas fa-times-circle text-6xl text-red-500 mb-4"></i>
                    <h3 class="text-xl font-bold <?= getTextClass($temaAtual) ?>">Problemas Detectados</h3>
                    <p class="<?= getTextSecondaryClass($temaAtual) ?>">${data.message || 'Integridade comprometida'}</p>
                    <button onclick="fecharModalAuditoria()" class="mt-6 px-6 py-3 bg-red-600 text-white rounded-lg hover:bg-red-700">
                        Fechar
                    </button>
                </div>
            `;
        }
    } catch (err) {
        conteudo.innerHTML = `
            <div class="text-center py-8">
                <i class="fas fa-exclamation-triangle text-6xl text-yellow-500 mb-4"></i>
                <h3 class="text-xl font-bold <?= getTextClass($temaAtual) ?>">Erro</h3>
                <p class="<?= getTextSecondaryClass($temaAtual) ?>">Falha na conexão</p>
                <button onclick="fecharModalAuditoria()" class="mt-6 px-6 py-3 bg-gray-600 text-white rounded-lg hover:bg-gray-700">
                    Fechar
                </button>
            </div>
        `;
    }
}

// Verificar integridade completa da blockchain
async function verificarIntegridadeBlockchain() {
    const modal = document.getElementById('modal-verificar-blockchain');
    const conteudo = document.getElementById('blockchain-conteudo');
    
    conteudo.innerHTML = `
        <div class="text-center py-8">
            <div class="loader mx-auto"></div>
            <p class="<?= getTextSecondaryClass($temaAtual) ?> mt-3">Verificando blockchain completa...</p>
        </div>
    `;
    
    abrirModal('modal-verificar-blockchain');
    
    try {
        const response = await fetch('includes/verificar_integridade_blockchain.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
        });
        
        if (!response.ok) throw new Error('Erro na requisição');
        
        const data = await response.json();
        
        if (data.success) {
            conteudo.innerHTML = `
                <div class="text-center py-8">
                    <i class="fas fa-check-circle text-6xl text-green-500 mb-4"></i>
                    <h3 class="text-xl font-bold <?= getTextClass($temaAtual) ?>">Blockchain Íntegra</h3>
                    <p class="<?= getTextSecondaryClass($temaAtual) ?>">${data.message || 'Todos os blocos verificados'}</p>
                    <button onclick="fecharModalBlockchain()" class="mt-6 px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700">
                        Fechar
                    </button>
                </div>
            `;
        } else {
            conteudo.innerHTML = `
                <div class="text-center py-8">
                    <i class="fas fa-times-circle text-6xl text-red-500 mb-4"></i>
                    <h3 class="text-xl font-bold <?= getTextClass($temaAtual) ?>">Problemas Detectados</h3>
                    <p class="<?= getTextSecondaryClass($temaAtual) ?>">${data.message || 'Integridade comprometida'}</p>
                    <button onclick="fecharModalBlockchain()" class="mt-6 px-6 py-3 bg-red-600 text-white rounded-lg hover:bg-red-700">
                        Fechar
                    </button>
                </div>
            `;
        }
    } catch (err) {
        conteudo.innerHTML = `
            <div class="text-center py-8">
                <i class="fas fa-exclamation-triangle text-6xl text-yellow-500 mb-4"></i>
                <h3 class="text-xl font-bold <?= getTextClass($temaAtual) ?>">Erro</h3>
                <p class="<?= getTextSecondaryClass($temaAtual) ?>">Falha na conexão</p>
                <button onclick="fecharModalBlockchain()" class="mt-6 px-6 py-3 bg-gray-600 text-white rounded-lg hover:bg-gray-700">
                    Fechar
                </button>
            </div>
        `;
    }
}

// Auditar evento individual (somente auditores)
async function auditarEvento(idEvento) {
    try {
        const response = await fetch(`includes/auditar_evento.php`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: `id_evento=${idEvento}`
        });
        
        if (!response.ok) throw new Error('Erro na requisição');
        
        const data = await response.json();
        
        if (data.success) {
            mostrarToast('Evento auditado com sucesso', 'success');
        } else {
            mostrarToast(data.message || 'Falha na auditoria', 'error');
        }
    } catch (err) {
        mostrarToast('Erro ao auditar evento', 'error');
    }
}

// Toast notification
function mostrarToast(mensagem, tipo = 'info') {
    const icones = {
        success: 'check-circle',
        error: 'exclamation-triangle',
        warning: 'exclamation-circle',
        info: 'info-circle'
    };
    
    const bgClasses = {
        success: 'success',
        error: 'error',
        warning: 'warning',
        info: 'info'
    };
    
    const toastId = 'toast-' + Date.now();
    const toast = document.createElement('div');
    toast.id = toastId;
    toast.className = `toast-notification ${bgClasses[tipo] || 'info'}`;
    
    toast.innerHTML = `
        <div class="p-4">
            <div class="flex items-center">
                <i class="fas fa-${icones[tipo] || 'info-circle'} text-lg mr-3"></i>
                <div class="flex-1">
                    <div class="font-medium text-white">${mensagem}</div>
                </div>
                <button onclick="document.getElementById('${toastId}').classList.add('hiding')" class="ml-4 text-white/70 hover:text-white">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="toast-progress mt-3" style="animation-duration: 4s"></div>
        </div>
    `;
    
    document.body.appendChild(toast);
    
    setTimeout(() => toast.style.display = 'block', 10);
    
    setTimeout(() => {
        toast.classList.add('hiding');
        setTimeout(() => toast.remove(), 300);
    }, 4000);
}

// Inicialização básica
document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('.clickable').forEach(el => {
        el.addEventListener('click', function() {
            this.style.transform = 'scale(0.97)';
            setTimeout(() => this.style.transform = '', 150);
        });
    });
});
</script>