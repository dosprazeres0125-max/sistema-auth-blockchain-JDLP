<?php
// Verificar se as constantes estão definidas
if (!defined('NOME_SISTEMA')) {
    require_once __DIR__ . '/../includes/config.php';
}

// Verificar se o usuário está logado
if (!isset($_SESSION['id_usuario']) || empty($_SESSION['id_usuario'])) {
    echo '<div class="p-6 text-center text-white">Faça login para acessar esta página</div>';
    return;
}

// Apenas administradores podem acessar esta página
if ($_SESSION['tipo_usuario'] !== 'admin') {
    echo '<div class="p-6 text-center text-red-500">Acesso negado. Apenas administradores podem gerenciar usuários.</div>';
    return;
}

// Incluir funções de segurança
require_once __DIR__ . '/../includes/funcoes-seguranca.php';

$pdo = conectarBancoDados();

// Buscar todos os usuários com email hashado
$stmt = $pdo->query("SELECT *, SHA2(email, 256) as email_hash FROM usuarios ORDER BY data_criacao DESC");
$usuarios = $stmt->fetchAll(PDO::FETCH_ASSOC);
$totalUsuarios = count($usuarios);

// Estatísticas
$totalAdmin = count(array_filter($usuarios, fn($u) => $u['tipo_usuario'] === 'admin'));
$totalComMFA = count(array_filter($usuarios, fn($u) => !empty($u['mfa_codigo_hash'])));
$totalAtivosLogin = count(array_filter($usuarios, fn($u) => $u['data_ultimo_login'] !== null));

// ID do administrador logado
$idAdminLogado = $_SESSION['id_usuario'];
?>

<div class="p-6">
    <!-- Breadcrumb -->
    <div class="mb-6 flex items-center text-sm <?= $temaAtual === 'dark' ? 'text-white/70' : 'text-gray-600' ?>">
        <a href="#" onclick="carregarPagina('dashboard')" class="hover:text-blue-400 clickable transition-colors flex items-center">
            <i class="fas fa-home mr-2 text-xs"></i> Dashboard
        </a>
        <i class="fas fa-chevron-right mx-2 text-xs <?= $temaAtual === 'dark' ? 'text-white/50' : 'text-gray-400' ?>"></i>
        <span class="text-blue-400 font-medium">Gerenciar Usuários</span>
    </div>

    <!-- Cabeçalho com ícone e status -->
    <div class="mb-8">
        <div class="flex items-center justify-between mb-4">
            <div class="flex items-center space-x-3">
                <div class="w-14 h-14 rounded-full bg-gradient-to-br from-blue-400 to-blue-600 flex items-center justify-center shadow-md">
                    <i class="fas fa-users text-white text-xl"></i>
                </div>
                <div>
                    <h1 class="text-2xl font-bold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?>">Gerenciar Usuários</h1>
                    <p class="<?= $temaAtual === 'dark' ? 'text-white/70' : 'text-gray-600' ?>">Administre todos os usuários do sistema</p>
                </div>
            </div>
            
            <div class="flex items-center space-x-3">
                <div class="px-4 py-2 bg-green-500/20 text-green-300 border-green-500/30 text-sm rounded-lg border flex items-center">
                    <i class="fas fa-check-circle mr-2"></i>
                    <span><?= $totalUsuarios ?> usuários</span>
                </div>
                <div class="text-xs <?= $temaAtual === 'dark' ? 'text-white/50' : 'text-gray-500' ?>">
                    <i class="fas fa-sync-alt mr-1"></i> <?= date('H:i') ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Botões principais -->
    <div class="flex justify-between items-center mb-6">
        <div class="flex space-x-3">
            <button onclick="abrirModalNovoUsuario()" 
                    class="px-4 py-2 btn-gradient rounded-lg clickable transition-all flex items-center">
                <i class="fas fa-user-plus mr-2"></i>Novo Usuário
            </button>
            <button onclick="exportarUsuarios()" 
                    class="px-4 py-2 <?= $temaAtual === 'dark' ? 'bg-white/10 hover:bg-white/20 text-white' : 'bg-gray-100 hover:bg-gray-200 text-gray-800' ?> rounded-lg clickable transition-all flex items-center">
                <i class="fas fa-file-export mr-2"></i>Exportar
            </button>
        </div>
    </div>

    <!-- Filtros -->
    <div class="card p-6 mb-6">
        <h3 class="text-lg font-semibold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?> mb-4">Filtros</h3>
        <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
                <label class="block text-sm font-medium <?= $temaAtual === 'dark' ? 'text-white/90' : 'text-gray-900' ?> mb-1">Tipo de Usuário</label>
                <select id="filtroTipo" class="w-full input-modern rounded-lg h-11" onchange="filtrarUsuarios()">
                    <option value="">Todos</option>
                    <option value="user">Usuário</option>
                    <option value="auditor">Auditor</option>
                    <option value="admin">Administrador</option>
                </select>
            </div>
            <div>
                <label class="block text-sm font-medium <?= $temaAtual === 'dark' ? 'text-white/90' : 'text-gray-900' ?> mb-1">Status MFA</label>
                <select id="filtroMFA" class="w-full input-modern rounded-lg h-11" onchange="filtrarUsuarios()">
                    <option value="">Todos</option>
                    <option value="ativo">Com MFA</option>
                    <option value="inativo">Sem MFA</option>
                </select>
            </div>
            <div>
                <label class="block text-sm font-medium <?= $temaAtual === 'dark' ? 'text-white/90' : 'text-gray-900' ?> mb-1">Status Ativo</label>
                <select id="filtroAtivo" class="w-full input-modern rounded-lg h-11" onchange="filtrarUsuarios()">
                    <option value="">Todos</option>
                    <option value="1">Ativo</option>
                    <option value="0">Inativo</option>
                </select>
            </div>
            <div>
                <label class="block text-sm font-medium <?= $temaAtual === 'dark' ? 'text-white/90' : 'text-gray-900' ?> mb-1">Buscar</label>
                <input type="text" id="filtroBusca" 
                       class="w-full input-modern rounded-lg h-11" 
                       placeholder="Nome ou email..."
                       onkeyup="filtrarUsuarios()">
            </div>
        </div>
    </div>

    <!-- Lista de Usuários -->
    <div class="card p-6">
        <div class="flex items-center justify-between mb-6">
            <h3 class="text-lg font-bold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?> flex items-center">
                <i class="fas fa-list text-blue-400 mr-3"></i>
                Lista de Usuários
            </h3>
            <span class="text-xs <?= $temaAtual === 'dark' ? 'text-white/50' : 'text-gray-500' ?>">
                <span id="contadorUsuarios"><?= $totalUsuarios ?></span> usuários encontrados
            </span>
        </div>
        
        <div class="overflow-x-auto rounded-lg border <?= $temaAtual === 'dark' ? 'border-white/10' : 'border-gray-200' ?>">
            <table class="w-full" id="tabelaUsuarios">
                <thead>
                    <tr class="text-left text-xs <?= $temaAtual === 'dark' ? 'text-white/70 bg-white/5' : 'text-gray-700 bg-gray-50' ?> border-b <?= $temaAtual === 'dark' ? 'border-white/10' : 'border-gray-200' ?>">
                        <th class="px-4 py-3 font-medium">Usuário</th>
                        <th class="px-4 py-3 font-medium">Email Hash</th>
                        <th class="px-4 py-3 font-medium">Tipo</th>
                        <th class="px-4 py-3 font-medium">Status</th>
                        <th class="px-4 py-3 font-medium">MFA</th>
                        <th class="px-4 py-3 font-medium">Última Atividade</th>
                        <th class="px-4 py-3 font-medium">Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($usuarios)): ?>
                    <tr>
                        <td colspan="7" class="px-4 py-8 text-center <?= $temaAtual === 'dark' ? 'text-white/50' : 'text-gray-500' ?>">
                            <i class="fas fa-users text-4xl <?= $temaAtual === 'dark' ? 'text-white/20' : 'text-gray-300' ?> mb-3 block"></i>
                            <p>Nenhum usuário encontrado</p>
                        </td>
                    </tr>
                    <?php else: ?>
                    <?php foreach ($usuarios as $usuario): 
                        $estaBloqueado = $usuario['bloqueado_ate'] && strtotime($usuario['bloqueado_ate']) > time();
                        $temTentativasFalhas = $usuario['tentativas_falhas'] > 0;
                        $isSelf = $usuario['id_usuario'] == $idAdminLogado;
                        $emailHash = substr($usuario['email_hash'] ?? '', 0, 16) . '...';
                    ?>
                    <tr class="table-row text-sm transition-colors" 
                        data-tipo="<?= htmlspecialchars($usuario['tipo_usuario']) ?>"
                        data-mfa="<?= !empty($usuario['mfa_codigo_hash']) ? 'ativo' : 'inativo' ?>"
                        data-ativo="<?= $usuario['ativo'] ?>"
                        data-nome="<?= htmlspecialchars(strtolower($usuario['nome_completo'])) ?>"
                        data-email="<?= htmlspecialchars(strtolower($usuario['email'])) ?>">
                        <td class="px-4 py-3">
                            <div class="flex items-center">
                                <div class="w-10 h-10 rounded-full <?= $temaAtual === 'dark' ? 'bg-blue-500/20' : 'bg-blue-100' ?> flex items-center justify-center mr-3">
                                    <span class="<?= $temaAtual === 'dark' ? 'text-blue-300' : 'text-blue-600' ?> font-bold text-sm">
                                        <?= strtoupper(substr($usuario['nome_completo'], 0, 1)) ?>
                                    </span>
                                </div>
                                <div>
                                    <p class="font-medium <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?>">
                                        <?= htmlspecialchars($usuario['nome_completo']) ?>
                                        <?php if ($isSelf): ?>
                                            <span class="ml-2 text-xs <?= $temaAtual === 'dark' ? 'bg-indigo-500/20 text-indigo-300' : 'bg-indigo-100 text-indigo-800' ?> px-2 py-0.5 rounded">VOCÊ</span>
                                        <?php endif; ?>
                                        <?php if ($estaBloqueado): ?>
                                            <span class="ml-2 text-xs <?= $temaAtual === 'dark' ? 'bg-red-500/20 text-red-300' : 'bg-red-100 text-red-800' ?> px-2 py-0.5 rounded">BLOQUEADO</span>
                                        <?php endif; ?>
                                        <?php if ($temTentativasFalhas): ?>
                                            <span class="ml-2 text-xs <?= $temaAtual === 'dark' ? 'bg-orange-500/20 text-orange-300' : 'bg-orange-100 text-orange-800' ?> px-2 py-0.5 rounded">
                                                <?= $usuario['tentativas_falhas'] ?> tentativas
                                            </span>
                                        <?php endif; ?>
                                    </p>
                                    <p class="text-xs <?= $temaAtual === 'dark' ? 'text-white/50' : 'text-gray-500' ?>">
                                        ID: <?= $usuario['id_usuario'] ?> • Criado: <?= date('d/m/Y', strtotime($usuario['data_criacao'])) ?>
                                    </p>
                                </div>
                            </div>
                        </td>
                        <td class="px-4 py-3 <?= $temaAtual === 'dark' ? 'text-white/90' : 'text-gray-700' ?>">
                            <div class="flex items-center">
                                <i class="fas fa-fingerprint <?= $temaAtual === 'dark' ? 'text-purple-400' : 'text-purple-600' ?> mr-2"></i>
                                <div>
                                    <code class="text-xs font-mono <?= $temaAtual === 'dark' ? 'text-purple-300' : 'text-purple-700' ?>" title="SHA256 Hash do Email">
                                        <?= $emailHash ?>
                                    </code>
                                    <?php if ($usuario['ultimo_ip']): ?>
                                        <p class="text-xs <?= $temaAtual === 'dark' ? 'text-white/50' : 'text-gray-500' ?> mt-1">IP: <?= $usuario['ultimo_ip'] ?></p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </td>
                        <td class="px-4 py-3">
                            <span class="text-xs px-2 py-1 rounded-full <?= 
                                $usuario['tipo_usuario'] === 'admin' ? ($temaAtual === 'dark' ? 'bg-purple-500/20 text-purple-300' : 'bg-purple-100 text-purple-800') : 
                                ($usuario['tipo_usuario'] === 'auditor' ? ($temaAtual === 'dark' ? 'bg-blue-500/20 text-blue-300' : 'bg-blue-100 text-blue-800') : 
                                ($temaAtual === 'dark' ? 'bg-white/10 text-white/90' : 'bg-gray-100 text-gray-800'))
                            ?>">
                                <?= ucfirst($usuario['tipo_usuario']) ?>
                            </span>
                        </td>
                        <td class="px-4 py-3">
                            <span class="text-xs px-2 py-1 rounded-full <?= 
                                $usuario['ativo'] ? 
                                ($temaAtual === 'dark' ? 'bg-green-500/20 text-green-300' : 'bg-green-100 text-green-800') : 
                                ($temaAtual === 'dark' ? 'bg-red-500/20 text-red-300' : 'bg-red-100 text-red-800')
                            ?>">
                                <?= $usuario['ativo'] ? 'Ativo' : 'Inativo' ?>
                            </span>
                        </td>
                        <td class="px-4 py-3">
                            <span class="text-xs px-2 py-1 rounded-full <?= 
                                !empty($usuario['mfa_codigo_hash']) ? 
                                ($temaAtual === 'dark' ? 'bg-green-500/20 text-green-300' : 'bg-green-100 text-green-800') : 
                                ($temaAtual === 'dark' ? 'bg-white/10 text-white/90' : 'bg-gray-100 text-gray-800')
                            ?>">
                                <?= !empty($usuario['mfa_codigo_hash']) ? 'Ativo' : 'Inativo' ?>
                            </span>
                        </td>
                        <td class="px-4 py-3 <?= $temaAtual === 'dark' ? 'text-white/90' : 'text-gray-700' ?> text-sm">
                            <?php if ($usuario['data_ultima_atividade']): ?>
                                <?= date('d/m H:i', strtotime($usuario['data_ultima_atividade'])) ?>
                            <?php else: ?>
                                <span class="<?= $temaAtual === 'dark' ? 'text-white/50' : 'text-gray-500' ?> italic">Nunca</span>
                            <?php endif; ?>
                        </td>
                        <td class="px-4 py-3">
                            <div class="flex space-x-1">
                                <button onclick="editarUsuario(<?= $usuario['id_usuario'] ?>)" title="Editar" class="px-3 py-1 text-xs <?= $temaAtual === 'dark' ? 'bg-blue-500/20 text-blue-300 hover:bg-blue-500/30' : 'bg-blue-100 text-blue-700 hover:bg-blue-200' ?> rounded clickable transition-colors">
                                    <i class="fas fa-edit"></i>
                                </button>
                                <button onclick="verDetalhesUsuario(<?= $usuario['id_usuario'] ?>)" title="Detalhes" class="px-3 py-1 text-xs <?= $temaAtual === 'dark' ? 'bg-white/10 text-white/90 hover:bg-white/20' : 'bg-gray-100 text-gray-700 hover:bg-gray-200' ?> rounded clickable transition-colors">
                                    <i class="fas fa-eye"></i>
                                </button>
                                <?php if ($estaBloqueado): ?>
                                    <button onclick="abrirModalDesbloquearUsuario(<?= $usuario['id_usuario'] ?>)" title="Desbloquear" class="px-3 py-1 text-xs <?= $temaAtual === 'dark' ? 'bg-green-500/20 text-green-300 hover:bg-green-500/30' : 'bg-green-100 text-green-700 hover:bg-green-200' ?> rounded clickable transition-colors">
                                        <i class="fas fa-unlock"></i>
                                    </button>
                                <?php elseif (!$isSelf): ?>
                                    <button onclick="abrirModalBloquearUsuario(<?= $usuario['id_usuario'] ?>)" title="Bloquear" class="px-3 py-1 text-xs <?= $temaAtual === 'dark' ? 'bg-orange-500/20 text-orange-300 hover:bg-orange-500/30' : 'bg-orange-100 text-orange-700 hover:bg-orange-200' ?> rounded clickable transition-colors">
                                        <i class="fas fa-lock"></i>
                                    </button>
                                <?php endif; ?>
                                <?php if ($usuario['ativo'] && !$isSelf): ?>
                                    <button onclick="abrirModalDesativarUsuario(<?= $usuario['id_usuario'] ?>)" title="Desativar" class="px-3 py-1 text-xs <?= $temaAtual === 'dark' ? 'bg-yellow-500/20 text-yellow-300 hover:bg-yellow-500/30' : 'bg-yellow-100 text-yellow-700 hover:bg-yellow-200' ?> rounded clickable transition-colors">
                                        <i class="fas fa-user-slash"></i>
                                    </button>
                                <?php elseif (!$usuario['ativo']): ?>
                                    <button onclick="abrirModalAtivarUsuario(<?= $usuario['id_usuario'] ?>)" title="Ativar" class="px-3 py-1 text-xs <?= $temaAtual === 'dark' ? 'bg-green-500/20 text-green-300 hover:bg-green-500/30' : 'bg-green-100 text-green-700 hover:bg-green-200' ?> rounded clickable transition-colors">
                                        <i class="fas fa-user-check"></i>
                                    </button>
                                <?php endif; ?>
                                <button onclick="abrirModalResetarSenha(<?= $usuario['id_usuario'] ?>)" title="Resetar senha" class="px-3 py-1 text-xs <?= $temaAtual === 'dark' ? 'bg-purple-500/20 text-purple-300 hover:bg-purple-500/30' : 'bg-purple-100 text-purple-700 hover:bg-purple-200' ?> rounded clickable transition-colors">
                                    <i class="fas fa-key"></i>
                                </button>
                                <?php if (!$isSelf): ?>
                                    <button onclick="abrirModalExcluirUsuario(<?= $usuario['id_usuario'] ?>)" title="Excluir" class="px-3 py-1 text-xs <?= $temaAtual === 'dark' ? 'bg-red-500/20 text-red-300 hover:bg-red-500/30' : 'bg-red-100 text-red-700 hover:bg-red-200' ?> rounded clickable transition-colors">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- Estatísticas -->
        <div class="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
            <div class="text-center p-4 <?= $temaAtual === 'dark' ? 'bg-white/5' : 'bg-gray-50' ?> rounded-lg">
                <p class="text-2xl font-bold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?>"><?= $totalUsuarios ?></p>
                <p class="text-xs <?= $temaAtual === 'dark' ? 'text-white/60' : 'text-gray-600' ?>">Total Usuários</p>
            </div>
            <div class="text-center p-4 <?= $temaAtual === 'dark' ? 'bg-white/5' : 'bg-gray-50' ?> rounded-lg">
                <p class="text-2xl font-bold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?>"><?= $totalAdmin ?></p>
                <p class="text-xs <?= $temaAtual === 'dark' ? 'text-white/60' : 'text-gray-600' ?>">Administradores</p>
            </div>
            <div class="text-center p-4 <?= $temaAtual === 'dark' ? 'bg-white/5' : 'bg-gray-50' ?> rounded-lg">
                <p class="text-2xl font-bold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?>"><?= $totalComMFA ?></p>
                <p class="text-xs <?= $temaAtual === 'dark' ? 'text-white/60' : 'text-gray-600' ?>">Com MFA</p>
            </div>
            <div class="text-center p-4 <?= $temaAtual === 'dark' ? 'bg-white/5' : 'bg-gray-50' ?> rounded-lg">
                <p class="text-2xl font-bold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?>"><?= $totalAtivosLogin ?></p>
                <p class="text-xs <?= $temaAtual === 'dark' ? 'text-white/60' : 'text-gray-600' ?>">Com Login Recente</p>
            </div>
        </div>
    </div>
</div>

<!-- Modal Novo Usuário -->
<div id="modalNovoUsuario" class="modal-overlay hidden" onclick="fecharModal('modalNovoUsuario')">
    <div class="modal-content" style="max-width: 500px; max-height: 90vh; overflow-y: auto;" onclick="event.stopPropagation()">
        <div class="p-6">
            <div class="flex items-center justify-between mb-6">
                <div class="flex items-center space-x-3">
                    <div class="w-10 h-10 rounded-lg <?= $temaAtual === 'dark' ? 'bg-green-500/20' : 'bg-green-100' ?> flex items-center justify-center">
                        <i class="fas fa-user-plus <?= $temaAtual === 'dark' ? 'text-green-400' : 'text-green-600' ?> text-lg"></i>
                    </div>
                    <h3 class="text-lg font-semibold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?>">Novo Usuário</h3>
                </div>
                <button type="button" onclick="fecharModal('modalNovoUsuario')" class="<?= $temaAtual === 'dark' ? 'text-white/50 hover:text-white' : 'text-gray-500 hover:text-gray-700' ?> clickable">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <form id="formNovoUsuario" onsubmit="criarUsuario(event)">
                <div class="space-y-4">
                    <div>
                        <label class="block text-sm font-medium <?= $temaAtual === 'dark' ? 'text-white/90' : 'text-gray-900' ?> mb-2">Nome Completo *</label>
                        <input type="text" name="nome_completo" required
                               class="w-full input-modern rounded-lg h-11"
                               placeholder="Digite o nome completo">
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium <?= $temaAtual === 'dark' ? 'text-white/90' : 'text-gray-900' ?> mb-2">Email *</label>
                        <input type="email" name="email" required
                               class="w-full input-modern rounded-lg h-11"
                               placeholder="email@exemplo.com">
                    </div>
                    
                    <div>
                        <label class="block text-sm font-medium <?= $temaAtual === 'dark' ? 'text-white/90' : 'text-gray-900' ?> mb-2">Tipo de Usuário *</label>
                        <select name="tipo_usuario" class="w-full input-modern rounded-lg h-11" required>
                            <option value="user">Usuário</option>
                            <option value="auditor">Auditor</option>
                            <option value="admin">Administrador</option>
                        </select>
                    </div>
                    
                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm font-medium <?= $temaAtual === 'dark' ? 'text-white/90' : 'text-gray-900' ?> mb-2">Senha *</label>
                            <input type="password" name="senha" required minlength="8"
                                   class="w-full input-modern rounded-lg h-11"
                                   placeholder="Mínimo 8 caracteres">
                        </div>
                        <div>
                            <label class="block text-sm font-medium <?= $temaAtual === 'dark' ? 'text-white/90' : 'text-gray-900' ?> mb-2">Confirmar Senha *</label>
                            <input type="password" name="confirmar_senha" required minlength="8"
                                   class="w-full input-modern rounded-lg h-11"
                                   placeholder="Digite novamente">
                        </div>
                    </div>
                    
                    <div class="flex items-center space-x-2">
                        <input type="checkbox" id="ativo" name="ativo" class="rounded <?= $temaAtual === 'dark' ? 'accent-blue-500' : '' ?>" checked>
                        <label for="ativo" class="text-sm <?= $temaAtual === 'dark' ? 'text-white/90' : 'text-gray-900' ?>">Usuário ativo</label>
                    </div>
                </div>
                
                <div class="flex justify-end space-x-3 mt-6 pt-6 border-t <?= $temaAtual === 'dark' ? 'border-white/10' : 'border-gray-200' ?>">
                    <button type="button" onclick="fecharModal('modalNovoUsuario')"
                            class="px-4 py-2 <?= $temaAtual === 'dark' ? 'text-white/70 hover:text-white' : 'text-gray-700 hover:text-gray-900' ?> clickable">
                        Cancelar
                    </button>
                    <button type="submit"
                            class="px-4 py-2 btn-gradient rounded-lg clickable transition-colors flex items-center">
                        <i class="fas fa-save mr-2"></i>Criar Usuário
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal Editar Usuário -->
<div id="modalEditarUsuario" class="modal-overlay hidden" onclick="fecharModal('modalEditarUsuario')">
    <div class="modal-content" style="max-width: 500px; max-height: 90vh; overflow-y: auto;" onclick="event.stopPropagation()">
        <div class="p-6">
            <div class="flex items-center justify-between mb-6">
                <div class="flex items-center space-x-3">
                    <div class="w-10 h-10 rounded-lg <?= $temaAtual === 'dark' ? 'bg-blue-500/20' : 'bg-blue-100' ?> flex items-center justify-center">
                        <i class="fas fa-edit <?= $temaAtual === 'dark' ? 'text-blue-400' : 'text-blue-600' ?> text-lg"></i>
                    </div>
                    <h3 class="text-lg font-semibold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?>">Editar Usuário</h3>
                </div>
                <button type="button" onclick="fecharModal('modalEditarUsuario')" class="<?= $temaAtual === 'dark' ? 'text-white/50 hover:text-white' : 'text-gray-500 hover:text-gray-700' ?> clickable">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <div id="conteudoEditarUsuario">
                <div class="text-center py-8">
                    <div class="loader mx-auto"></div>
                    <p class="<?= $temaAtual === 'dark' ? 'text-white/70' : 'text-gray-600' ?> mt-3">Carregando dados do usuário...</p>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal Detalhes Usuário -->
<div id="modalDetalhesUsuario" class="modal-overlay hidden" onclick="fecharModal('modalDetalhesUsuario')">
    <div class="modal-content" style="max-width: 600px; max-height: 90vh; overflow-y: auto;" onclick="event.stopPropagation()">
        <div class="p-6">
            <div class="flex items-center justify-between mb-6">
                <div class="flex items-center space-x-3">
                    <div class="w-10 h-10 rounded-lg <?= $temaAtual === 'dark' ? 'bg-purple-500/20' : 'bg-purple-100' ?> flex items-center justify-center">
                        <i class="fas fa-info-circle <?= $temaAtual === 'dark' ? 'text-purple-400' : 'text-purple-600' ?> text-lg"></i>
                    </div>
                    <h3 class="text-lg font-semibold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?>">Detalhes do Usuário</h3>
                </div>
                <button type="button" onclick="fecharModal('modalDetalhesUsuario')" class="<?= $temaAtual === 'dark' ? 'text-white/50 hover:text-white' : 'text-gray-500 hover:text-gray-700' ?> clickable">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <div id="conteudoDetalhesUsuario">
                <div class="text-center py-8">
                    <div class="loader mx-auto"></div>
                    <p class="<?= $temaAtual === 'dark' ? 'text-white/70' : 'text-gray-600' ?> mt-3">Carregando detalhes do usuário...</p>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal Confirmar Bloquear Usuário -->
<div id="modalConfirmarBloquear" class="modal-overlay hidden" onclick="fecharModal('modalConfirmarBloquear')">
    <div class="modal-content" style="max-width: 500px;" onclick="event.stopPropagation()">
        <div class="p-6">
            <div class="flex items-center justify-between mb-6">
                <div class="flex items-center space-x-3">
                    <div class="w-10 h-10 rounded-lg <?= $temaAtual === 'dark' ? 'bg-orange-500/20' : 'bg-orange-100' ?> flex items-center justify-center">
                        <i class="fas fa-lock <?= $temaAtual === 'dark' ? 'text-orange-400' : 'text-orange-600' ?> text-lg"></i>
                    </div>
                    <h3 class="text-lg font-semibold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?>">Bloquear Usuário</h3>
                </div>
                <button type="button" onclick="fecharModal('modalConfirmarBloquear')" class="<?= $temaAtual === 'dark' ? 'text-white/50 hover:text-white' : 'text-gray-500 hover:text-gray-700' ?> clickable">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <div class="space-y-4">
                <div class="<?= $temaAtual === 'dark' ? 'bg-orange-500/10 border-orange-500/20' : 'bg-orange-50 border-orange-100' ?> border rounded-lg p-4">
                    <div class="flex items-start">
                        <i class="fas fa-exclamation-triangle <?= $temaAtual === 'dark' ? 'text-orange-400' : 'text-orange-500' ?> mt-1 mr-3"></i>
                        <div>
                            <h4 class="font-medium <?= $temaAtual === 'dark' ? 'text-white' : 'text-orange-900' ?>">Atenção</h4>
                            <p class="text-sm <?= $temaAtual === 'dark' ? 'text-white/70' : 'text-orange-700' ?> mt-1">
                                O usuário não poderá fazer login por <span class="font-bold">1 hora</span> após o bloqueio.
                            </p>
                        </div>
                    </div>
                </div>
                
                <p class="<?= $temaAtual === 'dark' ? 'text-white/90' : 'text-gray-700' ?>">
                    Tem certeza que deseja bloquear este usuário?
                </p>
                
                <div class="flex justify-end space-x-3 mt-6 pt-6 border-t <?= $temaAtual === 'dark' ? 'border-white/10' : 'border-gray-200' ?>">
                    <button type="button" onclick="fecharModal('modalConfirmarBloquear')"
                            class="px-4 py-2 <?= $temaAtual === 'dark' ? 'text-white/70 hover:text-white' : 'text-gray-700 hover:text-gray-900' ?> clickable">
                        Cancelar
                    </button>
                    <button type="button" onclick="bloquearUsuarioConfirmado()"
                            class="px-4 py-2 <?= $temaAtual === 'dark' ? 'bg-orange-500 hover:bg-orange-600' : 'bg-orange-500 hover:bg-orange-600' ?> text-white rounded-lg clickable transition-colors flex items-center">
                        <i class="fas fa-lock mr-2"></i>Confirmar Bloqueio
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal Confirmar Desbloquear Usuário -->
<div id="modalConfirmarDesbloquear" class="modal-overlay hidden" onclick="fecharModal('modalConfirmarDesbloquear')">
    <div class="modal-content" style="max-width: 500px;" onclick="event.stopPropagation()">
        <div class="p-6">
            <div class="flex items-center justify-between mb-6">
                <div class="flex items-center space-x-3">
                    <div class="w-10 h-10 rounded-lg <?= $temaAtual === 'dark' ? 'bg-green-500/20' : 'bg-green-100' ?> flex items-center justify-center">
                        <i class="fas fa-unlock <?= $temaAtual === 'dark' ? 'text-green-400' : 'text-green-600' ?> text-lg"></i>
                    </div>
                    <h3 class="text-lg font-semibold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?>">Desbloquear Usuário</h3>
                </div>
                <button type="button" onclick="fecharModal('modalConfirmarDesbloquear')" class="<?= $temaAtual === 'dark' ? 'text-white/50 hover:text-white' : 'text-gray-500 hover:text-gray-700' ?> clickable">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <div class="space-y-4">
                <div class="<?= $temaAtual === 'dark' ? 'bg-green-500/10 border-green-500/20' : 'bg-green-50 border-green-100' ?> border rounded-lg p-4">
                    <div class="flex items-start">
                        <i class="fas fa-check-circle <?= $temaAtual === 'dark' ? 'text-green-400' : 'text-green-500' ?> mt-1 mr-3"></i>
                        <div>
                            <h4 class="font-medium <?= $temaAtual === 'dark' ? 'text-white' : 'text-green-900' ?>">Restaurar Acesso</h4>
                            <p class="text-sm <?= $temaAtual === 'dark' ? 'text-white/70' : 'text-green-700' ?> mt-1">
                                O usuário poderá fazer login imediatamente após o desbloqueio.
                            </p>
                        </div>
                    </div>
                </div>
                
                <p class="<?= $temaAtual === 'dark' ? 'text-white/90' : 'text-gray-700' ?>">
                    Tem certeza que deseja desbloquear este usuário?
                </p>
                
                <div class="flex justify-end space-x-3 mt-6 pt-6 border-t <?= $temaAtual === 'dark' ? 'border-white/10' : 'border-gray-200' ?>">
                    <button type="button" onclick="fecharModal('modalConfirmarDesbloquear')"
                            class="px-4 py-2 <?= $temaAtual === 'dark' ? 'text-white/70 hover:text-white' : 'text-gray-700 hover:text-gray-900' ?> clickable">
                        Cancelar
                    </button>
                    <button type="button" onclick="desbloquearUsuarioConfirmado()"
                            class="px-4 py-2 <?= $temaAtual === 'dark' ? 'bg-green-500 hover:bg-green-600' : 'bg-green-500 hover:bg-green-600' ?> text-white rounded-lg clickable transition-colors flex items-center">
                        <i class="fas fa-unlock mr-2"></i>Confirmar Desbloqueio
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal Confirmar Ativar Usuário -->
<div id="modalConfirmarAtivar" class="modal-overlay hidden" onclick="fecharModal('modalConfirmarAtivar')">
    <div class="modal-content" style="max-width: 500px;" onclick="event.stopPropagation()">
        <div class="p-6">
            <div class="flex items-center justify-between mb-6">
                <div class="flex items-center space-x-3">
                    <div class="w-10 h-10 rounded-lg <?= $temaAtual === 'dark' ? 'bg-green-500/20' : 'bg-green-100' ?> flex items-center justify-center">
                        <i class="fas fa-user-check <?= $temaAtual === 'dark' ? 'text-green-400' : 'text-green-600' ?> text-lg"></i>
                    </div>
                    <h3 class="text-lg font-semibold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?>">Ativar Usuário</h3>
                </div>
                <button type="button" onclick="fecharModal('modalConfirmarAtivar')" class="<?= $temaAtual === 'dark' ? 'text-white/50 hover:text-white' : 'text-gray-500 hover:text-gray-700' ?> clickable">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <div class="space-y-4">
                <div class="<?= $temaAtual === 'dark' ? 'bg-green-500/10 border-green-500/20' : 'bg-green-50 border-green-100' ?> border rounded-lg p-4">
                    <div class="flex items-start">
                        <i class="fas fa-check-circle <?= $temaAtual === 'dark' ? 'text-green-400' : 'text-green-500' ?> mt-1 mr-3"></i>
                        <div>
                            <h4 class="font-medium <?= $temaAtual === 'dark' ? 'text-white' : 'text-green-900' ?>">Ativar Acesso</h4>
                            <p class="text-sm <?= $temaAtual === 'dark' ? 'text-white/70' : 'text-green-700' ?> mt-1">
                                O usuário poderá fazer login normalmente após a ativação.
                            </p>
                        </div>
                    </div>
                </div>
                
                <p class="<?= $temaAtual === 'dark' ? 'text-white/90' : 'text-gray-700' ?>">
                    Tem certeza que deseja ativar este usuário?
                </p>
                
                <div class="flex justify-end space-x-3 mt-6 pt-6 border-t <?= $temaAtual === 'dark' ? 'border-white/10' : 'border-gray-200' ?>">
                    <button type="button" onclick="fecharModal('modalConfirmarAtivar')"
                            class="px-4 py-2 <?= $temaAtual === 'dark' ? 'text-white/70 hover:text-white' : 'text-gray-700 hover:text-gray-900' ?> clickable">
                        Cancelar
                    </button>
                    <button type="button" onclick="ativarUsuarioConfirmado()"
                            class="px-4 py-2 <?= $temaAtual === 'dark' ? 'bg-green-500 hover:bg-green-600' : 'bg-green-500 hover:bg-green-600' ?> text-white rounded-lg clickable transition-colors flex items-center">
                        <i class="fas fa-user-check mr-2"></i>Confirmar Ativação
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal Confirmar Desativar Usuário -->
<div id="modalConfirmarDesativar" class="modal-overlay hidden" onclick="fecharModal('modalConfirmarDesativar')">
    <div class="modal-content" style="max-width: 500px;" onclick="event.stopPropagation()">
        <div class="p-6">
            <div class="flex items-center justify-between mb-6">
                <div class="flex items-center space-x-3">
                    <div class="w-10 h-10 rounded-lg <?= $temaAtual === 'dark' ? 'bg-yellow-500/20' : 'bg-yellow-100' ?> flex items-center justify-center">
                        <i class="fas fa-user-slash <?= $temaAtual === 'dark' ? 'text-yellow-400' : 'text-yellow-600' ?> text-lg"></i>
                    </div>
                    <h3 class="text-lg font-semibold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?>">Desativar Usuário</h3>
                </div>
                <button type="button" onclick="fecharModal('modalConfirmarDesativar')" class="<?= $temaAtual === 'dark' ? 'text-white/50 hover:text-white' : 'text-gray-500 hover:text-gray-700' ?> clickable">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <div class="space-y-4">
                <div class="<?= $temaAtual === 'dark' ? 'bg-yellow-500/10 border-yellow-500/20' : 'bg-yellow-50 border-yellow-100' ?> border rounded-lg p-4">
                    <div class="flex items-start">
                        <i class="fas fa-exclamation-triangle <?= $temaAtual === 'dark' ? 'text-yellow-400' : 'text-yellow-500' ?> mt-1 mr-3"></i>
                        <div>
                            <h4 class="font-medium <?= $temaAtual === 'dark' ? 'text-white' : 'text-yellow-900' ?>">Atenção</h4>
                            <p class="text-sm <?= $temaAtual === 'dark' ? 'text-white/70' : 'text-yellow-700' ?> mt-1">
                                O usuário não poderá fazer login até ser reativado.
                            </p>
                        </div>
                    </div>
                </div>
                
                <p class="<?= $temaAtual === 'dark' ? 'text-white/90' : 'text-gray-700' ?>">
                    Tem certeza que deseja desativar este usuário?
                </p>
                
                <div class="flex justify-end space-x-3 mt-6 pt-6 border-t <?= $temaAtual === 'dark' ? 'border-white/10' : 'border-gray-200' ?>">
                    <button type="button" onclick="fecharModal('modalConfirmarDesativar')"
                            class="px-4 py-2 <?= $temaAtual === 'dark' ? 'text-white/70 hover:text-white' : 'text-gray-700 hover:text-gray-900' ?> clickable">
                        Cancelar
                    </button>
                    <button type="button" onclick="desativarUsuarioConfirmado()"
                            class="px-4 py-2 <?= $temaAtual === 'dark' ? 'bg-yellow-500 hover:bg-yellow-600' : 'bg-yellow-500 hover:bg-yellow-600' ?> text-white rounded-lg clickable transition-colors flex items-center">
                        <i class="fas fa-user-slash mr-2"></i>Confirmar Desativação
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal Confirmar Resetar Senha -->
<div id="modalConfirmarResetarSenha" class="modal-overlay hidden" onclick="fecharModal('modalConfirmarResetarSenha')">
    <div class="modal-content" style="max-width: 600px;" onclick="event.stopPropagation()">
        <div class="p-6">
            <div class="flex items-center justify-between mb-6">
                <div class="flex items-center space-x-3">
                    <div class="w-10 h-10 rounded-lg <?= $temaAtual === 'dark' ? 'bg-purple-500/20' : 'bg-purple-100' ?> flex items-center justify-center">
                        <i class="fas fa-key <?= $temaAtual === 'dark' ? 'text-purple-400' : 'text-purple-600' ?> text-lg"></i>
                    </div>
                    <h3 class="text-lg font-semibold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?>">Resetar Senha</h3>
                </div>
                <button type="button" onclick="fecharModal('modalConfirmarResetarSenha')" class="<?= $temaAtual === 'dark' ? 'text-white/50 hover:text-white' : 'text-gray-500 hover:text-gray-700' ?> clickable">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <div class="space-y-4">
                <div class="<?= $temaAtual === 'dark' ? 'bg-red-500/10 border-red-500/20' : 'bg-red-50 border-red-100' ?> border rounded-lg p-4">
                    <div class="flex items-start">
                        <i class="fas fa-exclamation-triangle <?= $temaAtual === 'dark' ? 'text-red-400' : 'text-red-500' ?> mt-1 mr-3"></i>
                        <div>
                            <h4 class="font-medium <?= $temaAtual === 'dark' ? 'text-white' : 'text-red-900' ?>">ATENÇÃO</h4>
                            <p class="text-sm <?= $temaAtual === 'dark' ? 'text-white/70' : 'text-red-700' ?> mt-1">
                                Esta ação irá gerar uma nova senha aleatória!
                            </p>
                        </div>
                    </div>
                </div>
                
                <div class="space-y-3">
                    <div class="flex items-start">
                        <i class="fas fa-info-circle <?= $temaAtual === 'dark' ? 'text-blue-400' : 'text-blue-500' ?> mt-0.5 mr-3"></i>
                        <div>
                            <p class="<?= $temaAtual === 'dark' ? 'text-white/90' : 'text-gray-700' ?> text-sm">
                                A nova senha será mostrada apenas <span class="font-bold">UMA VEZ</span> e deverá ser compartilhada com o usuário.
                            </p>
                        </div>
                    </div>
                    
                    <div class="flex items-start">
                        <i class="fas fa-exclamation-circle <?= $temaAtual === 'dark' ? 'text-orange-400' : 'text-orange-500' ?> mt-0.5 mr-3"></i>
                        <div>
                            <p class="<?= $temaAtual === 'dark' ? 'text-white/90' : 'text-gray-700' ?> text-sm">
                                Recomende que o usuário altere a senha após o primeiro login.
                            </p>
                        </div>
                    </div>
                </div>
                
                <p class="<?= $temaAtual === 'dark' ? 'text-white/90' : 'text-gray-700' ?> font-medium">
                    Tem certeza que deseja resetar a senha deste usuário?
                </p>
                
                <div class="flex justify-end space-x-3 mt-6 pt-6 border-t <?= $temaAtual === 'dark' ? 'border-white/10' : 'border-gray-200' ?>">
                    <button type="button" onclick="fecharModal('modalConfirmarResetarSenha')"
                            class="px-4 py-2 <?= $temaAtual === 'dark' ? 'text-white/70 hover:text-white' : 'text-gray-700 hover:text-gray-900' ?> clickable">
                        Cancelar
                    </button>
                    <button type="button" onclick="resetarSenhaConfirmado()"
                            class="px-4 py-2 <?= $temaAtual === 'dark' ? 'bg-purple-500 hover:bg-purple-600' : 'bg-purple-500 hover:bg-purple-600' ?> text-white rounded-lg clickable transition-colors flex items-center">
                        <i class="fas fa-key mr-2"></i>Gerar Nova Senha
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal Confirmar Excluir Usuário -->
<div id="modalConfirmarExcluir" class="modal-overlay hidden" onclick="fecharModal('modalConfirmarExcluir')">
    <div class="modal-content" style="max-width: 600px;" onclick="event.stopPropagation()">
        <div class="p-6">
            <div class="flex items-center justify-between mb-6">
                <div class="flex items-center space-x-3">
                    <div class="w-10 h-10 rounded-lg <?= $temaAtual === 'dark' ? 'bg-red-500/20' : 'bg-red-100' ?> flex items-center justify-center">
                        <i class="fas fa-trash <?= $temaAtual === 'dark' ? 'text-red-400' : 'text-red-600' ?> text-lg"></i>
                    </div>
                    <h3 class="text-lg font-semibold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?>">Excluir Usuário</h3>
                </div>
                <button type="button" onclick="fecharModal('modalConfirmarExcluir')" class="<?= $temaAtual === 'dark' ? 'text-white/50 hover:text-white' : 'text-gray-500 hover:text-gray-700' ?> clickable">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <div class="space-y-4">
                <div class="<?= $temaAtual === 'dark' ? 'bg-red-500/10 border-red-500/20' : 'bg-red-50 border-red-100' ?> border rounded-lg p-4">
                    <div class="flex items-start">
                        <i class="fas fa-exclamation-triangle <?= $temaAtual === 'dark' ? 'text-red-400' : 'text-red-500' ?> mt-1 mr-3"></i>
                        <div>
                            <h4 class="font-medium <?= $temaAtual === 'dark' ? 'text-white' : 'text-red-900' ?>">⚠️ ATENÇÃO</h4>
                            <p class="text-sm <?= $temaAtual === 'dark' ? 'text-white/70' : 'text-red-700' ?> mt-1">
                                Esta ação <span class="font-bold">NÃO PODE SER DESFEITA</span>!
                            </p>
                        </div>
                    </div>
                </div>
                
                <div class="space-y-3">
                    <div class="flex items-start">
                        <i class="fas fa-times-circle <?= $temaAtual === 'dark' ? 'text-red-400' : 'text-red-500' ?> mt-0.5 mr-3"></i>
                        <div>
                            <p class="<?= $temaAtual === 'dark' ? 'text-white/90' : 'text-gray-700' ?> text-sm">
                                O usuário será permanentemente excluído
                            </p>
                        </div>
                    </div>
                    
                    <div class="flex items-start">
                        <i class="fas fa-chart-bar <?= $temaAtual === 'dark' ? 'text-red-400' : 'text-red-500' ?> mt-0.5 mr-3"></i>
                        <div>
                            <p class="<?= $temaAtual === 'dark' ? 'text-white/90' : 'text-gray-700' ?> text-sm">
                                Todos os dados associados serão removidos
                            </p>
                        </div>
                    </div>
                    
                    <div class="flex items-start">
                        <i class="fas fa-ban <?= $temaAtual === 'dark' ? 'text-red-400' : 'text-red-500' ?> mt-0.5 mr-3"></i>
                        <div>
                            <p class="<?= $temaAtual === 'dark' ? 'text-white/90' : 'text-gray-700' ?> text-sm">
                                O usuário não poderá mais acessar o sistema
                            </p>
                        </div>
                    </div>
                </div>
                
                <div class="<?= $temaAtual === 'dark' ? 'bg-yellow-500/10 border-yellow-500/20' : 'bg-yellow-50 border-yellow-100' ?> border rounded-lg p-4">
                    <div class="flex items-start">
                        <i class="fas fa-question-circle <?= $temaAtual === 'dark' ? 'text-yellow-400' : 'text-yellow-500' ?> mt-0.5 mr-3"></i>
                        <div>
                            <p class="text-sm <?= $temaAtual === 'dark' ? 'text-white/90' : 'text-yellow-900' ?> font-medium">
                                Considerar a desativação do usuário em vez da exclusão?
                            </p>
                        </div>
                    </div>
                </div>
                
                <p class="<?= $temaAtual === 'dark' ? 'text-white/90' : 'text-gray-700' ?> font-medium">
                    Tem certeza <span class="font-bold">ABSOLUTA</span> que deseja excluir este usuário?
                </p>
                
                <div class="flex justify-end space-x-3 mt-6 pt-6 border-t <?= $temaAtual === 'dark' ? 'border-white/10' : 'border-gray-200' ?>">
                    <button type="button" onclick="fecharModal('modalConfirmarExcluir')"
                            class="px-4 py-2 <?= $temaAtual === 'dark' ? 'text-white/70 hover:text-white' : 'text-gray-700 hover:text-gray-900' ?> clickable">
                        Cancelar
                    </button>
                    <button type="button" onclick="excluirUsuarioConfirmado()"
                            class="px-4 py-2 <?= $temaAtual === 'dark' ? 'bg-red-500 hover:bg-red-600' : 'bg-red-500 hover:bg-red-600' ?> text-white rounded-lg clickable transition-colors flex items-center">
                        <i class="fas fa-trash mr-2"></i>Excluir Permanentemente
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal Nova Senha Gerada -->
<div id="modalNovaSenha" class="modal-overlay hidden" onclick="fecharModal('modalNovaSenha')">
    <div class="modal-content" style="max-width: 600px;" onclick="event.stopPropagation()">
        <div class="p-6">
            <div class="flex items-center justify-between mb-6">
                <div class="flex items-center space-x-3">
                    <div class="w-10 h-10 rounded-lg <?= $temaAtual === 'dark' ? 'bg-green-500/20' : 'bg-green-100' ?> flex items-center justify-center">
                        <i class="fas fa-key <?= $temaAtual === 'dark' ? 'text-green-400' : 'text-green-600' ?> text-lg"></i>
                    </div>
                    <h3 class="text-lg font-semibold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?>">Nova Senha Gerada</h3>
                </div>
                <button type="button" onclick="fecharModalNovaSenha()" class="<?= $temaAtual === 'dark' ? 'text-white/50 hover:text-white' : 'text-gray-500 hover:text-gray-700' ?> clickable">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            
            <div class="space-y-6">
                <div class="<?= $temaAtual === 'dark' ? 'bg-green-500/10 border-green-500/20' : 'bg-green-50 border-green-100' ?> border rounded-lg p-4">
                    <div class="flex items-start">
                        <i class="fas fa-check-circle <?= $temaAtual === 'dark' ? 'text-green-400' : 'text-green-500' ?> mt-1 mr-3"></i>
                        <div>
                            <h4 class="font-medium <?= $temaAtual === 'dark' ? 'text-white' : 'text-green-900' ?>">✅ Senha resetada com sucesso!</h4>
                            <p class="text-sm <?= $temaAtual === 'dark' ? 'text-white/70' : 'text-green-700' ?> mt-1">
                                A nova senha foi gerada com sucesso.
                            </p>
                        </div>
                    </div>
                </div>
                
                <div>
                    <label class="block text-sm font-medium <?= $temaAtual === 'dark' ? 'text-white/90' : 'text-gray-900' ?> mb-2">Nova Senha</label>
                    <div class="relative">
                        <input type="text" id="novaSenhaExibida" readonly
                               class="w-full input-modern rounded-lg h-11 font-mono text-lg tracking-wider text-center">
                        <button type="button" onclick="copiarNovaSenha()" class="absolute right-3 top-1/2 transform -translate-y-1/2">
                            <i class="fas fa-copy <?= $temaAtual === 'dark' ? 'text-white/50 hover:text-white' : 'text-gray-500 hover:text-gray-700' ?>"></i>
                        </button>
                    </div>
                </div>
                
                <div class="space-y-3 <?= $temaAtual === 'dark' ? 'bg-yellow-500/10' : 'bg-yellow-50' ?> p-4 rounded-lg">
                    <h5 class="font-medium <?= $temaAtual === 'dark' ? 'text-white' : 'text-yellow-900' ?>">⚠️ IMPORTANTE:</h5>
                    <div class="space-y-2">
                        <div class="flex items-start">
                            <i class="fas fa-flag <?= $temaAtual === 'dark' ? 'text-yellow-400' : 'text-yellow-600' ?> mt-0.5 mr-2 text-sm"></i>
                            <p class="text-sm <?= $temaAtual === 'dark' ? 'text-white/70' : 'text-yellow-700' ?>">Esta senha será mostrada apenas <span class="font-bold">UMA VEZ</span></p>
                        </div>
                        <div class="flex items-start">
                            <i class="fas fa-share-alt <?= $temaAtual === 'dark' ? 'text-yellow-400' : 'text-yellow-600' ?> mt-0.5 mr-2 text-sm"></i>
                            <p class="text-sm <?= $temaAtual === 'dark' ? 'text-white/70' : 'text-yellow-700' ?>">Compartilhe esta senha com o usuário imediatamente</p>
                        </div>
                        <div class="flex items-start">
                            <i class="fas fa-sync-alt <?= $temaAtual === 'dark' ? 'text-yellow-400' : 'text-yellow-600' ?> mt-0.5 mr-2 text-sm"></i>
                            <p class="text-sm <?= $temaAtual === 'dark' ? 'text-white/70' : 'text-yellow-700' ?>">Recomende que o usuário altere a senha após o primeiro login</p>
                        </div>
                    </div>
                </div>
                
                <div class="flex justify-end space-x-3 mt-6 pt-6 border-t <?= $temaAtual === 'dark' ? 'border-white/10' : 'border-gray-200' ?>">
                    <button type="button" onclick="fecharModalNovaSenha()"
                            class="px-4 py-2 <?= $temaAtual === 'dark' ? 'bg-blue-500 hover:bg-blue-600' : 'bg-blue-500 hover:bg-blue-600' ?> text-white rounded-lg clickable transition-colors flex items-center">
                        <i class="fas fa-check mr-2"></i>Entendi
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// Variáveis globais
let allRows = [];
let visibleRows = [];
let currentPage = 1;
const itensPorPagina = 10;
let usuarioParaAcao = null;
let novaSenhaGerada = null;

// Função auxiliar para mostrar toast com tempo estendido
function mostrarToastExtendido(tipo, titulo, mensagem, duracao = 10000) {
    const toastContainer = document.createElement('div');
    toastContainer.className = `toast-notification ${tipo}`;
    
    toastContainer.innerHTML = `
        <div class="p-4">
            <div class="flex items-start">
                <div class="flex-shrink-0 pt-0.5">
                    <i class="fas ${tipo === 'success' ? 'fa-check-circle' : tipo === 'error' ? 'fa-times-circle' : tipo === 'warning' ? 'fa-exclamation-triangle' : 'fa-info-circle'} text-xl"></i>
                </div>
                <div class="ml-3 flex-1">
                    <h4 class="font-semibold text-white">${titulo}</h4>
                    <p class="text-sm text-white/90 mt-1">${mensagem}</p>
                </div>
                <button onclick="this.parentElement.parentElement.remove()" class="ml-4 text-white/70 hover:text-white">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        </div>
        <div class="toast-progress" style="animation-duration: ${duracao}ms;"></div>
    `;
    
    document.body.appendChild(toastContainer);
    
    setTimeout(() => {
        if (toastContainer.parentElement) {
            toastContainer.classList.add('hiding');
            setTimeout(() => toastContainer.remove(), 500);
        }
    }, duracao);
}

document.addEventListener('DOMContentLoaded', function() {
    allRows = Array.from(document.querySelectorAll('#tabelaUsuarios tbody tr.table-row'));
    filtrarUsuarios();
    
    // Adicionar event listener para fechar modais com ESC
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            fecharTodosModais();
        }
    });
});

function filtrarUsuarios() {
    const filtroTipo = document.getElementById('filtroTipo').value.toLowerCase();
    const filtroMFA = document.getElementById('filtroMFA').value;
    const filtroAtivo = document.getElementById('filtroAtivo').value;
    const filtroBusca = document.getElementById('filtroBusca').value.toLowerCase().trim();

    visibleRows = allRows.filter(row => {
        const tipo = row.dataset.tipo.toLowerCase();
        const mfa = row.dataset.mfa;
        const ativo = row.dataset.ativo;
        const nome = row.dataset.nome;
        const email = row.dataset.email;

        if (filtroTipo && tipo !== filtroTipo) return false;
        if (filtroMFA && mfa !== filtroMFA) return false;
        if (filtroAtivo !== '' && ativo !== filtroAtivo) return false;
        if (filtroBusca && !(nome.includes(filtroBusca) || email.includes(filtroBusca))) return false;

        return true;
    });

    // Atualizar contador
    const contador = document.getElementById('contadorUsuarios');
    if (contador) {
        contador.textContent = visibleRows.length;
    }

    // Mostrar/ocultar linhas
    allRows.forEach(row => row.style.display = 'none');
    visibleRows.forEach(row => row.style.display = '');
}

// Funções para abrir/fechar modais
function abrirModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.remove('hidden');
        modal.classList.add('active');
        document.body.style.overflow = 'hidden';
    }
}

function fecharModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.remove('active');
        modal.classList.add('hidden');
        document.body.style.overflow = 'auto';
    }
}

function fecharTodosModais() {
    const modais = document.querySelectorAll('.modal-overlay');
    modais.forEach(modal => {
        modal.classList.remove('active');
        modal.classList.add('hidden');
    });
    document.body.style.overflow = 'auto';
}

// Funções para abrir modais específicos
function abrirModalNovoUsuario() {
    abrirModal('modalNovoUsuario');
}

function abrirModalEditarUsuario() {
    abrirModal('modalEditarUsuario');
}

function abrirModalDetalhesUsuario() {
    abrirModal('modalDetalhesUsuario');
}

function abrirModalBloquearUsuario(idUsuario) {
    usuarioParaAcao = idUsuario;
    abrirModal('modalConfirmarBloquear');
}

function abrirModalDesbloquearUsuario(idUsuario) {
    usuarioParaAcao = idUsuario;
    abrirModal('modalConfirmarDesbloquear');
}

function abrirModalAtivarUsuario(idUsuario) {
    usuarioParaAcao = idUsuario;
    abrirModal('modalConfirmarAtivar');
}

function abrirModalDesativarUsuario(idUsuario) {
    usuarioParaAcao = idUsuario;
    abrirModal('modalConfirmarDesativar');
}

function abrirModalResetarSenha(idUsuario) {
    usuarioParaAcao = idUsuario;
    abrirModal('modalConfirmarResetarSenha');
}

function abrirModalExcluirUsuario(idUsuario) {
    usuarioParaAcao = idUsuario;
    abrirModal('modalConfirmarExcluir');
}

function fecharModalNovaSenha() {
    fecharModal('modalNovaSenha');
    location.reload();
}

function copiarNovaSenha() {
    const senhaInput = document.getElementById('novaSenhaExibida');
    if (senhaInput && novaSenhaGerada) {
        navigator.clipboard.writeText(novaSenhaGerada).then(() => {
            mostrarToastExtendido('success', 'Copiado!', 'Senha copiada para a área de transferência.', 3000);
        });
    }
}

// Funções de confirmação
function bloquearUsuarioConfirmado() {
    if (!usuarioParaAcao) return;
    
    fecharModal('modalConfirmarBloquear');
    executarAcaoUsuario('bloquear');
}

function desbloquearUsuarioConfirmado() {
    if (!usuarioParaAcao) return;
    
    fecharModal('modalConfirmarDesbloquear');
    executarAcaoUsuario('desbloquear');
}

function ativarUsuarioConfirmado() {
    if (!usuarioParaAcao) return;
    
    fecharModal('modalConfirmarAtivar');
    executarAcaoUsuario('ativar');
}

function desativarUsuarioConfirmado() {
    if (!usuarioParaAcao) return;
    
    fecharModal('modalConfirmarDesativar');
    executarAcaoUsuario('desativar');
}

function resetarSenhaConfirmado() {
    if (!usuarioParaAcao) return;
    
    fecharModal('modalConfirmarResetarSenha');
    executarAcaoUsuario('resetar_senha');
}

function excluirUsuarioConfirmado() {
    if (!usuarioParaAcao) return;
    
    fecharModal('modalConfirmarExcluir');
    executarAcaoUsuario('excluir');
}

// Função principal para executar ações
async function executarAcaoUsuario(acao) {
    try {
        let url = '';
        
        switch(acao) {
            case 'bloquear':
            case 'desbloquear':
            case 'ativar':
            case 'desativar':
                url = `ajax/funcoes-usuarios.php?acao=${acao}&id=${usuarioParaAcao}`;
                break;
            case 'resetar_senha':
                url = `ajax/gerar_nova_senha.php?id=${usuarioParaAcao}`;
                break;
            case 'excluir':
                url = `ajax/excluir_usuario.php?id=${usuarioParaAcao}`;
                break;
            default:
                return;
        }
        
        const response = await fetch(url);
        const data = await response.json();
        
        if (data.success) {
            if (acao === 'resetar_senha' && data.nova_senha) {
                novaSenhaGerada = data.nova_senha;
                document.getElementById('novaSenhaExibida').value = novaSenhaGerada;
                abrirModal('modalNovaSenha');
            } else {
                mostrarToastExtendido('success', 'Sucesso', getMensagemSucesso(acao));
                setTimeout(() => location.reload(), 1500);
            }
        } else {
            mostrarToastExtendido('error', 'Erro', data.error || 'Erro ao executar ação');
        }
    } catch (error) {
        console.error('Erro:', error);
        mostrarToastExtendido('error', 'Erro', 'Erro ao conectar com o servidor');
    }
}

function getMensagemSucesso(acao) {
    const mensagens = {
        'bloquear': 'Usuário bloqueado com sucesso!',
        'desbloquear': 'Usuário desbloqueado com sucesso!',
        'ativar': 'Usuário ativado com sucesso!',
        'desativar': 'Usuário desativado com sucesso!',
        'excluir': 'Usuário excluído com sucesso!'
    };
    return mensagens[acao] || 'Ação realizada com sucesso!';
}

// Funções de CRUD
async function criarUsuario(event) {
    event.preventDefault();
    
    const form = event.target;
    const formData = new FormData(form);
    
    const senha = formData.get('senha');
    const confirmarSenha = formData.get('confirmar_senha');
    
    if (senha !== confirmarSenha) {
        mostrarToastExtendido('error', 'Erro', 'As senhas não coincidem!');
        return;
    }
    
    if (senha.length < 8) {
        mostrarToastExtendido('error', 'Erro', 'A senha deve ter pelo menos 8 caracteres!');
        return;
    }
    
    try {
        mostrarCarregamento();
        const response = await fetch('ajax/criar_usuario.php', {
            method: 'POST',
            body: formData
        });
        
        const data = await response.json();
        
        if (data.success) {
            mostrarToastExtendido('success', 'Sucesso', 'Usuário criado com sucesso!');
            fecharModal('modalNovoUsuario');
            form.reset();
            setTimeout(() => location.reload(), 1500);
        } else {
            mostrarToastExtendido('error', 'Erro', data.error || 'Erro ao criar usuário');
        }
    } catch (error) {
        console.error('Erro:', error);
        mostrarToastExtendido('error', 'Erro', 'Erro ao conectar com o servidor');
    } finally {
        esconderCarregamento();
    }
}

async function editarUsuario(idUsuario) {
    try {
        mostrarCarregamento();
        const response = await fetch(`ajax/detalhes_usuario.php?id=${idUsuario}`);
        const data = await response.json();
        
        if (data.success) {
            const usuario = data.usuario;
            document.getElementById('conteudoEditarUsuario').innerHTML = `
                <form id="formEditarUsuario" onsubmit="salvarEdicaoUsuario(event, ${idUsuario})">
                    <div class="space-y-4">
                        <div>
                            <label class="block text-sm font-medium <?= $temaAtual === 'dark' ? 'text-white/90' : 'text-gray-900' ?> mb-2">Nome Completo *</label>
                            <input type="text" name="nome_completo" value="${usuario.nome_completo}" required
                                   class="w-full input-modern rounded-lg h-11">
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium <?= $temaAtual === 'dark' ? 'text-white/90' : 'text-gray-900' ?> mb-2">Email *</label>
                            <input type="email" name="email" value="${usuario.email}" required
                                   class="w-full input-modern rounded-lg h-11">
                        </div>
                        
                        <div>
                            <label class="block text-sm font-medium <?= $temaAtual === 'dark' ? 'text-white/90' : 'text-gray-900' ?> mb-2">Tipo de Usuário *</label>
                            <select name="tipo_usuario" class="w-full input-modern rounded-lg h-11" required>
                                <option value="user" ${usuario.tipo_usuario === 'user' ? 'selected' : ''}>Usuário</option>
                                <option value="auditor" ${usuario.tipo_usuario === 'auditor' ? 'selected' : ''}>Auditor</option>
                                <option value="admin" ${usuario.tipo_usuario === 'admin' ? 'selected' : ''}>Administrador</option>
                            </select>
                        </div>
                        
                        <div class="flex items-center space-x-2">
                            <input type="checkbox" id="editarAtivo" name="ativo" ${usuario.ativo ? 'checked' : ''} class="rounded <?= $temaAtual === 'dark' ? 'accent-blue-500' : '' ?>">
                            <label for="editarAtivo" class="text-sm <?= $temaAtual === 'dark' ? 'text-white/90' : 'text-gray-900' ?>">Usuário ativo</label>
                        </div>
                        
                        <div class="mt-4 p-3 <?= $temaAtual === 'dark' ? 'bg-white/5' : 'bg-gray-50' ?> rounded-lg">
                            <p class="text-sm <?= $temaAtual === 'dark' ? 'text-white/70' : 'text-gray-600' ?> mb-2">Para alterar a senha, preencha os campos abaixo:</p>
                            <div class="grid grid-cols-2 gap-4">
                                <div>
                                    <label class="block text-sm font-medium <?= $temaAtual === 'dark' ? 'text-white/90' : 'text-gray-900' ?> mb-1">Nova Senha</label>
                                    <input type="password" name="nova_senha"
                                           class="w-full input-modern rounded-lg h-11"
                                           placeholder="Deixe em branco para não alterar"
                                           minlength="8">
                                </div>
                                <div>
                                    <label class="block text-sm font-medium <?= $temaAtual === 'dark' ? 'text-white/90' : 'text-gray-900' ?> mb-1">Confirmar Senha</label>
                                    <input type="password" name="confirmar_nova_senha"
                                           class="w-full input-modern rounded-lg h-11"
                                           minlength="8">
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="flex justify-end space-x-3 mt-6 pt-6 border-t <?= $temaAtual === 'dark' ? 'border-white/10' : 'border-gray-200' ?>">
                        <button type="button" onclick="fecharModal('modalEditarUsuario')"
                                class="px-4 py-2 <?= $temaAtual === 'dark' ? 'text-white/70 hover:text-white' : 'text-gray-700 hover:text-gray-900' ?> clickable">
                            Cancelar
                        </button>
                        <button type="submit"
                                class="px-4 py-2 btn-gradient rounded-lg clickable transition-colors flex items-center">
                            <i class="fas fa-save mr-2"></i>Salvar Alterações
                        </button>
                    </div>
                </form>
            `;
            
            abrirModalEditarUsuario();
        } else {
            mostrarToastExtendido('error', 'Erro', data.error || 'Erro ao carregar dados do usuário');
        }
    } catch (error) {
        console.error('Erro:', error);
        mostrarToastExtendido('error', 'Erro', 'Erro ao conectar com o servidor');
    } finally {
        esconderCarregamento();
    }
}

async function salvarEdicaoUsuario(event, idUsuario) {
    event.preventDefault();
    
    const form = event.target;
    const formData = new FormData(form);
    
    const novaSenha = formData.get('nova_senha');
    const confirmarSenha = formData.get('confirmar_nova_senha');
    
    if (novaSenha && novaSenha !== confirmarSenha) {
        mostrarToastExtendido('error', 'Erro', 'As novas senhas não coincidem!');
        return;
    }
    
    if (novaSenha && novaSenha.length < 8) {
        mostrarToastExtendido('error', 'Erro', 'A nova senha deve ter pelo menos 8 caracteres!');
        return;
    }
    
    try {
        mostrarCarregamento();
        const response = await fetch(`ajax/salvar_edicao_usuario.php?id=${idUsuario}`, {
            method: 'POST',
            body: formData
        });
        
        const data = await response.json();
        
        if (data.success) {
            mostrarToastExtendido('success', 'Sucesso', 'Usuário atualizado com sucesso!');
            fecharModal('modalEditarUsuario');
            setTimeout(() => location.reload(), 1500);
        } else {
            mostrarToastExtendido('error', 'Erro', data.error || 'Erro ao atualizar usuário');
        }
    } catch (error) {
        console.error('Erro:', error);
        mostrarToastExtendido('error', 'Erro', 'Erro ao conectar com o servidor');
    } finally {
        esconderCarregamento();
    }
}

async function verDetalhesUsuario(idUsuario) {
    try {
        mostrarCarregamento();
        const response = await fetch(`ajax/detalhes_usuario.php?id=${idUsuario}&detalhes=completo`);
        const data = await response.json();
        
        if (data.success) {
            const usuario = data.usuario;
            const sessoes = data.sessoes || [];
            const eventos = data.eventos || [];
            
            // Calcular hash do email para exibição
            const emailHash = await calcularHashEmail(usuario.email);
            
            let html = `
                <div class="space-y-6">
                    <div class="flex items-start space-x-4 p-4 <?= $temaAtual === 'dark' ? 'bg-white/5' : 'bg-gray-50' ?> rounded-lg">
                        <div class="w-16 h-16 rounded-full <?= $temaAtual === 'dark' ? 'bg-blue-500/20' : 'bg-blue-100' ?> flex items-center justify-center">
                            <span class="<?= $temaAtual === 'dark' ? 'text-blue-300' : 'text-blue-600' ?> font-bold text-2xl">
                                ${usuario.nome_completo ? usuario.nome_completo.charAt(0).toUpperCase() : 'U'}
                            </span>
                        </div>
                        <div class="flex-1">
                            <h4 class="text-lg font-semibold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?>">${usuario.nome_completo}</h4>
                            <div class="flex items-center mt-1">
                                <i class="fas fa-fingerprint <?= $temaAtual === 'dark' ? 'text-purple-400' : 'text-purple-600' ?> mr-2"></i>
                                <code class="text-sm font-mono <?= $temaAtual === 'dark' ? 'text-purple-300' : 'text-purple-700' ?>" title="SHA256 Hash do Email">
                                    ${emailHash}
                                </code>
                            </div>
                            <div class="flex flex-wrap gap-2 mt-2">
                                <span class="text-xs px-2 py-1 rounded-full ${usuario.tipo_usuario === 'admin' ? '<?= $temaAtual === 'dark' ? 'bg-purple-500/20 text-purple-300' : 'bg-purple-100 text-purple-800' ?>' : usuario.tipo_usuario === 'auditor' ? '<?= $temaAtual === 'dark' ? 'bg-blue-500/20 text-blue-300' : 'bg-blue-100 text-blue-800' ?>' : '<?= $temaAtual === 'dark' ? 'bg-white/10 text-white/90' : 'bg-gray-100 text-gray-800' ?>'}">
                                    ${usuario.tipo_usuario}
                                </span>
                                <span class="text-xs px-2 py-1 rounded-full ${usuario.ativo ? '<?= $temaAtual === 'dark' ? 'bg-green-500/20 text-green-300' : 'bg-green-100 text-green-800' ?>' : '<?= $temaAtual === 'dark' ? 'bg-red-500/20 text-red-300' : 'bg-red-100 text-red-800' ?>'}">
                                    ${usuario.ativo ? 'Ativo' : 'Inativo'}
                                </span>
                                <span class="text-xs px-2 py-1 rounded-full ${usuario.mfa_codigo_hash ? '<?= $temaAtual === 'dark' ? 'bg-green-500/20 text-green-300' : 'bg-green-100 text-green-800' ?>' : '<?= $temaAtual === 'dark' ? 'bg-white/10 text-white/90' : 'bg-gray-100 text-gray-800' ?>'}">
                                    MFA: ${usuario.mfa_codigo_hash ? 'Ativo' : 'Inativo'}
                                </span>
                            </div>
                        </div>
                    </div>
                    
                    <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                        <div class="<?= $temaAtual === 'dark' ? 'bg-white/5' : 'bg-gray-50' ?> p-4 rounded-lg text-center">
                            <p class="text-xs <?= $temaAtual === 'dark' ? 'text-white/50' : 'text-gray-500' ?>">ID</p>
                            <p class="text-lg font-bold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?>">${usuario.id_usuario}</p>
                        </div>
                        <div class="<?= $temaAtual === 'dark' ? 'bg-white/5' : 'bg-gray-50' ?> p-4 rounded-lg text-center">
                            <p class="text-xs <?= $temaAtual === 'dark' ? 'text-white/50' : 'text-gray-500' ?>">Criado em</p>
                            <p class="text-lg font-bold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?>">${new Date(usuario.data_criacao).toLocaleDateString('pt-BR')}</p>
                        </div>
                        <div class="<?= $temaAtual === 'dark' ? 'bg-white/5' : 'bg-gray-50' ?> p-4 rounded-lg text-center">
                            <p class="text-xs <?= $temaAtual === 'dark' ? 'text-white/50' : 'text-gray-500' ?>">Último Login</p>
                            <p class="text-lg font-bold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?>">${usuario.data_ultimo_login ? new Date(usuario.data_ultimo_login).toLocaleString('pt-BR') : 'Nunca'}</p>
                        </div>
                        <div class="<?= $temaAtual === 'dark' ? 'bg-white/5' : 'bg-gray-50' ?> p-4 rounded-lg text-center">
                            <p class="text-xs <?= $temaAtual === 'dark' ? 'text-white/50' : 'text-gray-500' ?>">Tentativas Falhas</p>
                            <p class="text-lg font-bold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?>">${usuario.tentativas_falhas || 0}</p>
                        </div>
                    </div>
                    
                    <div class="<?= $temaAtual === 'dark' ? 'bg-white/5' : 'bg-gray-50' ?> p-4 rounded-lg">
                        <h5 class="text-sm font-medium <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?> mb-3">Informações Adicionais</h5>
                        <div class="grid grid-cols-2 gap-4 text-sm">
                            <div>
                                <p class="<?= $temaAtual === 'dark' ? 'text-white/50' : 'text-gray-600' ?>">Última Atividade</p>
                                <p class="<?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?>">${usuario.data_ultima_atividade ? new Date(usuario.data_ultima_atividade).toLocaleString('pt-BR') : 'Nenhuma'}</p>
                            </div>
                            <div>
                                <p class="<?= $temaAtual === 'dark' ? 'text-white/50' : 'text-gray-600' ?>">Último IP</p>
                                <p class="<?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?>">${usuario.ultimo_ip || 'N/A'}</p>
                            </div>
                            <div>
                                <p class="<?= $temaAtual === 'dark' ? 'text-white/50' : 'text-gray-600' ?>">Bloqueado até</p>
                                <p class="<?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?>">${usuario.bloqueado_ate ? new Date(usuario.bloqueado_ate).toLocaleString('pt-BR') : 'Não bloqueado'}</p>
                            </div>
                            <div>
                                <p class="<?= $temaAtual === 'dark' ? 'text-white/50' : 'text-gray-600' ?>">Total Eventos</p>
                                <p class="<?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?>">${eventos.length}</p>
                            </div>
                        </div>
                    </div>
                    
                    <div>
                        <h5 class="text-sm font-medium <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?> mb-2">Sessões Ativas (${sessoes.length})</h5>
                        ${sessoes.length > 0 ? 
                            `<div class="space-y-2 max-h-48 overflow-y-auto">
                                ${sessoes.map(sessao => `
                                    <div class="<?= $temaAtual === 'dark' ? 'bg-white/5' : 'bg-gray-50' ?> p-3 rounded-lg flex justify-between items-center">
                                        <div>
                                            <p class="text-xs <?= $temaAtual === 'dark' ? 'text-white/70' : 'text-gray-700' ?>">IP: ${sessao.ip}</p>
                                            <p class="text-xs <?= $temaAtual === 'dark' ? 'text-white/50' : 'text-gray-600' ?>">Início: ${new Date(sessao.data_inicio).toLocaleString('pt-BR')}</p>
                                        </div>
                                        <button type="button" onclick="abrirModalEncerrarSessao('${sessao.token_sessao}', ${usuario.id_usuario})" 
                                                class="px-3 py-1 text-xs <?= $temaAtual === 'dark' ? 'bg-red-500/20 text-red-300 hover:bg-red-500/30' : 'bg-red-100 text-red-700 hover:bg-red-200' ?> rounded clickable transition-colors">
                                            Encerrar
                                        </button>
                                    </div>
                                `).join('')}
                            </div>` : 
                            '<p class="text-sm <?= $temaAtual === 'dark' ? 'text-white/50' : 'text-gray-500' ?> italic">Nenhuma sessão ativa</p>'
                        }
                    </div>
                    
                    <div>
                        <h5 class="text-sm font-medium <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?> mb-2">Últimos Eventos</h5>
                        ${eventos.length > 0 ? 
                            `<div class="space-y-2 max-h-40 overflow-y-auto">
                                ${eventos.map(evento => `
                                    <div class="<?= $temaAtual === 'dark' ? 'bg-white/5' : 'bg-gray-50' ?> p-3 rounded-lg">
                                        <div class="flex justify-between">
                                            <span class="<?= $temaAtual === 'dark' ? 'text-white/70' : 'text-gray-700' ?>">${evento.tipo_evento}</span>
                                            <span class="<?= $temaAtual === 'dark' ? 'text-white/50' : 'text-gray-500' ?> text-xs">${new Date(evento.data_hora).toLocaleDateString('pt-BR')}</span>
                                        </div>
                                        <p class="text-xs <?= $temaAtual === 'dark' ? 'text-white/50' : 'text-gray-500' ?> mt-1">IP: ${evento.ip_origem}</p>
                                    </div>
                                `).join('')}
                            </div>` : 
                            '<p class="text-sm <?= $temaAtual === 'dark' ? 'text-white/50' : 'text-gray-500' ?> italic">Nenhum evento registrado</p>'
                        }
                    </div>
                </div>
            `;
            
            document.getElementById('conteudoDetalhesUsuario').innerHTML = html;
            abrirModalDetalhesUsuario();
        } else {
            mostrarToastExtendido('error', 'Erro', data.error || 'Erro ao carregar detalhes do usuário');
        }
    } catch (error) {
        console.error('Erro:', error);
        mostrarToastExtendido('error', 'Erro', 'Erro ao conectar com o servidor');
    } finally {
        esconderCarregamento();
    }
}

// Função para calcular hash do email no cliente
async function calcularHashEmail(email) {
    // Usar SHA-256 para calcular o hash
    const msgBuffer = new TextEncoder().encode(email);
    const hashBuffer = await crypto.subtle.digest('SHA-256', msgBuffer);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
    return hashHex.substring(0, 16) + '...';
}

async function exportarUsuarios() {
    try {
        mostrarCarregamento();
        window.open('ajax/exportar_usuarios.php', '_blank');
    } catch (error) {
        mostrarToastExtendido('error', 'Erro', 'Erro ao exportar usuários');
    } finally {
        esconderCarregamento();
    }
}

// Modal para encerrar sessão
function abrirModalEncerrarSessao(tokenSessao, idUsuario) {
    // Criar modal dinâmico para confirmar encerramento de sessão
    const modalHtml = `
        <div id="modalEncerrarSessao" class="modal-overlay active" onclick="fecharModal('modalEncerrarSessao')">
            <div class="modal-content" style="max-width: 500px;" onclick="event.stopPropagation()">
                <div class="p-6">
                    <div class="flex items-center justify-between mb-6">
                        <div class="flex items-center space-x-3">
                            <div class="w-10 h-10 rounded-lg <?= $temaAtual === 'dark' ? 'bg-red-500/20' : 'bg-red-100' ?> flex items-center justify-center">
                                <i class="fas fa-sign-out-alt <?= $temaAtual === 'dark' ? 'text-red-400' : 'text-red-600' ?> text-lg"></i>
                            </div>
                            <h3 class="text-lg font-semibold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?>">Encerrar Sessão</h3>
                        </div>
                        <button type="button" onclick="fecharModal('modalEncerrarSessao')" class="<?= $temaAtual === 'dark' ? 'text-white/50 hover:text-white' : 'text-gray-500 hover:text-gray-700' ?> clickable">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                    
                    <div class="space-y-4">
                        <p class="<?= $temaAtual === 'dark' ? 'text-white/90' : 'text-gray-700' ?>">
                            Tem certeza que deseja encerrar esta sessão? O usuário será desconectado imediatamente.
                        </p>
                        
                        <div class="flex justify-end space-x-3 mt-6 pt-6 border-t <?= $temaAtual === 'dark' ? 'border-white/10' : 'border-gray-200' ?>">
                            <button type="button" onclick="fecharModal('modalEncerrarSessao')"
                                    class="px-4 py-2 <?= $temaAtual === 'dark' ? 'text-white/70 hover:text-white' : 'text-gray-700 hover:text-gray-900' ?> clickable">
                                Cancelar
                            </button>
                            <button type="button" onclick="encerrarSessaoConfirmado('${tokenSessao}', ${idUsuario})"
                                    class="px-4 py-2 <?= $temaAtual === 'dark' ? 'bg-red-500 hover:bg-red-600' : 'bg-red-500 hover:bg-red-600' ?> text-white rounded-lg clickable transition-colors flex items-center">
                                <i class="fas fa-sign-out-alt mr-2"></i>Encerrar Sessão
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    const modalContainer = document.createElement('div');
    modalContainer.innerHTML = modalHtml;
    document.body.appendChild(modalContainer);
    document.body.style.overflow = 'hidden';
}

async function encerrarSessaoConfirmado(tokenSessao, idUsuario) {
    try {
        mostrarCarregamento();
        const response = await fetch(`ajax/funcoes-usuarios.php?acao=encerrar_sessao&token=${tokenSessao}&id=${idUsuario}`);
        const data = await response.json();
        
        if (data.success) {
            fecharModal('modalEncerrarSessao');
            fecharModal('modalDetalhesUsuario');
            mostrarToastExtendido('success', 'Sucesso', 'Sessão encerrada com sucesso!');
            setTimeout(() => location.reload(), 1500);
        } else {
            mostrarToastExtendido('error', 'Erro', data.error || 'Erro ao encerrar sessão');
        }
    } catch (error) {
        mostrarToastExtendido('error', 'Erro', 'Erro ao conectar com o servidor');
    } finally {
        esconderCarregamento();
    }
}

// Funções de carregamento
function mostrarCarregamento() {
    const loadingOverlay = document.createElement('div');
    loadingOverlay.id = 'loading-overlay';
    loadingOverlay.className = 'fixed inset-0 bg-black/50 flex items-center justify-center z-50';
    loadingOverlay.innerHTML = `
        <div class="bg-gray-800 rounded-lg p-6 flex flex-col items-center">
            <div class="loader mb-4"></div>
            <p class="text-white">Processando...</p>
        </div>
    `;
    document.body.appendChild(loadingOverlay);
    document.body.style.cursor = 'wait';
}

function esconderCarregamento() {
    const loadingOverlay = document.getElementById('loading-overlay');
    if (loadingOverlay) {
        loadingOverlay.remove();
    }
    document.body.style.cursor = 'default';
}
</script>

<style>
/* Estilos para os modais */
.modal-overlay {
    position: fixed;
    inset: 0;
    background: rgba(0, 0, 0, 0.75);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 9998;
    opacity: 0;
    visibility: hidden;
    transition: all 0.3s ease;
}

.modal-overlay.active {
    opacity: 1;
    visibility: visible;
}

.modal-content {
    background: <?= $temaAtual === 'dark' ? '#1f2937' : '#ffffff' ?>;
    border-radius: 0.75rem;
    box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
    animation: modalSlideIn 0.3s ease-out;
    max-width: 90vw;
    max-height: 90vh;
    overflow-y: auto;
}

@keyframes modalSlideIn {
    from {
        transform: translateY(-20px);
        opacity: 0;
    }
    to {
        transform: translateY(0);
        opacity: 1;
    }
}

/* Estilos para inputs nos modais */
.input-modern {
    background: <?= $temaAtual === 'dark' ? 'rgba(255, 255, 255, 0.05)' : '#f9fafb' ?>;
    border: 1px solid <?= $temaAtual === 'dark' ? 'rgba(255, 255, 255, 0.1)' : '#e5e7eb' ?>;
    color: <?= $temaAtual === 'dark' ? '#ffffff' : '#111827' ?>;
    transition: all 0.2s ease;
}

.input-modern:focus {
    outline: none;
    border-color: #3b82f6;
    box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
}

/* Estilos para botões nos modais */
.btn-gradient {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    border: none;
}

.btn-gradient:hover {
    background: linear-gradient(135deg, #5a6fd8 0%, #6a4190 100%);
    transform: translateY(-1px);
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
}

/* Estilos para cards */
.card {
    background: <?= $temaAtual === 'dark' ? 'rgba(255, 255, 255, 0.03)' : '#ffffff' ?>;
    border: 1px solid <?= $temaAtual === 'dark' ? 'rgba(255, 255, 255, 0.1)' : '#e5e7eb' ?>;
    border-radius: 0.75rem;
    box-shadow: <?= $temaAtual === 'dark' ? '0 4px 6px rgba(0, 0, 0, 0.2)' : '0 1px 3px rgba(0, 0, 0, 0.1)' ?>;
}

/* Estilo para clickable elements */
.clickable {
    cursor: pointer;
    user-select: none;
}

.clickable:active {
    transform: scale(0.98);
}

/* Estilo para código de hash */
code {
    font-family: 'Consolas', 'Monaco', 'Courier New', monospace;
    background: <?= $temaAtual === 'dark' ? 'rgba(0, 0, 0, 0.3)' : '#f3f4f6' ?>;
    padding: 2px 6px;
    border-radius: 4px;
    font-size: 0.9em;
}

/* Toast notifications */
.toast-notification {
    position: fixed;
    top: 1rem;
    right: 1rem;
    z-index: 9999;
    min-width: 300px;
    max-width: 400px;
    background: #1f2937;
    border-radius: 0.5rem;
    overflow: hidden;
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.3);
    animation: slideIn 0.3s ease-out;
    border-left: 4px solid;
}

.toast-notification.success {
    border-left-color: #10b981;
}

.toast-notification.error {
    border-left-color: #ef4444;
}

.toast-notification.warning {
    border-left-color: #f59e0b;
}

.toast-notification.info {
    border-left-color: #3b82f6;
}

.toast-notification.hiding {
    animation: slideOut 0.3s ease-in forwards;
}

.toast-progress {
    height: 3px;
    background: currentColor;
    width: 100%;
    animation: progress linear;
}

@keyframes slideIn {
    from {
        transform: translateX(100%);
        opacity: 0;
    }
    to {
        transform: translateX(0);
        opacity: 1;
    }
}

@keyframes slideOut {
    from {
        transform: translateX(0);
        opacity: 1;
    }
    to {
        transform: translateX(100%);
        opacity: 0;
    }
}

@keyframes progress {
    from {
        width: 100%;
    }
    to {
        width: 0%;
    }
}

/* Loader */
.loader {
    border: 4px solid rgba(255, 255, 255, 0.3);
    border-radius: 50%;
    border-top: 4px solid #3b82f6;
    width: 40px;
    height: 40px;
    animation: spin 1s linear infinite;
}

@keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
}
</style>