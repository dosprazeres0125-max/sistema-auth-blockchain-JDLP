<?php
session_start();
require_once 'includes/config.php';
require_once 'includes/funcoes-seguranca.php';

error_log("[LOGOUT] ========== INICIANDO LOGOUT ==========");

// Registrar evento de logout se usuário estiver logado
if (isset($_SESSION['id_usuario']) && !empty($_SESSION['id_usuario'])) {
    try {
        $conn = conectarBancoDados();
        
        // Remover sessão ativa do banco
        if (isset($_SESSION['id_sessao'])) {
            $stmt = $conn->prepare("DELETE FROM sessoes_ativas WHERE id_sessao = ?");
            $stmt->execute([$_SESSION['id_sessao']]);
        }
        
        // Registrar evento de logout
        registrarEventoBlockchain('LOGOUT', $_SESSION['id_usuario'], $_SESSION['email'], obterIPCliente(), $_SERVER['HTTP_USER_AGENT'] ?? '');
        
        error_log("[LOGOUT] Logout realizado para usuário: " . $_SESSION['id_usuario']);
        
    } catch (Exception $e) {
        error_log("[LOGOUT] Erro ao processar logout: " . $e->getMessage());
    }
}

// Destruir sessão
session_unset();
session_destroy();

// Redirecionar para index com mensagem
$_SESSION['flash_mensagens'] = [[
    'tipo' => 'success',
    'titulo' => 'Logout realizado',
    'mensagem' => 'Você saiu do sistema com sucesso.'
]];

error_log("[LOGOUT] Redirecionando para index.php");
header("Location: index.php");
exit;
?>