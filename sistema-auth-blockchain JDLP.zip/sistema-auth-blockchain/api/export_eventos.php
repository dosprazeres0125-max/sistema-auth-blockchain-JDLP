<?php
require_once '../includes/config.php';
require_once '../includes/funcoes-seguranca.php';

// Verificar autenticação
if (!isset($_SESSION['id_usuario'])) {
    http_response_code(401);
    exit;
}

// Verificar permissões - apenas admin/auditor pode exportar
$stmt = $pdo->prepare("SELECT tipo_usuario FROM usuarios WHERE id_usuario = ?");
$stmt->execute([$_SESSION['id_usuario']]);
$usuario = $stmt->fetch(PDO::FETCH_ASSOC);

if (!in_array($usuario['tipo_usuario'], ['admin', 'auditor'])) {
    http_response_code(403);
    exit;
}

// Parâmetros de filtro (mesmos da página)
$filtros = [
    'tipo' => $_GET['tipo'] ?? '',
    'usuario' => $_GET['usuario'] ?? '',
    'data_inicio' => $_GET['data_inicio'] ?? '',
    'data_fim' => $_GET['data_fim'] ?? '',
    'ip' => $_GET['ip'] ?? '',
    'search' => $_GET['search'] ?? ''
];

// Construir query base (similar à página de eventos)
$whereConditions = [];
$params = [];
$paramTypes = [];

// Aplicar filtros
if (!empty($filtros['tipo'])) {
    $whereConditions[] = "re.tipo_evento LIKE ?";
    $params[] = '%' . $filtros['tipo'] . '%';
    $paramTypes[] = PDO::PARAM_STR;
}

if (!empty($filtros['usuario']) && is_numeric($filtros['usuario'])) {
    $whereConditions[] = "re.id_usuario = ?";
    $params[] = $filtros['usuario'];
    $paramTypes[] = PDO::PARAM_INT;
}

if (!empty($filtros['data_inicio'])) {
    $whereConditions[] = "re.data_hora >= ?";
    $params[] = $filtros['data_inicio'] . ' 00:00:00';
    $paramTypes[] = PDO::PARAM_STR;
}

if (!empty($filtros['data_fim'])) {
    $whereConditions[] = "re.data_hora <= ?";
    $params[] = $filtros['data_fim'] . ' 23:59:59';
    $paramTypes[] = PDO::PARAM_STR;
}

if (!empty($filtros['ip'])) {
    $whereConditions[] = "re.ip_origem LIKE ?";
    $params[] = '%' . $filtros['ip'] . '%';
    $paramTypes[] = PDO::PARAM_STR;
}

if (!empty($filtros['search'])) {
    $searchTerm = '%' . $filtros['search'] . '%';
    $whereConditions[] = "(re.tipo_evento LIKE ? OR re.ip_origem LIKE ? OR u.nome_completo LIKE ? OR u.email LIKE ? OR re.hash_conteudo LIKE ?)";
    $params = array_merge($params, array_fill(0, 5, $searchTerm));
    $paramTypes = array_merge($paramTypes, array_fill(0, 5, PDO::PARAM_STR));
}

$whereClause = '';
if (!empty($whereConditions)) {
    $whereClause = 'WHERE ' . implode(' AND ', $whereConditions);
}

// Buscar eventos para exportação
$query = "
    SELECT 
        re.id_evento,
        re.tipo_evento,
        re.data_hora,
        u.nome_completo,
        u.email,
        u.tipo_usuario,
        re.ip_origem,
        re.user_agent,
        re.hash_conteudo,
        re.hash_transacao
    FROM registro_eventos re 
    LEFT JOIN usuarios u ON re.id_usuario = u.id_usuario 
    $whereClause
    ORDER BY re.data_hora DESC
";

try {
    $stmt = $pdo->prepare($query);
    foreach ($params as $i => $param) {
        $stmt->bindValue($i + 1, $param, $paramTypes[$i]);
    }
    $stmt->execute();
    $eventos = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Configurar headers para download CSV
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=eventos_' . date('Y-m-d') . '.csv');
    
    // Criar output stream
    $output = fopen('php://output', 'w');
    
    // Escrever cabeçalho
    fputcsv($output, [
        'ID',
        'Tipo Evento',
        'Data/Hora',
        'Usuário',
        'Email',
        'Tipo Usuário',
        'IP Origem',
        'User Agent',
        'Hash Conteúdo',
        'Hash Transação'
    ], ';');
    
    // Escrever dados
    foreach ($eventos as $evento) {
        fputcsv($output, [
            $evento['id_evento'],
            $evento['tipo_evento'],
            $evento['data_hora'],
            $evento['nome_completo'] ?? 'Sistema',
            $evento['email'] ?? 'N/A',
            $evento['tipo_usuario'] ?? 'Sistema',
            $evento['ip_origem'],
            $evento['user_agent'] ?? '',
            $evento['hash_conteudo'],
            $evento['hash_transacao'] ?? ''
        ], ';');
    }
    
    fclose($output);
    
} catch (Exception $e) {
    error_log("Erro ao exportar eventos: " . $e->getMessage());
    http_response_code(500);
    echo "Erro ao exportar eventos.";
}
?>