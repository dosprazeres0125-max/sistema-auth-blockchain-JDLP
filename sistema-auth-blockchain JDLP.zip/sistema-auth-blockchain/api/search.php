<?php
require_once '../includes/config.php';
require_once '../includes/funcoes-seguranca.php';

// Verificar autenticação
header('Content-Type: application/json');

if (!isset($_SESSION['id_usuario'])) {
    echo json_encode(['success' => false, 'message' => 'Não autorizado']);
    exit;
}

// Verificar se foi passada a query de busca
if (!isset($_GET['q']) || empty(trim($_GET['q']))) {
    echo json_encode(['success' => false, 'message' => 'Query de busca vazia']);
    exit;
}

$query = trim($_GET['q']);
$searchTerm = '%' . $query . '%';

try {
    // Buscar usuários
    $stmt = $pdo->prepare("
        SELECT 
            id_usuario,
            nome_completo,
            email,
            tipo_usuario,
            DATE_FORMAT(data_criacao, '%d/%m/%Y') as data_criacao_formatada
        FROM usuarios 
        WHERE 
            nome_completo LIKE ? OR 
            email LIKE ? OR
            tipo_usuario LIKE ?
        ORDER BY 
            CASE 
                WHEN nome_completo LIKE ? THEN 1
                WHEN email LIKE ? THEN 2
                ELSE 3
            END
        LIMIT 10
    ");
    
    $stmt->execute([
        $searchTerm,
        $searchTerm,
        $searchTerm,
        $searchTerm,
        $searchTerm
    ]);
    
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if ($results) {
        echo json_encode([
            'success' => true,
            'results' => $results,
            'count' => count($results)
        ]);
    } else {
        // Buscar eventos também
        $stmt = $pdo->prepare("
            SELECT DISTINCT
                'evento' as tipo,
                CONCAT('Evento: ', tipo_evento) as nome_completo,
                DATE_FORMAT(data_hora, '%d/%m/%Y %H:%i') as descricao,
                NULL as email,
                NULL as tipo_usuario
            FROM registro_eventos 
            WHERE tipo_evento LIKE ?
            LIMIT 5
        ");
        
        $stmt->execute([$searchTerm]);
        $eventResults = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        if ($eventResults) {
            echo json_encode([
                'success' => true,
                'results' => $eventResults,
                'count' => count($eventResults)
            ]);
        } else {
            echo json_encode([
                'success' => true,
                'results' => [],
                'count' => 0,
                'message' => 'Nenhum resultado encontrado'
            ]);
        }
    }
} catch (Exception $e) {
    error_log("Erro na busca: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'Erro interno do servidor'
    ]);
}
?>