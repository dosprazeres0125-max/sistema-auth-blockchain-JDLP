<?php
require_once '../includes/config.php';
require_once '../includes/funcoes-seguranca.php';

// Verificar autenticação
header('Content-Type: application/json');

if (!isset($_SESSION['id_usuario'])) {
    echo json_encode(['success' => false, 'message' => 'Não autorizado']);
    exit;
}

// Verificar se foi passado o ID do evento
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    echo json_encode(['success' => false, 'message' => 'ID inválido']);
    exit;
}

$eventoId = (int)$_GET['id'];

// Obter informações do usuário para verificar permissões
$stmt = $pdo->prepare("SELECT tipo_usuario FROM usuarios WHERE id_usuario = ?");
$stmt->execute([$_SESSION['id_usuario']]);
$usuario = $stmt->fetch(PDO::FETCH_ASSOC);

$podeVerTodos = in_array($usuario['tipo_usuario'], ['admin', 'auditor']);

try {
    // Buscar detalhes do evento
    $query = "
        SELECT 
            re.*,
            u.nome_completo,
            u.email,
            u.tipo_usuario
        FROM registro_eventos re 
        LEFT JOIN usuarios u ON re.id_usuario = u.id_usuario 
        WHERE re.id_evento = ?
    ";
    
    $params = [$eventoId];
    
    // Se não for admin/auditor, só pode ver seus próprios eventos
    if (!$podeVerTodos) {
        $query .= " AND re.id_usuario = ?";
        $params[] = $_SESSION['id_usuario'];
    }
    
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $evento = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($evento) {
        // Formatar dados para exibição
        $evento['data_hora'] = date('d/m/Y H:i:s', strtotime($evento['data_hora']));
        $evento['tipo_evento_formatado'] = ucfirst(str_replace('_', ' ', $evento['tipo_evento']));
        
        echo json_encode([
            'success' => true,
            'evento' => $evento
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Evento não encontrado ou acesso negado'
        ]);
    }
} catch (Exception $e) {
    error_log("Erro ao buscar evento: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'Erro interno do servidor'
    ]);
}
?>