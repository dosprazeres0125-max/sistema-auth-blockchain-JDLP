# Sistema Auth Blockchain 
Sistema básico de autenticação em PHP com foco em segurança. 
