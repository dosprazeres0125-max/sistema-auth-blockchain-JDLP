<?php
// Incluir configuração e conectar ao banco
require_once __DIR__ . '/../includes/config.php';
$pdo = conectarBancoDados();  // <--- Esta linha resolve o erro de $pdo undefined

$hash = $_GET['hash_transacao'] ?? '';
if (!$hash) {
    echo '<p class="text-red-400 text-center">Hash não informado.</p>';
    exit;
}

$stmt = $pdo->prepare("
    SELECT 
        re.*, 
        bb.*, 
        u.nome_completo, 
        u.email 
    FROM registro_eventos re 
    LEFT JOIN blocos_blockchain bb ON re.bloco_hash = bb.bloco_hash
    LEFT JOIN usuarios u ON re.id_usuario = u.id_usuario
    WHERE re.hash_transacao = ?
");
$stmt->execute([$hash]);
$trans = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$trans) {
    echo '<div class="text-red-400 text-center text-lg font-semibold">Transação não encontrada na blockchain.</div>';
    exit;
}

// Resolução de usuário para tentativas falhas (via email_hash)
if (empty($trans['id_usuario']) && !empty($trans['email_hash'])) {
    $stmtUser = $pdo->prepare("SELECT nome_completo, email FROM usuarios WHERE email_hash = ?");
    $stmtUser->execute([$trans['email_hash']]);
    $userFalha = $stmtUser->fetch(PDO::FETCH_ASSOC);
    if ($userFalha) {
        $trans['nome_completo'] = $userFalha['nome_completo'] . ' (falha)';
        $trans['email'] = $userFalha['email'];
    } else {
        $trans['nome_completo'] = 'Email desconhecido';
        $trans['email'] = 'Hash: ' . substr($trans['email_hash'], 0, 20) . '...';
    }
}

echo '<div class="text-green-400 font-semibold text-center text-xl mb-6">✓ Transação válida e imutável na blockchain!</div>';

echo '<div class="grid grid-cols-1 md:grid-cols-2 gap-6 text-sm">';

echo '<div class="space-y-3">';
echo '<div><strong>ID Evento:</strong> #' . htmlspecialchars($trans['id_evento']) . '</div>';
echo '<div><strong>Tipo:</strong> ' . htmlspecialchars($trans['tipo_evento'] ?? 'Desconhecido') . '</div>';
echo '<div><strong>Usuário:</strong> ' . htmlspecialchars($trans['nome_completo'] ?? 'Desconhecido') . '</div>';
echo '<div><strong>Email:</strong> ' . htmlspecialchars($trans['email'] ?? 'N/A') . '</div>';
echo '<div><strong>IP:</strong> ' . htmlspecialchars($trans['ip_origem']) . '</div>';
echo '<div><strong>Data/Hora:</strong> ' . $trans['data_hora'] . '</div>';
echo '</div>';

echo '<div class="space-y-3">';
echo '<div><strong>Bloco ID:</strong> ' . ($trans['id_bloco'] ?? 'N/A') . '</div>';
echo '<div><strong>Bloco Hash:</strong><br><code class="text-xs break-all">' . substr($trans['bloco_hash'] ?? '', 0, 40) . '...</code></div>';
echo '<div><strong>Merkle Root:</strong><br><code class="text-xs break-all">' . substr($trans['hash_merkle_root'] ?? '', 0, 40) . '...</code></div>';
echo '<div><strong>Nonce:</strong> ' . ($trans['nonce'] ?? 'N/A') . '</div>';
echo '<div><strong>Dificuldade:</strong> ' . ($trans['dificuldade'] ?? '1') . '</div>';
echo '<div><strong>Transações no Bloco:</strong> ' . ($trans['numero_transacoes'] ?? 'N/A') . '</div>';
echo '</div>';

echo '</div>';
?>