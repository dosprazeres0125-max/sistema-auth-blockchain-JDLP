<?php
session_start();
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/funcoes-seguranca.php';

header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['id_usuario']) || !in_array($_SESSION['tipo_usuario'], ['admin', 'auditor'])) {
    echo json_encode(['success' => false, 'error' => 'Permissão negada']);
    exit;
}

$id = (int)($_GET['id'] ?? 0);
$modo = $_GET['detalhes'] ?? 'basic'; // basic, full, edit

if ($id <= 0) {
    echo json_encode(['success' => false, 'error' => 'ID inválido']);
    exit;
}

$pdo = conectarBancoDados();

$stmt = $pdo->prepare("
    SELECT id_usuario, nome_completo, email, tipo_usuario, ativo, 
           tentativas_falhas, bloqueado_ate, data_criacao, data_ultimo_login,
           data_ultima_atividade, ultimo_ip, mfa_codigo_hash
    FROM usuarios 
    WHERE id_usuario = ?
");
$stmt->execute([$id]);
$usuario = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$usuario) {
    echo json_encode(['success' => false, 'error' => 'Usuário não encontrado']);
    exit;
}

$resposta = ['success' => true, 'usuario' => $usuario];

if ($modo === 'full' || $modo === 'edit') {
    // Sessões ativas
    $stmtSess = $pdo->prepare("
        SELECT id_sessao, ip, user_agent, data_inicio, data_ultima_atividade, expiracao, token_sessao
        FROM sessoes_ativas 
        WHERE id_usuario = ? AND expiracao > NOW()
        ORDER BY data_ultima_atividade DESC
    ");
    $stmtSess->execute([$id]);
    $resposta['sessoes'] = $stmtSess->fetchAll(PDO::FETCH_ASSOC);

    // Últimos eventos
    $stmtEv = $pdo->prepare("
        SELECT tipo_evento, ip_origem, user_agent, data_hora
        FROM registro_eventos 
        WHERE id_usuario = ?
        ORDER BY data_hora DESC LIMIT 10
    ");
    $stmtEv->execute([$id]);
    $resposta['eventos'] = $stmtEv->fetchAll(PDO::FETCH_ASSOC);
}

if ($modo === 'edit') {
    // Retorna apenas dados editáveis
    echo json_encode($resposta);
    exit;
}

// Para detalhes completos → retorna HTML renderizado
if ($modo === 'full') {
    ob_start();
    ?>
    <div class="space-y-6 text-gray-200">
        <div class="flex items-center space-x-4">
            <div class="w-20 h-20 rounded-full bg-gradient-to-br from-blue-600 to-indigo-700 flex items-center justify-center text-3xl font-bold text-white shadow-lg">
                <?= strtoupper(substr($usuario['nome_completo'] ?: 'U', 0, 1)) ?>
            </div>
            <div>
                <h2 class="text-2xl font-bold text-white"><?= htmlspecialchars($usuario['nome_completo']) ?></h2>
                <p class="text-blue-400"><?= htmlspecialchars($usuario['email']) ?></p>
                <div class="flex flex-wrap gap-2 mt-2">
                    <span class="px-3 py-1 text-xs rounded-full bg-purple-900/50 text-purple-300">
                        <?= ucfirst($usuario['tipo_usuario']) ?>
                    </span>
                    <span class="px-3 py-1 text-xs rounded-full <?= $usuario['ativo'] ? 'bg-green-900/50 text-green-300' : 'bg-red-900/50 text-red-300' ?>">
                        <?= $usuario['ativo'] ? 'Ativo' : 'Inativo' ?>
                    </span>
                    <span class="px-3 py-1 text-xs rounded-full <?= $usuario['mfa_codigo_hash'] ? 'bg-green-900/50 text-green-300' : 'bg-gray-700/50 text-gray-300' ?>">
                        MFA: <?= $usuario['mfa_codigo_hash'] ? 'Ativo' : 'Inativo' ?>
                    </span>
                </div>
            </div>
        </div>

        <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div class="bg-gray-800/50 p-4 rounded-lg">
                <p class="text-xs text-gray-400">ID</p>
                <p class="text-lg font-bold text-white"><?= $usuario['id_usuario'] ?></p>
            </div>
            <div class="bg-gray-800/50 p-4 rounded-lg">
                <p class="text-xs text-gray-400">Criado em</p>
                <p class="text-lg font-bold text-white"><?= date('d/m/Y H:i', strtotime($usuario['data_criacao'])) ?></p>
            </div>
            <div class="bg-gray-800/50 p-4 rounded-lg">
                <p class="text-xs text-gray-400">Último Login</p>
                <p class="text-lg font-bold text-white"><?= $usuario['data_ultimo_login'] ? date('d/m H:i', strtotime($usuario['data_ultimo_login'])) : 'Nunca' ?></p>
            </div>
            <div class="bg-gray-800/50 p-4 rounded-lg">
                <p class="text-xs text-gray-400">Tentativas Falhas</p>
                <p class="text-lg font-bold <?= $usuario['tentativas_falhas'] > 0 ? 'text-orange-400' : 'text-white' ?>">
                    <?= $usuario['tentativas_falhas'] ?>
                </p>
            </div>
        </div>

        <?php if (!empty($resposta['sessoes'])): ?>
        <div>
            <h3 class="text-lg font-semibold text-white mb-3">Sessões Ativas (<?= count($resposta['sessoes']) ?>)</h3>
            <div class="space-y-3 max-h-60 overflow-y-auto">
                <?php foreach ($resposta['sessoes'] as $sessao): ?>
                <div class="bg-gray-800/40 p-4 rounded-lg border border-gray-700">
                    <div class="flex justify-between items-start">
                        <div>
                            <p class="text-sm text-gray-300">IP: <strong><?= htmlspecialchars($sessao['ip']) ?></strong></p>
                            <p class="text-xs text-gray-500 mt-1">
                                Início: <?= date('d/m/Y H:i', strtotime($sessao['data_inicio'])) ?>
                            </p>
                            <p class="text-xs text-gray-500">
                                Última atividade: <?= date('d/m/Y H:i', strtotime($sessao['data_ultima_atividade'])) ?>
                            </p>
                        </div>
                        <button onclick="encerrarSessao('<?= htmlspecialchars($sessao['token_sessao']) ?>', <?= $usuario['id_usuario'] ?>)"
                                class="px-3 py-1 bg-red-600/80 hover:bg-red-700 text-white text-sm rounded transition-colors">
                            Encerrar
                        </button>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

        <?php if (!empty($resposta['eventos'])): ?>
        <div>
            <h3 class="text-lg font-semibold text-white mb-3">Últimos Eventos</h3>
            <div class="space-y-2 max-h-60 overflow-y-auto">
                <?php foreach ($resposta['eventos'] as $evento): ?>
                <div class="bg-gray-800/30 p-3 rounded-lg text-sm">
                    <div class="flex justify-between">
                        <span class="font-medium <?= strpos($evento['tipo_evento'], 'FAILED') !== false ? 'text-red-400' : 'text-green-400' ?>">
                            <?= htmlspecialchars($evento['tipo_evento']) ?>
                        </span>
                        <span class="text-gray-500 text-xs">
                            <?= date('d/m H:i', strtotime($evento['data_hora'])) ?>
                        </span>
                    </div>
                    <p class="text-gray-400 text-xs mt-1">IP: <?= htmlspecialchars($evento['ip_origem']) ?></p>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>
    </div>
    <?php
    $html = ob_get_clean();
    echo $html;
    exit;
}

echo json_encode($resposta);
exit;