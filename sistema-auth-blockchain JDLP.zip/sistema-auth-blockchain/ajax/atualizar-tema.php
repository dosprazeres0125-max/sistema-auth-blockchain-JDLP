<?php
// ajax/atualizar-tema.php
session_start();
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    $tema = $data['tema'] ?? 'light';
    
    // Validar tema
    if (in_array($tema, ['light', 'dark'])) {
        $_SESSION['tema'] = $tema;
        echo json_encode(['success' => true, 'tema' => $tema]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Tema inválido']);
    }
    exit;
}
?>