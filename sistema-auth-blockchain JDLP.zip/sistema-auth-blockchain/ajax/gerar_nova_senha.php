<?php
session_start();
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/funcoes-seguranca.php';

header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['id_usuario']) || $_SESSION['tipo_usuario'] !== 'admin') {
    echo json_encode(['success' => false, 'error' => 'Permissão negada']);
    exit;
}

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    echo json_encode(['success' => false, 'error' => 'ID inválido']);
    exit;
}

$pdo = conectarBancoDados();

// Gerar senha aleatória forte
$novaSenha = bin2hex(random_bytes(8)); // 16 caracteres hex
$senhaHash = password_hash($novaSenha, PASSWORD_DEFAULT);

try {
    $stmt = $pdo->prepare("UPDATE usuarios SET senha_hash = ? WHERE id_usuario = ?");
    $stmt->execute([$senhaHash, $id]);

    registrarEventoBlockchain(
        'PASSWORD_RESET_ADMIN',
        $id,
        null,
        obterIPCliente(),
        $_SERVER['HTTP_USER_AGENT'] ?? 'desconhecido'
    );

    echo json_encode([
        'success' => true,
        'nova_senha' => $novaSenha
    ]);

} catch (Exception $e) {
    error_log("Erro ao resetar senha: " . $e->getMessage());
    echo json_encode(['success' => false, 'error' => 'Erro interno']);
}
exit;