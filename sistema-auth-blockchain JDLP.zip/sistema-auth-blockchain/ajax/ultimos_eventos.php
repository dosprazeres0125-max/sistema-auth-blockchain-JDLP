<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/funcoes-seguranca.php';

$pdo = conectarBancoDados();

$limite = isset($_GET['limite']) ? max(5, min(20, (int)$_GET['limite'])) : 8;

try {
    $stmt = $pdo->prepare("
        SELECT re.id_evento, re.tipo_evento, re.data_hora, re.ip_origem, re.email_hash, re.bloco_numero,
               u.nome_completo, u.email
        FROM registro_eventos re
        LEFT JOIN usuarios u ON re.id_usuario = u.id_usuario
        ORDER BY re.data_hora DESC
        LIMIT :lim
    ");
    $stmt->bindValue(':lim', $limite, PDO::PARAM_INT);
    $stmt->execute();
    $eventos = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode(['success' => true, 'eventos' => $eventos]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => 'Falha ao carregar eventos']);
}