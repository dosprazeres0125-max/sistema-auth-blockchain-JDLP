<?php
require_once '../includes/config.php';
require_once '../includes/funcoes-seguranca.php';

header('Content-Type: application/json');

if (!isset($_SESSION['id_usuario']) || empty($_SESSION['id_usuario'])) {
    echo json_encode(['success' => false, 'message' => 'Usuário não autenticado']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);
$acao = $data['acao'] ?? '';

$idUsuario = $_SESSION['id_usuario'];

try {
    $pdo = conectarBancoDados();
    
    if ($acao === 'encerrar_sessoes') {
        // Encerrar todas as sessões, exceto a atual
        $sessaoAtual = session_id();
        $hashSessaoAtual = hash('sha256', $sessaoAtual);
        
        $stmt = $pdo->prepare("DELETE FROM sessoes_ativas WHERE id_usuario = ? AND id_sessao != ?");
        $stmt->execute([$idUsuario, $hashSessaoAtual]);
        
        $sessoesEncerradas = $stmt->rowCount();
        
        // Registrar evento no blockchain
        $ipOrigem = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
        $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
        
        // Obter email do usuário
        $stmt = $pdo->prepare("SELECT email FROM usuarios WHERE id_usuario = ?");
        $stmt->execute([$idUsuario]);
        $email = $stmt->fetchColumn();
        
        // Registrar evento de encerramento de sessões
        $pdo->prepare("CALL registrar_evento_login('SESSOES_ENCERRADAS', ?, ?, ?, ?, ?)")
            ->execute([
                $idUsuario,
                $email,
                $ipOrigem,
                $userAgent,
                'SESSOES_ENCERRADAS'
            ]);
        
        // Registrar em logs de segurança
        $pdo->prepare("
            INSERT INTO logs_seguranca (tipo_log, id_usuario, severidade, descricao, ip_origem, user_agent) 
            VALUES (?, ?, ?, ?, ?, ?)
        ")->execute([
            'sessoes_encerradas',
            $idUsuario,
            'media',
            "{$sessoesEncerradas} sessões encerradas",
            $ipOrigem,
            $userAgent
        ]);
        
        echo json_encode([
            'success' => true,
            'message' => "{$sessoesEncerradas} sessões encerradas com sucesso"
        ]);
        
    } else {
        // Resetar tentativas de login falhas
        $stmt = $pdo->prepare("UPDATE usuarios SET tentativas_falhas = 0, bloqueado_ate = NULL WHERE id_usuario = ?");
        $stmt->execute([$idUsuario]);
        
        // Registrar evento no blockchain
        $ipOrigem = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
        $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
        
        // Obter email do usuário
        $stmt = $pdo->prepare("SELECT email FROM usuarios WHERE id_usuario = ?");
        $stmt->execute([$idUsuario]);
        $email = $stmt->fetchColumn();
        
        // Registrar evento de reset de tentativas
        $pdo->prepare("CALL registrar_evento_login('TENTATIVAS_RESETADAS', ?, ?, ?, ?, ?)")
            ->execute([
                $idUsuario,
                $email,
                $ipOrigem,
                $userAgent,
                'TENTATIVAS_RESETADAS'
            ]);
        
        // Registrar em logs de segurança
        $pdo->prepare("
            INSERT INTO logs_seguranca (tipo_log, id_usuario, severidade, descricao, ip_origem, user_agent) 
            VALUES (?, ?, ?, ?, ?, ?)
        ")->execute([
            'tentativas_resetadas',
            $idUsuario,
            'baixa',
            'Tentativas de login resetadas',
            $ipOrigem,
            $userAgent
        ]);
        
        echo json_encode(['success' => true, 'message' => 'Tentativas de login resetadas com sucesso']);
    }
    
} catch (Exception $e) {
    error_log("Erro ao resetar tentativas: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Erro interno do servidor']);
}
?>