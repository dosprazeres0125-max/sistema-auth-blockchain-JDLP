<?php
session_start();
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/funcoes-seguranca.php';

header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['id_usuario']) || $_SESSION['tipo_usuario'] !== 'admin') {
    echo json_encode(['success' => false, 'error' => 'Permissão negada']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'error' => 'Método inválido']);
    exit;
}

$nome_completo   = trim($_POST['nome_completo'] ?? '');
$email           = trim($_POST['email'] ?? '');
$tipo_usuario    = $_POST['tipo_usuario'] ?? 'user';
$senha           = $_POST['senha'] ?? '';
$confirmar_senha = $_POST['confirmar_senha'] ?? '';
$habilitar_mfa   = isset($_POST['habilitar_mfa']) ? 1 : 0;
$ativo           = isset($_POST['ativo']) ? 1 : 0;

if (empty($nome_completo) || empty($email) || empty($senha)) {
    echo json_encode(['success' => false, 'error' => 'Campos obrigatórios não preenchidos']);
    exit;
}

if ($senha !== $confirmar_senha) {
    echo json_encode(['success' => false, 'error' => 'As senhas não coincidem']);
    exit;
}

if (strlen($senha) < 8) {
    echo json_encode(['success' => false, 'error' => 'A senha deve ter pelo menos 8 caracteres']);
    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(['success' => false, 'error' => 'Email inválido']);
    exit;
}

$pdo = conectarBancoDados();

// Verificar se email já existe
$stmt = $pdo->prepare("SELECT id_usuario FROM usuarios WHERE email = ?");
$stmt->execute([$email]);
if ($stmt->fetch()) {
    echo json_encode(['success' => false, 'error' => 'Este email já está cadastrado']);
    exit;
}

$senha_hash = password_hash($senha, PASSWORD_DEFAULT);
$mfa_hash   = $habilitar_mfa ? password_hash(bin2hex(random_bytes(3)), PASSWORD_DEFAULT) : null; // Código MFA inicial fictício

try {
    $pdo->beginTransaction();

    $stmt = $pdo->prepare("
        INSERT INTO usuarios (
            nome_completo, email, email_hash, tipo_usuario, senha_hash, 
            mfa_codigo_hash, ativo, data_criacao
        ) VALUES (?, ?, SHA2(?, 256), ?, ?, ?, ?, NOW())
    ");
    $stmt->execute([$nome_completo, $email, $email, $tipo_usuario, $senha_hash, $mfa_hash, $ativo]);

    $idNovoUsuario = $pdo->lastInsertId();

    // Registrar evento
    registrarEventoBlockchain(
        'USER_CREATED',
        $idNovoUsuario,
        $email,
        obterIPCliente(),
        $_SERVER['HTTP_USER_AGENT'] ?? 'desconhecido'
    );

    $pdo->commit();

    echo json_encode([
        'success' => true,
        'message' => 'Usuário criado com sucesso',
        'id_usuario' => $idNovoUsuario
    ]);

} catch (Exception $e) {
    $pdo->rollBack();
    error_log("Erro ao criar usuário: " . $e->getMessage());
    echo json_encode(['success' => false, 'error' => 'Erro interno ao criar usuário']);
}
exit;