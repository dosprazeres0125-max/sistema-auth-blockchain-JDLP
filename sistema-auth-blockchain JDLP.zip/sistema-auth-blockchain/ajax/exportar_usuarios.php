<?php
session_start();
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/funcoes-seguranca.php';

if (!isset($_SESSION['id_usuario']) || !in_array($_SESSION['tipo_usuario'], ['admin', 'auditor'])) {
    die('Permissão negada');
}

$pdo = conectarBancoDados();

$stmt = $pdo->query("
    SELECT id_usuario, nome_completo, email, tipo_usuario, ativo, 
           data_criacao, data_ultimo_login, ultimo_ip, tentativas_falhas
    FROM usuarios 
    ORDER BY nome_completo
");
$usuarios = $stmt->fetchAll(PDO::FETCH_ASSOC);

header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="usuarios_'.date('Y-m-d_His').'.csv"');

$output = fopen('php://output', 'w');
fputs($output, chr(0xEF) . chr(0xBB) . chr(0xBF)); // BOM para UTF-8

fputcsv($output, ['ID', 'Nome Completo', 'Email', 'Tipo', 'Ativo', 'Data Criação', 'Último Login', 'Último IP', 'Tentativas Falhas']);

foreach ($usuarios as $u) {
    fputcsv($output, [
        $u['id_usuario'],
        $u['nome_completo'],
        $u['email'],
        $u['tipo_usuario'],
        $u['ativo'] ? 'Sim' : 'Não',
        $u['data_criacao'],
        $u['data_ultimo_login'] ?: 'Nunca',
        $u['ultimo_ip'] ?: 'N/A',
        $u['tentativas_falhas']
    ]);
}

fclose($output);
exit;