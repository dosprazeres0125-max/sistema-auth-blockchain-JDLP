<?php
require_once '../includes/config.php';
require_once '../includes/funcoes-seguranca.php';

$pdo = conectarBancoDados();

// Verificar se o usuário está autenticado
if (!isset($_SESSION['id_usuario']) || empty($_SESSION['id_usuario'])) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Não autenticado']);
    exit;
}

$periodo = $_GET['periodo'] ?? '7d'; // 7d, 30d, 90d
$tipo = $_GET['tipo'] ?? 'login'; // login, eventos, usuarios

$response = ['success' => true, 'labels' => [], 'datasets' => []];

try {
    // Definir intervalo baseado no período
    $intervalo = '';
    switch ($periodo) {
        case '30d':
            $intervalo = 'INTERVAL 30 DAY';
            $formatoData = 'd/m';
            break;
        case '90d':
            $intervalo = 'INTERVAL 90 DAY';
            $formatoData = 'd/m';
            break;
        case '7d':
        default:
            $intervalo = 'INTERVAL 7 DAY';
            $formatoData = 'd/m';
            break;
    }
    
    if ($tipo === 'login') {
        // Dados de login (sucesso vs falhas)
        $sql = "
            SELECT 
                DATE(data_hora) as data,
                SUM(CASE WHEN tipo_evento = 'LOGIN_SUCCESS' THEN 1 ELSE 0 END) as sucessos,
                SUM(CASE WHEN tipo_evento LIKE 'LOGIN_FAILED%' THEN 1 ELSE 0 END) as falhas
            FROM registro_eventos 
            WHERE data_hora >= DATE_SUB(NOW(), $intervalo)
                AND (tipo_evento = 'LOGIN_SUCCESS' OR tipo_evento LIKE 'LOGIN_FAILED%')
            GROUP BY DATE(data_hora)
            ORDER BY data ASC
        ";
        
        $stmt = $pdo->query($sql);
        $dados = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $labels = [];
        $sucessos = [];
        $falhas = [];
        
        foreach ($dados as $linha) {
            $labels[] = date($formatoData, strtotime($linha['data']));
            $sucessos[] = (int)$linha['sucessos'];
            $falhas[] = (int)$linha['falhas'];
        }
        
        $response['labels'] = $labels;
        $response['datasets'] = [
            [
                'label' => 'Logins Bem-sucedidos',
                'data' => $sucessos,
                'borderColor' => '#10b981',
                'backgroundColor' => 'rgba(16, 185, 129, 0.1)',
                'fill' => true
            ],
            [
                'label' => 'Tentativas Falhas',
                'data' => $falhas,
                'borderColor' => '#ef4444',
                'backgroundColor' => 'rgba(239, 68, 68, 0.1)',
                'fill' => true
            ]
        ];
        
    } elseif ($tipo === 'eventos') {
        // Dados de eventos por tipo
        $sql = "
            SELECT 
                DATE(data_hora) as data,
                tipo_evento,
                COUNT(*) as total
            FROM registro_eventos 
            WHERE data_hora >= DATE_SUB(NOW(), $intervalo)
            GROUP BY DATE(data_hora), tipo_evento
            ORDER BY data ASC, tipo_evento
        ";
        
        $stmt = $pdo->query($sql);
        $dados = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Organizar dados por tipo de evento
        $tiposEventos = [];
        $datas = [];
        $porData = [];
        
        foreach ($dados as $linha) {
            $data = $linha['data'];
            $tipoEvento = $linha['tipo_evento'];
            $total = (int)$linha['total'];
            
            if (!in_array($data, $datas)) {
                $datas[] = $data;
            }
            
            if (!in_array($tipoEvento, $tiposEventos)) {
                $tiposEventos[] = $tipoEvento;
            }
            
            if (!isset($porData[$data])) {
                $porData[$data] = [];
            }
            
            $porData[$data][$tipoEvento] = $total;
        }
        
        // Formatar labels
        $labels = [];
        foreach ($datas as $data) {
            $labels[] = date($formatoData, strtotime($data));
        }
        
        // Criar datasets para cada tipo de evento
        $datasets = [];
        $cores = [
            'LOGIN_SUCCESS' => '#10b981',
            'LOGIN_FAILED' => '#ef4444',
            'MFA_CREATED' => '#3b82f6',
            'MFA_VERIFIED' => '#8b5cf6',
            'LOGOUT' => '#6b7280',
            'USER_CREATED' => '#f59e0b',
            'PASSWORD_CHANGED' => '#ec4899'
        ];
        
        foreach ($tiposEventos as $tipoEvento) {
            $dadosTipo = [];
            foreach ($datas as $data) {
                $dadosTipo[] = $porData[$data][$tipoEvento] ?? 0;
            }
            
            $cor = $cores[$tipoEvento] ?? '#6b7280';
            
            $datasets[] = [
                'label' => formatarTipoEvento($tipoEvento),
                'data' => $dadosTipo,
                'borderColor' => $cor,
                'backgroundColor' => hexToRgba($cor, 0.1),
                'fill' => false
            ];
        }
        
        $response['labels'] = $labels;
        $response['datasets'] = $datasets;
        
    } elseif ($tipo === 'usuarios') {
        // Dados de criação de usuários
        $sql = "
            SELECT 
                DATE(data_criacao) as data,
                COUNT(*) as total,
                tipo_usuario
            FROM usuarios 
            WHERE data_criacao >= DATE_SUB(NOW(), $intervalo)
            GROUP BY DATE(data_criacao), tipo_usuario
            ORDER BY data ASC
        ";
        
        $stmt = $pdo->query($sql);
        $dados = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        $labels = [];
        $admin = [];
        $auditor = [];
        $usuario = [];
        
        // Inicializar arrays
        $datasUnicas = array_unique(array_column($dados, 'data'));
        sort($datasUnicas);
        
        foreach ($datasUnicas as $data) {
            $labels[] = date($formatoData, strtotime($data));
            
            // Buscar valores para cada tipo
            $valores = array_filter($dados, function($item) use ($data) {
                return $item['data'] == $data;
            });
            
            $admin[] = $this->obterValorTipo($valores, 'admin');
            $auditor[] = $this->obterValorTipo($valores, 'auditor');
            $usuario[] = $this->obterValorTipo($valores, 'usuario');
        }
        
        $response['labels'] = $labels;
        $response['datasets'] = [
            [
                'label' => 'Administradores',
                'data' => $admin,
                'borderColor' => '#8b5cf6',
                'backgroundColor' => 'rgba(139, 92, 246, 0.1)',
                'fill' => true
            ],
            [
                'label' => 'Auditores',
                'data' => $auditor,
                'borderColor' => '#3b82f6',
                'backgroundColor' => 'rgba(59, 130, 246, 0.1)',
                'fill' => true
            ],
            [
                'label' => 'Usuários',
                'data' => $usuario,
                'borderColor' => '#10b981',
                'backgroundColor' => 'rgba(16, 185, 129, 0.1)',
                'fill' => true
            ]
        ];
    }
    
} catch (PDOException $e) {
    $response['success'] = false;
    $response['message'] = 'Erro ao carregar dados do gráfico: ' . $e->getMessage();
}

header('Content-Type: application/json');
echo json_encode($response);

// Funções auxiliares
function formatarTipoEvento($tipo) {
    $formatos = [
        'LOGIN_SUCCESS' => 'Login Bem-sucedido',
        'LOGIN_FAILED' => 'Login Falhou',
        'MFA_CREATED' => 'MFA Criado',
        'MFA_VERIFIED' => 'MFA Verificado',
        'LOGOUT' => 'Logout',
        'USER_CREATED' => 'Usuário Criado',
        'PASSWORD_CHANGED' => 'Senha Alterada'
    ];
    
    return $formatos[$tipo] ?? $tipo;
}

function hexToRgba($hex, $alpha) {
    $hex = str_replace('#', '', $hex);
    if (strlen($hex) == 3) {
        $r = hexdec(substr($hex, 0, 1).substr($hex, 0, 1));
        $g = hexdec(substr($hex, 1, 1).substr($hex, 1, 1));
        $b = hexdec(substr($hex, 2, 1).substr($hex, 2, 1));
    } else {
        $r = hexdec(substr($hex, 0, 2));
        $g = hexdec(substr($hex, 2, 2));
        $b = hexdec(substr($hex, 4, 2));
    }
    return "rgba($r, $g, $b, $alpha)";
}

function obterValorTipo($valores, $tipo) {
    foreach ($valores as $valor) {
        if ($valor['tipo_usuario'] === $tipo) {
            return (int)$valor['total'];
        }
    }
    return 0;
}
?>