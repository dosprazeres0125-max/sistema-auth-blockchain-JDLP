<?php
session_start();
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/funcoes-seguranca.php';

if (!isset($_SESSION['id_usuario'])) {
    echo json_encode(['success' => false, 'message' => 'Não autenticado']);
    exit;
}

header('Content-Type: application/json');

try {
    $data = json_decode(file_get_contents('php://input'), true);
    
    if (!isset($data['codigo_verificacao']) || !isset($data['metodo'])) {
        throw new Exception('Dados incompletos');
    }
    
    $codigoVerificacao = $data['codigo_verificacao'];
    $metodo = $data['metodo'];
    $codigoSecreto = $data['codigo_secreto'] ?? null;
    
    if (strlen($codigoVerificacao) !== 6 || !ctype_digit($codigoVerificacao)) {
        throw new Exception('Código de verificação inválido');
    }
    
    $pdo = conectarBancoDados();
    $idUsuario = $_SESSION['id_usuario'];
    
    if ($metodo === 'email') {
        $stmt = $pdo->prepare("
            SELECT codigo_verificacao 
            FROM codigos_verificacao_mfa 
            WHERE id_usuario = ? 
            AND metodo = 'email' 
            AND expiracao > NOW() 
            AND utilizado = 0
            ORDER BY id DESC 
            LIMIT 1
        ");
        $stmt->execute([$idUsuario]);
        $codigoValido = $stmt->fetch();
        
        if (!$codigoValido || $codigoValido['codigo_verificacao'] !== $codigoVerificacao) {
            throw new Exception('Código inválido ou expirado');
        }
        
        $stmt = $pdo->prepare("UPDATE codigos_verificacao_mfa SET utilizado = 1 WHERE id_usuario = ? AND codigo_verificacao = ?");
        $stmt->execute([$idUsuario, $codigoVerificacao]);
        
        $codigoMFACriado = gerarCodigoMFA();
        $codigoMFAHash = password_hash($codigoMFACriado, PASSWORD_BCRYPT);
    } else {
        if (!$codigoSecreto) {
            throw new Exception('Código secreto não fornecido');
        }
        
        require_once __DIR__ . '/../includes/phpotp/rfc6238.php';
        
        if (!TokenAuth6238::verify($codigoSecreto, $codigoVerificacao)) {
            throw new Exception('Código de verificação inválido');
        }
        
        $codigoMFACriado = $codigoSecreto;
        $codigoMFAHash = password_hash($codigoVerificacao, PASSWORD_BCRYPT);
    }
    
    $stmt = $pdo->prepare("UPDATE usuarios SET mfa_codigo_hash = ?, mfa_ultima_alteracao = NOW() WHERE id_usuario = ?");
    $stmt->execute([$codigoMFAHash, $idUsuario]);
    
    $ipOrigem = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
    
    registrarEventoBlockchain(
        $pdo,
        'MFA_CREATED',
        $idUsuario,
        $_SESSION['email'],
        $ipOrigem,
        $userAgent,
        ['metodo' => $metodo]
    );
    
    echo json_encode([
        'success' => true, 
        'message' => 'MFA ativado com sucesso',
        'codigo_gerado' => $metodo === 'email' ? $codigoMFACriado : null
    ]);
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>