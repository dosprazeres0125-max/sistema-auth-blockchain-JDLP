<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/funcoes-seguranca.php';

$pdo = conectarBancoDados();

try {
    $dados = [
        'total_usuarios'   => $pdo->query("SELECT COUNT(*) FROM usuarios WHERE ativo=1")->fetchColumn(),
        'sessoes_ativas'   => $pdo->query("SELECT COUNT(*) FROM sessoes_ativas WHERE expiracao > NOW()")->fetchColumn(),
        'total_eventos'    => $pdo->query("SELECT COUNT(*) FROM registro_eventos")->fetchColumn(),
        'logins_sucesso'   => $pdo->query("SELECT COUNT(*) FROM registro_eventos WHERE tipo_evento='LOGIN_SUCCESS'")->fetchColumn(),
        'logins_falha'     => $pdo->query("SELECT COUNT(*) FROM registro_eventos WHERE tipo_evento LIKE 'LOGIN_FAILED%' OR tipo_evento IN ('LOGIN_BLOCKED','ACCOUNT_LOCKED')")->fetchColumn(),
        'total_blocos'     => $pdo->query("SELECT COUNT(*) FROM blocos_blockchain")->fetchColumn(),
    ];

    echo json_encode(['success' => true, 'data' => $dados]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => 'Erro interno']);
}