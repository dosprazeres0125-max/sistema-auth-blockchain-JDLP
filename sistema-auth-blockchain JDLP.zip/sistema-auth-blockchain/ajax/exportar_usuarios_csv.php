<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/funcoes-seguranca.php';

// Verificar autenticação e permissões
if (!isset($_SESSION['id_usuario']) || empty($_SESSION['id_usuario'])) {
    exit('Não autenticado');
}

// Verificar se é admin
$stmt = $pdo->prepare("SELECT tipo_usuario FROM usuarios WHERE id_usuario = ?");
$stmt->execute([$_SESSION['id_usuario']]);
$usuario = $stmt->fetch(PDO::FETCH_ASSOC);

if ($usuario['tipo_usuario'] !== 'admin') {
    exit('Permissão negada');
}

try {
    // Buscar todos os usuários
    $stmt = $pdo->query("SELECT 
        id_usuario,
        nome_completo,
        email,
        tipo_usuario,
        DATE_FORMAT(data_criacao, '%d/%m/%Y %H:%i') as data_criacao,
        DATE_FORMAT(data_ultimo_login, '%d/%m/%Y %H:%i') as data_ultimo_login,
        CASE 
            WHEN mfa_codigo_hash IS NOT NULL THEN 'Ativo'
            ELSE 'Inativo'
        END as mfa_status,
        tentativas_falhas,
        ultimo_ip
    FROM usuarios ORDER BY data_criacao DESC");
    
    $usuarios = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Configurar headers para download CSV
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="usuarios_' . date('Y-m-d') . '.csv"');
    
    $output = fopen('php://output', 'w');
    
    // Cabeçalhos CSV
    fputcsv($output, [
        'ID',
        'Nome Completo',
        'Email',
        'Tipo',
        'Data Criação',
        'Último Login',
        'MFA',
        'Tentativas Falhas',
        'Último IP'
    ], ';');
    
    // Dados
    foreach ($usuarios as $usuario) {
        fputcsv($output, [
            $usuario['id_usuario'],
            $usuario['nome_completo'],
            $usuario['email'],
            $usuario['tipo_usuario'],
            $usuario['data_criacao'],
            $usuario['data_ultimo_login'] ?: 'Nunca',
            $usuario['mfa_status'],
            $usuario['tentativas_falhas'],
            $usuario['ultimo_ip'] ?: 'N/A'
        ], ';');
    }
    
    fclose($output);
    
} catch (Exception $e) {
    error_log("Erro ao exportar CSV: " . $e->getMessage());
    exit('Erro ao gerar arquivo CSV');
}
?>