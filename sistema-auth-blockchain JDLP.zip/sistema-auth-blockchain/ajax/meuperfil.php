<?php
// ajax/meuperfil.php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/funcoes-seguranca.php';

// Verificar se o usuário está logado
if (!isset($_SESSION['id_usuario']) || empty($_SESSION['id_usuario'])) {
    echo json_encode(['success' => false, 'message' => 'Não autorizado']);
    exit;
}

// Conectar ao banco de dados
try {
    $pdo = conectarBancoDados();
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Erro ao conectar ao banco de dados']);
    exit;
}

// Obter ação
$acao = $_GET['acao'] ?? $_POST['acao'] ?? '';
$idUsuario = $_SESSION['id_usuario'];

// Processar ações
switch ($acao) {
    case 'editar':
        editarPerfil();
        break;
    case 'alterar_senha':
        alterarSenha();
        break;
    case 'exportar_dados':
        exportarDadosPessoais();
        break;
    case 'permissoes':
        obterPermissoes();
        break;
    case 'logout_outras_sessoes':
        logoutOutrasSessoes();
        break;
    default:
        echo json_encode(['success' => false, 'message' => 'Ação não reconhecida']);
        exit;
}

function editarPerfil() {
    global $pdo, $idUsuario;
    
    $nome = $_POST['nome_completo'] ?? '';
    $email = $_POST['email'] ?? '';
    
    // Validações
    if (empty($nome) || empty($email)) {
        echo json_encode(['success' => false, 'message' => 'Nome e email são obrigatórios']);
        exit;
    }
    
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode(['success' => false, 'message' => 'Email inválido']);
        exit;
    }
    
    try {
        // Verificar se email já existe (exceto para o próprio usuário)
        $queryVerificarEmail = "SELECT id_usuario FROM usuarios WHERE email = ? AND id_usuario != ?";
        $stmtVerificarEmail = $pdo->prepare($queryVerificarEmail);
        $stmtVerificarEmail->execute([$email, $idUsuario]);
        
        if ($stmtVerificarEmail->fetch()) {
            echo json_encode(['success' => false, 'message' => 'Este email já está em uso']);
            exit;
        }
        
        // Atualizar perfil
        $queryAtualizar = "UPDATE usuarios SET nome_completo = ?, email = ? WHERE id_usuario = ?";
        $stmtAtualizar = $pdo->prepare($queryAtualizar);
        $stmtAtualizar->execute([$nome, $email, $idUsuario]);
        
        // Atualizar sessão
        $_SESSION['nome_completo'] = $nome;
        $_SESSION['email'] = $email;
        
        // Registrar evento
        registrarEvento('PERFIL_ATUALIZADO', $idUsuario, 'Perfil atualizado pelo usuário');
        
        echo json_encode(['success' => true, 'message' => 'Perfil atualizado com sucesso']);
    } catch (Exception $e) {
        error_log("Erro ao editar perfil: " . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Erro ao atualizar perfil']);
    }
}

function alterarSenha() {
    global $pdo, $idUsuario;
    
    $senhaAtual = $_POST['senha_atual'] ?? '';
    $novaSenha = $_POST['nova_senha'] ?? '';
    $confirmarSenha = $_POST['confirmar_senha'] ?? '';
    
    // Validações
    if (empty($senhaAtual) || empty($novaSenha) || empty($confirmarSenha)) {
        echo json_encode(['success' => false, 'message' => 'Todos os campos são obrigatórios']);
        exit;
    }
    
    if ($novaSenha !== $confirmarSenha) {
        echo json_encode(['success' => false, 'message' => 'As senhas não coincidem']);
        exit;
    }
    
    if (strlen($novaSenha) < 8) {
        echo json_encode(['success' => false, 'message' => 'A senha deve ter no mínimo 8 caracteres']);
        exit;
    }
    
    try {
        // Buscar senha atual
        $querySenhaAtual = "SELECT senha_hash FROM usuarios WHERE id_usuario = ?";
        $stmtSenhaAtual = $pdo->prepare($querySenhaAtual);
        $stmtSenhaAtual->execute([$idUsuario]);
        $usuario = $stmtSenhaAtual->fetch(PDO::FETCH_ASSOC);
        
        if (!$usuario) {
            echo json_encode(['success' => false, 'message' => 'Usuário não encontrado']);
            exit;
        }
        
        // Verificar senha atual
        if (!password_verify($senhaAtual, $usuario['senha_hash'])) {
            echo json_encode(['success' => false, 'message' => 'Senha atual incorreta']);
            exit;
        }
        
        // Validar força da senha
        if (!validarSenhaForte($novaSenha)) {
            echo json_encode(['success' => false, 'message' => 'A senha deve conter letras, números e caracteres especiais']);
            exit;
        }
        
        // Hash da nova senha
        $novaSenhaHash = password_hash($novaSenha, PASSWORD_DEFAULT);
        
        // Atualizar senha
        $queryAtualizar = "UPDATE usuarios SET senha_hash = ? WHERE id_usuario = ?";
        $stmtAtualizar = $pdo->prepare($queryAtualizar);
        $stmtAtualizar->execute([$novaSenhaHash, $idUsuario]);
        
        // Registrar evento
        registrarEvento('SENHA_ALTERADA', $idUsuario, 'Senha alterada pelo usuário');
        
        echo json_encode(['success' => true, 'message' => 'Senha alterada com sucesso']);
    } catch (Exception $e) {
        error_log("Erro ao alterar senha: " . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Erro ao alterar senha']);
    }
}

function exportarDadosPessoais() {
    global $pdo, $idUsuario;
    
    try {
        // Buscar dados do usuário
        $queryUsuario = "
            SELECT 
                id_usuario,
                nome_completo,
                email,
                tipo_usuario,
                data_criacao,
                data_ultimo_login,
                data_ultima_atividade,
                tentativas_falhas,
                bloqueado_ate,
                ultimo_ip,
                ativo
            FROM usuarios 
            WHERE id_usuario = ?
        ";
        
        $stmtUsuario = $pdo->prepare($queryUsuario);
        $stmtUsuario->execute([$idUsuario]);
        $dadosUsuario = $stmtUsuario->fetch(PDO::FETCH_ASSOC);
        
        // Buscar eventos do usuário
        $queryEventos = "
            SELECT 
                tipo_evento,
                ip_origem,
                user_agent,
                data_hora
            FROM registro_eventos 
            WHERE id_usuario = ?
            ORDER BY data_hora DESC
            LIMIT 100
        ";
        
        $stmtEventos = $pdo->prepare($queryEventos);
        $stmtEventos->execute([$idUsuario]);
        $eventos = $stmtEventos->fetchAll(PDO::FETCH_ASSOC);
        
        // Buscar sessões ativas
        $querySessoes = "
            SELECT 
                ip,
                user_agent,
                data_inicio,
                data_ultima_atividade,
                expiracao
            FROM sessoes_ativas 
            WHERE id_usuario = ?
            ORDER BY data_ultima_atividade DESC
        ";
        
        $stmtSessoes = $pdo->prepare($querySessoes);
        $stmtSessoes->execute([$idUsuario]);
        $sessoes = $stmtSessoes->fetchAll(PDO::FETCH_ASSOC);
        
        // Preparar dados para exportação
        $dadosExportacao = [
            'metadata' => [
                'exportacao' => date('Y-m-d H:i:s'),
                'usuario_id' => $idUsuario,
                'formato' => 'JSON'
            ],
            'dados_pessoais' => $dadosUsuario,
            'eventos_recentes' => $eventos,
            'sessoes_ativas' => $sessoes
        ];
        
        // Exportar como JSON
        header('Content-Type: application/json; charset=utf-8');
        header('Content-Disposition: attachment; filename=dados_pessoais_' . date('Y-m-d_H-i-s') . '.json');
        
        echo json_encode($dadosExportacao, JSON_PRETTY_PRINT);
        exit;
        
    } catch (Exception $e) {
        error_log("Erro ao exportar dados pessoais: " . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Erro ao exportar dados']);
    }
}

function obterPermissoes() {
    global $pdo, $idUsuario;
    
    try {
        // Buscar tipo de usuário
        $queryTipo = "SELECT tipo_usuario FROM usuarios WHERE id_usuario = ?";
        $stmtTipo = $pdo->prepare($queryTipo);
        $stmtTipo->execute([$idUsuario]);
        $tipo = $stmtTipo->fetchColumn();
        
        if (!$tipo) {
            echo json_encode(['success' => false, 'message' => 'Usuário não encontrado']);
            exit;
        }
        
        // Buscar permissões do perfil
        $queryPermissoes = "SELECT permissoes FROM perfis_acesso WHERE nome_perfil = ?";
        $stmtPermissoes = $pdo->prepare($queryPermissoes);
        $stmtPermissoes->execute([$tipo]);
        $permissoes = $stmtPermissoes->fetchColumn();
        
        if ($permissoes) {
            $permissoesArray = json_decode($permissoes, true);
            echo json_encode(['success' => true, 'permissoes' => $permissoesArray]);
        } else {
            echo json_encode(['success' => true, 'permissoes' => []]);
        }
        
    } catch (Exception $e) {
        error_log("Erro ao obter permissões: " . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Erro ao obter permissões']);
    }
}

function logoutOutrasSessoes() {
    global $pdo, $idUsuario;
    
    try {
        // Obter ID da sessão atual
        $sessaoAtual = session_id();
        
        // Encerrar todas as outras sessões
        $queryLogout = "DELETE FROM sessoes_ativas WHERE id_usuario = ? AND id_sessao != ?";
        $stmtLogout = $pdo->prepare($queryLogout);
        $stmtLogout->execute([$idUsuario, $sessaoAtual]);
        $sessoesEncerradas = $stmtLogout->rowCount();
        
        // Registrar evento
        registrarEvento('LOGOUT_OUTRAS_SESSOES', $idUsuario, "Usuário encerrou $sessoesEncerradas outras sessões");
        
        echo json_encode([
            'success' => true, 
            'message' => 'Outras sessões encerradas com sucesso',
            'sessoes_encerradas' => $sessoesEncerradas
        ]);
        
    } catch (Exception $e) {
        error_log("Erro ao encerrar outras sessões: " . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Erro ao encerrar outras sessões']);
    }
}

function validarSenhaForte($senha) {
    // Mínimo 8 caracteres
    if (strlen($senha) < 8) return false;
    
    // Pelo menos uma letra maiúscula
    if (!preg_match('/[A-Z]/', $senha)) return false;
    
    // Pelo menos uma letra minúscula
    if (!preg_match('/[a-z]/', $senha)) return false;
    
    // Pelo menos um número
    if (!preg_match('/[0-9]/', $senha)) return false;
    
    // Pelo menos um caractere especial
    if (!preg_match('/[^A-Za-z0-9]/', $senha)) return false;
    
    return true;
}

function registrarEvento($tipo, $idUsuario, $descricao = '') {
    global $pdo;
    
    try {
        $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
        $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
        
        $query = "INSERT INTO logs_seguranca (tipo_log, id_usuario, severidade, descricao, ip_origem, user_agent) VALUES (?, ?, 'baixa', ?, ?, ?)";
        $stmt = $pdo->prepare($query);
        $stmt->execute([$tipo, $idUsuario, $descricao, $ip, $userAgent]);
    } catch (Exception $e) {
        error_log("Erro ao registrar evento: " . $e->getMessage());
    }
}