<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/funcoes-seguranca.php';

if (!isset($_SESSION['tipo_usuario']) || !in_array($_SESSION['tipo_usuario'], ['admin','auditor'])) {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'Acesso negado']);
    exit;
}

$pdo = conectarBancoDados();

try {
    $pdo->exec("CALL verificar_integridade_blockchain()");
    echo json_encode(['success' => true, 'message' => 'Verificação iniciada. Consulte logs_seguranca para resultado.']);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => 'Erro durante verificação']);
}