<?php
// ajax/carregar_notificacoes.php
require_once '../includes/config.php';
require_once '../includes/funcoes-seguranca.php';

header('Content-Type: application/json; charset=utf-8');

// Verificar se usuário está logado
if (!isset($_SESSION['id_usuario']) || empty($_SESSION['id_usuario'])) {
    echo json_encode(['success' => false, 'error' => 'Sessão expirada']);
    exit;
}

$pdo = conectarBancoDados();
$id_usuario = (int)$_SESSION['id_usuario'];

// Buscar notificações recentes (não lidas primeiro, depois as lidas)
$notificacoes = [];
try {
    $stmt = $pdo->prepare("
        SELECT 
            id_notificacao,
            tipo_notificacao,
            titulo,
            mensagem,
            lida,
            data_criacao,
            data_leitura
        FROM notificacoes_sistema
        WHERE (id_usuario = :id_usuario OR id_usuario IS NULL)
        ORDER BY lida ASC, data_criacao DESC
        LIMIT 10
    ");
    $stmt->execute([':id_usuario' => $id_usuario]);
    $notificacoes = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Formatar datas e tipo para exibição
    foreach ($notificacoes as &$notif) {
        $notif['data_hora_formatada'] = date('d/m/Y H:i', strtotime($notif['data_criacao']));
        
        // Tipo formatado para exibição (opcional - pode expandir)
        $notif['tipo_evento_formatado'] = ucfirst(str_replace('_', ' ', $notif['tipo_notificacao']));
    }
    
    echo json_encode([
        'success' => true,
        'notificacoes' => $notificacoes,
        'total_nao_lidas' => count(array_filter($notificacoes, fn($n) => !$n['lida']))
    ]);
    
} catch (Exception $e) {
    error_log("Erro ao carregar notificações: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'error' => 'Erro ao carregar notificações'
    ]);
}

exit;