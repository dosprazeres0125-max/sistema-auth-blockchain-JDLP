<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/funcoes-seguranca.php';

header('Content-Type: application/json');

if (!isset($_SESSION['id_usuario'])) {
    echo json_encode(['success' => false, 'error' => 'Não autenticado']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);

if (!isset($data['codigo_mfa']) || !preg_match('/^\d{6}$/', $data['codigo_mfa'])) {
    echo json_encode(['success' => false, 'error' => 'Código inválido']);
    exit;
}

try {
    $pdo = conectarBancoDados();
    $hash = password_hash($data['codigo_mfa'], PASSWORD_DEFAULT);
    
    $stmt = $pdo->prepare("UPDATE usuarios SET mfa_codigo_hash = ?, mfa_ultima_alteracao = NOW() WHERE id_usuario = ?");
    $stmt->execute([$hash, $_SESSION['id_usuario']]);
    
    registrarEventoBlockchain('MFA_CREATED', $_SESSION['id_usuario'], $_SESSION['email'], obterIPCliente(), $_SERVER['HTTP_USER_AGENT']);
    
    echo json_encode(['success' => true, 'message' => 'MFA configurado com sucesso']);
} catch (Exception $e) {
    error_log('Erro MFA: ' . $e->getMessage());
    echo json_encode(['success' => false, 'error' => 'Erro interno']);
}
?>