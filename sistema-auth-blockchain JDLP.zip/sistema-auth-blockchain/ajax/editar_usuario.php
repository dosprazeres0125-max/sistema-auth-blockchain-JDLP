<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/funcoes-seguranca.php';

// Verificar autenticação e permissões
if (!isset($_SESSION['id_usuario']) || empty($_SESSION['id_usuario'])) {
    echo json_encode(['success' => false, 'message' => 'Não autenticado']);
    exit;
}

// Verificar se é admin
$stmt = $pdo->prepare("SELECT tipo_usuario FROM usuarios WHERE id_usuario = ?");
$stmt->execute([$_SESSION['id_usuario']]);
$usuario = $stmt->fetch(PDO::FETCH_ASSOC);

if ($usuario['tipo_usuario'] !== 'admin') {
    echo json_encode(['success' => false, 'message' => 'Permissão negada']);
    exit;
}

if (!isset($_GET['id']) || empty($_GET['id'])) {
    echo json_encode(['success' => false, 'message' => 'ID do usuário não especificado']);
    exit;
}

$id_usuario = intval($_GET['id']);

try {
    $stmt = $pdo->prepare("SELECT 
        id_usuario,
        nome_completo,
        email,
        tipo_usuario,
        mfa_codigo_hash
    FROM usuarios WHERE id_usuario = ?");
    
    $stmt->execute([$id_usuario]);
    $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$usuario) {
        echo json_encode(['success' => false, 'message' => 'Usuário não encontrado']);
        exit;
    }
    
    // Retornar também se MFA está ativo
    $usuario['mfa_ativo'] = !empty($usuario['mfa_codigo_hash']);
    
    echo json_encode(['success' => true, 'usuario' => $usuario]);
    
} catch (Exception $e) {
    error_log("Erro ao buscar usuário para edição: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Erro ao buscar informações']);
}
?>