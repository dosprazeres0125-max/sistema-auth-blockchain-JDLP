<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/funcoes-seguranca.php';

if (!isset($_SESSION['id_usuario']) || !isset($_SESSION['id_sessao'])) {
    echo json_encode(['error' => 'Não autenticado']);
    exit;
}

try {
    $conn = conectarBancoDados();
    
    $stmt = $conn->prepare("UPDATE sessoes_ativas SET data_ultima_atividade = NOW() WHERE id_sessao = ?");
    $stmt->execute([$_SESSION['id_sessao']]);
    
    $stmt = $conn->prepare("UPDATE usuarios SET data_ultima_atividade = NOW() WHERE id_usuario = ?");
    $stmt->execute([$_SESSION['id_usuario']]);
    
    $_SESSION['ultima_atividade'] = time();
    
    echo json_encode(['success' => true]);
    
} catch (Exception $e) {
    error_log("Erro ao atualizar atividade: " . $e->getMessage());
    echo json_encode(['error' => 'Erro interno']);
}
?>