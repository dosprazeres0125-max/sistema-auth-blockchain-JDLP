<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/funcoes-seguranca.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-cache, no-store, must-revalidate');

$resposta = ['success' => false, 'existe' => false, 'error' => ''];

try {
    // Verificar método POST
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Método não permitido');
    }
    
    // Obter email
    $email = $_POST['email'] ?? '';
    
    if (empty($email)) {
        throw new Exception('Email não fornecido');
    }
    
    // Validar formato do email
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $resposta['success'] = true;
        $resposta['existe'] = false;
        $resposta['error'] = 'Formato de email inválido';
        echo json_encode($resposta, JSON_UNESCAPED_UNICODE);
        exit;
    }
    
    // Conectar ao banco
    $conn = conectarBancoDados();
    $emailHash = hash('sha256', $email);
    
    // Verificar se email existe
    $stmt = $conn->prepare("SELECT COUNT(*) as total FROM usuarios WHERE email_hash = ? AND ativo = 1");
    $stmt->execute([$emailHash]);
    $resultado = $stmt->fetch(PDO::FETCH_ASSOC);
    
    $resposta['success'] = true;
    $resposta['existe'] = ($resultado['total'] > 0);
    $resposta['message'] = $resposta['existe'] ? 'Email encontrado' : 'Email não encontrado';
    
} catch (Exception $e) {
    $resposta['error'] = $e->getMessage();
}

echo json_encode($resposta, JSON_UNESCAPED_UNICODE);
exit;
?>