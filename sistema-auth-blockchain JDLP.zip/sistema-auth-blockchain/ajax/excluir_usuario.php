<?php
session_start();
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/funcoes-seguranca.php';

header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['id_usuario']) || $_SESSION['tipo_usuario'] !== 'admin') {
    echo json_encode(['success' => false, 'error' => 'Permissão negada']);
    exit;
}

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    echo json_encode(['success' => false, 'error' => 'ID inválido']);
    exit;
}

if ($id === $_SESSION['id_usuario']) {
    echo json_encode(['success' => false, 'error' => 'Você não pode excluir sua própria conta']);
    exit;
}

$pdo = conectarBancoDados();

try {
    $pdo->beginTransaction();

    // Remover sessões ativas
    $stmt = $pdo->prepare("DELETE FROM sessoes_ativas WHERE id_usuario = ?");
    $stmt->execute([$id]);

    // Remover eventos (opcional - pode manter para auditoria)
    // $stmt = $pdo->prepare("DELETE FROM registro_eventos WHERE id_usuario = ?");
    // $stmt->execute([$id]);

    // Remover usuário
    $stmt = $pdo->prepare("DELETE FROM usuarios WHERE id_usuario = ?");
    $stmt->execute([$id]);

    registrarEventoBlockchain(
        'USER_DELETED',
        $id,
        null,
        obterIPCliente(),
        $_SERVER['HTTP_USER_AGENT'] ?? 'desconhecido'
    );

    $pdo->commit();

    echo json_encode(['success' => true, 'message' => 'Usuário excluído permanentemente']);

} catch (Exception $e) {
    $pdo->rollBack();
    error_log("Erro ao excluir usuário: " . $e->getMessage());
    echo json_encode(['success' => false, 'error' => 'Erro interno ao excluir']);
}
exit;