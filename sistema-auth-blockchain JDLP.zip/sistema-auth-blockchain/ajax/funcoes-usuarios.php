<?php
session_start();
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/funcoes-seguranca.php';

header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['id_usuario']) || $_SESSION['tipo_usuario'] !== 'admin') {
    echo json_encode(['success' => false, 'error' => 'Permissão negada']);
    exit;
}

$acao = $_GET['acao'] ?? '';
$id   = (int)($_GET['id'] ?? 0);

if ($id <= 0 || empty($acao)) {
    echo json_encode(['success' => false, 'error' => 'Parâmetros inválidos']);
    exit;
}

$pdo = conectarBancoDados();

try {
    $pdo->beginTransaction();

    switch ($acao) {
        case 'bloquear':
            $bloqueioAte = date('Y-m-d H:i:s', time() + 3600); // 1 hora
            $stmt = $pdo->prepare("UPDATE usuarios SET bloqueado_ate = ? WHERE id_usuario = ?");
            $stmt->execute([$bloqueioAte, $id]);
            $tipoEvento = 'USER_BLOCKED';
            break;

        case 'desbloquear':
            $stmt = $pdo->prepare("UPDATE usuarios SET bloqueado_ate = NULL WHERE id_usuario = ?");
            $stmt->execute([$id]);
            $tipoEvento = 'USER_UNBLOCKED';
            break;

        case 'ativar':
            $stmt = $pdo->prepare("UPDATE usuarios SET ativo = 1 WHERE id_usuario = ?");
            $stmt->execute([$id]);
            $tipoEvento = 'USER_ACTIVATED';
            break;

        case 'desativar':
            $stmt = $pdo->prepare("UPDATE usuarios SET ativo = 0 WHERE id_usuario = ?");
            $stmt->execute([$id]);
            $tipoEvento = 'USER_DEACTIVATED';
            break;

        case 'encerrar_sessao':
            $token = $_GET['token'] ?? '';
            if (empty($token)) throw new Exception('Token de sessão inválido');
            $stmt = $pdo->prepare("DELETE FROM sessoes_ativas WHERE token_sessao = ? AND id_usuario = ?");
            $stmt->execute([$token, $id]);
            $tipoEvento = 'SESSION_REVOKED';
            break;

        default:
            throw new Exception('Ação inválida');
    }

    registrarEventoBlockchain(
        $tipoEvento,
        $id,
        null, // email não disponível aqui, pode ser buscado se necessário
        obterIPCliente(),
        $_SERVER['HTTP_USER_AGENT'] ?? 'desconhecido'
    );

    $pdo->commit();

    echo json_encode(['success' => true, 'message' => 'Ação realizada com sucesso']);

} catch (Exception $e) {
    $pdo->rollBack();
    error_log("Erro em funcoes-usuarios: " . $e->getMessage());
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
exit;