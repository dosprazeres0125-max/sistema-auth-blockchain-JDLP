<?php
// ajax/salvar_configuracoes.php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/funcoes-seguranca.php';

header('Content-Type: application/json');

// Verificar se é admin
if (!isset($_SESSION['id_usuario']) || $_SESSION['tipo_usuario'] !== 'admin') {
    echo json_encode(['success' => false, 'message' => 'Acesso negado']);
    exit;
}

try {
    $pdo = conectarBancoDados();
    
    // Preparar statement para atualizar configurações
    $stmt = $pdo->prepare("
        INSERT INTO configuracoes_sistema (chave, valor) 
        VALUES (?, ?)
        ON DUPLICATE KEY UPDATE valor = VALUES(valor), data_atualizacao = CURRENT_TIMESTAMP
    ");
    
    // Atualizar cada configuração recebida
    $configs = [
        'tempo_expiracao_sessao' => $_POST['tempo_expiracao_sessao'] ?? '1800',
        'mfa_obrigatorio' => isset($_POST['mfa_obrigatorio']) ? '1' : '0',
        'tentativas_login_max' => $_POST['tentativas_login_max'] ?? '5',
        'bloqueio_tempo' => $_POST['bloqueio_tempo'] ?? '900',
        'log_manutencao' => isset($_POST['log_manutencao']) ? '1' : '0',
        'manutencao_modo' => isset($_POST['manutencao_modo']) ? '1' : '0',
        'tema_padrao' => $_POST['tema_padrao'] ?? 'dark'
    ];
    
    foreach ($configs as $chave => $valor) {
        $stmt->execute([$chave, $valor]);
    }
    
    // Registrar evento
    registrarEvento('CONFIGURACOES_ATUALIZADAS', $_SESSION['id_usuario'], 'Configurações do sistema atualizadas');
    
    echo json_encode(['success' => true, 'message' => 'Configurações salvas com sucesso!']);
    
} catch (Exception $e) {
    error_log("Erro ao salvar configurações: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Erro ao salvar configurações: ' . $e->getMessage()]);
}