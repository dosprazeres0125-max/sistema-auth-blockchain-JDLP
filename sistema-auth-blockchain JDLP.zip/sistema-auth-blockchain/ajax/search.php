<?php
// ajax/search.php
require_once '../includes/config.php';
require_once '../includes/funcoes-seguranca.php';

header('Content-Type: application/json; charset=utf-8');

// Verificar se usuário está logado
if (!isset($_SESSION['id_usuario']) || empty($_SESSION['id_usuario'])) {
    echo json_encode(['success' => false, 'error' => 'Sessão expirada']);
    exit;
}

$pdo = conectarBancoDados();
$query = trim($_GET['q'] ?? '');

if (strlen($query) < 2) {
    echo json_encode([
        'success' => false,
        'error' => 'Pesquisa muito curta',
        'count_usuarios' => 0,
        'count_eventos' => 0,
        'total_count' => 0,
        'results' => ['usuarios' => [], 'eventos' => []]
    ]);
    exit;
}

// Limite de resultados por tipo
$limit = 10;

// Buscar usuários (nome ou email)
$usuarios = [];
try {
    $stmt = $pdo->prepare("
        SELECT 
            id_usuario, 
            nome_completo, 
            email, 
            tipo_usuario 
        FROM usuarios 
        WHERE ativo = 1 
          AND (
              nome_completo LIKE :termo 
              OR email LIKE :termo 
              OR email_hash LIKE :termo_hash
          )
        ORDER BY nome_completo 
        LIMIT :limite
    ");
    $termo = '%' . $query . '%';
    $termo_hash = '%' . hash('sha256', $query) . '%';
    
    $stmt->bindValue(':termo', $termo, PDO::PARAM_STR);
    $stmt->bindValue(':termo_hash', $termo_hash, PDO::PARAM_STR);
    $stmt->bindValue(':limite', $limit, PDO::PARAM_INT);
    $stmt->execute();
    $usuarios = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    error_log("Erro na busca de usuários: " . $e->getMessage());
}

// Buscar eventos recentes (tipo_evento ou nome do usuário)
$eventos = [];
try {
    $stmt = $pdo->prepare("
        SELECT 
            re.id_evento,
            re.tipo_evento,
            re.data_hora,
            re.email_informado,
            u.nome_completo,
            u.tipo_usuario
        FROM registro_eventos re
        LEFT JOIN usuarios u ON re.id_usuario = u.id_usuario
        WHERE re.tipo_evento LIKE :termo 
           OR re.email_informado LIKE :termo
           OR u.nome_completo LIKE :termo
           OR re.ip_origem LIKE :termo
        ORDER BY re.data_hora DESC
        LIMIT :limite
    ");
    $termo = '%' . $query . '%';
    $stmt->bindValue(':termo', $termo, PDO::PARAM_STR);
    $stmt->bindValue(':limite', $limit, PDO::PARAM_INT);
    $stmt->execute();
    $eventos = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    error_log("Erro na busca de eventos: " . $e->getMessage());
}

$total_count = count($usuarios) + count($eventos);

echo json_encode([
    'success' => true,
    'query' => $query,
    'count_usuarios' => count($usuarios),
    'count_eventos' => count($eventos),
    'total_count' => $total_count,
    'results' => [
        'usuarios' => $usuarios,
        'eventos' => $eventos
    ]
]);

exit;