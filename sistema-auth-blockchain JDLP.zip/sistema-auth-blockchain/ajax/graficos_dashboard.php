<?php
require_once '../includes/config.php';
require_once '../includes/funcoes-seguranca.php';

// Verificar se o usuário está logado
if (!isset($_SESSION['id_usuario']) || empty($_SESSION['id_usuario'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'Não autorizado']);
    exit;
}

try {
    // Estatísticas por hora (últimas 6 horas)
    $stmt = $pdo->query("
        SELECT 
            DATE_FORMAT(data_hora, '%H:00') as hora,
            COUNT(CASE WHEN tipo_evento = 'login_sucesso' THEN 1 END) as logins_sucesso,
            COUNT(CASE WHEN tipo_evento LIKE 'login_falha_%' THEN 1 END) as logins_falha,
            COUNT(*) as total_eventos
        FROM registro_eventos 
        WHERE data_hora >= NOW() - INTERVAL 6 HOUR
        GROUP BY HOUR(data_hora)
        ORDER BY hora
    ");
    $estatisticasHora = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Distribuição de eventos
    $stmt = $pdo->query("
        SELECT 
            CASE 
                WHEN tipo_evento = 'login_sucesso' THEN 'Logins Sucesso'
                WHEN tipo_evento LIKE 'login_falha_%' THEN 'Logins Falha'
                WHEN tipo_evento = 'usuario_criado' THEN 'Usuários Criados'
                WHEN tipo_evento = 'logout' THEN 'Logouts'
                ELSE 'Outros Eventos'
            END as categoria,
            COUNT(*) as quantidade
        FROM registro_eventos 
        WHERE data_hora >= NOW() - INTERVAL 7 DAY
        GROUP BY categoria
        ORDER BY quantidade DESC
    ");
    $distribuicaoEventos = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Estatísticas gerais
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM usuarios");
    $totalUsuarios = $stmt->fetch()['total'];
    
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM registro_eventos");
    $totalEventos = $stmt->fetch()['total'];
    
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM registro_eventos WHERE tipo_evento = 'login_sucesso'");
    $loginSucesso = $stmt->fetch()['total'];
    
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM registro_eventos WHERE tipo_evento LIKE 'login_falha_%'");
    $loginFalhas = $stmt->fetch()['total'];
    
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM sessoes_ativas");
    $sessoesAtivas = $stmt->fetch()['total'];
    
    echo json_encode([
        'success' => true,
        'estatisticasHora' => $estatisticasHora,
        'distribuicaoEventos' => $distribuicaoEventos,
        'estatisticasGerais' => [
            'totalUsuarios' => $totalUsuarios,
            'totalEventos' => $totalEventos,
            'loginSucesso' => $loginSucesso,
            'loginFalhas' => $loginFalhas,
            'sessoesAtivas' => $sessoesAtivas
        ]
    ]);
    
} catch (Exception $e) {
    error_log("Erro ao carregar gráficos: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'error' => 'Erro ao carregar dados dos gráficos',
        'estatisticasHora' => [],
        'distribuicaoEventos' => []
    ]);
}
?>