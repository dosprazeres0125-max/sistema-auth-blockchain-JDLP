<?php
require_once __DIR__ . '/../includes/config.php';

// Reutilizar lógica de filtros da página principal (simplificado)
$filtroTipo = $_GET['tipo'] ?? '';
$filtroBusca = $_GET['busca'] ?? '';
$filtroDataInicio = $_GET['data_inicio'] ?? '';
$filtroDataFim = $_GET['data_fim'] ?? '';

$query = "SELECT re.*, u.nome_completo, u.email FROM registro_eventos re LEFT JOIN usuarios u ON re.id_usuario = u.id_usuario WHERE 1=1";
// (Adicionar filtros semelhantes ao principal - omitido por brevidade, copie da página principal)

$stmt = $pdo->prepare($query);
$stmt->execute();

header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename=eventos_seguranca_' . date('Y-m-d') . '.csv');

$output = fopen('php://output', 'w');
fputcsv($output, ['ID', 'Data/Hora', 'Tipo', 'Usuário', 'Email', 'IP', 'Status']);

while ($row = $stmt->fetch()) {
    $status = (strpos($row['tipo_evento'], 'SUCCESS') !== false) ? 'Sucesso' : 'Falha';
    fputcsv($output, [
        $row['id_evento'],
        $row['data_hora'],
        $row['tipo_evento'],
        $row['nome_completo'] ?? 'Desconhecido',
        $row['email'] ?? 'N/A',
        $row['ip_origem'],
        $status
    ]);
}
exit;
?>