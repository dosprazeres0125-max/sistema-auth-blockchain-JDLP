<?php
require_once '../includes/config.php';
require_once '../includes/funcoes-seguranca.php';

// Verificar se o usuário está logado
if (!isset($_SESSION['id_usuario']) || empty($_SESSION['id_usuario'])) {
    http_response_code(401);
    echo json_encode(['error' => 'Não autorizado']);
    exit;
}

// Obter a página solicitada
$pagina = $_GET['pagina'] ?? 'dashboard';

// Validar páginas permitidas
$paginasPermitidas = [
    'dashboard', 'eventos', 'mfa', 'usuarios', 
    'auditoria', 'relatorios', 'configuracoes',
    'perfil', 'seguranca', 'notificacoes'
];

if (!in_array($pagina, $paginasPermitidas)) {
    $pagina = 'dashboard';
}

// Mapear páginas para arquivos
$mapeamentoPaginas = [
    'dashboard' => 'dashboard.php',
    'eventos' => 'eventos.php',
    'mfa' => 'mfa.php',
    'usuarios' => 'usuarios.php',
    'auditoria' => 'auditoria.php',
    'relatorios' => 'relatorios.php',
    'configuracoes' => 'configuracoes.php',
    'perfil' => 'meuperfil.php',
    'seguranca' => 'seguranca.php',
    'notificacoes' => 'notificacoes.php'
];

// Determinar arquivo a ser carregado
$arquivoConteudo = isset($mapeamentoPaginas[$pagina]) ? $mapeamentoPaginas[$pagina] : 'dashboard.php';
$caminhoArquivo = "../conteudo/{$arquivoConteudo}";

// Verificar se o arquivo existe
if (!file_exists($caminhoArquivo)) {
    http_response_code(404);
    echo json_encode(['error' => 'Página não encontrada']);
    exit;
}

// Ler o conteúdo do arquivo
ob_start();
include $caminhoArquivo;
$conteudo = ob_get_clean();

// Retornar o conteúdo
echo $conteudo;
?>