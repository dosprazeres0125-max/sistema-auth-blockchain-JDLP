<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../../../includes/config.php';
require_once __DIR__ . '/../../../includes/funcoes-seguranca.php';

if (!isset($_SESSION['id_usuario']) || empty($_SESSION['id_usuario'])) {
    echo json_encode(['success' => false, 'message' => 'Sessão não autenticada']);
    exit;
}

$tipoUsuario = $_SESSION['tipo_usuario'] ?? '';
if ($tipoUsuario !== 'auditor') {
    echo json_encode(['success' => false, 'message' => 'Apenas auditores podem realizar auditoria completa']);
    exit;
}

try {
    $pdo = conectarBancoDados();

    // Executa o procedimento de verificação de integridade
    $pdo->exec("CALL verificar_integridade_blockchain()");

    // Verifica logs de corrupção recentes
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as total_criticos,
               GROUP_CONCAT(CONCAT('Evento #', SUBSTRING_INDEX(descricao, ': ', -1), ' - ', data_hora) SEPARATOR ' | ') as problemas
        FROM logs_seguranca
        WHERE tipo_log = 'blockchain_corrompida'
          AND data_hora >= DATE_SUB(NOW(), INTERVAL 15 MINUTE)
    ");
    $stmt->execute();
    $resultado = $stmt->fetch(PDO::FETCH_ASSOC);

    $totalCriticos = (int)$resultado['total_criticos'];

    if ($totalCriticos > 0) {
        echo json_encode([
            'success'  => false,
            'message'  => "Auditoria concluída. {$totalCriticos} problemas de integridade detectados.",
            'detalhes' => $resultado['problemas'] ?: 'Sem detalhes adicionais'
        ]);
    } else {
        echo json_encode([
            'success' => true,
            'message' => 'Auditoria completa realizada com sucesso. Blockchain íntegra no momento.'
        ]);
    }

} catch (Exception $e) {
    error_log("Erro ao realizar auditoria completa: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'Erro durante a execução da auditoria completa'
    ]);
}