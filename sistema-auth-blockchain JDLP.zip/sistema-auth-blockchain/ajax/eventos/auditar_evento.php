<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../../../includes/config.php';
require_once __DIR__ . '/../../../includes/funcoes-seguranca.php';

if (!isset($_SESSION['id_usuario']) || empty($_SESSION['id_usuario'])) {
    echo json_encode(['success' => false, 'message' => 'Sessão não autenticada']);
    exit;
}

$tipoUsuario = $_SESSION['tipo_usuario'] ?? '';
if ($tipoUsuario !== 'auditor') {
    echo json_encode(['success' => false, 'message' => 'Apenas auditores podem auditar eventos individualmente']);
    exit;
}

$idEvento = (int)($_POST['id_evento'] ?? 0);
if ($idEvento <= 0) {
    echo json_encode(['success' => false, 'message' => 'ID de evento inválido']);
    exit;
}

try {
    $pdo = conectarBancoDados();

    // Buscar dados relevantes do evento
    $stmt = $pdo->prepare("
        SELECT 
            tipo_evento,
            id_usuario,
            email_informado,
            ip_origem,
            user_agent,
            hash_transacao,
            hash_conteudo,
            hash_anterior,
            timestamp,
            bloco_hash,
            bloco_numero,
            data_hora
        FROM registro_eventos 
        WHERE id_evento = :id
        LIMIT 1
    ");
    $stmt->execute([':id' => $idEvento]);
    $evento = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$evento) {
        echo json_encode(['success' => false, 'message' => 'Evento não encontrado']);
        exit;
    }

    // Verificar consistência do hash da transação
    $hashCalculado = hash('sha256', $evento['hash_conteudo'] . ($evento['hash_anterior'] ?? '0') . $evento['timestamp']);
    $hashArmazenado = $evento['hash_transacao'];

    $valido = ($hashCalculado === $hashArmazenado);

    // Registrar log da auditoria
    $descricaoLog = "Auditoria manual realizada no evento #{$idEvento} ({$evento['tipo_evento']}) - " .
                    ($valido ? 'Hash válido' : 'Hash INVÁLIDO') .
                    " - Realizada por usuário ID {$_SESSION['id_usuario']} em " . date('d/m/Y H:i:s');

    $stmtLog = $pdo->prepare("
        INSERT INTO logs_seguranca 
        (tipo_log, id_usuario, severidade, descricao, ip_origem, user_agent, data_hora)
        VALUES 
        ('AUDITORIA_EVENTO_INDIVIDUAL', :id_usuario, 'media', :descricao, :ip, :ua, NOW())
    ");
    $stmtLog->execute([
        ':id_usuario' => $_SESSION['id_usuario'],
        ':descricao'  => $descricaoLog,
        ':ip'         => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
        ':ua'         => $_SERVER['HTTP_USER_AGENT'] ?? 'unknown'
    ]);

    echo json_encode([
        'success'         => $valido,
        'message'         => $valido 
            ? 'Evento auditado com sucesso – hash da transação íntegro'
            : 'Falha na auditoria – o hash da transação não confere com o conteúdo',
        'hash_calculado'  => $hashCalculado,
        'hash_armazenado' => $hashArmazenado,
        'tipo_evento'     => $evento['tipo_evento'],
        'data_hora'       => $evento['data_hora']
    ]);

} catch (Exception $e) {
    error_log("Erro ao auditar evento #{$idEvento}: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'Erro ao realizar auditoria do evento específico'
    ]);
}