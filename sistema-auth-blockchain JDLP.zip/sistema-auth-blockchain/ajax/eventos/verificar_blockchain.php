<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../../../includes/config.php';
require_once __DIR__ . '/../../../includes/funcoes-seguranca.php';

if (!isset($_SESSION['id_usuario']) || empty($_SESSION['id_usuario'])) {
    echo json_encode(['success' => false, 'message' => 'Sessão não autenticada']);
    exit;
}

$tipoUsuario = $_SESSION['tipo_usuario'] ?? '';
if (!in_array($tipoUsuario, ['admin', 'auditor'])) {
    echo json_encode(['success' => false, 'message' => 'Acesso negado']);
    exit;
}

$hashTransacao = $_POST['hash_transacao'] ?? '';
$idEvento      = (int)($_POST['id_evento'] ?? 0);

if (empty($hashTransacao) || $idEvento <= 0) {
    echo json_encode(['success' => false, 'message' => 'Parâmetros inválidos']);
    exit;
}

try {
    $pdo = conectarBancoDados();

    // Buscar dados do evento
    $stmt = $pdo->prepare("
        SELECT 
            hash_transacao,
            hash_anterior,
            hash_seguinte,
            hash_conteudo,
            timestamp,
            tipo_evento,
            data_hora,
            bloco_hash
        FROM registro_eventos 
        WHERE id_evento = :id AND hash_transacao = :hash
        LIMIT 1
    ");
    $stmt->execute([':id' => $idEvento, ':hash' => $hashTransacao]);
    $evento = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$evento) {
        echo json_encode(['success' => false, 'message' => 'Evento ou hash da transação não encontrado']);
        exit;
    }

    $integridade = true;
    $mensagem = "Transação verificada com sucesso";

    // 1. Verificar se o hash anterior existe (exceto genesis)
    if ($evento['hash_anterior'] && $evento['hash_anterior'] !== '0') {
        $stmtPrev = $pdo->prepare("
            SELECT id_evento 
            FROM registro_eventos 
            WHERE hash_transacao = :hash_anterior
            LIMIT 1
        ");
        $stmtPrev->execute([':hash_anterior' => $evento['hash_anterior']]);
        if (!$stmtPrev->fetch()) {
            $integridade = false;
            $mensagem = "Hash anterior não encontrado na cadeia – possível quebra de integridade";
        }
    }

    // 2. Verificar se o hash da transação foi calculado corretamente
    $hashCalculado = hash('sha256', $evento['hash_conteudo'] . ($evento['hash_anterior'] ?? '0') . $evento['timestamp']);
    if ($hashCalculado !== $evento['hash_transacao']) {
        $integridade = false;
        $mensagem = "Hash da transação não confere com o conteúdo e hash anterior";
    }

    echo json_encode([
        'success'        => $integridade,
        'message'        => $mensagem,
        'evento_id'      => $idEvento,
        'tipo_evento'    => $evento['tipo_evento'],
        'data_hora'      => $evento['data_hora'],
        'hash_transacao' => $evento['hash_transacao']
    ]);

} catch (Exception $e) {
    error_log("Erro ao verificar blockchain do evento #{$idEvento}: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'Erro ao verificar integridade da transação'
    ]);
}