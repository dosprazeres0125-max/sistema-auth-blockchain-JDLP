<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../../../includes/config.php';
require_once __DIR__ . '/../../../includes/funcoes-seguranca.php';

if (!isset($_SESSION['id_usuario']) || empty($_SESSION['id_usuario'])) {
    echo json_encode(['success' => false, 'message' => 'Sessão não autenticada']);
    exit;
}

$tipoUsuario = $_SESSION['tipo_usuario'] ?? '';
if (!in_array($tipoUsuario, ['admin', 'auditor'])) {
    echo json_encode(['success' => false, 'message' => 'Acesso negado']);
    exit;
}

try {
    $pdo = conectarBancoDados();

    // Executa verificação completa
    $pdo->exec("CALL verificar_integridade_blockchain()");

    // Consulta logs recentes de corrupção
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as total,
               GROUP_CONCAT(CONCAT('Evento #', SUBSTRING_INDEX(descricao, ': ', -1), ' - ', data_hora) SEPARATOR ' | ') as detalhes
        FROM logs_seguranca
        WHERE tipo_log = 'blockchain_corrompida'
          AND data_hora >= DATE_SUB(NOW(), INTERVAL 30 MINUTE)
    ");
    $stmt->execute();
    $resultado = $stmt->fetch(PDO::FETCH_ASSOC);

    $totalProblemas = (int)$resultado['total'];

    if ($totalProblemas > 0) {
        echo json_encode([
            'success'  => false,
            'message'  => "Integridade comprometida. {$totalProblemas} problemas detectados.",
            'detalhes' => $resultado['detalhes'] ?: 'Nenhum detalhe adicional'
        ]);
    } else {
        echo json_encode([
            'success' => true,
            'message' => 'Verificação concluída. Todos os blocos e transações estão íntegros.'
        ]);
    }

} catch (Exception $e) {
    error_log("Erro ao verificar integridade da blockchain: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'Erro ao executar verificação completa da blockchain'
    ]);
}