<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../../../includes/config.php';
require_once __DIR__ . '/../../../includes/funcoes-seguranca.php';

if (!isset($_SESSION['id_usuario']) || empty($_SESSION['id_usuario'])) {
    echo json_encode(['success' => false, 'message' => 'Sessão não autenticada']);
    exit;
}

$tipoUsuario = $_SESSION['tipo_usuario'] ?? '';
if (!in_array($tipoUsuario, ['admin', 'auditor'])) {
    echo json_encode(['success' => false, 'message' => 'Acesso negado']);
    exit;
}

$idEvento = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($idEvento <= 0) {
    echo json_encode(['success' => false, 'message' => 'ID de evento inválido']);
    exit;
}

try {
    $pdo = conectarBancoDados();

    $sql = "
        SELECT 
            re.id_evento,
            re.tipo_evento,
            re.id_usuario,
            re.email_hash,
            re.email_informado,
            re.ip_origem,
            re.user_agent,
            re.hash_transacao,
            re.hash_conteudo,
            re.hash_anterior,
            re.hash_seguinte,
            re.bloco_numero,
            re.bloco_hash,
            re.timestamp,
            re.data_hora,
            re.dados_auditoria,
            u.nome_completo,
            u.email AS usuario_email,
            u.tipo_usuario,
            bb.bloco_hash_anterior,
            bb.hash_merkle_root,
            bb.nonce,
            bb.dificuldade,
            bb.timestamp_criacao AS bloco_timestamp_criacao,
            bb.numero_transacoes AS bloco_numero_transacoes
        FROM registro_eventos re
        LEFT JOIN usuarios u ON re.id_usuario = u.id_usuario
        LEFT JOIN blocos_blockchain bb ON re.bloco_hash = bb.bloco_hash
        WHERE re.id_evento = :id
        LIMIT 1
    ";

    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':id', $idEvento, PDO::PARAM_INT);
    $stmt->execute();

    $evento = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$evento) {
        echo json_encode(['success' => false, 'message' => 'Evento não encontrado']);
        exit;
    }

    // Formatações úteis para exibição no modal
    $evento['data_hora_formatada']       = date('d/m/Y H:i:s', strtotime($evento['data_hora']));
    $evento['timestamp_formatado']        = date('d/m/Y H:i:s', $evento['timestamp']);
    $evento['bloco_timestamp_formatado']  = $evento['bloco_timestamp_criacao'] ? date('d/m/Y H:i:s', $evento['bloco_timestamp_criacao']) : 'N/A';

    echo json_encode([
        'success' => true,
        'evento'  => $evento
    ]);

} catch (Exception $e) {
    error_log("Erro ao obter detalhes do evento #{$idEvento}: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'Erro interno ao carregar os detalhes do evento'
    ]);
}