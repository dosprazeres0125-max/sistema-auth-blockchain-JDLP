<?php
session_start();
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/funcoes-seguranca.php';

header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['id_usuario']) || $_SESSION['tipo_usuario'] !== 'admin') {
    echo json_encode(['success' => false, 'error' => 'Permissão negada']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'error' => 'Método inválido']);
    exit;
}

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) {
    echo json_encode(['success' => false, 'error' => 'ID inválido']);
    exit;
}

$nome_completo = trim($_POST['nome_completo'] ?? '');
$email         = trim($_POST['email'] ?? '');
$tipo_usuario  = $_POST['tipo_usuario'] ?? 'user';
$ativo         = isset($_POST['ativo']) ? 1 : 0;
$nova_senha    = $_POST['nova_senha'] ?? '';

if (empty($nome_completo) || empty($email)) {
    echo json_encode(['success' => false, 'error' => 'Campos obrigatórios não preenchidos']);
    exit;
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(['success' => false, 'error' => 'Email inválido']);
    exit;
}

$pdo = conectarBancoDados();

// Verificar se email pertence a outro usuário
$stmt = $pdo->prepare("SELECT id_usuario FROM usuarios WHERE email = ? AND id_usuario != ?");
$stmt->execute([$email, $id]);
if ($stmt->fetch()) {
    echo json_encode(['success' => false, 'error' => 'Este email já está em uso por outro usuário']);
    exit;
}

$campos = [
    'nome_completo = ?',
    'email = ?',
    'email_hash = SHA2(?, 256)',
    'tipo_usuario = ?',
    'ativo = ?'
];
$valores = [$nome_completo, $email, $email, $tipo_usuario, $ativo];

if (!empty($nova_senha)) {
    if (strlen($nova_senha) < 8) {
        echo json_encode(['success' => false, 'error' => 'A nova senha deve ter pelo menos 8 caracteres']);
        exit;
    }
    $campos[] = 'senha_hash = ?';
    $valores[] = password_hash($nova_senha, PASSWORD_DEFAULT);
}

$camposSql = implode(', ', $campos);
$valores[] = $id;

try {
    $pdo->beginTransaction();

    $stmt = $pdo->prepare("UPDATE usuarios SET $camposSql WHERE id_usuario = ?");
    $stmt->execute($valores);

    registrarEventoBlockchain(
        'USER_UPDATED',
        $id,
        $email,
        obterIPCliente(),
        $_SERVER['HTTP_USER_AGENT'] ?? 'desconhecido'
    );

    $pdo->commit();

    echo json_encode(['success' => true, 'message' => 'Usuário atualizado com sucesso']);

} catch (Exception $e) {
    $pdo->rollBack();
    error_log("Erro ao atualizar usuário: " . $e->getMessage());
    echo json_encode(['success' => false, 'error' => 'Erro interno ao atualizar']);
}
exit;