<?php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/funcoes-seguranca.php';

// Verificar autenticação
if (!isset($_SESSION['id_usuario'])) {
    http_response_code(401);
    die('Não autenticado');
}

try {
    $pdo = conectarBancoDados();
    
    // Dados do usuário
    $stmt = $pdo->prepare("
        SELECT 
            id_usuario,
            nome_completo,
            email,
            tipo_usuario,
            data_criacao,
            data_ultimo_login,
            data_ultima_atividade,
            ultimo_ip
        FROM usuarios 
        WHERE id_usuario = ?
    ");
    $stmt->execute([$_SESSION['id_usuario']]);
    $dadosUsuario = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Eventos do usuário (últimos 100)
    $stmt = $pdo->prepare("
        SELECT 
            tipo_evento,
            email_informado,
            ip_origem,
            user_agent,
            data_hora
        FROM registro_eventos 
        WHERE id_usuario = ?
        ORDER BY data_hora DESC
        LIMIT 100
    ");
    $stmt->execute([$_SESSION['id_usuario']]);
    $eventos = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Sessões ativas
    $stmt = $pdo->prepare("
        SELECT 
            id_sessao,
            ip,
            user_agent,
            data_inicio,
            data_ultima_atividade,
            expiracao
        FROM sessoes_ativas 
        WHERE id_usuario = ?
        ORDER BY data_ultima_atividade DESC
    ");
    $stmt->execute([$_SESSION['id_usuario']]);
    $sessoes = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Notificações
    $stmt = $pdo->prepare("
        SELECT 
            tipo_notificacao,
            titulo,
            mensagem,
            data_criacao,
            data_leitura
        FROM notificacoes_sistema 
        WHERE id_usuario = ?
        ORDER BY data_criacao DESC
    ");
    $stmt->execute([$_SESSION['id_usuario']]);
    $notificacoes = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $dadosExportacao = [
        'metadata' => [
            'exportado_em' => date('Y-m-d H:i:s'),
            'id_usuario' => $_SESSION['id_usuario'],
            'formato' => 'JSON'
        ],
        'dados_pessoais' => $dadosUsuario,
        'eventos_recentes' => $eventos,
        'sessoes' => $sessoes,
        'notificacoes' => $notificacoes
    ];
    
    // Gerar arquivo JSON
    $json = json_encode($dadosExportacao, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    
    // Registrar evento de exportação
    registrarEventoBlockchain(
        'EXPORTACAO_DADOS',
        $_SESSION['id_usuario'],
        $_SESSION['email'] ?? '',
        obterIPCliente(),
        $_SERVER['HTTP_USER_AGENT'] ?? 'Desconhecido'
    );
    
    // Enviar como download
    header('Content-Type: application/json');
    header('Content-Disposition: attachment; filename="dados_pessoais_' . date('Y-m-d') . '.json"');
    header('Content-Length: ' . strlen($json));
    echo $json;
    
} catch (Exception $e) {
    error_log("Erro ao exportar dados: " . $e->getMessage());
    http_response_code(500);
    echo 'Erro ao exportar dados';
}
?>