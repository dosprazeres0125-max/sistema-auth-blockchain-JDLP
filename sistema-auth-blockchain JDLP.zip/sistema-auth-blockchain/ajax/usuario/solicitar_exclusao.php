<?php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/funcoes-seguranca.php';

// Verificar autenticação
if (!isset($_SESSION['id_usuario'])) {
    http_response_code(401);
    die(json_encode(['success' => false, 'error' => 'Não autenticado']));
}

// Verificar token CSRF
$data = json_decode(file_get_contents('php://input'), true);
if (!isset($data['token_csrf']) || !verificarTokenCSRF($data['token_csrf'])) {
    http_response_code(403);
    die(json_encode(['success' => false, 'error' => 'Token CSRF inválido']));
}

try {
    $pdo = conectarBancoDados();
    
    // Registrar solicitação nos logs
    $descricao = "Usuário " . $_SESSION['nome_completo'] . " (ID: " . $_SESSION['id_usuario'] . ") solicitou exclusão da conta.";
    
    $stmt = $pdo->prepare("
        INSERT INTO logs_seguranca (tipo_log, id_usuario, severidade, descricao, ip_origem, user_agent)
        VALUES ('solicitacao_exclusao_conta', ?, 'alta', ?, ?, ?)
    ");
    $stmt->execute([
        $_SESSION['id_usuario'],
        $descricao,
        obterIPCliente(),
        $_SERVER['HTTP_USER_AGENT'] ?? 'Desconhecido'
    ]);
    
    // Registrar evento
    registrarEventoBlockchain(
        'SOLICITACAO_EXCLUSAO_CONTA',
        $_SESSION['id_usuario'],
        $_SESSION['email'] ?? '',
        obterIPCliente(),
        $_SERVER['HTTP_USER_AGENT'] ?? 'Desconhecido'
    );
    
    // Criar notificação para administradores
    $mensagem = "Usuário " . $_SESSION['nome_completo'] . " (" . $_SESSION['email'] . ") solicitou exclusão da conta.";
    
    $stmt = $pdo->prepare("
        INSERT INTO notificacoes_sistema (id_usuario, tipo_notificacao, titulo, mensagem)
        SELECT id_usuario, 'exclusao_conta', 'Solicitação de Exclusão', ? 
        FROM usuarios 
        WHERE tipo_usuario = 'admin' AND ativo = 1
    ");
    $stmt->execute([$mensagem]);
    
    echo json_encode([
        'success' => true, 
        'message' => 'Solicitação de exclusão registrada. Um administrador entrará em contato.'
    ]);
    
} catch (Exception $e) {
    error_log("Erro ao solicitar exclusão: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Erro interno do servidor']);
}
?>

