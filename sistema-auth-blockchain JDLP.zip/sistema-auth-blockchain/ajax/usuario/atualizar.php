<?php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/funcoes-seguranca.php';

// Verificar autenticação
if (!isset($_SESSION['id_usuario'])) {
    http_response_code(401);
    die(json_encode(['success' => false, 'error' => 'Não autenticado']));
}

// Verificar token CSRF
$data = json_decode(file_get_contents('php://input'), true);
if (!isset($data['token_csrf']) || !verificarTokenCSRF($data['token_csrf'])) {
    http_response_code(403);
    die(json_encode(['success' => false, 'error' => 'Token CSRF inválido']));
}

// Validar dados
if (empty($data['nome_completo']) || empty($data['email'])) {
    http_response_code(400);
    die(json_encode(['success' => false, 'error' => 'Nome e email são obrigatórios']));
}

if (!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    die(json_encode(['success' => false, 'error' => 'Email inválido']));
}

try {
    $pdo = conectarBancoDados();
    
    // Verificar se email já existe (exceto para o próprio usuário)
    $stmt = $pdo->prepare("SELECT id_usuario FROM usuarios WHERE email = ? AND id_usuario != ?");
    $stmt->execute([$data['email'], $_SESSION['id_usuario']]);
    if ($stmt->fetch()) {
        http_response_code(409);
        die(json_encode(['success' => false, 'error' => 'Este email já está em uso']));
    }
    
    // Atualizar dados
    $stmt = $pdo->prepare("UPDATE usuarios SET nome_completo = ?, email = ? WHERE id_usuario = ?");
    $stmt->execute([$data['nome_completo'], $data['email'], $_SESSION['id_usuario']]);
    
    // Atualizar sessão
    $_SESSION['nome_completo'] = $data['nome_completo'];
    $_SESSION['email'] = $data['email'];
    
    // Registrar evento
    registrarEventoBlockchain(
        'PERFIL_ATUALIZADO',
        $_SESSION['id_usuario'],
        $data['email'],
        obterIPCliente(),
        $_SERVER['HTTP_USER_AGENT'] ?? 'Desconhecido'
    );
    
    echo json_encode(['success' => true, 'message' => 'Informações atualizadas com sucesso']);
    
} catch (Exception $e) {
    error_log("Erro ao atualizar usuário: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Erro interno do servidor']);
}
?>