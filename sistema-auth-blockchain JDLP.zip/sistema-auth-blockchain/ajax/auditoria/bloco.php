<?php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/funcoes-seguranca.php';

// Verificar autenticação e permissões
if (!isset($_SESSION['id_usuario'])) {
    http_response_code(401);
    die(json_encode(['success' => false, 'error' => 'Não autenticado']));
}

$tipoUsuario = $_SESSION['tipo_usuario'] ?? '';
if (!in_array($tipoUsuario, ['admin', 'auditor'])) {
    http_response_code(403);
    die(json_encode(['success' => false, 'error' => 'Acesso negado']));
}

// Obter ID do bloco
$idBloco = $_GET['id'] ?? 0;
if (!is_numeric($idBloco) || $idBloco <= 0) {
    http_response_code(400);
    die(json_encode(['success' => false, 'error' => 'ID do bloco inválido']));
}

try {
    $pdo = conectarBancoDados();
    
    // Buscar detalhes do bloco
    $queryBloco = "
        SELECT 
            id_bloco,
            bloco_hash,
            bloco_hash_anterior,
            hash_merkle_root,
            nonce,
            dificuldade,
            timestamp_criacao,
            numero_transacoes,
            data_hora,
            dados_bloco,
            assinatura_digital
        FROM blocos_blockchain 
        WHERE id_bloco = :id_bloco
    ";
    
    $stmtBloco = $pdo->prepare($queryBloco);
    $stmtBloco->execute([':id_bloco' => $idBloco]);
    $bloco = $stmtBloco->fetch(PDO::FETCH_ASSOC);
    
    if (!$bloco) {
        die(json_encode(['success' => false, 'error' => 'Bloco não encontrado']));
    }
    
    // Buscar eventos deste bloco
    $queryEventos = "
        SELECT 
            id_evento,
            tipo_evento,
            id_usuario,
            email_informado,
            ip_origem,
            data_hora,
            hash_transacao,
            timestamp
        FROM registro_eventos 
        WHERE bloco_hash = :bloco_hash
        ORDER BY data_hora DESC
        LIMIT 50
    ";
    
    $stmtEventos = $pdo->prepare($queryEventos);
    $stmtEventos->execute([':bloco_hash' => $bloco['bloco_hash']]);
    $eventos = $stmtEventos->fetchAll(PDO::FETCH_ASSOC);
    
    // Estatísticas dos eventos
    $queryEstatisticas = "
        SELECT 
            COUNT(*) as total_eventos,
            COUNT(DISTINCT id_usuario) as usuarios_unicos,
            COUNT(DISTINCT ip_origem) as ips_unicos,
            MIN(data_hora) as primeiro_evento,
            MAX(data_hora) as ultimo_evento
        FROM registro_eventos 
        WHERE bloco_hash = :bloco_hash
    ";
    
    $stmtEstatisticas = $pdo->prepare($queryEstatisticas);
    $stmtEstatisticas->execute([':bloco_hash' => $bloco['bloco_hash']]);
    $estatisticas = $stmtEstatisticas->fetch(PDO::FETCH_ASSOC);
    
    // Buscar bloco anterior (se existir)
    $blocoAnterior = null;
    if ($bloco['bloco_hash_anterior']) {
        $queryAnterior = "
            SELECT id_bloco, bloco_hash, numero_transacoes, timestamp_criacao
            FROM blocos_blockchain 
            WHERE bloco_hash = :hash_anterior
        ";
        
        $stmtAnterior = $pdo->prepare($queryAnterior);
        $stmtAnterior->execute([':hash_anterior' => $bloco['bloco_hash_anterior']]);
        $blocoAnterior = $stmtAnterior->fetch(PDO::FETCH_ASSOC);
    }
    
    // Buscar bloco seguinte (se existir)
    $querySeguinte = "
        SELECT id_bloco, bloco_hash, numero_transacoes, timestamp_criacao
        FROM blocos_blockchain 
        WHERE bloco_hash_anterior = :bloco_hash_atual
    ";
    
    $stmtSeguinte = $pdo->prepare($querySeguinte);
    $stmtSeguinte->execute([':bloco_hash_atual' => $bloco['bloco_hash']]);
    $blocoSeguinte = $stmtSeguinte->fetch(PDO::FETCH_ASSOC);
    
    // Verificar validade do hash do bloco
    $hashCalculado = hash('sha256', 
        $bloco['bloco_hash_anterior'] . 
        $bloco['hash_merkle_root'] . 
        $bloco['nonce'] . 
        $bloco['timestamp_criacao']
    );
    
    $hashValido = ($hashCalculado === $bloco['bloco_hash']);
    
    // Tipos de eventos no bloco
    $queryTiposEventos = "
        SELECT 
            tipo_evento,
            COUNT(*) as quantidade
        FROM registro_eventos 
        WHERE bloco_hash = :bloco_hash
        GROUP BY tipo_evento
        ORDER BY quantidade DESC
    ";
    
    $stmtTipos = $pdo->prepare($queryTiposEventos);
    $stmtTipos->execute([':bloco_hash' => $bloco['bloco_hash']]);
    $tiposEventos = $stmtTipos->fetchAll(PDO::FETCH_ASSOC);
    
    $resultado = [
        'success' => true,
        'bloco' => $bloco,
        'estatisticas' => $estatisticas,
        'eventos' => $eventos,
        'bloco_anterior' => $blocoAnterior,
        'bloco_seguinte' => $blocoSeguinte,
        'hash_valido' => $hashValido,
        'hash_calculado' => $hashValido ? null : $hashCalculado,
        'tipos_eventos' => $tiposEventos,
        'timestamp_formatado' => date('d/m/Y H:i:s', $bloco['timestamp_criacao']),
        'data_hora_formatada' => date('d/m/Y H:i:s', strtotime($bloco['data_hora']))
    ];
    
    // Tentar decodificar dados do bloco se existirem
    if (!empty($bloco['dados_bloco'])) {
        $dadosJson = json_decode($bloco['dados_bloco'], true);
        if ($dadosJson) {
            $resultado['dados_bloco_decodificado'] = $dadosJson;
        }
    }
    
    header('Content-Type: application/json');
    echo json_encode($resultado);
    
} catch (Exception $e) {
    error_log("Erro ao buscar detalhes do bloco: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Erro interno do servidor']);
}
?>