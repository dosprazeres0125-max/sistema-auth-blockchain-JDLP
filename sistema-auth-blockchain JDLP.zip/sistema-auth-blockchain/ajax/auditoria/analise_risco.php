<?php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/funcoes-seguranca.php';

// Verificar autenticação e permissões
if (!isset($_SESSION['id_usuario'])) {
    http_response_code(401);
    die(json_encode(['success' => false, 'error' => 'Não autenticado']));
}

$tipoUsuario = $_SESSION['tipo_usuario'] ?? '';
if (!in_array($tipoUsuario, ['admin', 'auditor'])) {
    http_response_code(403);
    die(json_encode(['success' => false, 'error' => 'Acesso negado']));
}

try {
    $pdo = conectarBancoDados();
    $pontuacao = 100; // Começa com 100 pontos, subtrai por problemas
    $pontosFortes = [];
    $recomendacoes = [];
    
    // 1. Analisar tentativas falhas recentes
    $queryTentativas = "
        SELECT 
            COUNT(*) as tentativas_24h,
            COUNT(DISTINCT ip_origem) as ips_unicos_24h,
            COUNT(DISTINCT email_informado) as emails_unicos_24h
        FROM registro_eventos 
        WHERE (tipo_evento LIKE '%FAILED%' OR tipo_evento LIKE '%FALHO%')
        AND data_hora >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
    ";
    
    $stmtTentativas = $pdo->query($queryTentativas);
    $tentativas = $stmtTentativas->fetch(PDO::FETCH_ASSOC);
    
    if ($tentativas['tentativas_24h'] > 20) {
        $pontuacao -= 10;
        $recomendacoes[] = 'Muitas tentativas falhas nas últimas 24h (' . $tentativas['tentativas_24h'] . ')';
    } elseif ($tentativas['tentativas_24h'] < 5) {
        $pontosFortes[] = 'Poucas tentativas falhas nas últimas 24h';
    }
    
    // 2. Verificar usuários bloqueados
    $queryBloqueados = "
        SELECT COUNT(*) as usuarios_bloqueados
        FROM usuarios 
        WHERE bloqueado_ate IS NOT NULL 
        AND bloqueado_ate > NOW()
    ";
    
    $stmtBloqueados = $pdo->query($queryBloqueados);
    $bloqueados = $stmtBloqueados->fetch(PDO::FETCH_ASSOC);
    
    if ($bloqueados['usuarios_bloqueados'] > 3) {
        $pontuacao -= 5;
        $recomendacoes[] = $bloqueados['usuarios_bloqueados'] . ' usuários bloqueados atualmente';
    } elseif ($bloqueados['usuarios_bloqueados'] == 0) {
        $pontosFortes[] = 'Nenhum usuário bloqueado no momento';
    }
    
    // 3. Verificar integridade blockchain
    $queryBlockchain = "
        SELECT 
            COUNT(*) as total_blocos,
            SUM(CASE WHEN bloco_hash_anterior IS NULL THEN 1 ELSE 0 END) as blocos_genesis,
            SUM(CASE WHEN numero_transacoes = 0 THEN 1 ELSE 0 END) as blocos_vazios
        FROM blocos_blockchain
    ";
    
    $stmtBlockchain = $pdo->query($queryBlockchain);
    $blockchain = $stmtBlockchain->fetch(PDO::FETCH_ASSOC);
    
    if ($blockchain['blocos_vazios'] > 2) {
        $pontuacao -= 8;
        $recomendacoes[] = $blockchain['blocos_vazios'] . ' blocos vazios na blockchain';
    }
    
    if ($blockchain['total_blocos'] > 1) {
        $pontosFortes[] = 'Blockchain ativa com ' . $blockchain['total_blocos'] . ' blocos';
    }
    
    // 4. Verificar logs críticos recentes
    $queryLogsCriticos = "
        SELECT COUNT(*) as logs_criticos_24h
        FROM logs_seguranca 
        WHERE severidade IN ('alta', 'critica')
        AND data_hora >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
    ";
    
    $stmtLogsCriticos = $pdo->query($queryLogsCriticos);
    $logsCriticos = $stmtLogsCriticos->fetch(PDO::FETCH_ASSOC);
    
    if ($logsCriticos['logs_criticos_24h'] > 5) {
        $pontuacao -= 15;
        $recomendacoes[] = $logsCriticos['logs_criticos_24h'] . ' logs críticos nas últimas 24h';
    } elseif ($logsCriticos['logs_criticos_24h'] == 0) {
        $pontosFortes[] = 'Nenhum log crítico nas últimas 24h';
    }
    
    // 5. Verificar sessões expiradas
    $querySessoesExpiradas = "
        SELECT COUNT(*) as sessoes_expiradas
        FROM sessoes_ativas 
        WHERE expiracao < NOW()
    ";
    
    $stmtSessoesExpiradas = $pdo->query($querySessoesExpiradas);
    $sessoesExpiradas = $stmtSessoesExpiradas->fetch(PDO::FETCH_ASSOC);
    
    if ($sessoesExpiradas['sessoes_expiradas'] > 10) {
        $pontuacao -= 7;
        $recomendacoes[] = $sessoesExpiradas['sessoes_expiradas'] . ' sessões expiradas para limpar';
    }
    
    // 6. Verificar MFA desativado
    $queryMFADesativado = "
        SELECT COUNT(*) as usuarios_sem_mfa
        FROM usuarios 
        WHERE (mfa_codigo_hash IS NULL OR mfa_codigo_hash = '')
        AND tipo_usuario IN ('admin', 'auditor')
        AND ativo = 1
    ";
    
    $stmtMFADesativado = $pdo->query($queryMFADesativado);
    $mfaDesativado = $stmtMFADesativado->fetch(PDO::FETCH_ASSOC);
    
    if ($mfaDesativado['usuarios_sem_mfa'] > 0) {
        $pontuacao -= 12;
        $recomendacoes[] = $mfaDesativado['usuarios_sem_mfa'] . ' administradores/auditores sem MFA ativo';
    } else {
        $pontosFortes[] = 'Todos administradores/auditores com MFA ativo';
    }
    
    // 7. Verificar atividades suspeitas por IP
    $queryIPsSuspeitos = "
        SELECT 
            ip_origem,
            COUNT(*) as tentativas,
            COUNT(DISTINCT email_informado) as emails_distintos
        FROM registro_eventos 
        WHERE tipo_evento LIKE '%FAILED%' 
        AND data_hora >= DATE_SUB(NOW(), INTERVAL 1 HOUR)
        GROUP BY ip_origem
        HAVING COUNT(*) > 5
    ";
    
    $stmtIPsSuspeitos = $pdo->query($queryIPsSuspeitos);
    $ipsSuspeitos = $stmtIPsSuspeitos->fetchAll(PDO::FETCH_ASSOC);
    
    if (count($ipsSuspeitos) > 0) {
        $pontuacao -= 20;
        foreach ($ipsSuspeitos as $ip) {
            $recomendacoes[] = 'IP suspeito: ' . $ip['ip_origem'] . ' - ' . $ip['tentativas'] . ' tentativas falhas em 1h';
        }
    }
    
    // 8. Verificar tempo desde último backup
    $queryUltimoBackup = "
        SELECT MAX(data_criacao) as ultimo_backup
        FROM backup_codigos_mfa
        WHERE data_criacao >= DATE_SUB(NOW(), INTERVAL 7 DAY)
    ";
    
    $stmtUltimoBackup = $pdo->query($queryUltimoBackup);
    $ultimoBackup = $stmtUltimoBackup->fetch(PDO::FETCH_ASSOC);
    
    if (!$ultimoBackup['ultimo_backup']) {
        $pontuacao -= 10;
        $recomendacoes[] = 'Nenhum backup de códigos MFA nos últimos 7 dias';
    } else {
        $pontosFortes[] = 'Backup de códigos MFA realizado recentemente';
    }
    
    // Determinar nível de risco
    if ($pontuacao >= 90) {
        $nivelRisco = 'baixo';
        $cor = 'success';
    } elseif ($pontuacao >= 70) {
        $nivelRisco = 'medio';
        $cor = 'warning';
    } else {
        $nivelRisco = 'alto';
        $cor = 'danger';
    }
    
    // Garantir pontuação mínima
    $pontuacao = max(0, $pontuacao);
    
    $response = [
        'success' => true,
        'nivel_risco' => $nivelRisco,
        'cor' => $cor,
        'pontuacao' => $pontuacao,
        'pontos_fortes' => $pontosFortes,
        'recomendacoes' => array_unique($recomendacoes),
        'metricas' => [
            'tentativas_falhas_24h' => $tentativas['tentativas_24h'],
            'usuarios_bloqueados' => $bloqueados['usuarios_bloqueados'],
            'logs_criticos_24h' => $logsCriticos['logs_criticos_24h'],
            'sessoes_expiradas' => $sessoesExpiradas['sessoes_expiradas'],
            'administradores_sem_mfa' => $mfaDesativado['usuarios_sem_mfa'],
            'ips_suspeitos' => count($ipsSuspeitos)
        ]
    ];
    
    header('Content-Type: application/json');
    echo json_encode($response);
    
} catch (Exception $e) {
    error_log("Erro na análise de risco: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Erro interno do servidor']);
}
?>