<?php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/funcoes-seguranca.php';

// Verificar autenticação e permissões
if (!isset($_SESSION['id_usuario'])) {
    http_response_code(401);
    die('Não autenticado');
}

$tipoUsuario = $_SESSION['tipo_usuario'] ?? '';
if (!in_array($tipoUsuario, ['admin', 'auditor'])) {
    http_response_code(403);
    die('Acesso negado');
}

try {
    $pdo = conectarBancoDados();
    
    // Dados para o relatório
    $dadosRelatorio = [
        'metadata' => [
            'titulo' => 'Relatório de Auditoria do Sistema',
            'data_geracao' => date('d/m/Y H:i:s'),
            'periodo' => 'Completo',
            'gerado_por' => $_SESSION['nome_completo'] ?? 'Sistema',
            'tipo_usuario' => $tipoUsuario
        ],
        'estatisticas' => [],
        'analises' => []
    ];
    
    // 1. Estatísticas gerais
    $queryEstatisticas = "SELECT * FROM view_estatisticas_sistema";
    $stmtEstatisticas = $pdo->query($queryEstatisticas);
    $dadosRelatorio['estatisticas']['gerais'] = $stmtEstatisticas->fetch(PDO::FETCH_ASSOC);
    
    // 2. Eventos por tipo
    $queryEventosTipo = "
        SELECT tipo_evento, COUNT(*) as total 
        FROM registro_eventos 
        GROUP BY tipo_evento 
        ORDER BY total DESC
    ";
    $stmtEventosTipo = $pdo->query($queryEventosTipo);
    $dadosRelatorio['estatisticas']['eventos_por_tipo'] = $stmtEventosTipo->fetchAll(PDO::FETCH_ASSOC);
    
    // 3. Usuários mais ativos
    $queryUsuariosAtivos = "
        SELECT 
            u.nome_completo,
            u.email,
            u.tipo_usuario,
            COUNT(re.id_evento) as total_eventos
        FROM usuarios u
        LEFT JOIN registro_eventos re ON u.id_usuario = re.id_usuario
        WHERE u.ativo = 1
        GROUP BY u.id_usuario, u.nome_completo, u.email, u.tipo_usuario
        HAVING COUNT(re.id_evento) > 0
        ORDER BY total_eventos DESC
        LIMIT 10
    ";
    $stmtUsuariosAtivos = $pdo->query($queryUsuariosAtivos);
    $dadosRelatorio['estatisticas']['usuarios_ativos'] = $stmtUsuariosAtivos->fetchAll(PDO::FETCH_ASSOC);
    
    // 4. Blocos da blockchain
    $queryBlocos = "SELECT * FROM view_blockchain_resumo ORDER BY id_bloco DESC LIMIT 10";
    $stmtBlocos = $pdo->query($queryBlocos);
    $dadosRelatorio['estatisticas']['blocos_recentes'] = $stmtBlocos->fetchAll(PDO::FETCH_ASSOC);
    
    // 5. Tentativas falhas recentes
    $queryTentativas = "
        SELECT 
            re.tipo_evento,
            re.email_informado,
            re.ip_origem,
            re.data_hora,
            u.nome_completo
        FROM registro_eventos re
        LEFT JOIN usuarios u ON re.email_informado = u.email
        WHERE re.tipo_evento LIKE '%FAILED%' OR re.tipo_evento LIKE '%FALHO%'
        AND re.data_hora >= DATE_SUB(NOW(), INTERVAL 7 DAY)
        ORDER BY re.data_hora DESC
        LIMIT 20
    ";
    $stmtTentativas = $pdo->query($queryTentativas);
    $dadosRelatorio['estatisticas']['tentativas_falhas'] = $stmtTentativas->fetchAll(PDO::FETCH_ASSOC);
    
    // 6. Logs críticos recentes
    $queryLogsCriticos = "
        SELECT 
            tipo_log,
            severidade,
            descricao,
            ip_origem,
            data_hora
        FROM logs_seguranca 
        WHERE severidade IN ('alta', 'critica')
        AND data_hora >= DATE_SUB(NOW(), INTERVAL 7 DAY)
        ORDER BY data_hora DESC
    ";
    $stmtLogsCriticos = $pdo->query($queryLogsCriticos);
    $dadosRelatorio['estatisticas']['logs_criticos'] = $stmtLogsCriticos->fetchAll(PDO::FETCH_ASSOC);
    
    // 7. Análise de risco básica
    $pontuacao = 100;
    $recomendacoes = [];
    
    // Verificar sessões expiradas
    $querySessoesExpiradas = "SELECT COUNT(*) as total FROM sessoes_ativas WHERE expiracao < NOW()";
    $sessoesExpiradas = $pdo->query($querySessoesExpiradas)->fetchColumn();
    if ($sessoesExpiradas > 0) {
        $pontuacao -= 10;
        $recomendacoes[] = "Limpar $sessoesExpiradas sessões expiradas";
    }
    
    // Verificar usuários bloqueados
    $queryUsuariosBloqueados = "SELECT COUNT(*) as total FROM usuarios WHERE bloqueado_ate > NOW()";
    $usuariosBloqueados = $pdo->query($queryUsuariosBloqueados)->fetchColumn();
    if ($usuariosBloqueados > 0) {
        $recomendacoes[] = "$usuariosBloqueados usuários bloqueados atualmente";
    }
    
    // Determinar nível de risco
    if ($pontuacao >= 90) {
        $nivelRisco = 'BAIXO';
        $corRisco = 'green';
    } elseif ($pontuacao >= 70) {
        $nivelRisco = 'MÉDIO';
        $corRisco = 'orange';
    } else {
        $nivelRisco = 'ALTO';
        $corRisco = 'red';
    }
    
    $dadosRelatorio['analises']['risco'] = [
        'pontuacao' => $pontuacao,
        'nivel' => $nivelRisco,
        'cor' => $corRisco,
        'recomendacoes' => $recomendacoes
    ];
    
    // Gerar PDF usando TCPDF (se disponível)
    if (class_exists('TCPDF')) {
        require_once('tcpdf/tcpdf.php');
        
        $pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
        
        // Configurações do documento
        $pdf->SetCreator('Sistema Auth Blockchain');
        $pdf->SetAuthor('Sistema de Auditoria');
        $pdf->SetTitle('Relatório de Auditoria');
        $pdf->SetSubject('Relatório de Segurança');
        
        // Adicionar página
        $pdf->AddPage();
        
        // Título
        $pdf->SetFont('helvetica', 'B', 16);
        $pdf->Cell(0, 10, 'RELATÓRIO DE AUDITORIA DO SISTEMA', 0, 1, 'C');
        $pdf->SetFont('helvetica', '', 10);
        $pdf->Cell(0, 5, 'Gerado em: ' . date('d/m/Y H:i:s'), 0, 1, 'C');
        $pdf->Ln(10);
        
        // Estatísticas gerais
        $pdf->SetFont('helvetica', 'B', 12);
        $pdf->Cell(0, 10, '1. ESTATÍSTICAS GERAIS', 0, 1);
        $pdf->SetFont('helvetica', '', 10);
        
        $estatisticas = $dadosRelatorio['estatisticas']['gerais'];
        $pdf->Cell(0, 5, 'Total de Usuários: ' . $estatisticas['total_usuarios'], 0, 1);
        $pdf->Cell(0, 5, 'Usuários Comuns: ' . $estatisticas['usuarios_comuns'], 0, 1);
        $pdf->Cell(0, 5, 'Auditores: ' . $estatisticas['auditores'], 0, 1);
        $pdf->Cell(0, 5, 'Administradores: ' . $estatisticas['administradores'], 0, 1);
        $pdf->Cell(0, 5, 'Sessões Ativas: ' . $estatisticas['sessoes_ativas'], 0, 1);
        $pdf->Cell(0, 5, 'Total de Eventos: ' . $estatisticas['total_eventos'], 0, 1);
        $pdf->Cell(0, 5, 'Total de Blocos Blockchain: ' . $estatisticas['total_blocos'], 0, 1);
        $pdf->Ln(5);
        
        // Análise de Risco
        $pdf->SetFont('helvetica', 'B', 12);
        $pdf->Cell(0, 10, '2. ANÁLISE DE RISCO', 0, 1);
        $pdf->SetFont('helvetica', '', 10);
        
        $risco = $dadosRelatorio['analises']['risco'];
        $pdf->Cell(0, 5, 'Pontuação: ' . $risco['pontuacao'] . '/100', 0, 1);
        $pdf->Cell(0, 5, 'Nível de Risco: ' . $risco['nivel'], 0, 1);
        
        if (!empty($risco['recomendacoes'])) {
            $pdf->Cell(0, 5, 'Recomendações:', 0, 1);
            foreach ($risco['recomendacoes'] as $recomendacao) {
                $pdf->Cell(10, 5, '', 0, 0);
                $pdf->Cell(0, 5, '• ' . $recomendacao, 0, 1);
            }
        }
        
        $pdf->Ln(5);
        
        // Conclusão
        $pdf->SetFont('helvetica', 'B', 12);
        $pdf->Cell(0, 10, '3. CONCLUSÃO', 0, 1);
        $pdf->SetFont('helvetica', '', 10);
        
        if ($risco['nivel'] === 'BAIXO') {
            $pdf->Cell(0, 5, 'O sistema está operando com baixo risco e alta segurança.', 0, 1);
        } elseif ($risco['nivel'] === 'MÉDIO') {
            $pdf->Cell(0, 5, 'O sistema está operando com risco médio. Algumas melhorias são recomendadas.', 0, 1);
        } else {
            $pdf->Cell(0, 5, 'ATENÇÃO: O sistema está operando com alto risco. Ações corretivas são necessárias.', 0, 1);
        }
        
        // Rodapé
        $pdf->SetY(-15);
        $pdf->SetFont('helvetica', 'I', 8);
        $pdf->Cell(0, 10, 'Página ' . $pdf->getAliasNumPage() . '/' . $pdf->getAliasNbPages(), 0, 0, 'C');
        
        // Saída
        $pdf->Output('relatorio_auditoria_' . date('Y-m-d_H-i-s') . '.pdf', 'D');
        
    } else {
        // Fallback para HTML
        header('Content-Type: text/html');
        echo '<h1>TCPDF não disponível</h1>';
        echo '<p>Para gerar PDFs, instale a biblioteca TCPDF.</p>';
        echo '<pre>' . json_encode($dadosRelatorio, JSON_PRETTY_PRINT) . '</pre>';
    }
    
} catch (Exception $e) {
    error_log("Erro ao gerar relatório: " . $e->getMessage());
    http_response_code(500);
    echo 'Erro ao gerar relatório';
}
?>