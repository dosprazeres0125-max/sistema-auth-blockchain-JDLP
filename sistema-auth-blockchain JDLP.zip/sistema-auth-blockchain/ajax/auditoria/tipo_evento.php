<?php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/funcoes-seguranca.php';

// Verificar autenticação e permissões
if (!isset($_SESSION['id_usuario'])) {
    http_response_code(401);
    die(json_encode(['success' => false, 'error' => 'Não autenticado']));
}

$tipoUsuario = $_SESSION['tipo_usuario'] ?? '';
if (!in_array($tipoUsuario, ['admin', 'auditor'])) {
    http_response_code(403);
    die(json_encode(['success' => false, 'error' => 'Acesso negado']));
}

// Obter parâmetro
$tipoEvento = $_GET['tipo'] ?? '';
if (empty($tipoEvento)) {
    http_response_code(400);
    die(json_encode(['success' => false, 'error' => 'Tipo de evento não especificado']));
}

try {
    $pdo = conectarBancoDados();
    
    // Estatísticas do tipo de evento
    $query = "
        SELECT 
            tipo_evento,
            COUNT(*) as total,
            COUNT(DISTINCT id_usuario) as usuarios_unicos,
            COUNT(DISTINCT email_informado) as emails_unicos,
            COUNT(DISTINCT ip_origem) as ips_unicos,
            MIN(data_hora) as primeira_ocorrencia,
            MAX(data_hora) as ultima_ocorrencia,
            AVG(TIMESTAMPDIFF(SECOND, data_hora, NOW())) as tempo_medio_ultima
        FROM registro_eventos 
        WHERE tipo_evento = :tipo
        GROUP BY tipo_evento
    ";
    
    $stmt = $pdo->prepare($query);
    $stmt->execute([':tipo' => $tipoEvento]);
    $estatisticas = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$estatisticas) {
        die(json_encode(['success' => true, 'tipo_evento' => $tipoEvento, 'total' => 0, 'mensagem' => 'Nenhum evento encontrado']));
    }
    
    // Usuários mais frequentes para este tipo de evento
    $queryUsuarios = "
        SELECT 
            u.id_usuario,
            u.nome_completo,
            u.email,
            u.tipo_usuario,
            COUNT(re.id_evento) as total_ocorrencias,
            MIN(re.data_hora) as primeira_ocorrencia,
            MAX(re.data_hora) as ultima_ocorrencia
        FROM registro_eventos re
        LEFT JOIN usuarios u ON re.id_usuario = u.id_usuario
        WHERE re.tipo_evento = :tipo
        AND re.id_usuario IS NOT NULL
        GROUP BY u.id_usuario, u.nome_completo, u.email, u.tipo_usuario
        ORDER BY total_ocorrencias DESC
        LIMIT 10
    ";
    
    $stmtUsuarios = $pdo->prepare($queryUsuarios);
    $stmtUsuarios->execute([':tipo' => $tipoEvento]);
    $usuarios = $stmtUsuarios->fetchAll(PDO::FETCH_ASSOC);
    
    // IPs mais frequentes
    $queryIPs = "
        SELECT 
            ip_origem,
            COUNT(*) as total_ocorrencias,
            MIN(data_hora) as primeira_ocorrencia,
            MAX(data_hora) as ultima_ocorrencia
        FROM registro_eventos 
        WHERE tipo_evento = :tipo
        GROUP BY ip_origem
        ORDER BY total_ocorrencias DESC
        LIMIT 10
    ";
    
    $stmtIPs = $pdo->prepare($queryIPs);
    $stmtIPs->execute([':tipo' => $tipoEvento]);
    $ips = $stmtIPs->fetchAll(PDO::FETCH_ASSOC);
    
    // Distribuição por hora do dia
    $queryHora = "
        SELECT 
            HOUR(data_hora) as hora,
            COUNT(*) as total_ocorrencias
        FROM registro_eventos 
        WHERE tipo_evento = :tipo
        GROUP BY HOUR(data_hora)
        ORDER BY hora
    ";
    
    $stmtHora = $pdo->prepare($queryHora);
    $stmtHora->execute([':tipo' => $tipoEvento]);
    $horas = $stmtHora->fetchAll(PDO::FETCH_ASSOC);
    
    // Distribuição por dia da semana
    $queryDiaSemana = "
        SELECT 
            DAYNAME(data_hora) as dia_semana,
            DAYOFWEEK(data_hora) as num_dia,
            COUNT(*) as total_ocorrencias
        FROM registro_eventos 
        WHERE tipo_evento = :tipo
        GROUP BY DAYNAME(data_hora), DAYOFWEEK(data_hora)
        ORDER BY num_dia
    ";
    
    $stmtDiaSemana = $pdo->prepare($queryDiaSemana);
    $stmtDiaSemana->execute([':tipo' => $tipoEvento]);
    $diasSemana = $stmtDiaSemana->fetchAll(PDO::FETCH_ASSOC);
    
    $resultado = [
        'success' => true,
        'tipo_evento' => $tipoEvento,
        'estatisticas' => $estatisticas,
        'usuarios' => $usuarios,
        'ips' => $ips,
        'distribuicao_hora' => $horas,
        'distribuicao_dia_semana' => $diasSemana,
        'ultima_ocorrencia' => date('d/m/Y H:i', strtotime($estatisticas['ultima_ocorrencia'])),
        'primeira_ocorrencia' => date('d/m/Y H:i', strtotime($estatisticas['primeira_ocorrencia']))
    ];
    
    header('Content-Type: application/json');
    echo json_encode($resultado);
    
} catch (Exception $e) {
    error_log("Erro ao buscar detalhes do tipo de evento: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Erro interno do servidor']);
}
?>