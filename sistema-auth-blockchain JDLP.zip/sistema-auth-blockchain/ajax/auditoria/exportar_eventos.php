<?php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/funcoes-seguranca.php';

// Verificar autenticação e permissões
if (!isset($_SESSION['id_usuario'])) {
    http_response_code(401);
    die('Não autenticado');
}

$tipoUsuario = $_SESSION['tipo_usuario'] ?? '';
if (!in_array($tipoUsuario, ['admin', 'auditor'])) {
    http_response_code(403);
    die('Acesso negado');
}

// Obter parâmetros
$tipo = $_GET['tipo'] ?? 'csv';
$dataInicio = $_GET['data_inicio'] ?? null;
$dataFim = $_GET['data_fim'] ?? null;
$tipoEvento = $_GET['tipo_evento'] ?? null;

try {
    $pdo = conectarBancoDados();
    
    // Construir query base
    $query = "
        SELECT 
            re.id_evento,
            re.tipo_evento,
            re.id_usuario,
            u.nome_completo as usuario_nome,
            u.email as usuario_email,
            re.email_informado,
            re.ip_origem,
            re.user_agent,
            re.hash_transacao,
            re.hash_conteudo,
            re.hash_anterior,
            re.bloco_hash,
            re.timestamp,
            re.data_hora,
            bb.id_bloco,
            bb.numero_transacoes as bloco_transacoes,
            bb.dificuldade as bloco_dificuldade,
            bb.nonce as bloco_nonce
        FROM registro_eventos re
        LEFT JOIN usuarios u ON re.id_usuario = u.id_usuario
        LEFT JOIN blocos_blockchain bb ON re.bloco_hash = bb.bloco_hash
        WHERE 1=1
    ";
    
    $params = [];
    
    // Adicionar filtros
    if ($dataInicio) {
        $query .= " AND re.data_hora >= :data_inicio";
        $params[':data_inicio'] = $dataInicio;
    }
    
    if ($dataFim) {
        $query .= " AND re.data_hora <= :data_fim";
        $params[':data_fim'] = $dataFim;
    }
    
    if ($tipoEvento) {
        $query .= " AND re.tipo_evento = :tipo_evento";
        $params[':tipo_evento'] = $tipoEvento;
    }
    
    $query .= " ORDER BY re.data_hora DESC";
    
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $eventos = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if ($tipo === 'csv') {
        // Exportar como CSV
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=eventos_auditoria_' . date('Y-m-d_H-i-s') . '.csv');
        
        $output = fopen('php://output', 'w');
        
        // Cabeçalho
        $cabecalhos = [
            'ID Evento',
            'Tipo Evento',
            'ID Usuário',
            'Nome Usuário',
            'Email Usuário',
            'Email Informado',
            'IP Origem',
            'User Agent',
            'Hash Transação',
            'Hash Conteúdo',
            'Hash Anterior',
            'Hash Bloco',
            'Timestamp',
            'Data/Hora',
            'ID Bloco',
            'Transações no Bloco',
            'Dificuldade Bloco',
            'Nonce Bloco'
        ];
        
        fputcsv($output, $cabecalhos, ';');
        
        // Dados
        foreach ($eventos as $evento) {
            $linha = [
                $evento['id_evento'],
                $evento['tipo_evento'],
                $evento['id_usuario'] ?? 'N/A',
                $evento['usuario_nome'] ?? 'N/A',
                $evento['usuario_email'] ?? 'N/A',
                $evento['email_informado'] ?? 'N/A',
                $evento['ip_origem'],
                $evento['user_agent'] ?? 'N/A',
                $evento['hash_transacao'],
                $evento['hash_conteudo'],
                $evento['hash_anterior'] ?? 'N/A',
                $evento['bloco_hash'] ?? 'N/A',
                $evento['timestamp'],
                $evento['data_hora'],
                $evento['id_bloco'] ?? 'N/A',
                $evento['bloco_transacoes'] ?? 'N/A',
                $evento['bloco_dificuldade'] ?? 'N/A',
                $evento['bloco_nonce'] ?? 'N/A'
            ];
            
            fputcsv($output, $linha, ';');
        }
        
        fclose($output);
        
    } elseif ($tipo === 'json') {
        // Exportar como JSON
        header('Content-Type: application/json');
        header('Content-Disposition: attachment; filename=eventos_auditoria_' . date('Y-m-d_H-i-s') . '.json');
        
        echo json_encode([
            'success' => true,
            'metadata' => [
                'exportacao' => date('Y-m-d H:i:s'),
                'total_eventos' => count($eventos),
                'filtros' => [
                    'data_inicio' => $dataInicio,
                    'data_fim' => $dataFim,
                    'tipo_evento' => $tipoEvento
                ]
            ],
            'eventos' => $eventos
        ], JSON_PRETTY_PRINT);
        
    } else {
        http_response_code(400);
        echo 'Tipo de exportação inválido';
    }
    
} catch (Exception $e) {
    error_log("Erro ao exportar eventos: " . $e->getMessage());
    http_response_code(500);
    echo 'Erro interno do servidor';
}
?>