<?php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/funcoes-seguranca.php';

// Verificar autenticação e permissões
if (!isset($_SESSION['id_usuario'])) {
    http_response_code(401);
    die(json_encode(['success' => false, 'error' => 'Não autenticado']));
}

$tipoUsuario = $_SESSION['tipo_usuario'] ?? '';
if (!in_array($tipoUsuario, ['admin', 'auditor'])) {
    http_response_code(403);
    die(json_encode(['success' => false, 'error' => 'Acesso negado']));
}

try {
    $pdo = conectarBancoDados();
    $resultados = [];
    $recomendacoes = [];
    
    // 1. Verificar integridade da cadeia de eventos
    $queryCadeia = "
        SELECT 
            COUNT(*) as total_eventos,
            SUM(CASE WHEN hash_anterior IS NULL THEN 1 ELSE 0 END) as eventos_sem_anterior,
            SUM(CASE WHEN hash_seguinte IS NULL THEN 1 ELSE 0 END) as eventos_sem_seguinte,
            SUM(CASE WHEN hash_transacao IS NULL OR hash_conteudo IS NULL THEN 1 ELSE 0 END) as eventos_sem_hash,
            COUNT(DISTINCT bloco_hash) as blocos_distintos
        FROM registro_eventos
    ";
    
    $stmtCadeia = $pdo->query($queryCadeia);
    $cadeia = $stmtCadeia->fetch(PDO::FETCH_ASSOC);
    
    $resultados[] = [
        'item' => 'Cadeia de Eventos',
        'sucesso' => ($cadeia['eventos_sem_anterior'] == 1 && $cadeia['eventos_sem_hash'] == 0),
        'status' => $cadeia['total_eventos'] . ' eventos verificados',
        'detalhes' => [
            'eventos_sem_anterior' => $cadeia['eventos_sem_anterior'],
            'eventos_sem_seguinte' => $cadeia['eventos_sem_seguinte'],
            'eventos_sem_hash' => $cadeia['eventos_sem_hash'],
            'blocos_distintos' => $cadeia['blocos_distintos']
        ]
    ];
    
    if ($cadeia['eventos_sem_seguinte'] > 1) {
        $recomendacoes[] = 'Existem ' . $cadeia['eventos_sem_seguinte'] . ' eventos sem hash seguinte na cadeia';
    }
    
    // 2. Verificar consistência de hashes
    $queryHashes = "
        SELECT 
            COUNT(*) as total_verificados,
            SUM(CASE WHEN hash_transacao != SHA2(CONCAT(hash_conteudo, COALESCE(hash_anterior, '0'), timestamp), 256) THEN 1 ELSE 0 END) as hashes_inconsistentes
        FROM registro_eventos
        WHERE hash_transacao IS NOT NULL 
        AND hash_conteudo IS NOT NULL 
        AND timestamp IS NOT NULL
    ";
    
    $stmtHashes = $pdo->query($queryHashes);
    $hashes = $stmtHashes->fetch(PDO::FETCH_ASSOC);
    
    $resultados[] = [
        'item' => 'Consistência de Hashes',
        'sucesso' => ($hashes['hashes_inconsistentes'] == 0),
        'status' => $hashes['hashes_inconsistentes'] == 0 ? 'Tudo OK' : $hashes['hashes_inconsistentes'] . ' hashes inconsistentes',
        'detalhes' => [
            'total_verificados' => $hashes['total_verificados'],
            'hashes_inconsistentes' => $hashes['hashes_inconsistentes']
        ]
    ];
    
    if ($hashes['hashes_inconsistentes'] > 0) {
        $recomendacoes[] = 'Encontrados ' . $hashes['hashes_inconsistentes'] . ' hashes inconsistentes';
    }
    
    // 3. Verificar blocos da blockchain
    $queryBlocos = "
        SELECT 
            COUNT(*) as total_blocos,
            COUNT(CASE WHEN bloco_hash_anterior IS NULL THEN 1 END) as blocos_genesis,
            COUNT(DISTINCT bloco_hash) as hashes_unicos,
            SUM(CASE WHEN bloco_hash != SHA2(CONCAT(COALESCE(bloco_hash_anterior, '0'), hash_merkle_root, nonce, timestamp_criacao), 256) THEN 1 ELSE 0 END) as blocos_inconsistentes
        FROM blocos_blockchain
    ";
    
    $stmtBlocos = $pdo->query($queryBlocos);
    $blocos = $stmtBlocos->fetch(PDO::FETCH_ASSOC);
    
    $resultados[] = [
        'item' => 'Blocos Blockchain',
        'sucesso' => ($blocos['blocos_inconsistentes'] == 0),
        'status' => $blocos['total_blocos'] . ' blocos, ' . $blocos['blocos_genesis'] . ' genesis',
        'detalhes' => [
            'total_blocos' => $blocos['total_blocos'],
            'blocos_genesis' => $blocos['blocos_genesis'],
            'hashes_unicos' => $blocos['hashes_unicos'],
            'blocos_inconsistentes' => $blocos['blocos_inconsistentes']
        ]
    ];
    
    // 4. Verificar consistência de emails
    $queryEmails = "
        SELECT 
            COUNT(DISTINCT email_hash) as hashes_unicos,
            COUNT(DISTINCT email_informado) as emails_informados_unicos,
            SUM(CASE WHEN email_hash != SHA2(email_informado, 256) THEN 1 ELSE 0 END) as emails_inconsistentes
        FROM registro_eventos
        WHERE email_informado IS NOT NULL 
        AND email_hash IS NOT NULL
    ";
    
    $stmtEmails = $pdo->query($queryEmails);
    $emails = $stmtEmails->fetch(PDO::FETCH_ASSOC);
    
    $resultados[] = [
        'item' => 'Consistência de Emails',
        'sucesso' => ($emails['emails_inconsistentes'] == 0),
        'status' => $emails['hashes_unicos'] . ' hashes únicos, ' . $emails['emails_inconsistentes'] . ' inconsistentes',
        'detalhes' => [
            'hashes_unicos' => $emails['hashes_unicos'],
            'emails_informados_unicos' => $emails['emails_informados_unicos'],
            'emails_inconsistentes' => $emails['emails_inconsistentes']
        ]
    ];
    
    // 5. Verificar sessões ativas
    $querySessoes = "
        SELECT 
            COUNT(*) as sessoes_ativas,
            SUM(CASE WHEN expiracao < NOW() THEN 1 ELSE 0 END) as sessoes_expiradas
        FROM sessoes_ativas
    ";
    
    $stmtSessoes = $pdo->query($querySessoes);
    $sessoes = $stmtSessoes->fetch(PDO::FETCH_ASSOC);
    
    $resultados[] = [
        'item' => 'Sessões Ativas',
        'sucesso' => ($sessoes['sessoes_expiradas'] == 0),
        'status' => $sessoes['sessoes_ativas'] . ' ativas, ' . $sessoes['sessoes_expiradas'] . ' expiradas',
        'detalhes' => [
            'sessoes_ativas' => $sessoes['sessoes_ativas'],
            'sessoes_expiradas' => $sessoes['sessoes_expiradas']
        ]
    ];
    
    if ($sessoes['sessoes_expiradas'] > 0) {
        $recomendacoes[] = 'Existem ' . $sessoes['sessoes_expiradas'] . ' sessões expiradas para limpar';
    }
    
    // 6. Verificar integridade dos logs
    $queryLogs = "
        SELECT 
            COUNT(*) as total_logs,
            SUM(CASE WHEN ip_origem IS NULL OR ip_origem = '' THEN 1 ELSE 0 END) as logs_sem_ip,
            SUM(CASE WHEN user_agent IS NULL OR user_agent = '' THEN 1 ELSE 0 END) as logs_sem_user_agent
        FROM logs_seguranca
    ";
    
    $stmtLogs = $pdo->query($queryLogs);
    $logs = $stmtLogs->fetch(PDO::FETCH_ASSOC);
    
    $resultados[] = [
        'item' => 'Logs de Segurança',
        'sucesso' => ($logs['logs_sem_ip'] == 0 && $logs['logs_sem_user_agent'] == 0),
        'status' => $logs['total_logs'] . ' logs, ' . $logs['logs_sem_ip'] . ' sem IP',
        'detalhes' => [
            'total_logs' => $logs['total_logs'],
            'logs_sem_ip' => $logs['logs_sem_ip'],
            'logs_sem_user_agent' => $logs['logs_sem_user_agent']
        ]
    ];
    
    // Calcular sucesso geral
    $sucessoGeral = true;
    foreach ($resultados as $resultado) {
        if (!$resultado['sucesso']) {
            $sucessoGeral = false;
            break;
        }
    }
    
    $response = [
        'success' => true,
        'sucesso' => $sucessoGeral,
        'mensagem' => $sucessoGeral ? 
            'Todas as verificações passaram com sucesso!' : 
            'Algumas verificações falharam. Verifique as recomendações.',
        'resultados' => $resultados,
        'recomendacoes' => $recomendacoes
    ];
    
    header('Content-Type: application/json');
    echo json_encode($response);
    
} catch (Exception $e) {
    error_log("Erro na verificação de integridade: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Erro interno do servidor: ' . $e->getMessage()]);
}
?>