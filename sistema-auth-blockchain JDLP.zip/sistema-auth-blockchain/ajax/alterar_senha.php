<?php
session_start();
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/funcoes-seguranca.php';

if (!isset($_SESSION['id_usuario'])) {
    echo json_encode(['success' => false, 'message' => 'Não autenticado']);
    exit;
}

header('Content-Type: application/json');

try {
    $data = json_decode(file_get_contents('php://input'), true);
    
    if (!isset($data['senha_atual']) || !isset($data['nova_senha']) || !isset($data['confirmar_senha'])) {
        throw new Exception('Dados incompletos');
    }
    
    $senhaAtual = $data['senha_atual'];
    $novaSenha = $data['nova_senha'];
    $confirmarSenha = $data['confirmar_senha'];
    
    if ($novaSenha !== $confirmarSenha) {
        throw new Exception('As senhas não coincidem');
    }
    
    if (strlen($novaSenha) < 8) {
        throw new Exception('A senha deve ter pelo menos 8 caracteres');
    }
    
    if (!preg_match('/[A-Z]/', $novaSenha)) {
        throw new Exception('A senha deve conter pelo menos uma letra maiúscula');
    }
    
    if (!preg_match('/\d/', $novaSenha)) {
        throw new Exception('A senha deve conter pelo menos um número');
    }
    
    $pdo = conectarBancoDados();
    $idUsuario = $_SESSION['id_usuario'];
    
    $stmt = $pdo->prepare("SELECT senha_hash FROM usuarios WHERE id_usuario = ?");
    $stmt->execute([$idUsuario]);
    $usuario = $stmt->fetch();
    
    if (!$usuario || !password_verify($senhaAtual, $usuario['senha_hash'])) {
        throw new Exception('Senha atual incorreta');
    }
    
    $novaSenhaHash = password_hash($novaSenha, PASSWORD_BCRYPT);
    
    $stmt = $pdo->prepare("UPDATE usuarios SET senha_hash = ? WHERE id_usuario = ?");
    $stmt->execute([$novaSenhaHash, $idUsuario]);
    
    $ipOrigem = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
    
    registrarEventoBlockchain(
        $pdo,
        'SENHA_ALTERADA',
        $idUsuario,
        $_SESSION['email'],
        $ipOrigem,
        $userAgent
    );
    
    echo json_encode(['success' => true, 'message' => 'Senha alterada com sucesso']);
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>