<?php
session_start();
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/funcoes-seguranca.php';

if (!isset($_SESSION['id_usuario'])) {
    echo json_encode(['success' => false, 'message' => 'Não autenticado']);
    exit;
}

header('Content-Type: application/json');

try {
    $pdo = conectarBancoDados();
    $idUsuario = $_SESSION['id_usuario'];
    $sessaoAtual = session_id();
    $sessaoAtualHash = hash('sha256', $sessaoAtual);
    
    $stmt = $pdo->prepare("DELETE FROM sessoes_ativas WHERE id_usuario = ? AND id_sessao != ?");
    $stmt->execute([$idUsuario, $sessaoAtualHash]);
    
    $sessoesEncerradas = $stmt->rowCount();
    
    $ipOrigem = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
    
    registrarEventoBlockchain(
        $pdo,
        'SESSOES_ENCERRADAS',
        $idUsuario,
        $_SESSION['email'],
        $ipOrigem,
        $userAgent,
        ['sessoes_encerradas' => $sessoesEncerradas]
    );
    
    echo json_encode([
        'success' => true, 
        'message' => "$sessoesEncerradas sessão(ões) encerrada(s)",
        'sessoes_encerradas' => $sessoesEncerradas
    ]);
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>