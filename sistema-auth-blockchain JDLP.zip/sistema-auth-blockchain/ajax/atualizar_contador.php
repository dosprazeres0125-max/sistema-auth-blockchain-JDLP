<?php
require_once '../includes/config.php';
require_once '../includes/funcoes-seguranca.php';

// Verificar se o usuário está logado
if (!isset($_SESSION['id_usuario']) || empty($_SESSION['id_usuario'])) {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'Não autorizado']);
    exit;
}

try {
    // Contar notificações não lidas
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM registro_eventos WHERE data_hora >= NOW() - INTERVAL 1 DAY");
    $totalNotificacoes = $stmt->fetch()['total'];
    
    // Contar eventos recentes
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM registro_eventos WHERE data_hora >= NOW() - INTERVAL 1 HOUR");
    $eventosRecentes = $stmt->fetch()['total'];
    
    // Contar usuários ativos
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM sessoes_ativas");
    $usuariosAtivos = $stmt->fetch()['total'];
    
    echo json_encode([
        'success' => true,
        'contadores' => [
            'notificacoes' => $totalNotificacoes,
            'eventosRecentes' => $eventosRecentes,
            'usuariosAtivos' => $usuariosAtivos
        ],
        'timestamp' => time()
    ]);
    
} catch (Exception $e) {
    error_log("Erro ao atualizar contadores: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'error' => 'Erro ao atualizar contadores'
    ]);
}
?>