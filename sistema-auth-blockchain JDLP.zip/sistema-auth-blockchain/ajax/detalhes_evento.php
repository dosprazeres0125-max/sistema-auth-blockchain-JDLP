<?php
require_once __DIR__ . '/../includes/config.php';
$pdo = conectarBancoDados();

$id = $_GET['id'] ?? 0;
if (!$id || !is_numeric($id)) {
    echo '<p class="text-red-400 text-center">ID inválido.</p>';
    exit;
}

$stmt = $pdo->prepare("
    SELECT 
        re.*, 
        u.nome_completo, 
        u.email, 
        bb.bloco_hash, 
        bb.nonce,
        bb.timestamp_criacao
    FROM registro_eventos re 
    LEFT JOIN usuarios u ON re.id_usuario = u.id_usuario 
    LEFT JOIN blocos_blockchain bb ON re.bloco_hash = bb.bloco_hash 
    WHERE re.id_evento = ?
");
$stmt->execute([$id]);
$evento = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$evento) {
    echo '<p class="text-red-400 text-center">Evento não encontrado.</p>';
    exit;
}

// Resolver nome/email se for tentativa falha
if (empty($evento['id_usuario']) && !empty($evento['email_hash'])) {
    $stmtUser = $pdo->prepare("SELECT nome_completo, email FROM usuarios WHERE email_hash = ?");
    $stmtUser->execute([$evento['email_hash']]);
    $userFalha = $stmtUser->fetch(PDO::FETCH_ASSOC);
    if ($userFalha) {
        $evento['nome_completo'] = $userFalha['nome_completo'] . ' (falha de autenticação)';
        $evento['email'] = $userFalha['email'];
    } else {
        $evento['nome_completo'] = 'Email desconhecido';
        $evento['email'] = 'Hash: ' . substr($evento['email_hash'], 0, 20) . '...';
    }
}

echo '<div class="space-y-6 text-sm">';

echo '<div class="grid grid-cols-1 md:grid-cols-2 gap-4">';
echo '<div><strong>ID do Evento:</strong> #' . htmlspecialchars($evento['id_evento']) . '</div>';
echo '<div><strong>Data/Hora:</strong> ' . $evento['data_hora'] . '</div>';
echo '<div><strong>Tipo de Evento:</strong> ' . htmlspecialchars($evento['tipo_evento']) . '</div>';
echo '<div><strong>Usuário:</strong> ' . htmlspecialchars($evento['nome_completo'] ?? 'Desconhecido') . '</div>';
echo '<div><strong>Email:</strong> ' . htmlspecialchars($evento['email'] ?? 'N/A') . '</div>';
echo '<div><strong>IP de Origem:</strong> ' . htmlspecialchars($evento['ip_origem']) . '</div>';
echo '</div>';

echo '<div class="border-t border-gray-600 pt-4">';
echo '<strong>User-Agent:</strong><br>';
echo '<span class="text-xs text-gray-400 break-all">' . htmlspecialchars($evento['user_agent'] ?? 'Não informado') . '</span>';
echo '</div>';

echo '<div class="border-t border-gray-600 pt-4 space-y-2">';
echo '<div><strong>Hash da Transação:</strong><br><code class="text-xs break-all">' . htmlspecialchars($evento['hash_transacao']) . '</code></div>';
echo '<div><strong>Hash do Conteúdo:</strong><br><code class="text-xs break-all">' . htmlspecialchars($evento['hash_conteudo']) . '</code></div>';
echo '<div><strong>Hash Anterior:</strong><br><code class="text-xs break-all">' . htmlspecialchars($evento['hash_anterior'] ?? 'N/A') . '</code></div>';
echo '</div>';

echo '<div class="border-t border-gray-600 pt-4">';
echo '<strong>Blockchain:</strong><br>';
echo '<div class="pl-4 text-xs space-y-1">';
echo '<div>Bloco Hash: ' . ($evento['bloco_hash'] ? substr($evento['bloco_hash'], 0, 32) . '...' : 'N/A') . '</div>';
echo '<div>Nonce: ' . ($evento['nonce'] ?? 'N/A') . '</div>';
echo '<div>Timestamp Bloco: ' . ($evento['timestamp_criacao'] ? date('d/m/Y H:i:s', $evento['timestamp_criacao']) : 'N/A') . '</div>';
echo '</div>';
echo '</div>';

echo '</div>';
?>