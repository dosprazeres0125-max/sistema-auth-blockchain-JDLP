<?php
session_start();
require_once __DIR__ . '/../../includes/config.php';

if (!isset($_SESSION['id_usuario']) || empty($_SESSION['id_usuario'])) {
    header('HTTP/1.1 401 Unauthorized');
    echo json_encode(['success' => false, 'error' => 'Não autorizado']);
    exit;
}

try {
    $pdo = conectarBancoDados();
    $idUsuario = $_SESSION['id_usuario'];
    
    // Verificar se o usuário existe e está ativo
    $stmt = $pdo->prepare("SELECT senha_hash, email FROM usuarios WHERE id_usuario = ? AND ativo = 1");
    $stmt->execute([$idUsuario]);
    $usuario = $stmt->fetch();
    
    if (!$usuario) {
        echo json_encode(['success' => false, 'error' => 'Usuário não encontrado ou inativo']);
        exit;
    }
    
    $dados = json_decode(file_get_contents('php://input'), true);
    
    if (!$dados || !isset($dados['senha_atual']) || !isset($dados['nova_senha'])) {
        echo json_encode(['success' => false, 'error' => 'Dados inválidos']);
        exit;
    }
    
    $senhaAtual = trim($dados['senha_atual']);
    $novaSenha = trim($dados['nova_senha']);
    $confirmarSenha = isset($dados['confirmar_senha']) ? trim($dados['confirmar_senha']) : '';
    
    // Verificar senha atual
    if (!password_verify($senhaAtual, $usuario['senha_hash'])) {
        echo json_encode(['success' => false, 'error' => 'Senha atual incorreta']);
        exit;
    }
    
    // Validar nova senha
    if (strlen($novaSenha) < 8) {
        echo json_encode(['success' => false, 'error' => 'A nova senha deve ter pelo menos 8 caracteres']);
        exit;
    }
    
    // Verificar se as senhas coincidem
    if (!empty($confirmarSenha) && $novaSenha !== $confirmarSenha) {
        echo json_encode(['success' => false, 'error' => 'As senhas não coincidem']);
        exit;
    }
    
    // Gerar hash da nova senha
    $novaSenhaHash = password_hash($novaSenha, PASSWORD_DEFAULT);
    
    // Atualizar senha no banco
    $stmt = $pdo->prepare("UPDATE usuarios SET senha_hash = ?, data_ultima_atividade = NOW() WHERE id_usuario = ?");
    $stmt->execute([$novaSenhaHash, $idUsuario]);
    
    // Registrar evento usando a procedure
    $tipoEvento = 'SENHA_ALTERADA';
    $ipOrigem = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
    
    try {
        $stmt = $pdo->prepare("CALL registrar_evento_login(?, ?, ?, ?, ?)");
        $stmt->execute([$tipoEvento, $idUsuario, $usuario['email'], $ipOrigem, $userAgent]);
    } catch (Exception $e) {
        // Se a procedure falhar, registrar manualmente
        error_log("Procedure falhou: " . $e->getMessage());
        $stmt = $pdo->prepare("
            INSERT INTO registro_eventos (
                tipo_evento, id_usuario, email_hash, ip_origem, user_agent,
                hash_transacao, hash_conteudo, timestamp, data_hora
            ) VALUES (
                ?, ?, SHA2(?, 256), ?, ?,
                SHA2(CONCAT(?, ?, UNIX_TIMESTAMP()), 256),
                SHA2(CONCAT(?, ?, UNIX_TIMESTAMP()), 256),
                UNIX_TIMESTAMP(), NOW()
            )
        ");
        $stmt->execute([
            $tipoEvento, $idUsuario, $usuario['email'], $ipOrigem, $userAgent,
            $tipoEvento, $idUsuario, $tipoEvento, $idUsuario
        ]);
    }
    
    echo json_encode(['success' => true, 'message' => 'Senha alterada com sucesso!']);
    
} catch (PDOException $e) {
    error_log("Erro PDO ao alterar senha: " . $e->getMessage());
    echo json_encode(['success' => false, 'error' => 'Erro de banco de dados']);
} catch (Exception $e) {
    error_log("Erro geral ao alterar senha: " . $e->getMessage());
    echo json_encode(['success' => false, 'error' => 'Erro interno do sistema']);
}
?>