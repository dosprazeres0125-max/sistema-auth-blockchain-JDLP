<?php
session_start();
require_once __DIR__ . '/../../includes/config.php';

if (!isset($_SESSION['id_usuario']) || empty($_SESSION['id_usuario'])) {
    header('HTTP/1.1 401 Unauthorized');
    echo json_encode(['success' => false, 'error' => 'Não autorizado']);
    exit;
}

try {
    $pdo = conectarBancoDados();
    $idUsuario = $_SESSION['id_usuario'];
    $sessaoAtual = hash('sha256', session_id());
    
    // Encerrar todas as outras sessões (exceto a atual)
    $stmt = $pdo->prepare("DELETE FROM sessoes_ativas WHERE id_usuario = ? AND id_sessao != ?");
    $stmt->execute([$idUsuario, $sessaoAtual]);
    
    $sessoesEncerradas = $stmt->rowCount();
    
    // Registrar evento
    $tipoEvento = 'OTHER_SESSIONS_ENDED';
    $ipOrigem = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
    
    try {
        $stmt = $pdo->prepare("SELECT email FROM usuarios WHERE id_usuario = ?");
        $stmt->execute([$idUsuario]);
        $usuario = $stmt->fetch();
        
        $stmt = $pdo->prepare("CALL registrar_evento_login(?, ?, ?, ?, ?)");
        $stmt->execute([$tipoEvento, $idUsuario, $usuario['email'], $ipOrigem, $userAgent]);
    } catch (Exception $e) {
        error_log("Procedure falhou: " . $e->getMessage());
    }
    
    echo json_encode([
        'success' => true, 
        'message' => "{$sessoesEncerradas} sessões foram encerradas com sucesso!"
    ]);
    
} catch (PDOException $e) {
    error_log("Erro PDO ao encerrar outras sessões: " . $e->getMessage());
    echo json_encode(['success' => false, 'error' => 'Erro de banco de dados']);
} catch (Exception $e) {
    error_log("Erro geral ao encerrar outras sessões: " . $e->getMessage());
    echo json_encode(['success' => false, 'error' => 'Erro interno do sistema']);
}
?>