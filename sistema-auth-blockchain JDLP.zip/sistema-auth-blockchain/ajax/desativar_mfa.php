<?php
session_start();
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/funcoes-seguranca.php';

if (!isset($_SESSION['id_usuario'])) {
    echo json_encode(['success' => false, 'message' => 'Não autenticado']);
    exit;
}

header('Content-Type: application/json');

try {
    $data = json_decode(file_get_contents('php://input'), true);
    
    if (!isset($data['codigo_mfa'])) {
        throw new Exception('Código MFA não fornecido');
    }
    
    $codigoMFA = $data['codigo_mfa'];
    
    if (strlen($codigoMFA) !== 6 || !ctype_digit($codigoMFA)) {
        throw new Exception('Código MFA inválido');
    }
    
    $pdo = conectarBancoDados();
    $idUsuario = $_SESSION['id_usuario'];
    
    if (!verificarCodigoMFA($pdo, $idUsuario, $codigoMFA)) {
        throw new Exception('Código MFA incorreto');
    }
    
    $stmt = $pdo->prepare("UPDATE usuarios SET mfa_codigo_hash = NULL, mfa_ultima_alteracao = NOW() WHERE id_usuario = ?");
    $stmt->execute([$idUsuario]);
    
    $ipOrigem = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
    
    registrarEventoBlockchain(
        $pdo,
        'MFA_REMOVED',
        $idUsuario,
        $_SESSION['email'],
        $ipOrigem,
        $userAgent
    );
    
    $stmt = $pdo->prepare("DELETE FROM backup_codigos_mfa WHERE id_usuario = ?");
    $stmt->execute([$idUsuario]);
    
    echo json_encode(['success' => true, 'message' => 'MFA desativado com sucesso']);
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>