<?php
require_once '../includes/config.php';
require_once '../includes/funcoes-seguranca.php';

// Verificar se o usuário está logado
if (!isset($_SESSION['id_usuario']) || empty($_SESSION['id_usuario'])) {
    http_response_code(401);
    exit('Não autorizado');
}

$idEvento = $_GET['id'] ?? 0;

try {
    $stmt = $pdo->prepare("
        SELECT 
            re.*,
            u.nome_completo,
            u.email,
            u.tipo_usuario
        FROM registro_eventos re 
        LEFT JOIN usuarios u ON re.id_usuario = u.id_usuario 
        WHERE re.id_evento = ?
    ");
    
    $stmt->execute([$idEvento]);
    $evento = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$evento) {
        exit('Evento não encontrado');
    }
    
    // Configurar cabeçalhos para download JSON
    header('Content-Type: application/json');
    header('Content-Disposition: attachment; filename="evento_' . $idEvento . '_' . date('Y-m-d') . '.json"');
    
    echo json_encode($evento, JSON_PRETTY_PRINT);
    
} catch (Exception $e) {
    error_log("Erro ao exportar evento: " . $e->getMessage());
    echo json_encode(['error' => 'Erro ao exportar evento']);
}
?>