<?php
session_start();
require_once __DIR__ . '/../includes/config.php';

if (!isset($_SESSION['id_usuario'])) {
    echo json_encode(['success' => false, 'message' => 'Não autenticado']);
    exit;
}

header('Content-Type: application/json');

try {
    require_once __DIR__ . '/../includes/phpotp/rfc6238.php';
    
    $codigoSecreto = TokenAuth6238::generateRandomClue();
    
    echo json_encode([
        'success' => true,
        'codigo_secreto' => $codigoSecreto
    ]);
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>