<?php
require_once __DIR__ . '/../includes/config.php';
$pdo = conectarBancoDados();

// === MESMA LÓGICA DE FILTROS E CONSULTA DA PÁGINA PRINCIPAL ===
$filtroTipo = $_GET['tipo'] ?? '';
$filtroBusca = $_GET['busca'] ?? '';
$filtroDataInicio = $_GET['data_inicio'] ?? '';
$filtroDataFim = $_GET['data_fim'] ?? '';
$paginaAtual = isset($_GET['pagina']) ? max(1, intval($_GET['pagina'])) : 1;

try {
    $query = "SELECT COUNT(*) as total FROM registro_eventos re LEFT JOIN usuarios u ON re.id_usuario = u.id_usuario WHERE 1=1";
    $params = [];
    
    if ($filtroTipo) {
        if ($filtroTipo === 'LOGIN_SUCCESS') {
            $query .= " AND re.tipo_evento = 'LOGIN_SUCCESS'";
        } elseif ($filtroTipo === 'LOGIN_FAILED') {
            $query .= " AND (re.tipo_evento LIKE 'LOGIN_FAILED%' OR re.tipo_evento IN ('LOGIN_BLOCKED', 'ACCOUNT_LOCKED', 'MFA_FAILED', 'LOGIN_FAILED_INVALID_EMAIL', 'LOGIN_FAILED_USER_NOT_FOUND', 'LOGIN_FAILED_WRONG_PASSWORD'))";
        } elseif ($filtroTipo === 'LOGOUT') {
            $query .= " AND re.tipo_evento = 'LOGOUT'";
        }
    }
    
    if ($filtroBusca) {
        $query .= " AND (
            re.tipo_evento LIKE :busca OR 
            u.nome_completo LIKE :busca OR 
            u.email LIKE :busca OR
            re.ip_origem LIKE :busca OR
            re.email_hash LIKE :busca
        )";
        $params[':busca'] = "%$filtroBusca%";
    }
    
    if ($filtroDataInicio) {
        $query .= " AND DATE(re.data_hora) >= :data_inicio";
        $params[':data_inicio'] = $filtroDataInicio;
    }
    
    if ($filtroDataFim) {
        $query .= " AND DATE(re.data_hora) <= :data_fim";
        $params[':data_fim'] = $filtroDataFim;
    }
    
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $totalEventos = $stmt->fetch()['total'];
    
    $eventosPorPagina = 10;
    $offset = ($paginaAtual - 1) * $eventosPorPagina;
    $totalPaginas = ceil($totalEventos / $eventosPorPagina);
    
    $queryDados = str_replace("SELECT COUNT(*) as total", "
        SELECT 
            re.*,
            u.nome_completo,
            u.email,
            u.tipo_usuario,
            CASE 
                WHEN re.tipo_evento = 'LOGIN_SUCCESS' THEN 'Login bem-sucedido'
                WHEN re.tipo_evento LIKE 'LOGIN_FAILED%' 
                     OR re.tipo_evento IN ('LOGIN_BLOCKED', 'ACCOUNT_LOCKED', 'MFA_FAILED', 
                                          'LOGIN_FAILED_INVALID_EMAIL', 'LOGIN_FAILED_USER_NOT_FOUND', 'LOGIN_FAILED_WRONG_PASSWORD') 
                     THEN 'Tentativa de login falha'
                WHEN re.tipo_evento = 'LOGOUT' THEN 'Logout realizado'
                ELSE 'Outro evento'
            END as tipo_evento_formatado
    ", $query);
    
    $queryDados .= " ORDER BY re.data_hora DESC LIMIT :limit OFFSET :offset";
    
    $stmt = $pdo->prepare($queryDados);
    $params[':limit'] = $eventosPorPagina;
    $params[':offset'] = $offset;
    
    foreach ($params as $key => $value) {
        if ($key === ':limit' || $key === ':offset') {
            $stmt->bindValue($key, $value, PDO::PARAM_INT);
        } else {
            $stmt->bindValue($key, $value);
        }
    }
    
    $stmt->execute();
    $eventos = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Resolver usuários para tentativas falhas
    $hashToUsuario = [];
    $hashesUnicos = [];
    foreach ($eventos as $evento) {
        if (empty($evento['id_usuario']) && !empty($evento['email_hash'])) {
            $hashesUnicos[$evento['email_hash']] = true;
        }
    }
    
    if (!empty($hashesUnicos)) {
        $keys = array_keys($hashesUnicos);
        $placeholders = implode(',', array_fill(0, count($keys), '?'));
        $stmtMap = $pdo->prepare("SELECT id_usuario, nome_completo, email, email_hash FROM usuarios WHERE email_hash IN ($placeholders)");
        $stmtMap->execute($keys);
        while ($row = $stmtMap->fetch(PDO::FETCH_ASSOC)) {
            $hashToUsuario[$row['email_hash']] = $row;
        }
    }
    
} catch (Exception $e) {
    error_log("Erro em atualizar_eventos: " . $e->getMessage());
    $eventos = [];
}

// === SAÍDA: Apenas o conteúdo do <tbody> (linhas da tabela) ===
if (count($eventos) > 0):
    foreach ($eventos as $evento):
        // Determinar informações do usuário/tentativa
        if (!empty($evento['id_usuario'])) {
            $nomeExibido = $evento['nome_completo'] ?? 'Sistema';
            $emailExibido = $evento['email'] ?? 'sistema@local';
            $avatarClass = 'bg-blue-100 text-blue-600';
            $inicialAvatar = strtoupper(substr($nomeExibido, 0, 1));
        } else {
            if (isset($hashToUsuario[$evento['email_hash']])) {
                $u = $hashToUsuario[$evento['email_hash']];
                $nomeExibido = $u['nome_completo'] . ' (falha de autenticação)';
                $emailExibido = $u['email'];
                $avatarClass = 'bg-red-100 text-red-600';
                $inicialAvatar = strtoupper(substr($u['nome_completo'], 0, 1));
            } else {
                $nomeExibido = 'Email desconhecido';
                $emailExibido = !empty($evento['email_hash']) ? 'Hash: ' . substr($evento['email_hash'], 0, 20) . '...' : 'Não informado';
                $avatarClass = 'bg-gray-100 text-gray-600';
                $inicialAvatar = '?';
            }
        }
        
        $isSucesso = $evento['tipo_evento'] === 'LOGIN_SUCCESS';
        $isFalha = strpos($evento['tipo_evento'], 'FAILED') !== false || in_array($evento['tipo_evento'], ['LOGIN_BLOCKED', 'ACCOUNT_LOCKED', 'MFA_FAILED', 'LOGIN_FAILED_INVALID_EMAIL', 'LOGIN_FAILED_USER_NOT_FOUND', 'LOGIN_FAILED_WRONG_PASSWORD']);
        $isLogout = $evento['tipo_evento'] === 'LOGOUT';
        
        $badgeClass = $isSucesso ? 'badge-success' : ($isFalha ? 'badge-error' : ($isLogout ? 'badge-warning' : 'badge-info'));
        $badgeText = $isSucesso ? 'Sucesso' : ($isFalha ? 'Falha' : ($isLogout ? 'Logout' : 'Evento'));
        $iconClass = $isSucesso ? 'fa-check-circle' : ($isFalha ? 'fa-exclamation-circle' : ($isLogout ? 'fa-sign-out-alt' : 'fa-history'));
        ?>
        <tr class="table-row text-sm hover:bg-gray-50/80 transition-colors" id="evento-<?= $evento['id_evento'] ?>">
            <td class="px-4 py-3 text-gray-700 font-mono">#<?= $evento['id_evento'] ?></td>
            <td class="px-4 py-3 text-gray-700">
                <div class="flex flex-col">
                    <span class="text-xs text-gray-900"><?= date('d/m/Y', strtotime($evento['data_hora'])) ?></span>
                    <span class="text-xs text-gray-500"><?= date('H:i:s', strtotime($evento['data_hora'])) ?></span>
                </div>
            </td>
            <td class="px-4 py-3">
                <div class="flex items-center">
                    <div class="w-8 h-8 rounded-full <?= $avatarClass ?> flex items-center justify-center mr-3">
                        <span class="font-bold text-xs"><?= $inicialAvatar ?></span>
                    </div>
                    <div>
                        <p class="font-medium text-gray-900 text-sm"><?= htmlspecialchars($nomeExibido) ?></p>
                        <p class="text-xs text-gray-500"><?= htmlspecialchars($emailExibido) ?></p>
                    </div>
                </div>
            </td>
            <td class="px-4 py-3 text-gray-700">
                <div class="flex flex-col">
                    <span class="text-sm"><?= $evento['tipo_evento_formatado'] ?></span>
                    <span class="text-xs text-gray-500"><?= htmlspecialchars($evento['tipo_evento']) ?></span>
                </div>
            </td>
            <td class="px-4 py-3">
                <div class="flex flex-col">
                    <span class="text-gray-700 font-mono text-xs"><?= htmlspecialchars($evento['ip_origem']) ?></span>
                    <span class="text-xs text-gray-500 truncate max-w-[150px]" title="<?= htmlspecialchars($evento['user_agent'] ?? '') ?>">
                        <?= substr($evento['user_agent'] ?? '', 0, 50) ?>...
                    </span>
                </div>
            </td>
            <td class="px-4 py-3">
                <span class="badge <?= $badgeClass ?>">
                    <i class="fas <?= $iconClass ?> mr-1 text-xs"></i>
                    <?= $badgeText ?>
                </span>
            </td>
            <td class="px-4 py-3">
                <div class="flex space-x-2">
                    <button onclick="verDetalhesEvento(<?= $evento['id_evento'] ?>)" class="px-3 py-1 text-xs bg-blue-100 text-blue-700 rounded hover:bg-blue-200 clickable" title="Detalhes completos">
                        <i class="fas fa-eye"></i>
                    </button>
                    <button onclick="copiarHash('<?= $evento['hash_conteudo'] ?>')" class="px-3 py-1 text-xs bg-gray-100 text-gray-700 rounded hover:bg-gray-200 clickable" title="Copiar hash de conteúdo">
                        <i class="fas fa-copy"></i>
                    </button>
                    <?php if (!empty($evento['hash_transacao'])): ?>
                    <button onclick="verificarBlockchain('<?= $evento['hash_transacao'] ?>')" class="px-3 py-1 text-xs bg-green-100 text-green-700 rounded hover:bg-green-200 clickable" title="Verificar na blockchain">
                        <i class="fas fa-shield-alt"></i>
                    </button>
                    <?php endif; ?>
                </div>
            </td>
        </tr>
        <?php
    endforeach;
else:
    ?>
    <tr>
        <td colspan="7" class="px-4 py-8 text-center text-gray-500">
            <div class="flex flex-col items-center justify-center">
                <i class="fas fa-inbox text-gray-400 text-3xl mb-3"></i>
                <p class="text-lg text-gray-600 mb-2">Nenhum evento encontrado</p>
                <p class="text-sm text-gray-500">
                    Tente ajustar os filtros ou aguarde novas atividades.
                </p>
            </div>
        </td>
    </tr>
<?php
endif;
?>