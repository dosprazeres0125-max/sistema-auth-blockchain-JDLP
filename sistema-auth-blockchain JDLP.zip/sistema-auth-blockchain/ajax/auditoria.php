<?php
// ajax/auditoria.php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/funcoes-seguranca.php';

// Verificar se o usuário está logado
if (!isset($_SESSION['id_usuario']) || empty($_SESSION['id_usuario'])) {
    echo json_encode(['success' => false, 'message' => 'Não autorizado']);
    exit;
}

// Verificar permissões
$tipoUsuario = $_SESSION['tipo_usuario'] ?? '';
$permitirAuditor = ($tipoUsuario === 'admin' || $tipoUsuario === 'auditor');

if (!$permitirAuditor) {
    echo json_encode(['success' => false, 'message' => 'Acesso negado']);
    exit;
}

// Conectar ao banco de dados
try {
    $pdo = conectarBancoDados();
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Erro ao conectar ao banco de dados']);
    exit;
}

// Obter ação
$acao = $_GET['acao'] ?? $_POST['acao'] ?? '';

// Processar ações
switch ($acao) {
    case 'detalhes_log':
        detalhesLog();
        break;
    case 'analisar_eventos':
        analisarEventos();
        break;
    case 'verificar_integridade':
        verificarIntegridade();
        break;
    case 'auditoria_completa':
        auditoriaCompleta();
        break;
    case 'exportar':
        exportarDados();
        break;
    case 'exportar_analise_eventos':
        exportarAnaliseEventos();
        break;
    case 'gerar_relatorio':
        gerarRelatorio();
        break;
    case 'limpar_dados_antigos':
        limparDadosAntigos();
        break;
    case 'configurar_alertas':
        configurarAlertas();
        break;
    case 'atualizar_grafico':
        atualizarGrafico();
        break;
    default:
        echo json_encode(['success' => false, 'message' => 'Ação não reconhecida']);
        exit;
}

function detalhesLog() {
    global $pdo;
    
    $idLog = $_GET['id'] ?? 0;
    
    if (!$idLog) {
        echo json_encode(['success' => false, 'message' => 'ID do log não informado']);
        exit;
    }
    
    try {
        $query = "
            SELECT 
                id_log,
                tipo_log,
                id_usuario,
                severidade,
                descricao,
                ip_origem,
                user_agent,
                dados_adicionais,
                data_hora
            FROM logs_seguranca 
            WHERE id_log = ?
        ";
        
        $stmt = $pdo->prepare($query);
        $stmt->execute([$idLog]);
        $log = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($log) {
            echo json_encode(['success' => true, ...$log]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Log não encontrado']);
        }
    } catch (Exception $e) {
        error_log("Erro ao buscar detalhes do log: " . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Erro ao buscar detalhes do log']);
    }
}

function analisarEventos() {
    global $pdo;
    
    $tipo = $_GET['tipo'] ?? '';
    
    if (!$tipo) {
        echo json_encode(['success' => false, 'message' => 'Tipo de evento não informado']);
        exit;
    }
    
    try {
        // Estatísticas do tipo de evento
        $queryEstatisticas = "
            SELECT 
                COUNT(*) as total,
                COUNT(DISTINCT ip_origem) as ips_unicos,
                COUNT(DISTINCT email_informado) as emails_unicos,
                COUNT(DISTINCT id_usuario) as usuarios_unicos,
                COUNT(CASE WHEN data_hora >= DATE_SUB(NOW(), INTERVAL 7 DAY) THEN 1 END) as ultimos_7_dias,
                COUNT(*) / GREATEST(DATEDIFF(MAX(data_hora), MIN(data_hora)), 1) as media_diaria
            FROM registro_eventos 
            WHERE tipo_evento = ?
        ";
        
        $stmtEstatisticas = $pdo->prepare($queryEstatisticas);
        $stmtEstatisticas->execute([$tipo]);
        $estatisticas = $stmtEstatisticas->fetch(PDO::FETCH_ASSOC);
        
        // Últimos eventos do tipo
        $queryEventos = "
            SELECT 
                id_evento,
                tipo_evento,
                id_usuario,
                email_informado,
                ip_origem,
                user_agent,
                hash_transacao,
                data_hora
            FROM registro_eventos 
            WHERE tipo_evento = ?
            ORDER BY data_hora DESC 
            LIMIT 10
        ";
        
        $stmtEventos = $pdo->prepare($queryEventos);
        $stmtEventos->execute([$tipo]);
        $eventos = $stmtEventos->fetchAll(PDO::FETCH_ASSOC);
        
        echo json_encode([
            'success' => true,
            'tipo_evento' => $tipo,
            'estatisticas' => $estatisticas,
            'eventos' => $eventos,
            'total' => $estatisticas['total'] ?? 0
        ]);
    } catch (Exception $e) {
        error_log("Erro ao analisar eventos: " . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Erro ao analisar eventos']);
    }
}

function verificarIntegridade() {
    global $pdo;
    
    try {
        // Executar procedure de verificação de integridade
        $stmt = $pdo->prepare("CALL verificar_integridade_blockchain()");
        $stmt->execute();
        
        // Buscar resultados da verificação
        $queryResultados = "
            SELECT 
                tipo_log,
                severidade,
                descricao,
                data_hora
            FROM logs_seguranca 
            WHERE tipo_log LIKE '%blockchain%' 
            ORDER BY data_hora DESC 
            LIMIT 10
        ";
        
        $stmtResultados = $pdo->query($queryResultados);
        $resultados = $stmtResultados->fetchAll(PDO::FETCH_ASSOC);
        
        // Estatísticas atuais
        $queryEstatisticas = "
            SELECT 
                (SELECT COUNT(*) FROM blocos_blockchain) as total_blocos,
                (SELECT COUNT(*) FROM registro_eventos) as total_eventos,
                (SELECT COUNT(*) FROM logs_seguranca WHERE tipo_log LIKE '%corrompida%' AND data_hora >= DATE_SUB(NOW(), INTERVAL 1 DAY)) as corrompidos,
                (SELECT 
                    CASE 
                        WHEN COUNT(*) = 0 THEN 100
                        ELSE (SUM(CASE WHEN hash_anterior IS NOT NULL AND hash_seguinte IS NOT NULL THEN 1 ELSE 0 END) * 100.0 / COUNT(*))
                    END
                FROM registro_eventos) as integridade
        ";
        
        $stmtEstatisticas = $pdo->query($queryEstatisticas);
        $estatisticas = $stmtEstatisticas->fetch(PDO::FETCH_ASSOC);
        
        // Formatar resultados
        $resultadosFormatados = [];
        foreach ($resultados as $resultado) {
            $resultadosFormatados[] = [
                'tipo' => $resultado['severidade'] === 'critica' ? 'erro' : ($resultado['severidade'] === 'alta' ? 'alerta' : 'sucesso'),
                'mensagem' => $resultado['descricao'],
                'detalhes' => date('d/m/Y H:i', strtotime($resultado['data_hora']))
            ];
        }
        
        echo json_encode([
            'success' => true,
            'message' => 'Verificação de integridade concluída com sucesso',
            'resultados' => $resultadosFormatados,
            'estatisticas' => $estatisticas
        ]);
    } catch (Exception $e) {
        error_log("Erro ao verificar integridade: " . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Erro ao verificar integridade: ' . $e->getMessage()]);
    }
}

function auditoriaCompleta() {
    global $pdo;
    
    try {
        // Verificações completas do sistema
        $verificacoes = [];
        
        // 1. Verificar integridade da blockchain
        $queryBlockchain = "
            SELECT 
                (SELECT COUNT(*) FROM registro_eventos WHERE hash_anterior IS NULL) as primeiro_evento_ok,
                (SELECT COUNT(*) FROM registro_eventos WHERE hash_seguinte IS NULL) as ultimo_evento_ok,
                (SELECT COUNT(DISTINCT bloco_hash) FROM registro_eventos WHERE bloco_hash IS NOT NULL) as blocos_com_eventos,
                (SELECT COUNT(*) FROM registro_eventos WHERE bloco_hash IS NULL) as eventos_sem_bloco
        ";
        
        $stmtBlockchain = $pdo->query($queryBlockchain);
        $blockchain = $stmtBlockchain->fetch(PDO::FETCH_ASSOC);
        
        $verificacoes[] = [
            'tipo' => $blockchain['primeiro_evento_ok'] == 1 ? 'sucesso' : 'erro',
            'titulo' => 'Primeiro evento da blockchain',
            'mensagem' => $blockchain['primeiro_evento_ok'] == 1 ? 'Primeiro evento está correto' : 'Problema no primeiro evento',
            'detalhes' => 'Hash anterior nulo: ' . $blockchain['primeiro_evento_ok']
        ];
        
        $verificacoes[] = [
            'tipo' => $blockchain['eventos_sem_bloco'] == 0 ? 'sucesso' : 'alerta',
            'titulo' => 'Eventos sem bloco',
            'mensagem' => $blockchain['eventos_sem_bloco'] == 0 ? 'Todos os eventos estão em blocos' : 'Existem eventos sem bloco',
            'detalhes' => 'Eventos sem bloco: ' . $blockchain['eventos_sem_bloco']
        ];
        
        // 2. Verificar consistência de usuários
        $queryUsuarios = "
            SELECT 
                (SELECT COUNT(*) FROM usuarios WHERE ativo = 1) as usuarios_ativos,
                (SELECT COUNT(*) FROM usuarios WHERE ativo = 0) as usuarios_inativos,
                (SELECT COUNT(*) FROM usuarios WHERE bloqueado_ate IS NOT NULL AND bloqueado_ate > NOW()) as usuarios_bloqueados,
                (SELECT COUNT(*) FROM sessoes_ativas WHERE expiracao > NOW()) as sessoes_ativas
        ";
        
        $stmtUsuarios = $pdo->query($queryUsuarios);
        $usuarios = $stmtUsuarios->fetch(PDO::FETCH_ASSOC);
        
        $verificacoes[] = [
            'tipo' => 'sucesso',
            'titulo' => 'Status dos usuários',
            'mensagem' => 'Verificação de usuários concluída',
            'detalhes' => 'Ativos: ' . $usuarios['usuarios_ativos'] . ', Inativos: ' . $usuarios['usuarios_inativos'] . ', Bloqueados: ' . $usuarios['usuarios_bloqueados']
        ];
        
        // 3. Verificar logs de segurança
        $queryLogs = "
            SELECT 
                COUNT(*) as total_logs,
                COUNT(CASE WHEN severidade = 'critica' THEN 1 END) as criticos,
                COUNT(CASE WHEN severidade = 'alta' THEN 1 END) as altos,
                COUNT(CASE WHEN data_hora >= DATE_SUB(NOW(), INTERVAL 24 HOUR) THEN 1 END) as ultimas_24h
            FROM logs_seguranca
        ";
        
        $stmtLogs = $pdo->query($queryLogs);
        $logs = $stmtLogs->fetch(PDO::FETCH_ASSOC);
        
        $verificacoes[] = [
            'tipo' => $logs['criticos'] == 0 ? 'sucesso' : 'alerta',
            'titulo' => 'Logs de segurança',
            'mensagem' => $logs['criticos'] == 0 ? 'Nenhum log crítico recente' : 'Existem logs críticos',
            'detalhes' => 'Total: ' . $logs['total_logs'] . ', Críticos: ' . $logs['criticos'] . ', Últimas 24h: ' . $logs['ultimas_24h']
        ];
        
        // 4. Verificar MFA
        $queryMFA = "
            SELECT 
                (SELECT COUNT(*) FROM usuarios WHERE mfa_codigo_hash IS NOT NULL) as usuarios_com_mfa,
                (SELECT COUNT(*) FROM codigos_verificacao_mfa WHERE utilizado = 0 AND expiracao > NOW()) as codigos_ativos,
                (SELECT COUNT(*) FROM backup_codigos_mfa WHERE utilizado = 0 AND data_expiracao > NOW()) as backup_ativos
        ";
        
        $stmtMFA = $pdo->query($queryMFA);
        $mfa = $stmtMFA->fetch(PDO::FETCH_ASSOC);
        
        $verificacoes[] = [
            'tipo' => 'sucesso',
            'titulo' => 'Status MFA',
            'mensagem' => 'Verificação MFA concluída',
            'detalhes' => 'Usuários com MFA: ' . $mfa['usuarios_com_mfa'] . ', Códigos ativos: ' . $mfa['codigos_ativos']
        ];
        
        // 5. Verificar tentativas de login falhas recentes
        $queryTentativas = "
            SELECT 
                COUNT(*) as total_24h,
                COUNT(DISTINCT ip_origem) as ips_unicos,
                COUNT(DISTINCT email_informado) as emails_unicos
            FROM registro_eventos 
            WHERE (tipo_evento LIKE '%FAILED%' OR tipo_evento LIKE '%FALHO%')
                AND data_hora >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
        ";
        
        $stmtTentativas = $pdo->query($queryTentativas);
        $tentativas = $stmtTentativas->fetch(PDO::FETCH_ASSOC);
        
        $verificacoes[] = [
            'tipo' => $tentativas['total_24h'] < 10 ? 'sucesso' : ($tentativas['total_24h'] < 50 ? 'alerta' : 'erro'),
            'titulo' => 'Tentativas de login falhas',
            'mensagem' => $tentativas['total_24h'] < 10 ? 'Tentativas falhas dentro do normal' : 'Muitas tentativas falhas',
            'detalhes' => 'Últimas 24h: ' . $tentativas['total_24h'] . ', IPs únicos: ' . $tentativas['ips_unicos']
        ];
        
        // Resumo da auditoria
        $sucessos = array_filter($verificacoes, fn($v) => $v['tipo'] === 'sucesso');
        $alertas = array_filter($verificacoes, fn($v) => $v['tipo'] === 'alerta');
        $erros = array_filter($verificacoes, fn($v) => $v['tipo'] === 'erro');
        
        echo json_encode([
            'success' => true,
            'message' => 'Auditoria completa concluída',
            'verificacoes' => $verificacoes,
            'resumo' => [
                'total' => count($verificacoes),
                'sucessos' => count($sucessos),
                'alertas' => count($alertas),
                'erros' => count($erros),
                'score' => count($sucessos) * 100 / max(count($verificacoes), 1)
            ]
        ]);
        
    } catch (Exception $e) {
        error_log("Erro na auditoria completa: " . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Erro na auditoria completa: ' . $e->getMessage()]);
    }
}

function exportarDados() {
    global $pdo;
    
    $tipo = $_GET['tipo'] ?? 'csv';
    $inicio = $_GET['inicio'] ?? '';
    $fim = $_GET['fim'] ?? '';
    $filtroTipo = $_GET['filtro_tipo'] ?? '';
    $filtroEmail = $_GET['filtro_email'] ?? '';
    
    try {
        // Construir query com filtros
        $where = [];
        $params = [];
        
        if ($inicio) {
            $where[] = "data_hora >= ?";
            $params[] = $inicio . ' 00:00:00';
        }
        
        if ($fim) {
            $where[] = "data_hora <= ?";
            $params[] = $fim . ' 23:59:59';
        }
        
        if ($filtroTipo) {
            $where[] = "tipo_evento = ?";
            $params[] = $filtroTipo;
        }
        
        if ($filtroEmail) {
            $where[] = "email_informado LIKE ?";
            $params[] = '%' . $filtroEmail . '%';
        }
        
        $whereClause = $where ? 'WHERE ' . implode(' AND ', $where) : '';
        
        $query = "
            SELECT 
                id_evento,
                tipo_evento,
                id_usuario,
                email_informado,
                ip_origem,
                user_agent,
                hash_transacao,
                hash_anterior,
                hash_seguinte,
                bloco_numero,
                bloco_hash,
                timestamp,
                data_hora
            FROM registro_eventos 
            {$whereClause}
            ORDER BY data_hora DESC
        ";
        
        $stmt = $pdo->prepare($query);
        $stmt->execute($params);
        $dados = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        if ($tipo === 'csv') {
            exportarCSV($dados);
        } elseif ($tipo === 'json') {
            exportarJSON($dados);
        } else {
            echo json_encode(['success' => false, 'message' => 'Tipo de exportação não suportado']);
        }
    } catch (Exception $e) {
        error_log("Erro ao exportar dados: " . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Erro ao exportar dados']);
    }
}

function exportarCSV($dados) {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=auditoria_' . date('Y-m-d_H-i-s') . '.csv');
    
    $output = fopen('php://output', 'w');
    
    // Cabeçalho
    fputcsv($output, [
        'ID Evento',
        'Tipo Evento',
        'ID Usuário',
        'Email',
        'IP Origem',
        'User Agent',
        'Hash Transação',
        'Hash Anterior',
        'Hash Seguinte',
        'Bloco Número',
        'Bloco Hash',
        'Timestamp',
        'Data/Hora'
    ]);
    
    // Dados
    foreach ($dados as $linha) {
        fputcsv($output, [
            $linha['id_evento'],
            $linha['tipo_evento'],
            $linha['id_usuario'] ?? '',
            $linha['email_informado'] ?? '',
            $linha['ip_origem'],
            $linha['user_agent'] ?? '',
            $linha['hash_transacao'],
            $linha['hash_anterior'] ?? '',
            $linha['hash_seguinte'] ?? '',
            $linha['bloco_numero'] ?? '',
            $linha['bloco_hash'] ?? '',
            $linha['timestamp'],
            $linha['data_hora']
        ]);
    }
    
    fclose($output);
    exit;
}

function exportarJSON($dados) {
    header('Content-Type: application/json; charset=utf-8');
    header('Content-Disposition: attachment; filename=auditoria_' . date('Y-m-d_H-i-s') . '.json');
    
    echo json_encode([
        'metadata' => [
            'exportacao' => date('Y-m-d H:i:s'),
            'total_registros' => count($dados),
            'filtros' => [
                'inicio' => $_GET['inicio'] ?? '',
                'fim' => $_GET['fim'] ?? '',
                'tipo_evento' => $_GET['filtro_tipo'] ?? '',
                'email' => $_GET['filtro_email'] ?? ''
            ]
        ],
        'dados' => $dados
    ], JSON_PRETTY_PRINT);
    exit;
}

function exportarAnaliseEventos() {
    global $pdo;
    
    try {
        $query = "
            SELECT 
                tipo_evento,
                COUNT(*) as total,
                COUNT(CASE WHEN id_usuario IS NOT NULL THEN 1 END) as com_usuario,
                COUNT(CASE WHEN id_usuario IS NULL THEN 1 END) as sem_usuario,
                MIN(data_hora) as primeiro_evento,
                MAX(data_hora) as ultimo_evento
            FROM registro_eventos 
            GROUP BY tipo_evento 
            ORDER BY total DESC
        ";
        
        $stmt = $pdo->query($query);
        $dados = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        exportarCSV($dados);
    } catch (Exception $e) {
        error_log("Erro ao exportar análise de eventos: " . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Erro ao exportar análise de eventos']);
    }
}

function gerarRelatorio() {
    // Em uma implementação real, você usaria uma biblioteca como TCPDF ou mPDF
    // Aqui é apenas um exemplo simplificado
    
    $nomeArquivo = 'relatorio_auditoria_' . date('Y-m-d_H-i-s') . '.pdf';
    $url = 'relatorios/' . $nomeArquivo;
    
    // Simular geração de relatório
    // Em produção, gere o PDF real aqui
    
    echo json_encode([
        'success' => true,
        'message' => 'Relatório gerado com sucesso',
        'url' => $url
    ]);
}

function limparDadosAntigos() {
    global $pdo;
    
    try {
        // Obter configuração de dias para manter logs
        $queryConfig = "SELECT valor FROM configuracoes_sistema WHERE chave = 'manter_logs_dias'";
        $stmtConfig = $pdo->query($queryConfig);
        $config = $stmtConfig->fetch(PDO::FETCH_ASSOC);
        $diasManter = $config['valor'] ?? 90;
        
        // Calcular data limite
        $dataLimite = date('Y-m-d H:i:s', strtotime('-' . $diasManter . ' days'));
        
        // Limpar logs antigos
        $queryLimparLogs = "DELETE FROM logs_seguranca WHERE data_hora < ?";
        $stmtLimparLogs = $pdo->prepare($queryLimparLogs);
        $stmtLimparLogs->execute([$dataLimite]);
        $logsRemovidos = $stmtLimparLogs->rowCount();
        
        // Limpar notificações antigas lidas
        $queryLimparNotificacoes = "DELETE FROM notificacoes_sistema WHERE lida = 1 AND data_criacao < ?";
        $stmtLimparNotificacoes = $pdo->prepare($queryLimparNotificacoes);
        $stmtLimparNotificacoes->execute([$dataLimite]);
        $notificacoesRemovidas = $stmtLimparNotificacoes->rowCount();
        
        // Limpar códigos MFA expirados
        $queryLimparCodigosMFA = "DELETE FROM codigos_verificacao_mfa WHERE expiracao < NOW()";
        $stmtLimparCodigosMFA = $pdo->prepare($queryLimparCodigosMFA);
        $stmtLimparCodigosMFA->execute();
        $codigosMFARemovidos = $stmtLimparCodigosMFA->rowCount();
        
        // Limpar backup códigos MFA expirados
        $queryLimparBackupMFA = "DELETE FROM backup_codigos_mfa WHERE data_expiracao < NOW()";
        $stmtLimparBackupMFA = $pdo->prepare($queryLimparBackupMFA);
        $stmtLimparBackupMFA->execute();
        $backupMFARemovidos = $stmtLimparBackupMFA->rowCount();
        
        echo json_encode([
            'success' => true,
            'message' => 'Limpeza de dados antigos concluída',
            'resultados' => [
                ['item' => 'Logs de segurança', 'removidos' => $logsRemovidos],
                ['item' => 'Notificações lidas', 'removidos' => $notificacoesRemovidas],
                ['item' => 'Códigos MFA expirados', 'removidos' => $codigosMFARemovidos],
                ['item' => 'Backup códigos MFA expirados', 'removidos' => $backupMFARemovidos]
            ]
        ]);
    } catch (Exception $e) {
        error_log("Erro ao limpar dados antigos: " . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Erro ao limpar dados antigos']);
    }
}

function configurarAlertas() {
    global $pdo;
    
    try {
        // Obter configurações atuais
        $queryConfig = "
            SELECT chave, valor, descricao 
            FROM configuracoes_sistema 
            WHERE categoria = 'seguranca'
            ORDER BY chave
        ";
        
        $stmtConfig = $pdo->query($queryConfig);
        $configuracoes = $stmtConfig->fetchAll(PDO::FETCH_ASSOC);
        
        echo json_encode([
            'success' => true,
            'configuracoes' => $configuracoes
        ]);
    } catch (Exception $e) {
        error_log("Erro ao carregar configurações de alertas: " . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Erro ao carregar configurações']);
    }
}

function atualizarGrafico() {
    global $pdo;
    
    try {
        // Atualizar dados do gráfico
        // Esta função normalmente retornaria os dados atualizados
        // Mas para simplificar, vamos apenas retornar sucesso
        
        echo json_encode([
            'success' => true,
            'message' => 'Dados do gráfico atualizados'
        ]);
    } catch (Exception $e) {
        error_log("Erro ao atualizar gráfico: " . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Erro ao atualizar gráfico']);
    }
}