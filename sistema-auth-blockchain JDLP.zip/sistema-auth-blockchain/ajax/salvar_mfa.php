<?php
require_once '../includes/config.php';
require_once '../includes/autenticacao.php';

header('Content-Type: application/json');

if (!isset($_SESSION['id_usuario'])) {
    echo json_encode(['success' => false, 'message' => 'Não autenticado']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Método não permitido']);
    exit;
}

// Verificar token CSRF
if (!verificarTokenCSRF($_POST['token_form'] ?? '')) {
    echo json_encode(['success' => false, 'message' => 'Token CSRF inválido']);
    exit;
}

$codigo_mfa = $_POST['codigo_mfa'] ?? '';
$confirmacao = $_POST['codigo_mfa_confirmacao'] ?? '';

// Validações
if (empty($codigo_mfa) || empty($confirmacao)) {
    echo json_encode(['success' => false, 'message' => 'Preencha ambos os códigos']);
    exit;
}

if (strlen($codigo_mfa) !== 6 || !ctype_digit($codigo_mfa)) {
    echo json_encode(['success' => false, 'message' => 'O código MFA deve ter exatamente 6 dígitos numéricos']);
    exit;
}

if ($codigo_mfa !== $confirmacao) {
    echo json_encode(['success' => false, 'message' => 'Os códigos não coincidem']);
    exit;
}

// Criar MFA
$resultado = criarMFAParaUsuario($_SESSION['id_usuario'], $codigo_mfa);

if ($resultado) {
    $_SESSION['tem_mfa'] = true;
    $_SESSION['mfa_criado'] = true;
    
    // Registrar evento
    registrarEventoBlockchain('mfa_configurado', $_SESSION['id_usuario']);
    
    echo json_encode([
        'success' => true,
        'message' => 'MFA configurado com sucesso!'
    ]);
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Erro ao configurar MFA. Tente novamente.'
    ]);
}
?>