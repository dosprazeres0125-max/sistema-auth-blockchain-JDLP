<?php
session_start();
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/funcoes-seguranca.php';

if (!isset($_SESSION['id_usuario'])) {
    echo json_encode(['success' => false, 'message' => 'Não autenticado']);
    exit;
}

header('Content-Type: application/json');

try {
    $pdo = conectarBancoDados();
    $idUsuario = $_SESSION['id_usuario'];
    
    $stmt = $pdo->prepare("SELECT mfa_codigo_hash FROM usuarios WHERE id_usuario = ?");
    $stmt->execute([$idUsuario]);
    $usuario = $stmt->fetch();
    
    if (!$usuario || empty($usuario['mfa_codigo_hash'])) {
        throw new Exception('MFA não está ativado');
    }
    
    $stmt = $pdo->prepare("DELETE FROM backup_codigos_mfa WHERE id_usuario = ?");
    $stmt->execute([$idUsuario]);
    
    $codigos = gerarCodigosBackupMFA(10);
    $codigosHashes = [];
    
    foreach ($codigos as $codigo) {
        $codigoHash = hash('sha256', $codigo);
        $codigosHashes[] = $codigoHash;
        
        $expiracao = date('Y-m-d H:i:s', strtotime('+1 year'));
        
        $stmt = $pdo->prepare("
            INSERT INTO backup_codigos_mfa (id_usuario, codigo_hash, data_expiracao) 
            VALUES (?, ?, ?)
        ");
        $stmt->execute([$idUsuario, $codigoHash, $expiracao]);
    }
    
    $ipOrigem = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
    
    registrarEventoBlockchain(
        $pdo,
        'MFA_BACKUP_GENERATED',
        $idUsuario,
        $_SESSION['email'],
        $ipOrigem,
        $userAgent,
        ['quantidade' => count($codigos)]
    );
    
    echo json_encode([
        'success' => true,
        'codigos' => $codigos,
        'message' => 'Códigos de backup gerados com sucesso'
    ]);
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?>