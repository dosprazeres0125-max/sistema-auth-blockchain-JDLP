<?php
require_once '../includes/config.php';
require_once '../includes/funcoes-seguranca.php';

$pdo = conectarBancoDados();

// Verificar se o usuário está autenticado
if (!isset($_SESSION['id_usuario']) || empty($_SESSION['id_usuario'])) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Não autenticado']);
    exit;
}

$response = [
    'success' => true,
    'stats' => [],
    'ultimos_eventos' => []
];

try {
    // Estatísticas gerais
    $stats = [];
    
    // Total de usuários
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM usuarios");
    $stats['total_usuarios'] = $stmt->fetch()['total'];
    
    // Total de eventos
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM registro_eventos");
    $stats['total_eventos'] = $stmt->fetch()['total'];
    
    // Logins bem-sucedidos
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM registro_eventos WHERE tipo_evento = 'LOGIN_SUCCESS'");
    $stats['login_sucesso'] = $stmt->fetch()['total'];
    
    // Logins falhos
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM registro_eventos WHERE tipo_evento LIKE 'LOGIN_FAILED%'");
    $stats['login_falhas'] = $stmt->fetch()['total'];
    
    // Sessões ativas
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM sessoes_ativas WHERE expiracao > NOW()");
    $stats['sessoes_ativas'] = $stmt->fetch()['total'];
    
    // Usuários com MFA ativo
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM mfa_registros WHERE ativo = 1");
    $stats['mfa_ativos'] = $stmt->fetch()['total'];
    
    $response['stats'] = $stats;
    
    // Últimos eventos
    $sqlEventos = "
        SELECT 
            re.id_evento,
            re.tipo_evento,
            re.data_hora,
            re.detalhes,
            re.endereco_ip,
            u.nome_completo,
            u.email,
            u.tipo_usuario
        FROM registro_eventos re 
        LEFT JOIN usuarios u ON re.id_usuario = u.id_usuario 
        ORDER BY re.data_hora DESC 
        LIMIT 5
    ";
    
    $stmt = $pdo->prepare($sqlEventos);
    $stmt->execute();
    $eventos = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Formatar eventos
    foreach ($eventos as $evento) {
        $response['ultimos_eventos'][] = [
            'id_evento' => $evento['id_evento'],
            'tipo_evento' => $evento['tipo_evento'],
            'tipo_evento_formatado' => formatarTipoEvento($evento['tipo_evento']),
            'data_hora' => $evento['data_hora'],
            'data_formatada' => date('d/m/Y H:i', strtotime($evento['data_hora'])),
            'detalhes' => $evento['detalhes'],
            'endereco_ip' => $evento['endereco_ip'],
            'nome_completo' => $evento['nome_completo'] ?? 'Sistema',
            'email' => $evento['email'],
            'tipo_usuario' => $evento['tipo_usuario'],
            'icone' => obterIconeEvento($evento['tipo_evento'])
        ];
    }
    
} catch (PDOException $e) {
    $response['success'] = false;
    $response['message'] = 'Erro ao carregar dados: ' . $e->getMessage();
}

header('Content-Type: application/json');
echo json_encode($response);

// Funções auxiliares
function formatarTipoEvento($tipo) {
    $formatos = [
        'LOGIN_SUCCESS' => 'Login realizado',
        'LOGIN_FAILED' => 'Tentativa de login falhou',
        'LOGIN_FAILED_PASSWORD' => 'Senha incorreta',
        'LOGIN_FAILED_USER' => 'Usuário não encontrado',
        'MFA_CREATED' => 'MFA configurado',
        'MFA_VERIFIED' => 'MFA verificado',
        'LOGOUT' => 'Logout realizado',
        'USER_CREATED' => 'Usuário criado',
        'USER_UPDATED' => 'Usuário atualizado',
        'USER_DELETED' => 'Usuário excluído',
        'PASSWORD_CHANGED' => 'Senha alterada',
        'PROFILE_UPDATED' => 'Perfil atualizado',
        'SESSION_CREATED' => 'Sessão criada',
        'SESSION_EXPIRED' => 'Sessão expirada'
    ];
    
    return $formatos[$tipo] ?? $tipo;
}

function obterIconeEvento($tipo) {
    $icones = [
        'LOGIN_SUCCESS' => 'fas fa-sign-in-alt text-green-500',
        'LOGIN_FAILED' => 'fas fa-exclamation-triangle text-red-500',
        'LOGIN_FAILED_PASSWORD' => 'fas fa-key text-red-500',
        'LOGIN_FAILED_USER' => 'fas fa-user-times text-red-500',
        'MFA_CREATED' => 'fas fa-shield-alt text-blue-500',
        'MFA_VERIFIED' => 'fas fa-check-circle text-green-500',
        'LOGOUT' => 'fas fa-sign-out-alt text-gray-500',
        'USER_CREATED' => 'fas fa-user-plus text-green-500',
        'USER_UPDATED' => 'fas fa-user-edit text-blue-500',
        'USER_DELETED' => 'fas fa-user-minus text-red-500',
        'PASSWORD_CHANGED' => 'fas fa-key text-yellow-500',
        'PROFILE_UPDATED' => 'fas fa-id-card text-blue-500'
    ];
    
    return $icones[$tipo] ?? 'fas fa-circle text-gray-400';
}
?>