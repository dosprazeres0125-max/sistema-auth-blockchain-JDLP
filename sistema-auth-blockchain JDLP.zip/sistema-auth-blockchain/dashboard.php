<?php
require_once 'includes/config.php';
require_once 'includes/funcoes-seguranca.php';

$pdo = conectarBancoDados();

if (!isset($_SESSION['id_usuario']) || empty($_SESSION['id_usuario'])) {
    $_SESSION['flash_messages'] = [
        ['tipo' => 'error', 'titulo' => 'Acesso Negado', 'mensagem' => 'Você precisa fazer login para acessar esta página']
    ];
    header("Location: index.php");
    exit;
}

// Verificar e definir tema
$temaAtual = $_SESSION['tema'] ?? 'dark';

// Atualizar tema se recebido via POST
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['tema'])) {
    $temaAtual = $_POST['tema'] === 'light' ? 'light' : 'dark';
    $_SESSION['tema'] = $temaAtual;
    
    // Responder para AJAX
    if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && $_SERVER['HTTP_X_REQUESTED_WITH'] === 'XMLHttpRequest') {
        header('Content-Type: application/json');
        echo json_encode(['success' => true, 'tema' => $temaAtual]);
        exit;
    }
}

$stmt = $pdo->prepare("SELECT nome_completo, email, tipo_usuario, data_ultimo_login FROM usuarios WHERE id_usuario = ?");
$stmt->execute([$_SESSION['id_usuario']]);
$usuario = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$usuario) {
    session_destroy();
    header("Location: index.php");
    exit;
}

$pagina = $_GET['pagina'] ?? 'dashboard';

$paginasPermitidas = [
    'dashboard', 'eventos', 'mfa', 'usuarios', 
    'auditoria', 'relatorios', 'configuracoes',
    'perfil', 'seguranca', 'notificacoes'
];

if (!in_array($pagina, $paginasPermitidas)) {
    $pagina = 'dashboard';
}

try {
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM usuarios");
    $totalUsuarios = $stmt->fetch()['total'];
    
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM registro_eventos");
    $totalEventos = $stmt->fetch()['total'];
    
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM registro_eventos WHERE tipo_evento = 'LOGIN_SUCCESS'");
    $loginSucesso = $stmt->fetch()['total'];
    
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM registro_eventos WHERE tipo_evento LIKE 'LOGIN_FAILED%'");
    $loginFalhas = $stmt->fetch()['total'];
    
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM sessoes_ativas WHERE expiracao > NOW()");
    $sessoesAtivas = $stmt->fetch()['total'];
    
    $stmt = $pdo->prepare("
        SELECT 
            re.id_evento,
            re.tipo_evento,
            re.data_hora,
            u.nome_completo,
            u.email,
            u.tipo_usuario
        FROM registro_eventos re 
        LEFT JOIN usuarios u ON re.id_usuario = u.id_usuario 
        ORDER BY re.data_hora DESC 
        LIMIT 5
    ");
    $stmt->execute();
    $ultimosEventos = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Buscar notificações não lidas
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as total 
        FROM notificacoes_sistema 
        WHERE (id_usuario = ? OR id_usuario IS NULL) 
        AND lida = 0
    ");
    $stmt->execute([$_SESSION['id_usuario']]);
    $notificacoesNaoLidas = $stmt->fetch()['total'];
    
} catch (Exception $e) {
    error_log("Erro ao buscar dados do dashboard: " . $e->getMessage());
    $totalUsuarios = 0;
    $totalEventos = 0;
    $loginSucesso = 0;
    $loginFalhas = 0;
    $sessoesAtivas = 0;
    $ultimosEventos = [];
    $notificacoesNaoLidas = 0;
}

$mensagensFlash = obterMensagensFlash();

$tipoUsuario = $usuario['tipo_usuario'];
$menuItens = [];

if ($tipoUsuario === 'admin') {
    $menuItens = [
        ['pagina' => 'dashboard', 'icone' => 'fas fa-home', 'texto' => 'Dashboard'],
        ['pagina' => 'eventos', 'icone' => 'fas fa-history', 'texto' => 'Eventos', 'badge' => count($ultimosEventos)],        
        ['pagina' => 'usuarios', 'icone' => 'fas fa-users', 'texto' => 'Usuários', 'badge' => $totalUsuarios],
        ['pagina' => 'configuracoes', 'icone' => 'fas fa-cog', 'texto' => 'Configurações'],
        ['pagina' => 'seguranca', 'icone' => 'fas fa-lock', 'texto' => 'Minha Segurança'],    
    ];
} elseif ($tipoUsuario === 'auditor') {
    $menuItens = [
        ['pagina' => 'dashboard', 'icone' => 'fas fa-home', 'texto' => 'Dashboard'],
        ['pagina' => 'eventos', 'icone' => 'fas fa-history', 'texto' => 'Eventos', 'badge' => count($ultimosEventos)],        
        ['pagina' => 'seguranca', 'icone' => 'fas fa-lock', 'texto' => 'Minha Segurança'],
    ];
} else {
    $menuItens = [
        ['pagina' => 'dashboard', 'icone' => 'fas fa-home', 'texto' => 'Dashboard'],
        ['pagina' => 'seguranca', 'icone' => 'fas fa-lock', 'texto' => 'Minha Segurança'],        
    ];
}
?>
<!DOCTYPE html>
<html lang="pt" class="scroll-smooth <?= $temaAtual === 'dark' ? 'dark' : '' ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= ucfirst($pagina) ?> • <?= NOME_SISTEMA ?></title>
    <link rel="icon" type="image/x-icon" href="<?= CAMINHO_FAVICON ?>">
    
    <script src="https://cdn.tailwindcss.com"></script>
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdn.jsdelivr.net/particles.js/2.0.0/particles.min.js"></script>

    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                fontFamily: {
                    'sans': ['Inter', 'system-ui', 'sans-serif'],
                },
                extend: {
                    colors: {
                        'marinho': {
                            50: '#e6f2ff',
                            100: '#cce5ff',
                            200: '#99ccff',
                            300: '#66b2ff',
                            400: '#3399ff',
                            500: '#007fff',
                            600: '#0066cc',
                            700: '#004c99',
                            800: '#003366',
                            900: '#001933',
                        },
                        'security': {
                            'blue': '#0066ff',
                            'dark-blue': '#001a35',
                            'light-blue': '#4a90e2',
                            'success': '#10b981',
                            'warning': '#f59e0b',
                            'danger': '#ef4444',
                            'info': '#3b82f6'
                        }
                    },
                    animation: {
                        'slide-in': 'slideIn 0.3s ease-out',
                        'fade-in': 'fadeIn 0.4s ease-out',
                        'slide-up': 'slideUp 0.3s ease-out',
                        'pulse-subtle': 'pulseSubtle 2s ease-in-out infinite',
                        'bounce-subtle': 'bounceSubtle 0.5s ease-out',
                        'click-effect': 'clickEffect 0.3s ease-out',
                        'toast-in': 'toastIn 0.5s ease-out',
                        'toast-out': 'toastOut 0.5s ease-in',
                        'dropdown-slide': 'dropdownSlide 0.2s ease-out',
                        'float': 'float 6s ease-in-out infinite',
                        'gradient': 'gradient 8s ease infinite',
                    },
                    keyframes: {
                        slideIn: {
                            '0%': { 
                                transform: 'translateX(-20px)',
                                opacity: '0'
                            },
                            '100%': { 
                                transform: 'translateX(0)',
                                opacity: '1'
                            },
                        },
                        fadeIn: {
                            '0%': { opacity: '0' },
                            '100%': { opacity: '1' },
                        },
                        slideUp: {
                            '0%': { 
                                transform: 'translateY(10px)',
                                opacity: '0'
                            },
                            '100%': { 
                                transform: 'translateY(0)',
                                opacity: '1'
                            },
                        },
                        pulseSubtle: {
                            '0%, 100%': { opacity: '1' },
                            '50%': { opacity: '0.8' },
                        },
                        bounceSubtle: {
                            '0%': { transform: 'scale(0.95)' },
                            '50%': { transform: 'scale(1.02)' },
                            '100%': { transform: 'scale(1)' },
                        },
                        clickEffect: {
                            '0%': { 
                                transform: 'scale(1)',
                                boxShadow: '0 0 0 0 rgba(0, 127, 255, 0.7)'
                            },
                            '50%': { 
                                transform: 'scale(0.95)',
                                boxShadow: '0 0 0 10px rgba(0, 127, 255, 0)'
                            },
                            '100%': { 
                                transform: 'scale(1)',
                                boxShadow: '0 0 0 0 rgba(0, 127, 255, 0)'
                            },
                        },
                        toastIn: {
                            '0%': { 
                                transform: 'translateX(100%)',
                                opacity: '0'
                            },
                            '100%': { 
                                transform: 'translateX(0)',
                                opacity: '1'
                            },
                        },
                        toastOut: {
                            '0%': { 
                                transform: 'translateX(0)',
                                opacity: '1'
                            },
                            '100%': { 
                                transform: 'translateX(100%)',
                                opacity: '0'
                            },
                        },
                        dropdownSlide: {
                            '0%': {
                                opacity: '0',
                                transform: 'translateY(-10px)'
                            },
                            '100%': {
                                opacity: '1',
                                transform: 'translateY(0)'
                            },
                        },
                        float: {
                            '0%, 100%': { 
                                transform: 'translateY(0)' 
                            },
                            '50%': { 
                                transform: 'translateY(-10px)' 
                            },
                        },
                        gradient: {
                            '0%, 100%': {
                                'background-position': '0% 50%'
                            },
                            '50%': {
                                'background-position': '100% 50%'
                            }
                        }
                    }
                }
            }
        }
    </script>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            -webkit-tap-highlight-color: transparent;
        }
        
        ::-webkit-scrollbar {
            width: 10px;
            height: 10px;
        }
        
        ::-webkit-scrollbar-track {
            background: rgba(0, 26, 53, 0.8);
            border-radius: 10px;
        }
        
        .dark ::-webkit-scrollbar-track {
            background: rgba(0, 26, 53, 0.8);
        }
        
        body:not(.dark) ::-webkit-scrollbar-track {
            background: rgba(0, 127, 255, 0.1);
        }
        
        ::-webkit-scrollbar-thumb {
            background: linear-gradient(to bottom, #007fff, #4a90e2);
            border-radius: 10px;
            border: 2px solid rgba(0, 26, 53, 0.8);
        }
        
        .dark ::-webkit-scrollbar-thumb {
            border-color: rgba(0, 26, 53, 0.8);
        }
        
        body:not(.dark) ::-webkit-scrollbar-thumb {
            border-color: rgba(0, 127, 255, 0.1);
        }
        
        ::-webkit-scrollbar-thumb:hover {
            background: linear-gradient(to bottom, #0066cc, #3b82f6);
        }
        
        body {
            font-family: 'Inter', sans-serif;
            min-height: 100vh;
            scrollbar-width: thin;
            scrollbar-color: #007fff rgba(0, 26, 53, 0.8);
        }
        
        .dark body {
            background: linear-gradient(135deg, #0a192f 0%, #0f2b46 100%);
            color: #e2e8f0;
            scrollbar-color: #007fff rgba(0, 26, 53, 0.8);
        }
        
        body:not(.dark) {
            background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%);
            color: #1e293b;
        }
        
        /* Sidebar Styles - Marinho Theme */
        .sidebar {
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            width: 260px;
            color: white;
            border-right: 1px solid;
            box-shadow: 2px 0 20px rgba(0, 0, 0, 0.3);
            scrollbar-width: thin;
            scrollbar-color: #007fff rgba(0, 26, 53, 0.8);
        }
        
        .dark .sidebar {
            background: linear-gradient(180deg, #001a35 0%, #00264d 100%);
            border-color: rgba(255, 255, 255, 0.1);
        }
        
        body:not(.dark) .sidebar {
            background: linear-gradient(180deg, #ffffff 0%, #f8fafc 100%);
            border-color: rgba(0, 127, 255, 0.1);
            color: #1e293b;
        }
        
        .sidebar::-webkit-scrollbar {
            width: 6px;
        }
        
        .sidebar::-webkit-scrollbar-thumb {
            background: #007fff;
            border-radius: 3px;
        }
        
        .sidebar-collapsed {
            width: 80px !important;
        }
        
        .sidebar-collapsed .sidebar-text,
        .sidebar-collapsed .logo-text,
        .sidebar-collapsed .user-info,
        .sidebar-collapsed .section-title {
            opacity: 0;
            display: none;
        }
        
        .sidebar-link {
            transition: all 0.2s ease;
            border-radius: 10px;
            padding: 10px 14px;
            margin: 3px 12px;
            cursor: pointer;
            user-select: none;
            display: flex;
            align-items: center;
            position: relative;
            overflow: hidden;
            gap: 12px;
        }
        
        .sidebar-link::before {
            content: '';
            position: absolute;
            left: 0;
            top: 0;
            height: 100%;
            width: 3px;
            background: linear-gradient(to bottom, #007fff, #4a90e2);
            transform: scaleY(0);
            transition: transform 0.2s ease;
        }
        
        .sidebar-link:hover::before {
            transform: scaleY(1);
        }
        
        .dark .sidebar-link:hover {
            background: rgba(255, 255, 255, 0.08);
            transform: translateX(3px);
        }
        
        body:not(.dark) .sidebar-link:hover {
            background: rgba(0, 127, 255, 0.08);
            transform: translateX(3px);
        }
        
        .sidebar-link.active {
            background: var(--sidebar-active-bg);
            box-shadow: 0 2px 8px rgba(0, 127, 255, 0.15);
        }
        
        .dark .sidebar-link.active {
            --sidebar-active-bg: rgba(255, 255, 255, 0.12);
        }
        
        body:not(.dark) .sidebar-link.active {
            --sidebar-active-bg: rgba(0, 127, 255, 0.12);
        }
        
        .sidebar-link.active::before {
            transform: scaleY(1);
        }
        
        .sidebar-link:active {
            transform: translateX(3px) scale(0.98);
        }
        
        .sidebar-icon {
            width: 24px;
            text-align: center;
            font-size: 1.1rem;
            transition: color 0.2s ease;
        }
        
        .dark .sidebar-icon {
            color: rgba(255, 255, 255, 0.8);
        }
        
        body:not(.dark) .sidebar-icon {
            color: rgba(30, 41, 59, 0.8);
        }
        
        .sidebar-link:hover .sidebar-icon {
            color: rgba(255, 255, 255, 0.95);
        }
        
        body:not(.dark) .sidebar-link:hover .sidebar-icon {
            color: rgba(30, 41, 59, 0.95);
        }
        
        .sidebar-link.active .sidebar-icon {
            color: #4a90e2;
        }
        
        /* Main Content */
        .main-content {
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            margin-left: 260px;
            scrollbar-width: thin;
            scrollbar-color: #007fff rgba(0, 26, 53, 0.8);
        }
        
        .main-content-expanded {
            margin-left: 80px;
        }
        
        /* Topbar - Marinho Theme */
        .topbar {
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border-bottom: 1px solid;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
            position: sticky;
            top: 0;
            z-index: 40;
        }
        
        .dark .topbar {
            background: linear-gradient(90deg, #001a35 0%, #00264d 100%);
            border-color: rgba(255, 255, 255, 0.1);
        }
        
        body:not(.dark) .topbar {
            background: linear-gradient(90deg, rgba(255, 255, 255, 0.95), rgba(248, 250, 252, 0.95));
            border-color: rgba(0, 127, 255, 0.1);
        }
        
        /* Cards - Marinho Theme */
        .card {
            border-radius: 14px;
            transition: all 0.3s ease;
            backdrop-filter: blur(4px);
            -webkit-backdrop-filter: blur(4px);
            cursor: pointer;
        }
        
        .dark .card {
            background: rgba(255, 255, 255, 0.05);
            border: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        body:not(.dark) .card {
            background: rgba(255, 255, 255, 0.95);
            border: 1px solid rgba(0, 127, 255, 0.1);
        }
        
        .card:hover {
            transform: translateY(-4px);
            box-shadow: 0 12px 40px rgba(0, 0, 0, 0.25);
        }
        
        .dark .card:hover {
            border-color: rgba(255, 255, 255, 0.2);
        }
        
        body:not(.dark) .card:hover {
            border-color: rgba(0, 127, 255, 0.2);
        }
        
        .card:active {
            transform: translateY(-2px) scale(0.99);
        }
        
        .card-light {
            border-radius: 14px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
            transition: all 0.3s ease;
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
        }
        
        .dark .card-light {
            background: rgba(31, 41, 55, 0.8);
            border: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        body:not(.dark) .card-light {
            background: rgba(255, 255, 255, 0.97);
            border: 1px solid rgba(0, 127, 255, 0.1);
        }
        
        .card-light:hover {
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.12);
            transform: translateY(-2px);
        }
        
        .dark .card-light:hover {
            border-color: rgba(255, 255, 255, 0.2);
        }
        
        body:not(.dark) .card-light:hover {
            border-color: rgba(0, 127, 255, 0.2);
        }
        
        /* Card Colors - Marinho Theme */
        .card-blue {
            background: linear-gradient(135deg, rgba(0, 127, 255, 0.12), rgba(0, 127, 255, 0.2));
            border: 1px solid rgba(0, 127, 255, 0.25);
        }
        
        .card-green {
            background: linear-gradient(135deg, rgba(16, 185, 129, 0.12), rgba(16, 185, 129, 0.2));
            border: 1px solid rgba(16, 185, 129, 0.25);
        }
        
        .card-red {
            background: linear-gradient(135deg, rgba(239, 68, 68, 0.12), rgba(239, 68, 68, 0.2));
            border: 1px solid rgba(239, 68, 68, 0.25);
        }
        
        .card-purple {
            background: linear-gradient(135deg, rgba(139, 92, 246, 0.12), rgba(139, 92, 246, 0.2));
            border: 1px solid rgba(139, 92, 246, 0.25);
        }
        
        .card-amber {
            background: linear-gradient(135deg, rgba(245, 158, 11, 0.12), rgba(245, 158, 11, 0.2));
            border: 1px solid rgba(245, 158, 11, 0.25);
        }
        
        /* Buttons - Marinho Theme */
        .btn-gradient {
            background: linear-gradient(135deg, #007fff 0%, #004c99 100%);
            position: relative;
            overflow: hidden;
            transition: all 0.3s ease;
            cursor: pointer;
        }
        
        .btn-gradient:hover {
            background: linear-gradient(135deg, #0066cc 0%, #003366 100%);
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(0, 127, 255, 0.2);
        }
        
        .btn-gradient:active {
            transform: translateY(0) scale(0.98);
            box-shadow: 0 4px 10px rgba(0, 127, 255, 0.15);
        }
        
        /* Modal - Marinho Theme */
        .modal-overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 1000;
            opacity: 0;
            visibility: hidden;
            transition: all 0.3s ease;
            backdrop-filter: blur(5px);
            -webkit-backdrop-filter: blur(5px);
        }
        
        .dark .modal-overlay {
            background: rgba(0, 0, 0, 0.85);
        }
        
        body:not(.dark) .modal-overlay {
            background: rgba(0, 0, 0, 0.7);
        }
        
        .modal-overlay.active {
            opacity: 1;
            visibility: visible;
        }
        
        .modal-content {
            border-radius: 18px;
            width: 90%;
            max-width: 600px;
            max-height: 80vh;
            overflow-y: auto;
            transform: translateY(-20px) scale(0.95);
            transition: all 0.3s ease;
            box-shadow: 0 25px 60px rgba(0, 0, 0, 0.4);
        }
        
        .dark .modal-content {
            background: linear-gradient(135deg, #001a35 0%, #00264d 100%);
            border: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        body:not(.dark) .modal-content {
            background: white;
            border: 1px solid rgba(0, 127, 255, 0.1);
        }
        
        .modal-overlay.active .modal-content {
            transform: translateY(0) scale(1);
        }
        
        /* Toast - Marinho Theme */
        .toast-notification {
            position: fixed;
            top: 100px;
            right: 24px;
            z-index: 9999;
            max-width: 400px;
            animation: toastIn 0.5s ease-out;
            border-radius: 12px;
            overflow: hidden;
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            border: 1px solid;
            transform-origin: top right;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
        }
        
        .dark .toast-notification {
            border-color: rgba(255, 255, 255, 0.1);
        }
        
        body:not(.dark) .toast-notification {
            border-color: rgba(0, 127, 255, 0.15);
        }
        
        .toast-notification.hiding {
            animation: toastOut 0.5s ease-in forwards;
        }
        
        .toast-notification.success {
            background: linear-gradient(135deg, rgba(16, 185, 129, 0.95), rgba(16, 185, 129, 0.85));
            border-left: 4px solid #10b981;
        }
        
        .toast-notification.error {
            background: linear-gradient(135deg, rgba(239, 68, 68, 0.95), rgba(239, 68, 68, 0.85));
            border-left: 4px solid #ef4444;
        }
        
        .toast-notification.warning {
            background: linear-gradient(135deg, rgba(245, 158, 11, 0.95), rgba(245, 158, 11, 0.85));
            border-left: 4px solid #f59e0b;
        }
        
        .toast-notification.info {
            background: linear-gradient(135deg, rgba(59, 130, 246, 0.95), rgba(59, 130, 246, 0.85));
            border-left: 4px solid #3b82f6;
        }
        
        .toast-progress {
            position: absolute;
            bottom: 0;
            left: 0;
            height: 3px;
            background: rgba(255, 255, 255, 0.5);
            animation: progressBar 5s linear forwards;
        }
        
        @keyframes progressBar {
            from { width: 100%; }
            to { width: 0%; }
        }
        
        /* Inputs - Marinho Theme */
        .input-modern {
            border: 2px solid;
            transition: all 0.2s ease;
        }
        
        .dark .input-modern {
            background: rgba(255, 255, 255, 0.07);
            border-color: rgba(255, 255, 255, 0.12);
            color: white;
        }
        
        body:not(.dark) .input-modern {
            background: rgba(255, 255, 255, 0.95);
            border-color: rgba(0, 127, 255, 0.15);
            color: #1f2937;
        }
        
        .input-modern:focus {
            outline: none;
        }
        
        .dark .input-modern:focus {
            background: rgba(255, 255, 255, 0.1);
            border-color: #007fff;
            box-shadow: 0 0 0 3px rgba(0, 127, 255, 0.15);
        }
        
        body:not(.dark) .input-modern:focus {
            background: white;
            border-color: #007fff;
            box-shadow: 0 0 0 3px rgba(0, 127, 255, 0.15);
        }
        
        /* Dropdowns - Marinho Theme */
        .dropdown-panel {
            border-radius: 12px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
            border: 1px solid;
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
        }
        
        .dark .dropdown-panel {
            background: linear-gradient(135deg, #001a35, #00264d);
            border-color: rgba(255, 255, 255, 0.1);
        }
        
        body:not(.dark) .dropdown-panel {
            background: white;
            border-color: rgba(0, 127, 255, 0.15);
        }
        
        .dropdown-item {
            transition: all 0.2s ease;
            border-radius: 8px;
        }
        
        .dark .dropdown-item:hover {
            background: rgba(255, 255, 255, 0.1);
        }
        
        body:not(.dark) .dropdown-item:hover {
            background: rgba(239, 246, 255, 0.9);
        }
        
        .dropdown-item:hover {
            transform: translateX(2px);
        }
        
        .dropdown-arrow::before {
            content: '';
            position: absolute;
            top: -8px;
            right: 16px;
            width: 0;
            height: 0;
            border-left: 8px solid transparent;
            border-right: 8px transparent;
            border-bottom: 8px solid;
        }
        
        .dark .dropdown-arrow::before {
            border-bottom-color: #001a35;
        }
        
        body:not(.dark) .dropdown-arrow::before {
            border-bottom-color: white;
        }
        
        .dropdown-arrow::after {
            content: '';
            position: absolute;
            top: -9px;
            right: 16px;
            width: 0;
            height: 0;
            border-left: 9px solid transparent;
            border-right: 9px solid transparent;
            border-bottom: 9px solid;
            z-index: -1;
        }
        
        .dark .dropdown-arrow::after {
            border-bottom-color: rgba(0, 0, 0, 0.1);
        }
        
        body:not(.dark) .dropdown-arrow::after {
            border-bottom-color: rgba(0, 0, 0, 0.05);
        }
        
        /* Badges - Marinho Theme */
        .badge {
            font-size: 0.7rem;
            padding: 3px 10px;
            border-radius: 12px;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-width: 60px;
        }
        
        .badge-success {
            background: rgba(16, 185, 129, 0.15);
            color: #10b981;
            border: 1px solid rgba(16, 185, 129, 0.3);
        }
        
        .badge-error {
            background: rgba(239, 68, 68, 0.15);
            color: #ef4444;
            border: 1px solid rgba(239, 68, 68, 0.3);
        }
        
        .badge-warning {
            background: rgba(245, 158, 11, 0.15);
            color: #f59e0b;
            border: 1px solid rgba(245, 158, 11, 0.3);
        }
        
        .badge-info {
            background: rgba(59, 130, 246, 0.15);
            color: #3b82f6;
            border: 1px solid rgba(59, 130, 246, 0.3);
        }
        
        .badge-marinho {
            background: linear-gradient(135deg, #007fff, #4a90e2);
            color: white;
            border: none;
        }
        
        /* Table Rows */
        .table-row:nth-child(even) {
            background: rgba(249, 250, 251, 0.9);
        }
        
        .table-row:nth-child(odd) {
            background: rgba(255, 255, 255, 0.95);
        }
        
        .table-row:hover {
            background: rgba(239, 246, 255, 0.95);
        }
        
        .dark .table-row:nth-child(even) {
            background: rgba(31, 41, 55, 0.5);
        }
        
        .dark .table-row:nth-child(odd) {
            background: rgba(55, 65, 81, 0.5);
        }
        
        .dark .table-row:hover {
            background: rgba(0, 127, 255, 0.1);
        }
        
        /* Clickable */
        .clickable {
            cursor: pointer;
            user-select: none;
            -webkit-tap-highlight-color: transparent;
        }
        
        .clickable:active {
            transform: scale(0.98);
        }
        
        /* Particles */
        #particles-container {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
            z-index: -1;
            opacity: 0.3;
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
                position: fixed;
                height: 100vh;
                z-index: 1000;
                width: 280px !important;
            }
            
            .sidebar-mobile-open {
                transform: translateX(0);
            }
            
            .main-content {
                margin-left: 0 !important;
            }
            
            .topbar {
                padding-left: 1rem;
                padding-right: 1rem;
            }
            
            .toast-notification {
                left: 16px;
                right: 16px;
                max-width: none;
            }
        }
        
        @media (min-width: 769px) {
            .bottom-nav {
                display: none !important;
            }
        }
        
        /* Animations */
        .animate-delay-1 { animation-delay: 0.1s; }
        .animate-delay-2 { animation-delay: 0.2s; }
        .animate-delay-3 { animation-delay: 0.3s; }
        .animate-delay-4 { animation-delay: 0.4s; }
        .animate-delay-5 { animation-delay: 0.5s; }
        
        .search-results, .notifications-dropdown {
            max-height: 400px;
            overflow-y: auto;
            scrollbar-width: thin;
            scrollbar-color: #007fff rgba(0, 26, 53, 0.1);
        }
        
        .dark .search-results, .dark .notifications-dropdown {
            scrollbar-color: #007fff rgba(0, 26, 53, 0.1);
        }
        
        body:not(.dark) .search-results, body:not(.dark) .notifications-dropdown {
            scrollbar-color: #007fff rgba(0, 127, 255, 0.1);
        }
        
        /* Loader */
        .loader {
            border: 4px solid rgba(255, 255, 255, 0.1);
            border-left-color: #007fff;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            animation: spin 1s linear infinite;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        /* Glass Effect */
        .glass-effect {
            backdrop-filter: blur(10px);
            -webkit-backdrop-filter: blur(10px);
            background: rgba(255, 255, 255, 0.05);
        }
        
        .dark .glass-effect {
            background: rgba(0, 26, 53, 0.3);
        }
        
        body:not(.dark) .glass-effect {
            background: rgba(255, 255, 255, 0.7);
        }
        
        /* Text Gradient */
        .text-gradient {
            background: linear-gradient(135deg, #007fff, #4a90e2);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        /* Notification Dot */
        .notification-dot {
            animation: pulseSubtle 2s infinite;
        }
    </style>
</head>
<body class="min-h-screen overflow-x-hidden">
    <!-- Particles container -->
    <div id="particles-container"></div>
    
    <!-- Sidebar -->
    <aside id="sidebar" class="sidebar fixed left-0 top-0 h-screen overflow-y-auto z-50">
        <div class="p-5 flex items-center justify-between border-b <?= $temaAtual === 'dark' ? 'border-white/10' : 'border-gray-200' ?>">
            <div class="flex items-center space-x-3">
                <?php if (file_exists('assets/img/logo.png')): ?>
                <div class="w-10 h-10 rounded-xl overflow-hidden bg-gradient-to-br from-blue-400 to-blue-600 flex items-center justify-center shadow-lg animate-float">
                    <img src="assets/img/logo.png" alt="Logo" class="w-8 h-8 object-contain">
                </div>
                <?php else: ?>
                <div class="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-400 to-blue-600 flex items-center justify-center shadow-lg animate-float">
                    <i class="fas fa-shield-alt text-white text-lg"></i>
                </div>
                <?php endif; ?>
                <span class="logo-text text-lg font-bold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?> tracking-tight"><?= NOME_SISTEMA ?></span>
            </div>
            <button id="toggle-sidebar" class="<?= $temaAtual === 'dark' ? 'text-white/70 hover:text-white hover:bg-white/5' : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100' ?> clickable p-2 rounded-lg transition-colors">
                <i class="fas fa-chevron-left text-lg transition-transform duration-300"></i>
            </button>
        </div>

        <div class="p-4 border-b <?= $temaAtual === 'dark' ? 'border-white/10' : 'border-gray-200' ?> user-info">
            <div class="flex items-center space-x-3">
                <div class="relative">
                    <div class="w-12 h-12 rounded-full bg-gradient-to-br from-blue-400 to-blue-600 flex items-center justify-center shadow-md">
                        <span class="text-white font-bold text-lg"><?= strtoupper(substr($usuario['nome_completo'], 0, 1)) ?></span>
                    </div>
                    <div class="absolute -bottom-1 -right-1 w-4 h-4 bg-green-500 rounded-full border-2 <?= $temaAtual === 'dark' ? 'border-white/90' : 'border-white' ?>"></div>
                </div>
                <div class="flex-1 min-w-0">
                    <h3 class="font-semibold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?> truncate text-sm"><?= htmlspecialchars($usuario['nome_completo']) ?></h3>
                    <p class="<?= $temaAtual === 'dark' ? 'text-white/60' : 'text-gray-600' ?> text-xs truncate"><?= htmlspecialchars($usuario['email']) ?></p>
                    <div class="flex items-center mt-1">
                        <span class="inline-block px-2 py-1 text-xs <?= $temaAtual === 'dark' ? 'bg-white/10 text-white/80' : 'bg-gray-100 text-gray-800' ?> rounded-full">
                            <?= htmlspecialchars(ucfirst($usuario['tipo_usuario'])) ?>
                        </span>
                    </div>
                </div>
            </div>
        </div>

        <div class="py-3">
            <div class="section-title px-6 py-2 text-xs font-semibold <?= $temaAtual === 'dark' ? 'text-white/50' : 'text-gray-500' ?> uppercase tracking-wider sidebar-text">
                Navegação
            </div>
            <nav class="px-2 space-y-1">
                <?php foreach ($menuItens as $item): ?>
                <a href="#" class="sidebar-link <?= $pagina === $item['pagina'] ? 'active' : '' ?>" data-pagina="<?= $item['pagina'] ?>">
                    <i class="sidebar-icon <?= $item['icone'] ?>"></i>
                    <span class="sidebar-text <?= $temaAtual === 'dark' ? 'text-white/90' : 'text-gray-800' ?> text-sm font-medium flex-1"><?= $item['texto'] ?></span>
                    <?php if (isset($item['badge']) && $item['badge'] > 0): ?>
                    <span class="badge badge-marinho"><?= $item['badge'] ?></span>
                    <?php endif; ?>
                </a>
                <?php endforeach; ?>
            </nav>
        </div>

        <div class="py-3 border-t <?= $temaAtual === 'dark' ? 'border-white/10' : 'border-gray-200' ?>">
            <div class="section-title px-6 py-2 text-xs font-semibold <?= $temaAtual === 'dark' ? 'text-white/50' : 'text-gray-500' ?> uppercase tracking-wider sidebar-text">
                Sistema
            </div>
            <nav class="px-2 space-y-1">
                <a href="#" class="sidebar-link clickable" onclick="openModal('ajuda')">
                    <i class="sidebar-icon fas fa-question-circle"></i>
                    <span class="sidebar-text <?= $temaAtual === 'dark' ? 'text-white/90' : 'text-gray-800' ?> text-sm font-medium flex-1">Ajuda</span>
                </a>
                
                <a href="#" class="sidebar-link clickable" onclick="openModal('documentacao')">
                    <i class="sidebar-icon fas fa-book"></i>
                    <span class="sidebar-text <?= $temaAtual === 'dark' ? 'text-white/90' : 'text-gray-800' ?> text-sm font-medium flex-1">Documentação</span>
                </a>
                
                <div class="mt-3 px-3">
                    <div class="flex items-center justify-between <?= $temaAtual === 'dark' ? 'bg-white/5' : 'bg-gray-100' ?> rounded-lg p-2">
                        <div class="flex items-center space-x-2">
                            <i class="fas <?= $temaAtual === 'dark' ? 'fa-moon text-blue-300' : 'fa-sun text-amber-500' ?> text-sm"></i>
                            <span class="text-xs <?= $temaAtual === 'dark' ? 'text-white/70' : 'text-gray-600' ?>">Tema</span>
                        </div>
                        <button id="toggle-tema" class="relative w-10 h-5 <?= $temaAtual === 'dark' ? 'bg-white/20' : 'bg-gray-300' ?> rounded-full transition-all duration-300 clickable" onclick="alternarTema()">
                            <div class="absolute top-0.5 left-0.5 w-4 h-4 bg-white rounded-full transition-transform duration-300 <?= $temaAtual === 'light' ? 'transform translate-x-5' : '' ?>"></div>
                        </button>
                    </div>
                </div>
                
                <a href="logout.php" class="sidebar-link mt-3 <?= $temaAtual === 'dark' ? 'bg-white/5 hover:bg-white/10' : 'bg-red-50 hover:bg-red-100' ?>">
                    <i class="sidebar-icon fas fa-sign-out-alt"></i>
                    <span class="sidebar-text <?= $temaAtual === 'dark' ? 'text-white/90' : 'text-red-600' ?> text-sm font-medium flex-1">Sair</span>
                </a>
            </nav>
        </div>
        
        <div class="p-4 mt-auto border-t <?= $temaAtual === 'dark' ? 'border-white/10' : 'border-gray-200' ?>">
            <div class="flex items-center justify-between">
                <div class="flex items-center space-x-2">
                    <div class="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                    <span class="text-xs <?= $temaAtual === 'dark' ? 'text-white/50' : 'text-gray-500' ?>">Online</span>
                </div>
                <span class="text-xs <?= $temaAtual === 'dark' ? 'text-white/50' : 'text-gray-500' ?>">v<?= VERSAO ?></span>
            </div>
        </div>
    </aside>

    <div id="sidebar-overlay" class="fixed inset-0 bg-black/50 z-40 hidden"></div>

    <!-- Main Content -->
    <div id="main-content" class="main-content min-h-screen">
        <!-- Topbar -->
        <header class="topbar sticky top-0 z-20">
            <div class="px-6 py-4 flex items-center justify-between">
                <button id="toggle-sidebar-mobile" class="lg:hidden clickable p-2 rounded-lg transition-colors">
                    <i class="fas fa-bars text-xl <?= $temaAtual === 'dark' ? 'text-white/70 hover:text-white' : 'text-gray-600 hover:text-gray-900' ?>"></i>
                </button>
                
                <div class="flex items-center space-x-3">
                    <h1 id="page-title" class="text-xl font-bold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?> tracking-tight">
                        <?= ucfirst($pagina) === 'Dashboard' ? 'Dashboard' : ucfirst($pagina) ?>
                    </h1>
                    <span class="ml-3 px-3 py-1 <?= $temaAtual === 'dark' ? 'bg-blue-500/20 text-blue-300' : 'bg-blue-100 text-blue-800' ?> text-xs font-medium rounded-full">
                        v<?= VERSAO ?>
                    </span>
                </div>
                
                <div class="flex items-center space-x-4">
                    <!-- Search -->
                    <div class="hidden md:block relative">
                        <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <i class="<?= $temaAtual === 'dark' ? 'text-white/50' : 'text-gray-400' ?> fas fa-search"></i>
                        </div>
                        <input 
                            type="text" 
                            id="search-input"
                            placeholder="Buscar usuários..."
                            class="pl-10 pr-4 py-2 w-64 rounded-xl input-modern <?= $temaAtual === 'dark' ? 'placeholder-white/50 focus:placeholder-white/70' : 'placeholder-gray-500 focus:placeholder-gray-700' ?> transition-all duration-200"
                            autocomplete="off">
                        
                        <div id="search-results" class="hidden absolute top-full left-0 right-0 mt-2 dropdown-panel z-40 search-results">
                        </div>
                    </div>
                    
                    <!-- Notifications -->
                    <div class="relative">
                        <button id="btn-notificacoes" class="relative p-2 rounded-lg clickable transition-colors">
                            <div class="<?= $temaAtual === 'dark' ? 'text-white/70 hover:text-white hover:bg-white/5' : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100' ?> p-2 rounded-lg">
                                <i class="fas fa-bell text-xl"></i>
                                <?php if ($notificacoesNaoLidas > 0): ?>
                                <span class="absolute top-0 right-0 w-2 h-2 bg-red-500 rounded-full notification-dot"></span>
                                <?php endif; ?>
                            </div>
                        </button>
                        
                        <div id="dropdown-notificacoes" class="hidden absolute right-0 mt-2 w-80 dropdown-panel z-30 dropdown-arrow">
                            <div class="p-4 border-b <?= $temaAtual === 'dark' ? 'border-gray-700' : 'border-gray-200' ?>">
                                <h3 class="font-semibold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?>">Notificações</h3>
                                <span class="text-sm <?= $temaAtual === 'dark' ? 'text-gray-400' : 'text-gray-500' ?>">Carregando...</span>
                            </div>
                            <div class="notifications-dropdown max-h-[350px]">
                            </div>
                            <div class="p-4 border-t <?= $temaAtual === 'dark' ? 'border-gray-700' : 'border-gray-200' ?> text-center">
                                <a href="#" class="text-sm text-blue-500 hover:text-blue-600 font-medium clickable" onclick="carregarPagina('notificacoes')">
                                    Ver todas as notificações
                                </a>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Profile -->
                    <div class="relative">
                        <button id="btn-perfil" class="flex items-center space-x-2 p-2 rounded-lg clickable transition-colors">
                            <div class="w-8 h-8 rounded-full bg-gradient-to-br from-blue-400 to-blue-600 flex items-center justify-center shadow-sm">
                                <span class="text-white font-bold text-sm"><?= strtoupper(substr($usuario['nome_completo'], 0, 1)) ?></span>
                            </div>
                            <div class="hidden md:block text-left">
                                <p class="text-sm font-medium <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?>"><?= htmlspecialchars($usuario['nome_completo']) ?></p>
                                <p class="text-xs <?= $temaAtual === 'dark' ? 'text-white/50' : 'text-gray-500' ?>"><?= htmlspecialchars($usuario['tipo_usuario']) ?></p>
                            </div>
                            <i class="<?= $temaAtual === 'dark' ? 'text-white/50' : 'text-gray-400' ?> fas fa-chevron-down text-xs hidden md:block"></i>
                        </button>
                        
                        <div id="dropdown-perfil" class="hidden absolute right-0 mt-2 w-56 dropdown-panel z-30 dropdown-arrow">
                            <div class="p-4 border-b <?= $temaAtual === 'dark' ? 'border-gray-700' : 'border-gray-200' ?>">
                                <div class="flex items-center space-x-3">
                                    <div class="w-10 h-10 rounded-full bg-gradient-to-br from-blue-400 to-blue-600 flex items-center justify-center">
                                        <span class="text-white font-bold"><?= strtoupper(substr($usuario['nome_completo'], 0, 1)) ?></span>
                                    </div>
                                    <div>
                                        <h4 class="font-semibold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?> text-sm"><?= htmlspecialchars($usuario['nome_completo']) ?></h4>
                                        <p class="text-xs <?= $temaAtual === 'dark' ? 'text-gray-400' : 'text-gray-500' ?>"><?= htmlspecialchars($usuario['email']) ?></p>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="py-2">
                                <a href="#" data-pagina="perfil" onclick="carregarPagina('perfil')" 
                                   class="dropdown-item flex items-center px-4 py-2 text-sm <?= $temaAtual === 'dark' ? 'text-gray-300 hover:bg-gray-700 hover:text-white' : 'text-gray-700 hover:bg-gray-50 hover:text-gray-900' ?> clickable">
                                    <i class="fas fa-user mr-3 <?= $temaAtual === 'dark' ? 'text-gray-400' : 'text-gray-500' ?> w-5 text-center"></i>
                                    Meu Perfil
                                </a>
                                
                                <a href="#" data-pagina="configuracoes" onclick="carregarPagina('configuracoes')" 
                                   class="dropdown-item flex items-center px-4 py-2 text-sm <?= $temaAtual === 'dark' ? 'text-gray-300 hover:bg-gray-700 hover:text-white' : 'text-gray-700 hover:bg-gray-50 hover:text-gray-900' ?> clickable">
                                    <i class="fas fa-cog mr-3 <?= $temaAtual === 'dark' ? 'text-gray-400' : 'text-gray-500' ?> w-5 text-center"></i>
                                    Configurações
                                </a>
                                
                                <a href="#" data-pagina="seguranca" onclick="carregarPagina('seguranca')" 
                                   class="dropdown-item flex items-center px-4 py-2 text-sm <?= $temaAtual === 'dark' ? 'text-gray-300 hover:bg-gray-700 hover:text-white' : 'text-gray-700 hover:bg-gray-50 hover:text-gray-900' ?> clickable">
                                    <i class="fas fa-shield-alt mr-3 <?= $temaAtual === 'dark' ? 'text-gray-400' : 'text-gray-500' ?> w-5 text-center"></i>
                                    Minha Segurança
                                </a>
                                
                                <div class="border-t <?= $temaAtual === 'dark' ? 'border-gray-700' : 'border-gray-200' ?> my-2"></div>
                                
                                <div class="px-4 py-2">
                                    <div class="flex items-center justify-between">
                                        <span class="text-sm <?= $temaAtual === 'dark' ? 'text-gray-400' : 'text-gray-600' ?>">Tema</span>
                                        <button onclick="alternarTema()" 
                                                class="flex items-center space-x-2 text-sm <?= $temaAtual === 'dark' ? 'text-blue-400 hover:text-blue-300' : 'text-blue-600 hover:text-blue-700' ?> clickable">
                                            <i class="fas <?= $temaAtual === 'dark' ? 'fa-sun' : 'fa-moon' ?> text-sm"></i>
                                            <span><?= $temaAtual === 'dark' ? 'Claro' : 'Escuro' ?></span>
                                        </button>
                                    </div>
                                </div>
                                
                                <div class="border-t <?= $temaAtual === 'dark' ? 'border-gray-700' : 'border-gray-200' ?> my-2"></div>
                                
                                <a href="logout.php" 
                                   class="dropdown-item flex items-center px-4 py-2 text-sm text-red-600 hover:bg-red-50 hover:text-red-700 clickable">
                                    <i class="fas fa-sign-out-alt mr-3 w-5 text-center"></i>
                                    Sair
                                </a>
                            </div>
                            
                            <div class="p-4 border-t <?= $temaAtual === 'dark' ? 'border-gray-700 bg-gray-900/50' : 'border-gray-200 bg-gray-50' ?> rounded-b-xl">
                                <div class="flex items-center justify-between">
                                    <span class="text-xs <?= $temaAtual === 'dark' ? 'text-gray-400' : 'text-gray-500' ?>">v<?= VERSAO ?></span>
                                    <div class="flex items-center">
                                        <div class="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
                                        <span class="text-xs <?= $temaAtual === 'dark' ? 'text-gray-400' : 'text-gray-500' ?>">Online</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>

        <!-- Main Content Area -->
        <div id="conteudo-dinamico" class="min-h-screen">
            <div id="loading-spinner" class="hidden fixed inset-0 <?= $temaAtual === 'dark' ? 'bg-black/50' : 'bg-black/20' ?> z-50 flex items-center justify-center">
                <div class="loader"></div>
            </div>
            
            <?php 
            $mapeamentoPaginas = [
                'dashboard' => 'dashboard.php',
                'eventos' => 'eventos.php',
                'mfa' => 'mfa.php',
                'usuarios' => 'usuarios.php',
                'auditoria' => 'auditoria.php',
                'relatorios' => 'relatorios.php',
                'configuracoes' => 'configuracoes.php',
                'perfil' => 'meuperfil.php',
                'seguranca' => 'seguranca.php',
                'notificacoes' => 'notificacoes.php'
            ];
            
            $arquivoConteudo = isset($mapeamentoPaginas[$pagina]) ? $mapeamentoPaginas[$pagina] : 'dashboard.php';
            $caminhoArquivo = "conteudo/{$arquivoConteudo}";
            
            if (file_exists($caminhoArquivo)) {
                include $caminhoArquivo;
            } else {
                include 'conteudo/dashboard.php';
            }
            ?>
        </div>
    </div>

    <!-- Modais Inline -->
    <!-- Modal Ajuda -->
    <div id="modal-ajuda" class="modal-overlay" onclick="closeModal(event, 'ajuda')">
        <div class="modal-content" onclick="event.stopPropagation()">
            <div class="p-6">
                <div class="flex items-center justify-between mb-4">
                    <div class="flex items-center space-x-3">
                        <div class="w-10 h-10 rounded-lg bg-blue-500/20 flex items-center justify-center">
                            <i class="fas fa-question-circle text-blue-400 text-lg"></i>
                        </div>
                        <h3 class="text-lg font-semibold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?>">Ajuda do Sistema</h3>
                    </div>
                    <button onclick="closeModal(event, 'ajuda')" class="<?= $temaAtual === 'dark' ? 'text-white/50 hover:text-white' : 'text-gray-500 hover:text-gray-700' ?> clickable">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div class="space-y-4">
                    <p class="<?= $temaAtual === 'dark' ? 'text-white/80' : 'text-gray-700' ?>">
                        Bem-vindo ao sistema de ajuda do <?= NOME_SISTEMA ?>. Aqui você encontrará informações sobre como utilizar todas as funcionalidades do sistema.
                    </p>
                    <div class="<?= $temaAtual === 'dark' ? 'bg-white/10' : 'bg-gray-100' ?> rounded-lg p-4">
                        <h4 class="font-medium <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?> mb-2 text-sm">Tópicos Principais:</h4>
                        <ul class="text-sm <?= $temaAtual === 'dark' ? 'text-white/70' : 'text-gray-700' ?> space-y-2">
                            <li class="flex items-start">
                                <i class="fas fa-check-circle text-blue-400 mt-0.5 mr-2 text-xs"></i>
                                <span>Como configurar a autenticação multifator (MFA)</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check-circle text-blue-400 mt-0.5 mr-2 text-xs"></i>
                                <span>Como visualizar e exportar relatórios</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check-circle text-blue-400 mt-0.5 mr-2 text-xs"></i>
                                <span>Como auditar eventos de segurança</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check-circle text-blue-400 mt-0.5 mr-2 text-xs"></i>
                                <span>Gerenciamento de usuários e permissões</span>
                            </li>
                        </ul>
                    </div>
                    <p class="<?= $temaAtual === 'dark' ? 'text-white/60' : 'text-gray-600' ?> text-sm">
                        Para suporte técnico específico, entre em contato com nossa equipe através da seção de Suporte.
                    </p>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Documentação -->
    <div id="modal-documentacao" class="modal-overlay" onclick="closeModal(event, 'documentacao')">
        <div class="modal-content" onclick="event.stopPropagation()">
            <div class="p-6">
                <div class="flex items-center justify-between mb-4">
                    <div class="flex items-center space-x-3">
                        <div class="w-10 h-10 rounded-lg bg-green-500/20 flex items-center justify-center">
                            <i class="fas fa-book text-green-400 text-lg"></i>
                        </div>
                        <h3 class="text-lg font-semibold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?>">Documentação Técnica</h3>
                    </div>
                    <button onclick="closeModal(event, 'documentacao')" class="<?= $temaAtual === 'dark' ? 'text-white/50 hover:text-white' : 'text-gray-500 hover:text-gray-700' ?> clickable">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div class="space-y-4">
                    <p class="<?= $temaAtual === 'dark' ? 'text-white/80' : 'text-gray-700' ?>">
                        Documentação completa do sistema <?= NOME_SISTEMA ?> com informações técnicas detalhadas sobre arquitetura, segurança e implementação.
                    </p>
                    <div class="grid grid-cols-2 gap-3">
                        <div class="<?= $temaAtual === 'dark' ? 'bg-white/10' : 'bg-gray-100' ?> rounded-lg p-3">
                            <h4 class="font-medium <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?> mb-1 text-sm">Arquitetura</h4>
                            <p class="text-xs <?= $temaAtual === 'dark' ? 'text-white/60' : 'text-gray-600' ?>">Sistema baseado em blockchain para imutabilidade de registros</p>
                        </div>
                        <div class="<?= $temaAtual === 'dark' ? 'bg-white/10' : 'bg-gray-100' ?> rounded-lg p-3">
                            <h4 class="font-medium <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?> mb-1 text-sm">Segurança</h4>
                            <p class="text-xs <?= $temaAtual === 'dark' ? 'text-white/60' : 'text-gray-600' ?>">Criptografia ponta a ponta e autenticação multifator</p>
                        </div>
                        <div class="<?= $temaAtual === 'dark' ? 'bg-white/10' : 'bg-gray-100' ?> rounded-lg p-3">
                            <h4 class="font-medium <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?> mb-1 text-sm">API</h4>
                            <p class="text-xs <?= $temaAtual === 'dark' ? 'text-white/60' : 'text-gray-600' ?>">Documentação completa da API REST disponível</p>
                        </div>
                        <div class="<?= $temaAtual === 'dark' ? 'bg-white/10' : 'bg-gray-100' ?> rounded-lg p-3">
                            <h4 class="font-medium <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?> mb-1 text-sm">Integração</h4>
                            <p class="text-xs <?= $temaAtual === 'dark' ? 'text-white/60' : 'text-gray-600' ?>">Guia de integração com outros sistemas</p>
                        </div>
                    </div>
                    <p class="<?= $temaAtual === 'dark' ? 'text-white/60' : 'text-gray-600' ?> text-sm">
                        A documentação completa está disponível para download em formato PDF ou pode ser acessada online através do portal de desenvolvedores.
                    </p>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Suporte -->
    <div id="modal-suporte" class="modal-overlay" onclick="closeModal(event, 'suporte')">
        <div class="modal-content" onclick="event.stopPropagation()">
            <div class="p-6">
                <div class="flex items-center justify-between mb-4">
                    <div class="flex items-center space-x-3">
                        <div class="w-10 h-10 rounded-lg bg-amber-500/20 flex items-center justify-center">
                            <i class="fas fa-headset text-amber-400 text-lg"></i>
                        </div>
                        <h3 class="text-lg font-semibold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?>">Suporte Técnico</h3>
                    </div>
                    <button onclick="closeModal(event, 'suporte')" class="<?= $temaAtual === 'dark' ? 'text-white/50 hover:text-white' : 'text-gray-500 hover:text-gray-700' ?> clickable">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div class="space-y-4">
                    <p class="<?= $temaAtual === 'dark' ? 'text-white/80' : 'text-gray-700' ?>">
                        Nossa equipe de suporte está disponível para ajudar com qualquer problema ou dúvida relacionada ao sistema <?= NOME_SISTEMA ?>.
                    </p>
                    <div class="<?= $temaAtual === 'dark' ? 'bg-white/10' : 'bg-gray-100' ?> rounded-lg p-4">
                        <h4 class="font-medium <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?> mb-2 text-sm">Canais de Suporte:</h4>
                        <div class="space-y-3">
                            <div class="flex items-center">
                                <i class="fas fa-envelope text-blue-400 mr-3"></i>
                                <div>
                                    <p class="text-sm <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?>">suporte@<?= strtolower(NOME_SISTEMA) ?>.com</p>
                                    <p class="text-xs <?= $temaAtual === 'dark' ? 'text-white/60' : 'text-gray-600' ?>">Resposta em até 24 horas</p>
                                </div>
                            </div>
                            <div class="flex items-center">
                                <i class="fas fa-phone text-green-400 mr-3"></i>
                                <div>
                                    <p class="text-sm <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?>">+55 (11) 99999-9999</p>
                                    <p class="text-xs <?= $temaAtual === 'dark' ? 'text-white/60' : 'text-gray-600' ?>">Segunda a sexta, 9h às 18h</p>
                                </div>
                            </div>
                            <div class="flex items-center">
                                <i class="fas fa-comments text-purple-400 mr-3"></i>
                                <div>
                                    <p class="text-sm <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?>">Chat Online</p>
                                    <p class="text-xs <?= $temaAtual === 'dark' ? 'text-white/60' : 'text-gray-600' ?>">Disponível 24/7 para urgências</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <p class="<?= $temaAtual === 'dark' ? 'text-white/60' : 'text-gray-600' ?> text-sm">
                        Para questões técnicas complexas, recomendamos o uso do email para que possamos fornecer uma resposta detalhada e documentada.
                    </p>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Privacidade -->
    <div id="modal-privacidade" class="modal-overlay" onclick="closeModal(event, 'privacidade')">
        <div class="modal-content" onclick="event.stopPropagation()">
            <div class="p-6">
                <div class="flex items-center justify-between mb-4">
                    <div class="flex items-center space-x-3">
                        <div class="w-10 h-10 rounded-lg bg-purple-500/20 flex items-center justify-center">
                            <i class="fas fa-shield-heart text-purple-400 text-lg"></i>
                        </div>
                        <h3 class="text-lg font-semibold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?>">Política de Privacidade</h3>
                    </div>
                    <button onclick="closeModal(event, 'privacidade')" class="<?= $temaAtual === 'dark' ? 'text-white/50 hover:text-white' : 'text-gray-500 hover:text-gray-700' ?> clickable">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div class="space-y-4">
                    <p class="<?= $temaAtual === 'dark' ? 'text-white/80' : 'text-gray-700' ?>">
                        Esta política de privacidade descreve como o <?= NOME_SISTEMA ?> coleta, usa e protege suas informações.
                    </p>
                    <div class="<?= $temaAtual === 'dark' ? 'bg-white/10' : 'bg-gray-100' ?> rounded-lg p-4">
                        <h4 class="font-medium <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?> mb-2 text-sm">Coleta de Dados:</h4>
                        <ul class="text-sm <?= $temaAtual === 'dark' ? 'text-white/70' : 'text-gray-700' ?> space-y-1">
                            <li class="flex items-start">
                                <i class="fas fa-check-circle text-purple-400 mt-0.5 mr-2 text-xs"></i>
                                <span>Coletamos apenas informações necessárias para autenticação</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check-circle text-purple-400 mt-0.5 mr-2 text-xs"></i>
                                <span>Dados são criptografados usando padrões de segurança avançados</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check-circle text-purple-400 mt-0.5 mr-2 text-xs"></i>
                                <span>Não compartilhamos dados com terceiros sem consentimento</span>
                            </li>
                        </ul>
                    </div>
                    <div class="<?= $temaAtual === 'dark' ? 'bg-white/10' : 'bg-gray-100' ?> rounded-lg p-4">
                        <h4 class="font-medium <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?> mb-2 text-sm">Seus Direitos:</h4>
                        <ul class="text-sm <?= $temaAtual === 'dark' ? 'text-white/70' : 'text-gray-700' ?> space-y-1">
                            <li class="flex items-start">
                                <i class="fas fa-check-circle text-purple-400 mt-0.5 mr-2 text-xs"></i>
                                <span>Direito de acessar seus dados pessoais</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check-circle text-purple-400 mt-0.5 mr-2 text-xs"></i>
                                <span>Direito de corrigir informações incorretas</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check-circle text-purple-400 mt-0.5 mr-2 text-xs"></i>
                                <span>Direito de solicitar exclusão de dados</span>
                            </li>
                        </ul>
                    </div>
                    <p class="<?= $temaAtual === 'dark' ? 'text-white/60' : 'text-gray-600' ?> text-sm">
                        Última atualização: <?= date('d/m/Y') ?>
                    </p>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Termos -->
    <div id="modal-termos" class="modal-overlay" onclick="closeModal(event, 'termos')">
        <div class="modal-content" onclick="event.stopPropagation()">
            <div class="p-6">
                <div class="flex items-center justify-between mb-4">
                    <div class="flex items-center space-x-3">
                        <div class="w-10 h-10 rounded-lg bg-red-500/20 flex items-center justify-center">
                            <i class="fas fa-file-contract text-red-400 text-lg"></i>
                        </div>
                        <h3 class="text-lg font-semibold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?>">Termos de Uso</h3>
                    </div>
                    <button onclick="closeModal(event, 'termos')" class="<?= $temaAtual === 'dark' ? 'text-white/50 hover:text-white' : 'text-gray-500 hover:text-gray-700' ?> clickable">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div class="space-y-4">
                    <p class="<?= $temaAtual === 'dark' ? 'text-white/80' : 'text-gray-700' ?>">
                        Ao utilizar o sistema <?= NOME_SISTEMA ?>, você concorda com os seguintes termos e condições:
                    </p>
                    <div class="<?= $temaAtual === 'dark' ? 'bg-white/10' : 'bg-gray-100' ?> rounded-lg p-4">
                        <h4 class="font-medium <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?> mb-2 text-sm">Responsabilidades do Usuário:</h4>
                        <ul class="text-sm <?= $temaAtual === 'dark' ? 'text-white/70' : 'text-gray-700' ?> space-y-1">
                            <li class="flex items-start">
                                <i class="fas fa-check-circle text-red-400 mt-0.5 mr-2 text-xs"></i>
                                <span>Manter a confidencialidade de suas credenciais</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check-circle text-red-400 mt-0.5 mr-2 text-xs"></i>
                                <span>Não utilizar o sistema para atividades ilegais</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check-circle text-red-400 mt-0.5 mr-2 text-xs"></i>
                                <span>Reportar quaisquer vulnerabilidades encontradas</span>
                            </li>
                        </ul>
                    </div>
                    <div class="<?= $temaAtual === 'dark' ? 'bg-white/10' : 'bg-gray-100' ?> rounded-lg p-4">
                        <h4 class="font-medium <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?> mb-2 text-sm">Uso Aceitável:</h4>
                        <ul class="text-sm <?= $temaAtual === 'dark' ? 'text-white/70' : 'text-gray-700' ?> space-y-1">
                            <li class="flex items-start">
                                <i class="fas fa-check-circle text-red-400 mt-0.5 mr-2 text-xs"></i>
                                <span>Autenticação de usuários autorizados</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check-circle text-red-400 mt-0.5 mr-2 text-xs"></i>
                                <span>Auditoria de eventos de segurança</span>
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check-circle text-red-400 mt-0.5 mr-2 text-xs"></i>
                                <span>Geração de relatórios de atividades</span>
                            </li>
                        </ul>
                    </div>
                    <p class="<?= $temaAtual === 'dark' ? 'text-white/60' : 'text-gray-600' ?> text-sm">
                        O não cumprimento destes termos pode resultar na suspensão ou encerramento do acesso ao sistema.
                    </p>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Configurações principais
        const temaAtual = "<?= $temaAtual ?>";
        let sidebarCollapsed = localStorage.getItem('sidebarCollapsed') === 'true';
        
        // Elementos DOM
        const sidebar = document.getElementById('sidebar');
        const mainContent = document.getElementById('main-content');
        const toggleBtn = document.getElementById('toggle-sidebar');
        const toggleMobileBtn = document.getElementById('toggle-sidebar-mobile');
        const sidebarOverlay = document.getElementById('sidebar-overlay');
        const loadingSpinner = document.getElementById('loading-spinner');
        const pageTitle = document.getElementById('page-title');
        const conteudoDinamico = document.getElementById('conteudo-dinamico');
        
        // Mapeamento de páginas
        const mapeamentoPaginas = {
            'dashboard': 'dashboard.php',
            'eventos': 'eventos.php',
            'mfa': 'mfa.php',
            'usuarios': 'usuarios.php',
            'auditoria': 'auditoria.php',
            'relatorios': 'relatorios.php',
            'configuracoes': 'configuracoes.php',
            'perfil': 'meuperfil.php',
            'seguranca': 'seguranca.php',
            'notificacoes': 'notificacoes.php'
        };
        
        // Inicializar sidebar state
        function inicializarSidebar() {
            if (sidebarCollapsed) {
                sidebar.classList.add('sidebar-collapsed');
                mainContent.classList.add('main-content-expanded');
                toggleBtn.innerHTML = '<i class="fas fa-chevron-right"></i>';
                toggleBtn.querySelector('i').style.transform = 'rotate(180deg)';
            }
        }
        
        // Alternar sidebar
        function toggleSidebar() {
            sidebarCollapsed = !sidebarCollapsed;
            if (sidebarCollapsed) {
                sidebar.classList.add('sidebar-collapsed');
                mainContent.classList.add('main-content-expanded');
                toggleBtn.innerHTML = '<i class="fas fa-chevron-right"></i>';
                toggleBtn.querySelector('i').style.transform = 'rotate(180deg)';
            } else {
                sidebar.classList.remove('sidebar-collapsed');
                mainContent.classList.remove('main-content-expanded');
                toggleBtn.innerHTML = '<i class="fas fa-chevron-left"></i>';
                toggleBtn.querySelector('i').style.transform = 'rotate(0deg)';
            }
            localStorage.setItem('sidebarCollapsed', sidebarCollapsed);
        }
        
        // Alternar sidebar mobile
        function toggleMobileSidebar() {
            sidebar.classList.toggle('sidebar-mobile-open');
            sidebarOverlay.classList.toggle('hidden');
            document.body.classList.toggle('overflow-hidden');
        }
        
        // Alternar tema
        async function alternarTema() {
            const novoTema = temaAtual === 'dark' ? 'light' : 'dark';
            
            try {
                const response = await fetch('', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                        'X-Requested-With': 'XMLHttpRequest'
                    },
                    body: `tema=${novoTema}`
                });
                
                if (response.ok) {
                    location.reload();
                }
            } catch (error) {
                console.error('Erro ao alternar tema:', error);
                document.documentElement.classList.toggle('dark');
                location.reload();
            }
        }
        
        // Inicializar partículas
        function inicializarParticulas() {
            if (typeof particlesJS !== 'undefined') {
                particlesJS('particles-container', {
                    particles: {
                        number: {
                            value: temaAtual === 'dark' ? 80 : 50,
                            density: { enable: true, value_area: 800 }
                        },
                        color: { value: temaAtual === 'dark' ? '#007fff' : '#4a90e2' },
                        shape: { type: 'circle' },
                        opacity: {
                            value: temaAtual === 'dark' ? 0.3 : 0.2,
                            random: true,
                            anim: { enable: true, speed: 1, opacity_min: 0.1 }
                        },
                        size: {
                            value: 3,
                            random: true,
                            anim: { enable: true, speed: 2, size_min: 0.1 }
                        },
                        line_linked: {
                            enable: true,
                            distance: temaAtual === 'dark' ? 150 : 100,
                            color: temaAtual === 'dark' ? '#007fff' : '#4a90e2',
                            opacity: temaAtual === 'dark' ? 0.1 : 0.05,
                            width: 1
                        },
                        move: {
                            enable: true,
                            speed: 1,
                            direction: 'none',
                            random: true,
                            out_mode: 'out'
                        }
                    },
                    interactivity: {
                        events: {
                            onhover: { enable: true, mode: 'repulse' },
                            onclick: { enable: true, mode: 'push' }
                        }
                    },
                    retina_detect: true
                });
            }
        }
        
        // Carregar página
        async function carregarPagina(pagina) {
            try {
                loadingSpinner.classList.remove('hidden');
                
                // Atualizar URL
                const novaUrl = new URL(window.location);
                novaUrl.searchParams.set('pagina', pagina);
                window.history.pushState({ pagina }, '', novaUrl);
                
                // Atualizar título
                pageTitle.textContent = pagina === 'dashboard' ? 'Dashboard' : 
                                      pagina.charAt(0).toUpperCase() + pagina.slice(1);
                
                // Atualizar menu ativo
                document.querySelectorAll('.sidebar-link').forEach(link => {
                    link.classList.remove('active');
                });
                const linkAtivo = document.querySelector(`.sidebar-link[data-pagina="${pagina}"]`);
                if (linkAtivo) linkAtivo.classList.add('active');
                
                // Carregar conteúdo
                const arquivoPagina = mapeamentoPaginas[pagina] || 'dashboard.php';
                const response = await fetch(`conteudo/${arquivoPagina}?pagina=${pagina}`);
                
                if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
                
                const html = await response.text();
                
                // Animação de transição
                conteudoDinamico.style.opacity = '0';
                conteudoDinamico.style.transform = 'translateY(20px)';
                
                setTimeout(() => {
                    conteudoDinamico.innerHTML = html;
                    conteudoDinamico.style.transition = 'opacity 0.3s ease, transform 0.3s ease';
                    conteudoDinamico.style.opacity = '1';
                    conteudoDinamico.style.transform = 'translateY(0)';
                    
                    // Fechar sidebar mobile se aberta
                    if (window.innerWidth < 768) {
                        toggleMobileSidebar();
                    }
                    
                    // Inicializar componentes da página
                    setTimeout(() => {
                        conteudoDinamico.style.transition = '';
                        inicializarComponentesPagina(pagina);
                    }, 300);
                }, 150);
                
            } catch (error) {
                console.error('Erro ao carregar página:', error);
                mostrarToast('error', 'Erro', 'Não foi possível carregar o conteúdo solicitado.');
            } finally {
                setTimeout(() => {
                    loadingSpinner.classList.add('hidden');
                }, 300);
            }
        }
        
        // Buscar usuários
        async function searchUsers(query) {
            try {
                const response = await fetch(`ajax/search.php?q=${encodeURIComponent(query)}`);
                const data = await response.json();
                
                const searchResults = document.getElementById('search-results');
                
                if (data.success && (data.count_usuarios > 0 || data.count_eventos > 0)) {
                    let html = `
                        <div class="p-3 border-b <?= $temaAtual === 'dark' ? 'border-gray-700 bg-gray-900' : 'border-gray-200 bg-gray-50' ?>">
                            <h3 class="text-sm font-semibold <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?>">Resultados da Busca</h3>
                            <p class="text-xs <?= $temaAtual === 'dark' ? 'text-gray-400' : 'text-gray-500' ?>">${data.total_count} resultado(s) encontrado(s)</p>
                        </div>
                    `;
                    
                    if (data.results.usuarios.length > 0) {
                        html += `
                            <div class="px-3 pt-2">
                                <div class="text-xs font-medium <?= $temaAtual === 'dark' ? 'text-gray-400' : 'text-gray-500' ?> uppercase tracking-wider mb-1">
                                    <i class="fas fa-users mr-1"></i> Usuários
                                </div>
                        `;
                        
                        data.results.usuarios.forEach(user => {
                            html += `
                                <a href="#" onclick="carregarPagina('usuarios'); return false;" class="flex items-center px-2 py-2 <?= $temaAtual === 'dark' ? 'hover:bg-gray-700' : 'hover:bg-gray-50' ?> cursor-pointer transition-colors rounded-lg">
                                    <div class="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center mr-3">
                                        <span class="text-blue-600 font-bold text-sm">${user.nome_completo ? user.nome_completo.charAt(0).toUpperCase() : 'U'}</span>
                                    </div>
                                    <div class="flex-1 min-w-0">
                                        <p class="text-sm font-medium <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?> truncate">${user.nome_completo}</p>
                                        <p class="text-xs <?= $temaAtual === 'dark' ? 'text-gray-400' : 'text-gray-500' ?> truncate">${user.email}</p>
                                    </div>
                                    <span class="text-xs px-2 py-1 ${user.tipo_usuario === 'admin' ? 'bg-purple-100 text-purple-800' : user.tipo_usuario === 'auditor' ? 'bg-blue-100 text-blue-800' : 'bg-gray-100 text-gray-800'} rounded-full">
                                        ${user.tipo_usuario}
                                    </span>
                                </a>
                            `;
                        });
                        
                        html += `</div><div class="border-t <?= $temaAtual === 'dark' ? 'border-gray-700' : 'border-gray-200' ?> my-2"></div>`;
                    }
                    
                    if (data.results.eventos.length > 0) {
                        html += `
                            <div class="px-3">
                                <div class="text-xs font-medium <?= $temaAtual === 'dark' ? 'text-gray-400' : 'text-gray-500' ?> uppercase tracking-wider mb-1">
                                    <i class="fas fa-history mr-1"></i> Eventos
                                </div>
                        `;
                        
                        data.results.eventos.forEach(evento => {
                            const dataFormatada = new Date(evento.data_hora).toLocaleDateString('pt-BR');
                            const horaFormatada = new Date(evento.data_hora).toLocaleTimeString('pt-BR');
                            
                            let iconClass = 'fa-circle';
                            let iconColor = 'text-gray-500';
                            
                            if (evento.tipo_evento === 'LOGIN_SUCCESS') {
                                iconClass = 'fa-check-circle';
                                iconColor = 'text-green-600';
                            } else if (evento.tipo_evento.includes('LOGIN_FAILED')) {
                                iconClass = 'fa-times-circle';
                                iconColor = 'text-red-600';
                            } else if (evento.tipo_evento === 'MFA_CREATED') {
                                iconClass = 'fa-user-plus';
                                iconColor = 'text-blue-600';
                            } else if (evento.tipo_evento === 'LOGOUT') {
                                iconClass = 'fa-sign-out-alt';
                                iconColor = 'text-amber-600';
                            }
                            
                            html += `
                                <a href="#" onclick="carregarPagina('eventos'); return false;" class="flex items-center px-2 py-2 <?= $temaAtual === 'dark' ? 'hover:bg-gray-700' : 'hover:bg-gray-50' ?> cursor-pointer transition-colors rounded-lg">
                                    <div class="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center mr-3">
                                        <i class="fas ${iconClass} ${iconColor} text-sm"></i>
                                    </div>
                                    <div class="flex-1 min-w-0">
                                        <p class="text-sm font-medium <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?> truncate">${evento.tipo_evento_formatado || evento.tipo_evento}</p>
                                        <p class="text-xs <?= $temaAtual === 'dark' ? 'text-gray-400' : 'text-gray-500' ?> truncate">
                                            ${evento.nome_completo || 'Sistema'} • ${dataFormatada} ${horaFormatada}
                                        </p>
                                    </div>
                                    <div class="text-right">
                                        <span class="text-xs <?= $temaAtual === 'dark' ? 'text-gray-400' : 'text-gray-500' ?> block">${horaFormatada}</span>
                                        <span class="text-xs <?= $temaAtual === 'dark' ? 'text-gray-500' : 'text-gray-400' ?>">${evento.tipo_usuario || 'Sistema'}</span>
                                    </div>
                                </a>
                            `;
                        });
                        
                        html += `</div>`;
                    }
                    
                    if (data.total_count > 0) {
                        html += `
                            <div class="border-t <?= $temaAtual === 'dark' ? 'border-gray-700' : 'border-gray-200' ?> p-3 text-center <?= $temaAtual === 'dark' ? 'bg-gray-900' : 'bg-gray-50' ?> rounded-b-lg">
                                <a href="#" onclick="abrirBuscaAvancada('${query}'); return false;" 
                                   class="text-xs text-blue-500 hover:text-blue-600 font-medium clickable inline-flex items-center">
                                    <i class="fas fa-search-plus mr-1"></i> Ver todos os resultados para "${query}"
                                </a>
                            </div>
                        `;
                    }
                    
                    searchResults.innerHTML = html;
                    searchResults.classList.remove('hidden');
                } else {
                    searchResults.innerHTML = `
                        <div class="p-6 text-center">
                            <i class="fas fa-search <?= $temaAtual === 'dark' ? 'text-gray-500' : 'text-gray-400' ?> text-2xl mb-3"></i>
                            <p class="text-sm <?= $temaAtual === 'dark' ? 'text-gray-400' : 'text-gray-600' ?>">Nenhum resultado encontrado para "${query}"</p>
                            <p class="text-xs <?= $temaAtual === 'dark' ? 'text-gray-500' : 'text-gray-500' ?> mt-1">Tente buscar por nome de usuário, email ou tipo de evento</p>
                        </div>
                    `;
                    searchResults.classList.remove('hidden');
                }
            } catch (error) {
                console.error('Erro na busca:', error);
                searchResults.innerHTML = `
                    <div class="p-6 text-center">
                        <i class="fas fa-exclamation-triangle text-red-400 text-2xl mb-3"></i>
                        <p class="text-sm <?= $temaAtual === 'dark' ? 'text-gray-400' : 'text-gray-600' ?>">Erro ao buscar resultados</p>
                    </div>
                `;
                searchResults.classList.remove('hidden');
            }
        }
        
        // Carregar notificações
        async function carregarNotificacoes() {
            try {
                const response = await fetch('ajax/carregar_notificacoes.php');
                const data = await response.json();
                
                const dropdown = document.querySelector('#dropdown-notificacoes .notifications-dropdown');
                const contador = document.querySelector('#dropdown-notificacoes .text-sm');
                
                if (data.success && data.notificacoes.length > 0) {
                    let html = '';
                    data.notificacoes.forEach(notificacao => {
                        html += `
                            <div class="p-4 border-b <?= $temaAtual === 'dark' ? 'border-gray-700 hover:bg-gray-700' : 'border-gray-100 hover:bg-gray-50' ?> cursor-pointer transition-colors">
                                <div class="flex items-start">
                                    <div class="flex-shrink-0 w-8 h-8 rounded-full ${notificacao.tipo_evento === 'LOGIN_SUCCESS' ? 'bg-green-100' : notificacao.tipo_evento === 'MFA_CREATED' ? 'bg-blue-100' : 'bg-red-100'} flex items-center justify-center">
                                        <i class="fas ${notificacao.tipo_evento === 'LOGIN_SUCCESS' ? 'fa-check-circle text-green-600' : notificacao.tipo_evento === 'MFA_CREATED' ? 'fa-user-plus text-blue-600' : 'fa-exclamation-triangle text-red-600'} text-sm"></i>
                                    </div>
                                    <div class="ml-3 flex-1">
                                        <p class="text-sm font-medium <?= $temaAtual === 'dark' ? 'text-white' : 'text-gray-900' ?>">
                                            ${notificacao.tipo_evento_formatado || notificacao.tipo_evento}
                                        </p>
                                        <p class="text-xs <?= $temaAtual === 'dark' ? 'text-gray-400' : 'text-gray-500' ?>">
                                            ${notificacao.nome_completo || 'Usuário desconhecido'} • ${new Date(notificacao.data_hora).toLocaleTimeString('pt-BR')}
                                        </p>
                                    </div>
                                </div>
                            </div>
                        `;
                    });
                    
                    dropdown.innerHTML = html;
                    contador.textContent = `${data.notificacoes.length} notificações recentes`;
                } else {
                    dropdown.innerHTML = `
                        <div class="p-6 text-center">
                            <i class="fas fa-bell-slash <?= $temaAtual === 'dark' ? 'text-gray-500' : 'text-gray-300' ?> text-2xl mb-3"></i>
                            <p class="text-sm <?= $temaAtual === 'dark' ? 'text-gray-400' : 'text-gray-500' ?>">Nenhuma notificação</p>
                        </div>
                    `;
                    contador.textContent = '0 notificações';
                }
            } catch (error) {
                console.error('Erro ao carregar notificações:', error);
            }
        }
        
        // Mostrar toast
        function mostrarToast(tipo, titulo, mensagem) {
            const toastContainer = document.createElement('div');
            toastContainer.className = `toast-notification ${tipo}`;
            
            toastContainer.innerHTML = `
                <div class="p-4">
                    <div class="flex items-start">
                        <div class="flex-shrink-0 pt-0.5">
                            <i class="fas ${tipo === 'success' ? 'fa-check-circle' : tipo === 'error' ? 'fa-times-circle' : tipo === 'warning' ? 'fa-exclamation-triangle' : 'fa-info-circle'} text-xl"></i>
                        </div>
                        <div class="ml-3 flex-1">
                            <h4 class="font-semibold text-white">${titulo}</h4>
                            <p class="text-sm text-white/90 mt-1">${mensagem}</p>
                        </div>
                        <button onclick="this.parentElement.parentElement.remove()" class="ml-4 text-white/70 hover:text-white">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                </div>
                <div class="toast-progress"></div>
            `;
            
            document.body.appendChild(toastContainer);
            
            setTimeout(() => {
                if (toastContainer.parentElement) {
                    toastContainer.classList.add('hiding');
                    setTimeout(() => toastContainer.remove(), 500);
                }
            }, 5000);
        }
        
        // Abrir modal
        function openModal(modalId) {
            const modal = document.getElementById(`modal-${modalId}`);
            if (modal) {
                modal.classList.add('active');
                document.body.style.overflow = 'hidden';
            }
        }
        
        // Fechar modal
        function closeModal(event, modalId) {
            event.preventDefault();
            const modal = document.getElementById(`modal-${modalId}`);
            if (modal) {
                modal.classList.remove('active');
                document.body.style.overflow = 'auto';
            }
        }
        
        // Inicializar componentes da página
        function inicializarComponentesPagina(pagina) {
            console.log(`Inicializando: ${pagina}`);
            // Aqui você pode adicionar inicializações específicas por página
        }
        
        // Event Listeners
        document.addEventListener('DOMContentLoaded', function() {
            // Inicializar
            inicializarSidebar();
            inicializarParticulas();
            
            // Eventos do sidebar
            toggleBtn?.addEventListener('click', toggleSidebar);
            toggleMobileBtn?.addEventListener('click', toggleMobileSidebar);
            sidebarOverlay?.addEventListener('click', toggleMobileSidebar);
            
            // Eventos de navegação
            document.querySelectorAll('.sidebar-link[data-pagina]').forEach(link => {
                link.addEventListener('click', function(e) {
                    e.preventDefault();
                    carregarPagina(this.dataset.pagina);
                });
            });
            
            // Eventos do dropdown
            const btnPerfil = document.getElementById('btn-perfil');
            const dropdownPerfil = document.getElementById('dropdown-perfil');
            const btnNotificacoes = document.getElementById('btn-notificacoes');
            const dropdownNotificacoes = document.getElementById('dropdown-notificacoes');
            
            if (btnPerfil) {
                btnPerfil.addEventListener('click', (e) => {
                    e.stopPropagation();
                    dropdownPerfil.classList.toggle('hidden');
                    if (!dropdownNotificacoes.classList.contains('hidden')) {
                        dropdownNotificacoes.classList.add('hidden');
                    }
                });
            }
            
            if (btnNotificacoes) {
                btnNotificacoes.addEventListener('click', async (e) => {
                    e.stopPropagation();
                    dropdownNotificacoes.classList.toggle('hidden');
                    if (!dropdownPerfil.classList.contains('hidden')) {
                        dropdownPerfil.classList.add('hidden');
                    }
                    
                    if (!dropdownNotificacoes.classList.contains('hidden')) {
                        await carregarNotificacoes();
                    }
                });
            }
            
            // Fechar dropdowns ao clicar fora
            document.addEventListener('click', (e) => {
                if (!btnPerfil?.contains(e.target) && !dropdownPerfil?.contains(e.target)) {
                    dropdownPerfil?.classList.add('hidden');
                }
                if (!btnNotificacoes?.contains(e.target) && !dropdownNotificacoes?.contains(e.target)) {
                    dropdownNotificacoes?.classList.add('hidden');
                }
            });
            
            // Busca em tempo real
            const searchInput = document.getElementById('search-input');
            const searchResults = document.getElementById('search-results');
            let searchTimeout;
            
            if (searchInput) {
                searchInput.addEventListener('input', function() {
                    clearTimeout(searchTimeout);
                    
                    const query = this.value.trim();
                    if (query.length < 2) {
                        searchResults.classList.add('hidden');
                        searchResults.innerHTML = '';
                        return;
                    }
                    
                    searchTimeout = setTimeout(() => {
                        searchUsers(query);
                    }, 300);
                });
                
                document.addEventListener('click', function(e) {
                    if (!searchInput.contains(e.target) && !searchResults.contains(e.target)) {
                        searchResults.classList.add('hidden');
                    }
                });
            }
            
            // Fechar modais com ESC
            document.addEventListener('keydown', (e) => {
                if (e.key === 'Escape') {
                    document.querySelectorAll('.modal-overlay.active').forEach(modal => {
                        modal.classList.remove('active');
                    });
                    document.body.style.overflow = 'auto';
                }
            });
            
            // Mostrar mensagens flash
            const mensagens = <?= json_encode($mensagensFlash) ?>;
            mensagens.forEach(mensagem => {
                mostrarToast(mensagem.tipo, mensagem.titulo, mensagem.mensagem);
            });
            
            // History API
            window.addEventListener('popstate', function(event) {
                if (event.state?.pagina) {
                    carregarPagina(event.state.pagina);
                }
            });
        });
    </script>
</body>
</html>